#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail() { printf 'BLOCKED: %s\n' "$1" >&2; exit 2; }
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
[[ -n "$SDK" && -d "$SDK/platforms/android-36" ]] || fail 'Install Android SDK Platform 36 and set ANDROID_HOME or ANDROID_SDK_ROOT.'
[[ -d "$SDK/build-tools/36.0.0" ]] || fail 'Install Android Build Tools 36.0.0.'
[[ -n "${JAVA_HOME:-}" && -x "$JAVA_HOME/bin/java" ]] || fail 'Set JAVA_HOME to JDK 17 or 21.'
JAVA_VERSION="$("$JAVA_HOME/bin/java" -version 2>&1 | head -n 1)"
[[ "$JAVA_VERSION" == *'17.'* || "$JAVA_VERSION" == *'21.'* ]] || fail "JDK 17 or 21 required; found: $JAVA_VERSION"
for key in MUNGIL_STORE_FILE MUNGIL_STORE_PASSWORD MUNGIL_KEY_ALIAS MUNGIL_KEY_PASSWORD; do
  [[ -n "${!key:-}" ]] || fail "$key must be configured locally for a signed release. Do not commit these values."
done
[[ -f "$MUNGIL_STORE_FILE" ]] || fail 'MUNGIL_STORE_FILE does not point to an existing keystore.'
if [[ -x "$ROOT/gradlew" ]]; then GRADLE="$ROOT/gradlew"; elif command -v gradle >/dev/null 2>&1; then GRADLE="$(command -v gradle)"; else fail 'Install Gradle 9.6.0 or generate the official Gradle 9.6.0 wrapper.'; fi
cd "$ROOT"
"$GRADLE" --no-daemon --warning-mode fail clean lintRelease testReleaseUnitTest assembleRelease bundleRelease
APK="$ROOT/app/build/outputs/apk/release/app-release.apk"
AAB="$ROOT/app/build/outputs/bundle/release/app-release.aab"
[[ -s "$APK" ]] || fail 'Release APK was not produced.'
[[ -s "$AAB" ]] || fail 'Release AAB was not produced.'
"$SDK/build-tools/36.0.0/apksigner" verify --verbose --print-certs "$APK"
"$JAVA_HOME/bin/jarsigner" -verify "$AAB" >/dev/null || fail 'AAB signature verification failed.'
printf '\nBuild and signature checks completed. Install and test on Android 5, Android 13 Go, and target hardware before distribution.\n'
