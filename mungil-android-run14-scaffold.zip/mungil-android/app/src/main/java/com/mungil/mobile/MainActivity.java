package com.mungil.mobile;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.TextView;

import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

public final class MainActivity extends Activity {
    private static final String LOCAL_ENTRY = "https://appassets.androidplatform.net/assets/index.html";
    private static final int BACKGROUND = Color.rgb(13, 16, 23);
    private WebView webView;
    private WebViewAssetLoader assetLoader;

    @SuppressWarnings("deprecation")
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(16, 19, 27));
        getWindow().setNavigationBarColor(BACKGROUND);
        assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        createWebView();
        if (savedInstanceState == null) webView.loadUrl(LOCAL_ENTRY);
        else if (!webView.restoreState(savedInstanceState)) webView.loadUrl(LOCAL_ENTRY);
    }

    @SuppressWarnings("deprecation")
    private void createWebView() {
        webView = new WebView(this);
        webView.setFitsSystemWindows(true);
        webView.setBackgroundColor(BACKGROUND);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.setWebViewClient(new WebViewClientCompat() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return routeNavigation(request.getUrl());
            }

            @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                if (view != webView) return true;
                destroyWebView(view);
                showRendererRecovery();
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
    }

    private void showRendererRecovery() {
        TextView recovery = new TextView(this);
        recovery.setText("MUNGIL Studio berhenti sementara karena proses WebView ditutup sistem.\n\nKetuk untuk memuat ulang Studio.");
        recovery.setTextColor(Color.rgb(237, 242, 250));
        recovery.setBackgroundColor(BACKGROUND);
        recovery.setGravity(Gravity.CENTER);
        recovery.setPadding(32, 32, 32, 32);
        recovery.setOnClickListener(view -> restartWebRuntime());
        setContentView(recovery);
    }

    private void restartWebRuntime() {
        if (webView != null) destroyWebView(webView);
        createWebView();
        webView.loadUrl(LOCAL_ENTRY);
    }

    private void destroyWebView(WebView target) {
        if (target == null) return;
        target.stopLoading();
        target.setWebChromeClient(null);
        target.setWebViewClient(null);
        ViewGroup parent = (target.getParent() instanceof ViewGroup) ? (ViewGroup) target.getParent() : null;
        if (parent != null) parent.removeView(target);
        target.removeAllViews();
        target.destroy();
        if (target == webView) webView = null;
    }

    private boolean routeNavigation(Uri uri) {
        if (uri == null) return true;
        String scheme = uri.getScheme();
        if ("https".equalsIgnoreCase(scheme)
            && "appassets.androidplatform.net".equalsIgnoreCase(uri.getHost())
            && uri.getPath() != null
            && uri.getPath().startsWith("/assets/")) return false;
        if ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
            catch (RuntimeException ignored) { /* Fail closed. */ }
        }
        return true;
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override protected void onPause() {
        if (webView != null) {
            webView.onPause();
            webView.pauseTimers();
        }
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
            webView.resumeTimers();
        }
    }

    @Override protected void onDestroy() {
        if (webView != null) destroyWebView(webView);
        super.onDestroy();
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView != null && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
