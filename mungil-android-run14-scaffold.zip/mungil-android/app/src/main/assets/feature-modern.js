/* Syntax gate: a parse failure on older WebView triggers the script error fallback. */
(function () {
  var probe = { a: { b: 1 } };
  if (probe?.a?.b === 1) window.__mungilModernSyntax = true;
}());
