# MUNGIL Studio Android shell — Run 14

## Build configuration
- Application ID: `com.mungil.mobile`
- Version: `1.4.0-dev.14` / versionCode `14` (development source; not a published release)
- Minimum Android SDK: API 21 (Android 5.0)
- Compile / target SDK: API 36 (Android 16 stable; API 37 is Android 17 preview)
- Android Gradle Plugin: 9.5.0; Gradle: 9.6.0; JDK: 17 or 21 (verified compatibility pairing from the current Android release notes)
- AndroidX WebKit: `androidx.webkit:webkit:1.14.0` (selected to preserve API 21; 1.15 raises minSdk to 23 and 1.16 to 24)

## Local content and security
- `WebViewAssetLoader` serves packaged app assets at `https://appassets.androidplatform.net/assets/`.
- `setAllowFileAccess(false)` and `setAllowContentAccess(false)` are used; no JavaScript bridge is exposed.
- External HTTP(S) links are handed to the system browser. Mixed content is blocked. Renderer-process termination removes the dead WebView and shows a reload action; background/foreground transitions pause and resume WebView timers.
- The launcher loads `feature-modern.js` as a syntax gate. Compatible WebViews load `studio.html`; older WebViews fall back to `legacy.html`, a small Canvas2D planner.

## Runtime compatibility
- `minSdk 21` means install API floor only. It does not guarantee modern JavaScript or WebGL2 support on every Android 5 WebView.
- Legacy mode is an offline Canvas2D planner/preview. It does not run perspective 3D, external AI, remote asset generation, or native platform exports.
- Modern Studio includes a local prompt planner, 2D/2.5D preview, scene hierarchy/inspector/history, bounded local knowledge, controller mapping, bounded sprite-atlas/animation/particle/audio runtime APIs, local asset intake and a constrained offline HTML5 platformer prototype export. It is not connected to an external AI provider/backend.
- Scene edits update a renderer-neutral document. Run 14 adds single-selected-image Sprite binding through the local Asset Vault and unified WebGL2 textured-sprite/primitive batching, plus a bounded Canvas2D fallback. The renderer batches compatible texture runs but the current Studio binds one selected image at a time. Full transform gizmos, multi-sprite scene timeline, and perspective 3D viewport remain future work.
- WebGL2 is a primitive and textured-sprite 2D/2.5D batch renderer, not a general perspective 3D renderer. The HTML5 export is a limited offline 2D platformer proof-of-concept; it does not package arbitrary Vault assets or every genre.

## Release build prerequisites
1. Install Android SDK Platform 36 and Build Tools 36.0.0.
2. Install JDK 17 or 21 and Gradle 9.6.0, or generate the official Gradle wrapper for 9.6.0.
3. Set `ANDROID_HOME` (or `ANDROID_SDK_ROOT`) and `JAVA_HOME`.
4. Configure a release keystore locally using `MUNGIL_STORE_FILE`, `MUNGIL_STORE_PASSWORD`, `MUNGIL_KEY_ALIAS`, and `MUNGIL_KEY_PASSWORD`. Never commit these values.
5. Run `./build-android-release.sh`.

The scaffold uses AGP 9.5.0 with Gradle 9.6.0. WebKit 1.14.0 is intentionally pinned because the newer stable WebKit releases no longer preserve the API 21 floor. The script fails on Gradle warnings and verifies APK/AAB signatures. Run 14 does not include a signed APK/AAB: Android SDK Platform 36, Build Tools 36.0.0, and a complete Gradle release toolchain are not available in the build environment. Physical testing on Android 5 and itel A70 is still required.
