/* MUNGIL editor extension primitives. Supports current flat Hierarchy entity records and nested adapters. */
'use strict';
const PHYSICS_PRESETS = Object.freeze({
  BOUNCY: Object.freeze({ mass: 1, gravityScale: 1, restitution: 0.92, friction: 0.18, linearDamping: 0.02, angularDamping: 0.04, isSensor: false }),
  HEAVY: Object.freeze({ mass: 8, gravityScale: 1.25, restitution: 0.04, friction: 0.86, linearDamping: 0.12, angularDamping: 0.2, isSensor: false }),
  GHOST: Object.freeze({ mass: 1, gravityScale: 0, restitution: 0, friction: 0, linearDamping: 0, angularDamping: 0, isSensor: true }),
  SLIPPERY: Object.freeze({ mass: 1, gravityScale: 1, restitution: 0.05, friction: 0.015, linearDamping: 0.005, angularDamping: 0.02, isSensor: false })
});
const MAX_ENTITIES = 128;
const finite = (v, fallback = 0) => Number.isFinite(v) ? v : fallback;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
function readTransform(entity) {
  if (!entity) return null;
  if (entity.transform && typeof entity.transform === 'object') {
    const t=entity.transform;
    return {x:finite(t.x),y:finite(t.y),rotation:finite(t.rotation),scaleX:clamp(finite(t.scaleX,1),.01,100),scaleY:clamp(finite(t.scaleY,1),.01,100)};
  }
  return {x:finite(entity.x),y:finite(entity.y),rotation:finite(entity.rot),scaleX:clamp(finite(entity.scale,100)/100,.01,100),scaleY:clamp(finite(entity.scale,100)/100,.01,100)};
}
function writeTransform(entity, t) {
  if (entity.transform && typeof entity.transform === 'object') Object.assign(entity.transform,t);
  else { entity.x=t.x; entity.y=t.y; entity.rot=t.rotation; entity.scale=clamp((t.scaleX+t.scaleY)*50,1,10000); }
}
function applyPhysicsPreset(entity, presetName) {
  if (!entity || typeof entity !== 'object') return {ok:false,error:'ENTITY_MISSING'};
  const preset=PHYSICS_PRESETS[String(presetName||'').toUpperCase()]; if(!preset)return {ok:false,error:'UNKNOWN_PRESET'};
  // Existing MUNGIL physics body records use flat fields and percentage friction/restitution.
  if (!entity.physics || typeof entity.physics !== 'object') {
    entity.mass=preset.mass; entity.gravityScale=preset.gravityScale;
    entity.restitution=preset.restitution*100; entity.friction=preset.friction*100;
    entity.linearDamping=preset.linearDamping; entity.angularDamping=preset.angularDamping;
    entity.isSensor=preset.isSensor; entity.physicsPreset=String(presetName).toUpperCase();
  } else { Object.assign(entity.physics,preset); entity.physics.preset=String(presetName).toUpperCase(); }
  return {ok:true,preset:String(presetName).toUpperCase()};
}
function normalizeEntity(entity) {
  if(!entity||typeof entity.id!=='string'||!entity.id)throw new TypeError('Entity requires a stable string id');
  entity.parentId??=null; entity.children ||= [];
  if(!entity.transform && !Number.isFinite(entity.x)) {entity.x=0;entity.y=0;entity.rot=0;entity.scale=100;}
  if(entity.transform){const t=readTransform(entity);writeTransform(entity,t)}
  return entity;
}
function groupEntities(entities,selectedIds,containerId,name='Container') {
  if(!Array.isArray(entities)||!Array.isArray(selectedIds)||selectedIds.length<2)return{ok:false,error:'SELECT_AT_LEAST_TWO'};
  if(entities.length>=MAX_ENTITIES)return{ok:false,error:'ENTITY_CAP_REACHED'};
  if(entities.some(e=>e&&e.id===containerId))return{ok:false,error:'DUPLICATE_CONTAINER_ID'};
  const selected=entities.filter(e=>e&&selectedIds.includes(e.id));
  if(selected.length!==new Set(selectedIds).size||selected.length!==selectedIds.length)return{ok:false,error:'INVALID_SELECTION'};
  if(selected.some(e=>e.parentId))return{ok:false,error:'NESTED_GROUPING_NOT_SUPPORTED_IN_V1'};
  const ts=selected.map(readTransform);if(ts.some(t=>!t))return{ok:false,error:'INVALID_TRANSFORM'};
  const cx=ts.reduce((s,t)=>s+t.x,0)/ts.length,cy=ts.reduce((s,t)=>s+t.y,0)/ts.length;
  const container=normalizeEntity({id:containerId,name,type:'Container',emoji:'📦',parentId:null,visible:true,locked:false,x:cx,y:cy,rot:0,scale:100,depth:0,opacity:100,comps:['Transform'],children:selected.map(e=>e.id)});
  selected.forEach((e,i)=>{normalizeEntity(e);const t=ts[i];e.parentId=containerId;writeTransform(e,{...t,x:t.x-cx,y:t.y-cy});});
  entities.push(container);return{ok:true,container,grouped:selected.length};
}
function worldTransform(entity,byId,depth=0) {
  if(!entity||depth>16)return null;const t=readTransform(entity);if(!t)return null;
  if(!entity.parentId)return t;const parent=byId.get(entity.parentId),p=worldTransform(parent,byId,depth+1);if(!p)return null;
  const c=Math.cos(p.rotation),s=Math.sin(p.rotation),lx=t.x*p.scaleX,ly=t.y*p.scaleY;
  return{x:p.x+lx*c-ly*s,y:p.y+lx*s+ly*c,rotation:p.rotation+t.rotation,scaleX:p.scaleX*t.scaleX,scaleY:p.scaleY*t.scaleY};
}
function setContainerTransform(entities,containerId,patch) {
  const container=entities.find(e=>e&&e.id===containerId&&e.type==='Container');if(!container)return{ok:false,error:'CONTAINER_NOT_FOUND'};
  const t=readTransform(container);if(patch.x!==undefined)t.x=finite(patch.x,t.x);if(patch.y!==undefined)t.y=finite(patch.y,t.y);
  if(patch.rotation!==undefined)t.rotation=finite(patch.rotation,t.rotation);
  if(container.transform && typeof container.transform==='object') { if(patch.scaleX!==undefined)t.scaleX=clamp(finite(patch.scaleX,t.scaleX),.01,100);if(patch.scaleY!==undefined)t.scaleY=clamp(finite(patch.scaleY,t.scaleY),.01,100); }
  else if(patch.scaleX!==undefined || patch.scaleY!==undefined) { const sx=patch.scaleX===undefined?patch.scaleY:patch.scaleX,sy=patch.scaleY===undefined?patch.scaleX:patch.scaleY;if(Math.abs(sx-sy)>1e-8)return{ok:false,error:'NON_UNIFORM_SCALE_UNSUPPORTED_BY_MUNGIL_ENTITY_SCHEMA'};t.scaleX=t.scaleY=clamp(finite(sx,t.scaleX),.01,100); }
  writeTransform(container,t);return{ok:true,container};
}
function setCollisionShape(entity,shape) {
  if(!entity||typeof entity!=='object')return{ok:false,error:'ENTITY_MISSING'};if(!shape||!['AABB','CIRCLE'].includes(shape.type))return{ok:false,error:'INVALID_SHAPE_TYPE'};
  if(shape.type==='AABB'){const width=finite(shape.width,-1),height=finite(shape.height,-1);if(width<=0||height<=0||width>10000||height>10000)return{ok:false,error:'INVALID_AABB_SIZE'};entity.collision={type:'AABB',offsetX:finite(shape.offsetX),offsetY:finite(shape.offsetY),width,height};}
  else{const radius=finite(shape.radius,-1);if(radius<=0||radius>5000)return{ok:false,error:'INVALID_CIRCLE_RADIUS'};entity.collision={type:'CIRCLE',offsetX:finite(shape.offsetX),offsetY:finite(shape.offsetY),radius};}
  return{ok:true,collision:entity.collision};
}
function collisionOverlap(a,b) {
  if(!a||!b||!a.collision||!b.collision)return false;const ta=readTransform(a),tb=readTransform(b);if(!ta||!tb)return false;
  const A=a.collision,B=b.collision;if(!['AABB','CIRCLE'].includes(A.type)||!['AABB','CIRCLE'].includes(B.type))return false;
  const ax=ta.x+finite(A.offsetX),ay=ta.y+finite(A.offsetY),bx=tb.x+finite(B.offsetX),by=tb.y+finite(B.offsetY);
  if(A.type==='CIRCLE'&&B.type==='CIRCLE'){const r=A.radius+B.radius,dx=ax-bx,dy=ay-by;return dx*dx+dy*dy<=r*r;}
  if(A.type==='CIRCLE'||B.type==='CIRCLE'){const circle=A.type==='CIRCLE'?{x:ax,y:ay,r:A.radius}:{x:bx,y:by,r:B.radius};const rect=A.type==='AABB'?{x:ax,y:ay,w:A.width,h:A.height}:{x:bx,y:by,w:B.width,h:B.height};const nx=clamp(circle.x,rect.x-rect.w/2,rect.x+rect.w/2),ny=clamp(circle.y,rect.y-rect.h/2,rect.y+rect.h/2),dx=circle.x-nx,dy=circle.y-ny;return dx*dx+dy*dy<=circle.r*circle.r;}
  return Math.abs(ax-bx)*2<=A.width+B.width&&Math.abs(ay-by)*2<=A.height+B.height;
}
module.exports={PHYSICS_PRESETS,MAX_ENTITIES,readTransform,writeTransform,applyPhysicsPreset,groupEntities,worldTransform,setContainerTransform,setCollisionShape,collisionOverlap};
