'use strict';
/* Event-driven canvas overlay adapter; host supplies existing selection/store and commit callback. */
const { setCollisionShape, collisionOverlap, readTransform } = require('./editor-extensions');
function attachCollisionEditor(canvas, getSelection, getEntities, commit, options = {}) {
  if (!canvas || typeof canvas.addEventListener !== 'function' || typeof getSelection !== 'function' || typeof getEntities !== 'function' || typeof commit !== 'function') return { ok:false, error:'INVALID_HOST_ADAPTER' };
  const ctx = canvas.getContext && canvas.getContext('2d'); if (!ctx) return { ok:false, error:'CANVAS_CONTEXT_UNAVAILABLE' };
  const state = { enabled:false, drag:null, destroyed:false, scaleX:1, scaleY:1 };
  const handleSize = Math.max(6, Math.min(14, Number(options.handleSize)||10));
  function selected(){ const id=getSelection(); return getEntities().find(e=>e && e.id===id)||null; }
  function point(e){ const r=canvas.getBoundingClientRect(); return {x:(e.clientX-r.left)*(canvas.width/r.width),y:(e.clientY-r.top)*(canvas.height/r.height)}; }
  function geometry(entity){ const c=entity&&entity.collision,t=readTransform(entity);if(!c||!t)return null;const x=t.x+(c.offsetX||0),y=t.y+(c.offsetY||0);return c.type==='CIRCLE'?{type:'CIRCLE',x,y,r:c.radius}:{type:'AABB',x,y,w:c.width,h:c.height}; }
  function draw(){ if(state.destroyed||!state.enabled)return;ctx.clearRect(0,0,canvas.width,canvas.height);const e=selected(),g=geometry(e);if(!g)return;ctx.save();ctx.lineWidth=2;ctx.strokeStyle='#55d6a5';ctx.fillStyle='rgba(85,214,165,.12)';if(g.type==='CIRCLE'){ctx.beginPath();ctx.arc(g.x,g.y,g.r,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.fillRect(g.x+g.r-handleSize/2,g.y-handleSize/2,handleSize,handleSize)}else{ctx.fillRect(g.x-g.w/2,g.y-g.h/2,g.w,g.h);ctx.strokeRect(g.x-g.w/2,g.y-g.h/2,g.w,g.h);ctx.fillStyle='#55d6a5';ctx.fillRect(g.x+g.w/2-handleSize/2,g.y+g.h/2-handleSize/2,handleSize,handleSize)}const overlaps=getEntities().some(other=>other&&other.id!==e.id&&collisionOverlap(e,other));ctx.fillStyle=overlaps?'#ff6b78':'#55d6a5';ctx.font='12px system-ui';ctx.fillText(overlaps?'OVERLAP':'CLEAR',g.x+8,g.y-8);ctx.restore(); }
  function down(e){if(!state.enabled)return;const ent=selected(),g=geometry(ent);if(!g)return;const p=point(e);if(g.type==='CIRCLE'){const d=Math.hypot(p.x-g.x,p.y-g.y);if(Math.abs(d-g.r)<=handleSize*2)state.drag={id:ent.id,kind:'radius',start:g.r};}else if(Math.abs(p.x-(g.x+g.w/2))<=handleSize*2&&Math.abs(p.y-(g.y+g.h/2))<=handleSize*2)state.drag={id:ent.id,kind:'box',startW:g.w,startH:g.h};if(state.drag)canvas.setPointerCapture?.(e.pointerId); }
  function move(e){if(!state.enabled||!state.drag)return;const ent=getEntities().find(v=>v&&v.id===state.drag.id);if(!ent)return;const p=point(e),t=readTransform(ent)||{x:0,y:0},dx=Math.max(4,Math.abs(p.x-t.x)*2),dy=Math.max(4,Math.abs(p.y-t.y)*2);let shape;if(state.drag.kind==='radius')shape={type:'CIRCLE',radius:Math.max(2,Math.hypot(p.x-t.x,p.y-t.y))};else shape={type:'AABB',width:dx,height:dy};const result=setCollisionShape(ent,shape);if(result.ok){commit(ent);draw();}}
  function up(){state.drag=null;}
  function enabled(v){state.enabled=!!v;draw();}
  function destroy(){state.destroyed=true;canvas.removeEventListener('pointerdown',down);canvas.removeEventListener('pointermove',move);canvas.removeEventListener('pointerup',up);canvas.removeEventListener('pointercancel',up);}
  canvas.addEventListener('pointerdown',down);canvas.addEventListener('pointermove',move);canvas.addEventListener('pointerup',up);canvas.addEventListener('pointercancel',up);
  return {ok:true,enabled,destroy,draw};
}
module.exports={attachCollisionEditor};
