# Patch Notes — Optional MUNGIL Prototypes

These additions are original helper code, not copied from GitHub repositories, and are **not integrated into the original HTML**.


## Projection adapter

`patches/projection-math.js` exports four functions:

- `projectFake3D(point, camera, out)`
- `projectIsometric(point, config, out)`
- `unprojectIsometric(screen, config, height, out)`
- `compareDepth(a, b)`

Functions write to the caller-supplied output object and avoid temporary arrays in validation. Fake3D projection rejects points at or behind the near clip. Isometric unprojection requires a known vertical height. Depth comparison is deterministic for equal keys.

## Frame-pacing probe

`patches/frame-pacing-probe.js` exports `FramePacingProbe`. `push(timestampMs)` is intended to be called with monotonic frame timestamps, such as `performance.now()`. It stores a fixed-capacity interval ring and only sorts/allocates when `snapshot()` is requested. It does not schedule frames or adjust engine quality.

## Integration guard

Do not add either helper to the bundled HTML until an authoritative source/build entrypoint is identified and browser regression tests are available. The current project has many existing render, physics, AI, editor and quality features; a second manager or camera/renderer would risk duplicated responsibilities.
