# Source Inspection: Javascript Racer

Repository: https://github.com/jakesgordon/javascript-racer
License: MIT for repository code. Asset restrictions are separate and documented below.


## What was inspected

- `common.js`, GitHub web viewer at `master`, approximately 17.2 KB displayed; exact commit SHA not pinned.
- `v4.final.html`, GitHub web viewer, approximately 30.9 KB displayed; README/source metadata.
- Source tree via GitHub web viewer. Full cloning is blocked by DNS.

## Projection pattern

The `Util.project` helper computes camera-relative x/y/z and applies `cameraDepth / cameraZ`, then calculates projected screen x, screen y, and road width. The pattern is appropriate for classic segment-based fake-3D road scenes, but must guard near-zero/behind-camera depth and avoid unnecessary rounding in intermediate math.

## Game-loop pattern and caveat

`Game.run` uses an accumulator with a fixed `step` for updates, followed by render. It caps delta time at 1 second, but the `while (gdt > step)` catch-up loop has no explicit max-step count. A long background gap can still result in many update calls. This should not be copied to low-end MUNGIL. The inspected MUNGIL physics loop has a two-step cap; verify other loops independently.

## Asset/lifecycle caveats

- The image loader waits for `load` events and the inspected helper shows no `error` handling; a missing image may prevent the ready callback from completing.
- The statistics helper starts a 5-second `setInterval` and the helper does not show a teardown method.
- The project README explicitly calls this a tutorial/demo, notes globals/inline JS, and says mobile performance is poor/unoptimized.
- README says borrowed OutRun sprites and paid/licensed music are only for this project. Do not reuse.

## MUNGIL implications

- Use projection equations only as a conceptual reference; our prototype adds input validation, near-clip rejection, reusable outputs, and optional isometric forward/inverse math.
- Do not port the demo loop or loader. Preserve MUNGIL's existing capped simulation, image loading, renderer and lifecycle systems, subject to further verification.
- No code/assets from this repository have been copied into MUNGIL or the research workspace.
