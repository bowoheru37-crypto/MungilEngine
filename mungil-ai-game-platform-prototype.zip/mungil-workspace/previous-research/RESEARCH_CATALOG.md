# MUNGIL Open-Source Research Catalog (25 slots)

**Research snapshot:** 2026-11-24. Ranked by *fit to the category and potential transferable patterns*, not a strict GitHub star ranking. Repository pages/README text and visible license metadata were inspected through web search/browser results where available. **Git clone, full source-tree inspection, exact commit SHA/revision pinning, and local LICENSE-file validation are blocked in this environment** because DNS to github.com/api.github.com fails. Treat every entry as a candidate until clone-and-source review is completed. No third-party source code has been copied or integrated.


## 1. Fake 3D (5 candidates)

| Rank | Repository | License status | Activity/popularity snapshot | Relevant ideas | MUNGIL fit / risk |
|---:|---|---|---|---|
| 1 | [jakesgordon/javascript-racer](https://github.com/jakesgordon/javascript-racer) | MIT repo license visible; **assets have separate restrictions** | ~1.2k stars, 516 forks, 15 commits; old tutorial | Segment projection, curves/hills, draw distance, resolution control, fog, camera offsets | **Very high algorithmic fit.** Do not copy sprites/music: README states sprites are borrowed from OutRun and music is licensed only for that project. README also explicitly says code is demo-quality, uses globals/inline scripts, and mobile performance is poor; port math/patterns only, not code or assets. |
| 2 | [ssusnic/Pseudo-3d-Racer](https://github.com/ssusnic/Pseudo-3d-Racer) | MIT metadata visible | ~65 stars, 32 forks, 8 commits; tutorial project | Road segment projection, curves/hills, camera/player state, Phaser 2-era workflow | High conceptual fit; legacy Phaser dependency and limited activity. Algorithm study only; no engine port. |
| 3 | [git-hubratlee/cyber-racer-3d-engine](https://github.com/git-hubratlee/cyber-racer-3d-engine) | MIT stated in repo page | 0 stars, 0 forks, 4 commits | Single-file Canvas, perspective scale, 5-lane world, touch scaling | High mobile-specific ideas; very small/low community signal, needs source correctness review. |
| 4 | [Vlakoosh/js-pseudo-3d-racing-game](https://github.com/Vlakoosh/js-pseudo-3d-racing-game) | **No license found in visible repo page; do not copy/adapt** | 1 star, 1 fork, 12 commits | Vanilla JS/Canvas road simulation | Useful visual reference only pending license and source review. |
| 5 | [17-codes/Pseudo-3d-road-js](https://github.com/17-codes/Pseudo-3d-road-js) | **No license found in visible repo page; do not copy/adapt** | 0 stars, 0 forks, 4 commits; p5.js dependency | Smooth curves/hills, simple 2D road projection | Low weight as reference; p5 dependency and low activity; no code adoption until license verified. |

**Priority patterns:** road-segment projection and camera math; precompute curve/hill offsets; draw-distance limits; stable perspective scale; screen-space fog; resolution scaling. Keep MUNGIL's current movement, scene, camera, and constructors.


## 2. Pseudo-3D / raycasting (5 candidates)

| Rank | Repository | License status | Activity/popularity snapshot | Relevant ideas | MUNGIL fit / risk |
|---:|---|---|---|---|
| 1 | [krotik/gladiator_3d](https://github.com/krotik/gladiator_3d) | MIT confirmed in repo metadata | 32 stars, 14 forks, 3 commits; last commit shown 2014-06-19 | Canvas raycasting, wall intersection, texture coordinates, example game | Good math reference; very old and low commit count. Source inspection and tests required. |
| 2 | [justMoritz/3d-game-engine](https://github.com/justMoritz/3d-game-engine) | MIT metadata visible | 58 stars, 6 forks, 162 commits | ASCII raycaster, z-buffered sprites, directional/depth shading, asset IO; caching, lookup tables, combining loops | **High pattern value:** cache player/world state and expensive trig, LUTs, reduce inner-loop calls, avoid expensive console logging. Renderer is ASCII-specific; adapt ideas only. |
| 3 | [justMoritz/sector-based-3d-engine](https://github.com/justMoritz/sector-based-3d-engine) | MIT metadata visible | 10 stars, 2 forks, 579 commits | Sector renderer, variable-height sectors, windows/platforms, voxel objects, camera look-up/down | Potential high value for sector culling/visibility. Source not inspected; project complexity and renderer-specific approach need study. |
| 4 | [rohit-s-init/3d-raycaster-wolfstein](https://github.com/rohit-s-init/3d-raycaster-wolfstein) | **License not verified; no code adaptation** | Popularity/activity not reliably captured in current page result | JavaScript Canvas, DDA raycasting, wall-distance/height projection, player movement | Algorithm reference only until source and license are inspected. |
| 5 | [shiro1307/raycast_wolfenstein_renderer](https://github.com/shiro1307/raycast_wolfenstein_renderer) | **No license found in visible repo page; no code adaptation** | 0 stars, 6 commits | Separate game loop/map/script files; 2.5D Canvas raycaster | Useful to study loop/map separation; small project and license blocked. |

**Priority patterns:** DDA/grid traversal; ray-per-column resolution; fisheye correction; texture sampling; z-buffer for sprites; depth-aware floor/wall/sprite occlusion; cached trigonometry and camera basis; typed-array buffers; render at reduced internal resolution then scale. Avoid porting full raycaster unless a MUNGIL scene specifically needs it.


## 3. 2.5D / isometric (5 candidates)

| Rank | Repository | License status | Activity/popularity snapshot | Relevant ideas | MUNGIL fit / risk |
|---:|---|---|---|---|
| 1 | [melonJS/melonJS](https://github.com/melonjs/melonJS) | MIT confirmed | ~6.5k stars; active, substantial codebase | Orthogonal/perspective cameras, isometric/hex/staggered Tiled maps, renderer abstraction (WebGPU/WebGL2/Canvas fallback), batching, physics, audio, glTF | Strong architecture reference, **not** a dependency to add wholesale. Modern GPU paths can exceed low-end device budget; examine fallback and selective concepts. |
| 2 | [jwwicks/phaser3-plugin-isometric](https://github.com/jwwicks/phaser3-plugin-isometric) | MIT confirmed | 0 stars; visible history 103 commits; WIP fork | Point3/Cube helpers, configurable axonometric angle, z-aware sorting, 3D AABB physics | Good projection/collision reference; Phaser-specific, fork status, debug tools noted as incomplete. |
| 3 | [jamaalsawyerd/twopointfive-phaser-4](https://github.com/jamaalsawyerd/twopointfive-phaser-4) | MIT metadata visible | ~25 stars, 35 commits | Perspective viewport, sector culling, floor/walls/ceiling, 3D-position entities, collision/light map | Strong sector/visibility reference; Phaser 4/Impact version-specific. Review bundled `impact-version` provenance before use. |
| 4 | [7hebel/IsoEngine](https://github.com/7hebel/IsoEngine) | **License not found in visible page; no code adaptation** | 16 stars, 7 commits; last update shown 2024-06-22 | Voxel/isometric world, Perlin terrain, terraforming, particles, pathfinding, seed saves | Conceptual reference; Python dependencies and limited activity; not directly mobile-web compatible. |
| 5 | [ON00dev/Isoria](https://github.com/ON00dev/Isoria) | MIT confirmed | 0 stars, 0 forks, 51 commits; page crawled ~1.3 years ago | Tile-based isometric editor/engine, multiplayer, File System Access API with browser fallback, client/server/shared separation | Useful architecture/workflow reference; online server stack and modern browser APIs are unnecessary for single-file offline MUNGIL unless selectively adapted. |

**Priority patterns:** projection transform as a single shared function; camera-space depth key; deterministic tie-breaking for sort; sector/chunk culling; z-aware hit tests; grid pathfinding; tile metadata for elevation/collision; dirty tile/layer redraw. Keep orthogonal scene support intact.


## 4. Web game/render engines (5 candidates)

| Rank | Repository | License status | Activity/popularity snapshot | Relevant ideas | MUNGIL fit / risk |
|---:|---|---|---|---|
| 1 | [phaserjs/phaser](https://github.com/phaserjs/phaser) | MIT confirmed | Mature/active; broad community | Canvas/WebGL, scenes, camera, input, animation, asset/audio systems, mobile-browser workflow | Workflow and API concepts only; full framework would replace/overlap MUNGIL. |
| 2 | [KilledByAPixel/LittleJS](https://github.com/KilledByAPixel/LittleJS) | MIT confirmed | ~4.4k stars, ~243 forks; active repository page | Tiny/no-dependency architecture, 2D/3D hybrid, WebGL2/Canvas, physics, particles, sound/input, examples/tests | Very high for lean subsystem design; assess API and features individually before adaptation. |
| 3 | [pixijs/pixijs](https://github.com/pixijs/pixijs) | MIT confirmed | ~48.9k stars, ~5.2k forks; active | Renderer, batching, textures/assets, touch, WebGL/WebGPU, filters, masks | Renderer-only reference; not a game engine; GPU-first features can be costly on weak devices. |
| 4 | [melonjs/melonJS](https://github.com/melonjs/melonJS) | MIT confirmed | ~6.5k stars; active | 2.5D camera, renderer abstraction, batchers, Tiled, physics, audio, asset pipeline, fallback | High architecture value, but large feature scope and WebGPU/WebGL2 baseline make wholesale adoption unsuitable. |
| 5 | [playcanvas/engine](https://github.com/playcanvas/engine) | MIT confirmed | ~17.4k stars, ~2.1k forks | WebGL/WebGPU/WebXR, glTF, asset streaming, scene/component architecture, physics, tooling | Strong reference for 3D asset/runtime pipeline; high complexity and footprint—select only narrow concepts. |

**Priority patterns:** renderer capability negotiation; feature fallback; batched sprite/texture operations; asset manifest and async loading; lifecycle-safe scene transitions; mobile touch/gamepad input; render-scale control; profiling hooks. Galacean ([galacean/engine](https://github.com/galacean/engine), MIT, ~5.9k stars) is an alternate engine reference if PlayCanvas concepts prove too heavy.


## 5. Mobile/native game engines (5 candidates)

| Rank | Repository | License status | Activity/popularity snapshot | Relevant ideas | MUNGIL fit / risk |
|---:|---|---|---|---|
| 1 | [godotengine/godot](https://github.com/godotengine/godot) | MIT confirmed | Large, active, multi-platform project | 2D/3D scenes, component/node lifecycle, mobile exports, editor, animation/physics/input | Architecture, lifecycle, editor UX reference only; native engine too large to embed. |
| 2 | [defold/defold](https://github.com/defold/defold) | Source-available developer-friendly license derived from Apache 2.0; **not simply Apache/MIT** | ~6.5k stars, ~468 forks; active, complex engine | Build tooling, native/mobile/web targets, scene/component lifecycle, asset pipeline, profiler, license compliance | High reference value for packaging and lifecycle; exact license and third-party notices must be reviewed. No code adaptation in this pass. |
| 3 | [TRAGsoft/solar2d](https://github.com/TRAGsoft/solar2d) | MIT confirmed; bundled third-party components have separate licenses | ~2.9k stars, ~312 forks (official `coronalabs/corona` repo page also surfaced) | Lua runtime, native mobile APIs, cross-platform build, plugins, asset/audio workflows | Mobile packaging and lifecycle reference; different runtime/language, not a direct dependency. |
| 4 | [4ian/GDevelop](https://github.com/4ian/GDevelop) | MIT for Core/GDJS/IDE/extensions; name/logo are separately owned | Active; substantial engine and IDE | Event/behavior editor, scene/game logic, extension model, HTML5/native engine, WASM physics, asset workflows | UX and system separation reference; React/Electron/Pixi/Three and native stack are too heavy for direct transplant. |
| 5 | [raredeveloperofficial/RareEngine2](https://github.com/raredeveloperofficial/RareEngine2) | MIT confirmed | 2 stars, 1 fork, 41 commits | Pure Java Android Canvas, component-style architecture, scenes/rendering, tiny APK goal | Useful low-level mobile architecture reference; README contradicts itself (“no physics/dependencies” vs JBox2D-powered physics), so dependency and claim verification required. |

**Priority patterns:** low-cost native canvas loops; component lifecycle; Android touch/input handling; asset memory discipline; mobile build/export and offline operation. These projects are not port targets; keep MUNGIL browser/single-file constraints.


## Comparison matrix (transferable value)

| Feature | Fake 3D | Pseudo-3D | 2.5D | Web engines | Mobile engines | MUNGIL action |
|---|---|---|---|---|---|
| Perspective projection | Strong | Strong | Medium | Mixed | Mixed | Add projection helper behind mode-specific adapter; avoid camera rewrite |
| Raycasting/DDA | Low | Strong | Medium | Some engines | Optional raycast module; use for wall/visibility queries only |
| Depth ordering/z-buffer | Strong | Strong | Strong | Strong | Shared stable depth key + deterministic tie-break |
| Camera modes | Road camera | First-person | Isometric/perspective | Broad | Native lifecycle | Centralize transforms but preserve current camera constructors |
| Terrain/chunks | Road segments | Grid map | Tiles/sectors/voxels | Tilemaps/assets | Scene/world | Culling and chunk cache; only rebuild dirty chunks |
| Physics/collision | Road obstacles | Wall collision | AABB/grid | Integrated | Native | Reuse existing physics; validate spatial grid and masks, avoid duplicated solvers |
| Animation | Sprite traffic | Sprites | Tile/entity | Scene/sprite | Native | Central update budget, pool objects, time-based animation |
| Asset IO | Small sprites | Textures/maps | Tile/sector assets | Streaming | Native packaging | Manifest, lazy load, bounds, checksum, cleanup |
| Mobile input | Touch lane zones | Touch controls | Tap/drag | Mobile input | Android input | Keep one input abstraction; no duplicated touch listeners |
| Low-end performance | Draw distance | Resolution/cache | Culling/dirty redraw | Renderer fallback | Native Canvas | Measure actual frame pacing; scale quality based on sustained signals |
| Export/offline | Single HTML | Simple Canvas | Browser/desktop | Toolchain/build | Native builds | Keep single-file export; development source may be modular |


## License/provenance gate

- **Green (repo license metadata verified):** MIT candidates are eligible for *source review*, not automatic copying. Preserve copyright/license text and notices if code is adapted.
- **Yellow (license not found/unclear):** use public README/feature descriptions only; do not copy, adapt, or port code until license is verified.
- **Special assets:** repo license may not cover external art/audio. Verify asset provenance independently; do not reuse any OutRun sprites/music from `javascript-racer`.
- **Exact revision:** none pinned in this research pass. Repository default branches and current visible GitHub metadata are not a substitute for a commit SHA.


## Integration plan for MUNGIL (incremental, reversible)

1. **RenderMode adapter:** keep the existing constructor/renderer. Add optional Fake3D/2.5D modes only as adapters that receive current scene/camera data and return render commands; do not replace the main pipeline.
2. **Projection math module:** isolate projection transforms; unit-test forward/inverse transforms and round trips where applicable. Cache constant camera values per frame.
3. **Depth sort:** one stable key (`screenY`/camera depth plus deterministic entity ID tie-break); test equal-depth ordering and negative/elevation cases.
4. **Chunk/sector culling:** use existing world/chunk system; compute visibility once per camera change, mark dirty chunks, cap work per frame.
5. **Optional raycast:** DDA over existing collision grid for wall/line-of-sight only; use step cap and reuse buffers.
6. **Performance telemetry:** bounded rolling frame-time probe (patch in this workspace) to instrument existing adaptive-quality manager; do not create a competing tier manager.
7. **Asset lifecycle:** preserve registry; add missing/unused checks, refcounts/eviction only after source-level map and tests.
8. **Input lifecycle:** centralize listeners and cleanup, keep touch targets and UI CSS unchanged.
9. **Single-file build:** keep modular authoring sources if available; produce the same standalone HTML as distribution. Do not edit the bundled artifact until a safe build/test workflow is identified.

## Source and revision inspection status

- 25 category slots / 24 unique repositories (melonJS appears in 2.5D and web-engine categories).
- License metadata status by slot: 19 MIT candidates, 5 unknown/missing license, 1 custom Defold license. These are visible repo-page metadata only—not local LICENSE validation.

- Repository web pages and README excerpts: **partial**.
- License metadata: **partial; green/yellow status above**.
- Raw files/tree browsing: restricted/failed in this environment.
- Clone: **blocked** (`git clone` failed with `Could not resolve host: github.com`).
- Commit hashes/revisions: **not pinned**.
- Source-level adoption: **none**.

## Additional source-level inspection (web-view, not clone)

### `jakesgordon/javascript-racer/common.js` and `v4.final.html`
The GitHub web viewer allowed inspection of the actual `common.js` projection and loop, plus `v4.final.html` project README content:

- Projection stores camera-relative coordinates and uses `scale = cameraDepth / cameraZ`, then projects screen x/y and road width. This is the compact classic road-segment projection pattern.
- Its RAF loop uses an accumulator and fixed `step`, but clamps `dt` to **1 second** and has no explicit maximum catch-up step count. A long background gap can therefore trigger many fixed updates in one frame. MUNGIL's current physics loop appears to cap substeps at two in the inspected bundle; preserve that cap and validate all other loops.
- The project README explicitly warns that it is a tutorial/demo, uses globals and embedded scripts, and has poor mobile performance; it says mobile play is not expected and optimization has not been done. **Do not port its engine structure or claim it is a mobile-optimized reference.**
- The `common.js` image loader in the viewed source only waits for successful `load` events; no error fallback is shown in that helper. A failed image may leave the ready callback pending. MUNGIL's asset loader should be tested for both success and error paths.
- A statistics helper schedules a 5-second `setInterval` and returns a stats object, but no teardown is shown in the helper. This is a demo lifecycle weakness; do not copy it into MUNGIL.
- The repository is MIT, but its README states that music tracks are licensed only for this project and sprites are borrowed from an old OutRun version. Do not reuse those assets.

**Source page inspected:** `common.js` (GitHub web viewer, `master`, no pinned SHA) and `v4.final.html` README section. Full clone and commit pinning remain blocked.


## New original prototypes (not third-party ports)

### `patches/projection-math.js`
- `projectFake3D(point,camera,out)` — perspective scale and near-plane rejection; finite-value guards; caller-owned output.
- `projectIsometric(point,config,out)` — orthographic isometric projection; ground depth key; zero elevation scale supported.
- `unprojectIsometric(screen,config,height,out)` — inverse ground projection at a known height.
- `compareDepth(a,b)` — deterministic depth ordering with stable ID tie-break.
- Explicit finite checks avoid temporary validation arrays in the hot path; mixed ID types only stringify on tie-break fallback.

Limitations: These are standalone mathematical adapters, not the MUNGIL renderer. `depthKey = x + y` is only a simple ground-plane ordering hint; overhangs, tall sprites, multi-cell objects, and stacked geometry require a footprint/occlusion-aware sorter.

### `patches/frame-pacing-probe.js`
- Bounded fixed ring of frame intervals (default 120, max 600).
- Rolling average FPS, p95 interval, and long-frame count.
- Long background gap resets samples but starts a fresh timestamp baseline.
- No timers, RAF scheduling, listeners, quality-tier mutation, or per-frame snapshot allocation.
- Diagnostic use only; the existing adaptive-quality system remains authoritative.
