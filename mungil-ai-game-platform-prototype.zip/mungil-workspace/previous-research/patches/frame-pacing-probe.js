/**
 * MUNGIL Mobile Frame-Pacing Probe (diagnostic-only, dependency-free).
 *
 * It measures frame intervals and does NOT schedule frames, change quality tiers,
 * touch the renderer, or install browser listeners. Integrate only after review.
 * Original implementation; no third-party source copied.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else if (root) root.MungilFramePacingProbe = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  class FramePacingProbe {
    constructor(options) {
      const opts = options || {};
      const capacity = Math.floor(Number(opts.capacity) || 120);
      const targetFps = Number(opts.targetFps) || 30;
      const longFrameMs = Number(opts.longFrameMs) || 50;
      const pauseResetMs = Number(opts.pauseResetMs) || 250;
      this.capacity = Math.max(8, Math.min(600, capacity));
      this.targetFps = Math.max(1, Math.min(240, targetFps));
      this.longFrameMs = Math.max(1, longFrameMs);
      this.pauseResetMs = Math.max(this.longFrameMs, pauseResetMs);
      this._samples = new Float64Array(this.capacity);
      this._next = 0;
      this._count = 0;
      this._sum = 0;
      this._longCount = 0;
      this._last = null;
    }

    push(timestampMs) {
      const now = Number(timestampMs);
      if (!Number.isFinite(now)) return false;
      if (this._last === null) {
        this._last = now;
        return false;
      }
      const dt = now - this._last;
      this._last = now;
      if (!(dt > 0)) return false;
      if (dt > this.pauseResetMs) {
        this.clearSamples();
        this._last = now;
        return false;
      }

      const old = this._count === this.capacity ? this._samples[this._next] : 0;
      if (this._count === this.capacity && old >= this.longFrameMs) this._longCount--;
      this._samples[this._next] = dt;
      this._sum += dt - old;
      if (dt >= this.longFrameMs) this._longCount++;
      this._next = (this._next + 1) % this.capacity;
      if (this._count < this.capacity) this._count++;
      return true;
    }

    clearSamples() {
      this._samples.fill(0);
      this._next = 0;
      this._count = 0;
      this._sum = 0;
      this._longCount = 0;
    }

    reset(timestampMs) {
      this.clearSamples();
      this._last = Number.isFinite(Number(timestampMs)) ? Number(timestampMs) : null;
    }

    snapshot() {
      if (!this._count) {
        return {
          targetFps: this.targetFps,
          targetFrameMs: 1000 / this.targetFps,
          samples: 0,
          averageFrameMs: null,
          fps: null,
          p95FrameMs: null,
          longFrames: 0,
          longFrameThresholdMs: this.longFrameMs,
          capacity: this.capacity,
        };
      }
      const avg = this._sum / this._count;
      // Sort only on snapshot requests, not on the hot per-frame push path.
      const sorted = Array.from(this._samples.subarray(0, this._count)).sort((a, b) => a - b);
      const p95Index = Math.max(0, Math.ceil(sorted.length * 0.95) - 1);
      return {
        targetFps: this.targetFps,
        targetFrameMs: 1000 / this.targetFps,
        samples: this._count,
        averageFrameMs: avg,
        fps: avg > 0 ? 1000 / avg : null,
        p95FrameMs: sorted[p95Index],
        longFrames: this._longCount,
        longFrameThresholdMs: this.longFrameMs,
        capacity: this.capacity,
      };
    }
  }


  return { FramePacingProbe };
});
