/** MUNGIL Projection Math Adapters — original, dependency-free prototype.
 * Not integrated into the shipped HTML. Caller supplies/reuses output objects.
 * Coordinate conventions:
 *  - Fake3D: world x/y, positive z is farther from camera; camera cz is near.
 *  - Isometric: x/y are ground-plane axes; z is vertical elevation.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else if (root) root.MungilProjectionMath = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  function finite(value) { return Number.isFinite(value); }

  function projectFake3D(point, camera, out) {
    if (!point || !camera || !out) return false;
    const x = Number(point.x), y = Number(point.y), z = Number(point.z);
    const cx = Number(camera.cx ?? 0), cy = Number(camera.cy ?? 0), cz = Number(camera.cz ?? 0);
    const centerX = Number(camera.centerX ?? 0), horizonY = Number(camera.horizonY ?? 0);
    const focal = Number(camera.focalLength), near = Math.max(0.0001, Number(camera.nearClip || 0.1));
    if (!finite(x) || !finite(y) || !finite(z) || !finite(cx) || !finite(cy) || !finite(cz) || !finite(centerX) || !finite(horizonY) || !finite(focal) || !finite(near) || focal <= 0) return false;
    const depth = z - cz;
    if (depth <= near) return false;
    const scale = focal / depth;
    out.x = centerX + (x - cx) * scale;
    out.y = horizonY - (y - cy) * scale;
    out.scale = scale;
    out.depth = depth;
    return finite(out.x) && finite(out.y) && finite(out.scale);
  }

  function projectIsometric(point, config, out) {
    if (!point || !config || !out) return false;
    const x = Number(point.x), y = Number(point.y), z = Number(point.z ?? 0);
    const originX = Number(config.originX ?? 0), originY = Number(config.originY ?? 0);
    const halfWidth = Number(config.halfWidth), halfHeight = Number(config.halfHeight);
    const heightScale = Number(config.heightScale ?? 1);
    if (!finite(x) || !finite(y) || !finite(z) || !finite(originX) || !finite(originY) || !finite(halfWidth) || !finite(halfHeight) || !finite(heightScale) || halfWidth <= 0 || halfHeight <= 0) return false;
    out.x = originX + (x - y) * halfWidth;
    out.y = originY + (x + y) * halfHeight - z * heightScale;
    out.depthKey = x + y;
    return finite(out.x) && finite(out.y) && finite(out.depthKey);
  }

  function unprojectIsometric(screen, config, height, out) {
    if (!screen || !config || !out) return false;
    const sx = Number(screen.x), sy = Number(screen.y), z = Number(height ?? 0);
    const originX = Number(config.originX ?? 0), originY = Number(config.originY ?? 0);
    const halfWidth = Number(config.halfWidth), halfHeight = Number(config.halfHeight);
    const heightScale = Number(config.heightScale ?? 1);
    if (!finite(sx) || !finite(sy) || !finite(z) || !finite(originX) || !finite(originY) || !finite(halfWidth) || !finite(halfHeight) || !finite(heightScale) || halfWidth <= 0 || halfHeight <= 0) return false;
    const difference = (sx - originX) / halfWidth;
    const sum = (sy - originY + z * heightScale) / halfHeight;
    out.x = (sum + difference) * 0.5;
    out.y = (sum - difference) * 0.5;
    out.z = z;
    return finite(out.x) && finite(out.y);
  }

  // Sort front-to-back according to caller-defined depthKey; tie-break by stable ID.
  function compareDepth(a, b) {
    const da = Number(a && a.depthKey), db = Number(b && b.depthKey);
    const aValid = Boolean(a && a.depthKey != null && finite(da)), bValid = Boolean(b && b.depthKey != null && finite(db));
    if (aValid && bValid && da !== db) return da - db;
    if (aValid !== bValid) return aValid ? -1 : 1;
    const ia = a && a.id != null ? a.id : '', ib = b && b.id != null ? b.id : '';
    if (typeof ia === 'number' && typeof ib === 'number') return ia - ib;
    if (typeof ia === 'string' && typeof ib === 'string') return ia < ib ? -1 : ia > ib ? 1 : 0;
    if (ia === ib) return 0;
    // Mixed ID types are rare; stringify only on this tie-break fallback.
    const sa = String(ia), sb = String(ib);
    return sa < sb ? -1 : sa > sb ? 1 : 0;
  }

  return { projectFake3D, projectIsometric, unprojectIsometric, compareDepth };
});
