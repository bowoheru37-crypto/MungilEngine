# MUNGIL Research and Optimization Progress

**Run 1 — 2026-11-24**


## Source baseline

- Original HTML accessible: yes (`/mnt/data/source_1795245442550.html`).
- Backup checkpoint created at `/mnt/data/mungil-research/source.original.html` (copy only; no overwrite).
- SHA-256: `bd12f920c02c487cee9cc8617f2272dd57ddf489b232edd75c58ea8dffca8a53`.
- File: 877,743 bytes (870,328 characters), 4,499 lines.
- Inline JavaScript total: 816,535 bytes; largest module is 788,414 bytes (89.82% of HTML bytes). Six JavaScript blocks and one JSON data block are present.
- Six JavaScript blocks passed `node --check`; JSON block intentionally excluded.
- Raw `<script` tokens: 9, but raw-text-aware actual script blocks: 7 (6 JavaScript + 1 JSON). Two opening-tag strings are inside JavaScript bundle text, so they are not real HTML script tags. The audit tool was updated to distinguish these.
- Static audit counters: RAF 8 / cancelRAF 3; setInterval 26 / clearInterval 27; setTimeout 38 / clearTimeout 6; addEventListener 24 / removeEventListener 11; innerHTML assignments 3; dangerouslySetInnerHTML tokens 13; WebGL context tokens 4; Canvas2D context tokens 12; eval 0; new Function 0; localStorage/sessionStorage/indexedDB tokens 0; Worker 0; ResizeObserver 1; IntersectionObserver 0.
- Counts are only static pattern inventories. They do not establish runtime bugs, leak behavior, sink vulnerability, or actual active loop count.

## Concrete deliverables this run

- `audit_mungil.mjs` — dependency-free static HTML audit utility.
- `test-audit.mjs` — 4 automated tests for script classification/counts/warnings/report output, including raw `<script>` literals inside JS.
- `reports/source_1795245442550.audit.json` and `.md` — machine-readable and human-readable baseline.
- `patches/projection-math.js` — optional original Fake3D/isometric projection adapter prototype with reusable outputs and tests (not integrated).
- `patches/frame-pacing-probe.js` — optional original diagnostic-only probe; no listeners/timers/scheduler, bounded 120-sample ring by default, reports FPS/average/p95/long frames. **Not integrated into original HTML.**
- `test-frame-pacing-probe.js` — 6 tests covering 30 FPS, ring bounds, long-frame roll-off, background-gap reset, invalid timestamps, and 250,000 synthetic samples.
- `test-projection-math.js` — 9 tests covering projection math, inverse round-trip, clipping, malformed inputs, depth sorting, flat-height mode, and a 100,000-point synthetic loop.
- `RESEARCH_CATALOG.md` — 25 category slots (5 each), links, feature notes, license status, risks, comparison matrix, integration roadmap.


## Tests

- Combined `node --test test-audit.mjs test-frame-pacing-probe.js test-projection-math.js`: 19/19 passed.

- `node --check` on the six JavaScript script blocks: 6/6 passed.
- No browser runtime test, real Android/itel A70 benchmark, memory profiler, gameplay regression suite, or full source-level third-party repo inspection was possible in this run.


## Research progress

- Candidates cataloged: 25 slots (5 × 5 categories).
- License metadata status by 25 slots: 19 MIT candidates, 5 unknown/missing license (yellow), 1 custom Defold license. Metadata-only verification; local LICENSE files not validated. 24 unique repositories because melonJS is used in two categories.
- Full clones: 0/25. `git clone --depth 1 https://github.com/jakesgordon/javascript-racer.git` attempted and failed due DNS (`Could not resolve host: github.com`).
- Exact commit/revision hashes: 0 pinned.
- Source code copied/adapted from third-party repositories: 0.


## Prioritized findings

### P1 — Source modularity/build reproducibility
The main inline module is about 788 KB. Keep the one-file delivery requirement, but author modular source if the original source map/build project is available. A single bundle should be generated from source rather than hand-edited. This is a risk/opportunity, not proof of a runtime defect.

### P1/P2 — Runtime lifecycle and instrumentation
Static counts show many timer/listener tokens and multiple RAF call sites. Review each React effect/loop and lifecycle ownership individually; the current counts alone do not establish a leak. A bounded frame-pacing probe was prepared and tested as an instrumentation option, but integration is intentionally deferred.

### P2 — HTML sinks
Three `innerHTML` assignments and thirteen `dangerouslySetInnerHTML` tokens occur in the bundle. React/framework presence alone is not a vulnerability; each actual sink needs data-flow review and source context. No exploitability claim is made.

### P2 — Repository clone/source inspection blocked
Because GitHub clone/raw source access is blocked, license verification is metadata-only and source/commit review cannot be completed. Do not adopt code until cloning and inspecting full source/README/LICENSE and provenance.


## Next run
1. Retry repository cloning/source access only if network access is available; inspect source/build artifacts and establish a safe integration path.
2. Prioritize source-level mapping of lifecycle loops, timer cleanup, renderer and physics logic; use web-view source inspection for additional candidates where accessible.
3. Verify repo licenses, exact commit hashes, source tree and dependencies; revise the 25-slot shortlist if better matches appear.
4. Review the projection adapter and frame probe against MUNGIL existing camera/render/quality systems; integrate only after locating a safe source/build insertion point.
5. Run static/runtime/regression checks and update this progress file.

### Source-level review (limited web viewer)
- Inspected `jakesgordon/javascript-racer/common.js` projection and loop, plus `v4.final.html` README/source metadata.
- Found classic camera-relative projection with `cameraDepth / cameraZ`, screen x/y and road width scaling.
- The tutorial loop clamps delta to 1 second but can execute unbounded fixed-step catch-up within that clamp; MUNGIL's inspected physics loop caps at 2 substeps, which is a safer mobile pattern to preserve and verify.
- The tutorial helper's image loader waits for load events without a visible error fallback; its stats helper schedules a 5-second interval without a visible teardown. Do not adopt those lifecycle patterns.
- README says this is a demo/tutorial, uses globals/inline code, has poor mobile performance, and is not optimized for mobile. The code is MIT, but borrowed OutRun sprites and project-only licensed music are excluded from reuse.
- Additional source page navigation was attempted for several repositories, but GitHub restricted the source tree in this web session.
