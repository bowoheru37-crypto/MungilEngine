'use strict';
const assert=require('node:assert/strict');
const {spawnSync}=require('node:child_process');
const input=[
 {jsonrpc:'2.0',id:1,method:'initialize',params:{protocolVersion:'2024-11-05'}},
 {jsonrpc:'2.0',id:2,method:'tools/list'},
 {jsonrpc:'2.0',id:3,method:'tools/call',params:{name:'mungil.explain_engine',arguments:{topic:'loop'}}},
 {jsonrpc:'2.0',id:4,method:'tools/call',params:{name:'mungil.physics_preset',arguments:{entity:{id:'e',physics:'Arcade',mass:10,friction:50,restitution:10},preset:'BOUNCY'}}}
].map(x=>JSON.stringify(x)).join('\n')+'\n';
const p=spawnSync(process.execPath,['mcp/server.js'],{input,encoding:'utf8'});assert.equal(p.status,0,p.stderr);const lines=p.stdout.trim().split('\n').map(JSON.parse);assert.equal(lines.length,4);assert.equal(lines[0].result.serverInfo.name,'mungil-game-agent');assert.ok(lines[1].result.tools.length>=8);assert.ok(lines[2].result.content[0].text.includes('30 Hz'));const physics=JSON.parse(lines[3].result.content[0].text);assert.equal(physics.entity.friction,18);console.log('PASS MCP initialize, tool discovery, engine explanation and entity physics mutation round-trip');
