# Recovered MUNGIL source map (static inspection)

Baseline: `baseline/source.original.html`, SHA-256 `bd12f920c02c487cee9cc8617f2272dd57ddf489b232edd75c58ea8dffca8a53`.

Observed in the bundled React module:

- Hierarchy data is currently a flat entity record with fields including `id`, `name`, `type`, `parentId`, `visible`, `locked`, `x`, `y`, `rot`, `scale` (percentage), `depth`, `opacity`, and `comps`.
- The hierarchy starts with Game and Scene roots and creates entity nodes beneath `scene`; it already supports selecting nodes, visible/lock toggles, duplicate/delete/order actions, rename and a limited parent picker.
- The viewport maps entities to absolute `left:N.x`, `top:N.y` positions and applies rotation/scale for display. The inspected rendering expression does not compose a selected entity's parent transform into child world coordinates. A Container feature therefore needs a renderer adapter, not just a parentId assignment.
- Physics body records use flat values such as `kind`, `role`, `layer`, `x`, `y`, `vx`, `vy`, `angle`, `mass`, `friction`, `restitution`, `r`, `w`, and `h`.
- The physics workflow already has engine/profile options Arcade, Matter, Rapier, Jolt, MuJoCo, Bullet and Custom, plus a 30 Hz timestep setting, broadphase/narrowphase routines, collision layers, CCD, sleeping, joints and sensors. These are not equivalent to per-entity material presets such as Bouncy/Heavy/Ghost/Slippery.
- The editor exposes a global Collision toggle and existing physics/collision workflows. A per-entity collision shape editor still needs an overlay canvas and a commit path through the existing state/history system.
- The large React module is bundled/minified in a single inline script. No source map or maintainable component source was established from the supplied file.
- Existing persistence calls use a host `actions` endpoint. The MCP server must not bypass this persistence boundary or write directly into undocumented storage.

## Integration consequences

1. The extension adapter now reads/writes MUNGIL's flat transform schema and preserves the original record fields.
2. MUNGIL's flat transform schema supports uniform scale only; non-uniform parent scaling is rejected rather than approximated silently.
3. Parent transform composition must be inserted in the existing viewport/world-transform path after the exact store and renderer functions are mapped.
4. Presets update the existing flat physics body values (friction/restitution as 0–100) when the target is a MUNGIL body record; nested `physics` objects are also supported for adapters.
5. Do not patch minified source with broad string replacement. Obtain maintainable source/build pipeline or a precisely identified AST-level patch path first.
