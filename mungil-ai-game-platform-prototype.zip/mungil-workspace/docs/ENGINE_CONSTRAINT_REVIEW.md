# Review of proposed 9 prohibitions and performance targets

The principles are useful as guardrails, but several literal requirements are not portable or technically consistent:

1. **NO GC / zero allocation:** realistic for selected C++ hot paths after profiling; not a blanket guarantee for React/JavaScript/WebView. Keep allocations out of simulation hot loops and reuse buffers where measured.
2. **NO FC:** pointer checks and exception boundaries are appropriate for native code. In JavaScript use null guards, validation, rejected-promise handling and error boundaries; a try/catch around every operation is not a substitute for design.
3. **NO ANR:** no synchronous disk/network/asset decode on Android main thread. Keep UI tasks short; worker availability and transfer costs vary by Android version.
4. **NO NPE:** Kotlin/Java null safety and validated boundaries; avoid unchecked `!!` and unchecked optional unwraps.
5. **NO LEAK:** RAII is native-side; object pools are useful only for measured high-churn objects. Pools must never return live objects or grow without cap.
6. **NO OOM:** 300 MB is a ceiling proposal, not a safe allocation target. Include WebView/graphics driver/native buffers and OS pressure; choose a lower working target based on `ActivityManager.memoryClass` and runtime measurements.
7. **NO LAG:** fixed 30 Hz simulation requires an accumulator with `STEP=1/30`, a bounded catch-up count and explicit pause/resume. `Clamp(dt, 0.016, 0.033)` is not a fixed timestep and can over-advance simulation. Four workers are a ceiling to test, not always optimal on a low-end SoC. 128 threads is not a sensible target.
8. **NO HEAT:** CPU <20 ms and GPU <14 ms are separate pipeline budgets; their sum is 34 ms, slightly above a 33.3 ms frame and real device thermal throttling can reduce throughput. Measure sustained performance, not a short run.
9. **NO TYPO:** UPPER_SNAKE_CASE is a C/C++ constant naming convention, not a universal language rule. Use language-specific linting and strict types.

Additional correction: avoid `GC_Pools_ReturnAll()` during memory pressure unless every returned object is proven idle. Do not evict resources still referenced by the renderer. LRU eviction must respect active references and asynchronous upload fences.

The claimed FPS, CPU/GPU times, temperatures, 4-hour stability, binary size, battery use and crash-free metrics in the supplied prompt are unverified claims. They are not treated as measured MUNGIL results.
