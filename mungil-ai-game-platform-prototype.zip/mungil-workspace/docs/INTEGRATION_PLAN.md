# MUNGIL integration plan

## Phase 1 — Safe extension seam
1. Map current entity schema and immutable update pattern in the compiled React bundle.
2. Identify hierarchy selection and multi-select state; map transform storage and undo/redo.
3. Add preset application as a pure adapter that updates only the selected entity's existing physics component.
4. Add Container as an existing entity type/component convention, preserving child local transforms and parent world transforms.
5. Add collision editor overlay to the existing canvas pointer pipeline; render handles only while selected and editor mode is active.
6. Persist through the existing records/save mechanism; add migration defaults and rollback.

## Phase 2 — AI/MCP bridge
1. Host MCP server in an app companion process or local service; do not expose stdio directly to browser JavaScript.
2. Browser panel emits request events; trusted host validates tool name, arguments, project ID and permission.
3. Tools return structured results; mutations require explicit confirmation and an undo transaction.
4. Keep project files local by default; network calls and asset uploads require user consent.

## Phase 3 — Gameplay AI
1. Separate deterministic game rules from policy selection.
2. Support AI-vs-AI simulation, player-vs-AI, replay seed and action log.
3. Add difficulty levels through search depth/heuristic budget, not unbounded computation.
4. Keep AI ticks bounded and throttle off-screen/background simulation.

## Non-negotiable mobile budgets
- Fixed 30 Hz simulation target; render pacing independently.
- No synchronous file/network I/O on UI thread.
- 300 MB total app budget is a hard ceiling, not a desired allocation; target lower and reserve headroom for WebView/OS.
- Avoid claiming zero allocation globally in JS/React; enforce allocation-free hot paths only where measured and feasible.
- Job concurrency should be based on actual CPU cores and thermal state; four threads is not universal, 128 threads is inappropriate for an entry-level phone.
- 35 draw calls, CPU <20 ms, GPU <14 ms are test targets to verify on hardware, not guaranteed outputs.
