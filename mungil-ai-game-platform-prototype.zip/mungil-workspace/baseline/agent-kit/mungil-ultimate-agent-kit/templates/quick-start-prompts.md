# Quick start prompts

**Full audit and repair:**
Read AGENTS.md and invoke `mungil-ultimate`. Audit this project first. Report evidence-backed P0–P3 findings and plan. Then implement the highest-priority safe repairs, add regression checks, verify, and review the diff.


**Read-only audit:**
Use `mungil-audit` only. Do not edit. Provide findings with file/line evidence, confidence, and remediation.


**Performance pass:**
Use `mungil-ultimate` and `performance-specialist`. Profile actual code first; focus on mobile Android and low memory. Optimize measurable bottlenecks, then compare tests/measurements.


**Security pass:**
Use `security-reviewer` and `mungil-audit`. Audit imports, storage, DOM, URLs, AI prompts/API integration, and multiplayer. Do not execute unsafe input. Fix high-confidence findings only after recording evidence.


**Feature integration:**
Trace the existing implementation and UX first. Plan the smallest modular integration, preserve saves and existing workflows, add feature tests, and avoid parallel duplicate subsystems.
