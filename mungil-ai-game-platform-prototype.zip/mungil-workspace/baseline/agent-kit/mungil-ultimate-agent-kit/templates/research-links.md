# Free/open-source references (reviewed as inspiration; check current license and compatibility before adopting)

- Vercel Skills CLI: https://github.com/vercel-labs/skills — portable SKILL.md installation across many coding agents; CLI docs list project/global installs and supported agent targets.
- Superpowers: https://github.com/obra/superpowers — workflow methodology emphasizing brainstorming, plans, subagent tasks, TDD, code review, and verification. MIT.
- Gemini CLI: https://github.com/google-gemini/gemini-cli — open-source terminal agent with MCP support.
- Lighthouse: https://github.com/GoogleChrome/lighthouse — web quality/performance audit tooling.
- frontend-performance/perf-audit: https://github.com/frontend-performance/perf-audit — browserless HTML/header audit CLI; review license and suitability before adding.
- Agent Skills specification: https://agentskills.io/ — interoperable Markdown skill format.

Do not vendor source code from these projects into this pack. Install or use them according to their own licenses and upstream instructions.
