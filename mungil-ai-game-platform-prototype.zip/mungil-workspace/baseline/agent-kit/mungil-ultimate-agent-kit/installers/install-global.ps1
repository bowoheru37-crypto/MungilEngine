$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Node.js is required.' }
if (-not (Get-Command npx -ErrorAction SilentlyContinue)) { throw 'npm/npx is required.' }
Set-Location $Root
npx skills add . --skill mungil-ultimate --skill mungil-audit --skill mungil-repair -g -a '*' -y
