#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
command -v node >/dev/null || { echo 'Node.js is required.' >&2; exit 1; }
command -v npx >/dev/null || { echo 'npm/npx is required.' >&2; exit 1; }
# Install portable skill files globally for the chosen agents.
cd "$ROOT"
npx skills add . --skill mungil-ultimate --skill mungil-audit --skill mungil-repair -g -a '*' -y
