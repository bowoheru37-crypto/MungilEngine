# MUNGIL Engineering Rules

## Goal
Improve MUNGIL / HTML game-editor or game-runtime projects while preserving current functionality, emphasizing stability, mobile usability, offline resilience, and low-resource Android performance.

## Mandatory workflow
1. Inventory repository/files and determine project entry points, dependencies, build/test commands, and architecture. Do not guess.
2. Create or confirm a backup/branch before modifying the primary artifact.
3. Audit first: list findings with evidence (file + line/function/snippet), severity, impact, confidence, and suggested fix.
4. Prioritize correctness/security/reliability over visual additions. Make a plan with acceptance criteria.
5. Implement small, focused changes; avoid unnecessary dependencies and unrelated refactors.
6. Run available tests, syntax checks, static analysis, and manual smoke tests. If unavailable, state limitations and provide reproducible commands.
7. Inspect the diff for regressions, unused code, accessibility, mobile touch, memory cleanup, and security.
8. Report: changed files, fixes, tests run/results, remaining risks, and rollback path.

## Guardrails
- Never delete or replace an existing feature simply because it is difficult to understand. Trace call sites and dependencies first.
- Do not alter save-file formats without migration/backward compatibility and recovery.
- Avoid untrusted HTML injection (`innerHTML` with unsanitized strings), unsafe URL schemes, eval/Function, uncontrolled storage writes, or exposing secrets.
- Ensure event listeners, timers, observers, workers, WebGL contexts, audio nodes, and object pools have lifecycle cleanup.
- Keep rendering and UI work bounded; use fixed-step simulation where appropriate, clamp frame delta, and avoid unbounded loops/allocations in hot paths.
- Default target: mobile-first Android entry-level hardware, 30 FPS baseline; treat targets as goals, not measured results.
- Optimize for progressive enhancement: graceful Canvas2D fallback, optional GPU features, offline mode when feasible.
- No hidden network dependency; disclose external assets, APIs, or telemetry.
- Prefer accessible contrast, semantic controls, touch targets, keyboard navigation, reduced motion, and responsive layouts.
- Never declare work complete without verification evidence.
