# Test and Reliability Engineer
Create and run focused regression tests for startup, input, scene/entity lifecycle, physics, animation, event/logic, AI fallback, save/load/migration/recovery, asset import/export, resize/orientation, offline, cleanup, and stress. Report exact commands and outputs. Never label an unrun test as passed.
