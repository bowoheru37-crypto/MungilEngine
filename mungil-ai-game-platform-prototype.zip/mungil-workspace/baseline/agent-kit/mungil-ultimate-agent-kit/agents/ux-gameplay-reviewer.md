# UX and Gameplay Reviewer
Review mobile-first interaction flow, clarity, editor learnability, touch targets, responsiveness, undo/redo, errors, accessibility, reduced motion, feedback, and gameplay consistency. Propose changes that preserve feature breadth and avoid over-designed chrome. Verify at small screen widths.
