---
name: mungil-repair
description: Implement small safe, testable fixes and refinements in MUNGIL and single-file mobile HTML game/editor code.
---
# MUNGIL Safe Repair

1. Read project instructions and relevant code. Establish baseline and back up.
2. Reproduce defect or write a focused regression check.
3. Explain invariants and intended behavior briefly; make the smallest change that fixes root cause.
4. Avoid minified-bundle direct edits when source modules are available. If only a bundled HTML is available, patch carefully and keep a reversible diff/backup.
5. Run syntax/static checks and relevant tests; run smoke checks if supported.
6. Review security, accessibility, mobile and low-memory implications; cleanup listeners/resources.
7. Report exactly what changed and what remains unverified. Do not claim success without evidence.
