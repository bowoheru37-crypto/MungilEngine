---
name: mungil-audit
description: Evidence-based read-only engineering audit for MUNGIL, HTML/JS game editors, and mobile web games.
---
# MUNGIL Read-only Audit

Do not modify files. Build a concise inventory, then inspect:
1. architecture and source-to-output map;
2. security and privacy (DOM injection, URL handling, storage, API keys, permissions, third-party dependencies);
3. correctness and error handling;
4. mobile performance (frame budget, hot loops, allocations, DPR, render path, asset loads);
5. memory/lifecycle cleanup;
6. save/load and backward compatibility;
7. UX/accessibility/touch responsiveness;
8. game systems integration and testability.

Findings must include exact evidence, severity, confidence, impact, and a testable remedy. Separate confirmed defects from risks/hypotheses. Never claim a runtime feature exists based on a UI label or string. Finish with P0–P3 roadmap and a proposed verification checklist.
