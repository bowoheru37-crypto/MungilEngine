'use strict';
const ENGINE_GUIDE = Object.freeze({
  architecture: 'MUNGIL is a bundled React-based editor with multiple existing constructors, scene tools, physics workflows, fake-3D tools and a single-file delivery path. Extend through adapters; do not replace constructors or UI foundations.',
  loop: 'Keep simulation fixed-step at 30 Hz, render independently when supported, clamp accumulated catch-up work, pause background simulation, and keep blocking I/O off the UI thread.',
  physics: 'Use bounded entity pools, finite-number validation, explicit collision filters, sleeping and broad-phase culling. Presets are editable starting points, not universal material truth.',
  mobile: 'Use feature detection and tiered quality. Android 5+ is a compatibility target, not a guarantee of WebGL2, WebGPU, modern codecs or worker features.',
  safety: 'Treat imported assets, project JSON, prompts and network messages as untrusted. Validate size, type, numeric bounds and ownership before applying mutations.'
});
const GAME_ACTIONS = Object.freeze(['MOVE','ATTACK','GUARD','WAIT']);
function explain(topic) { const key=String(topic||'architecture').toLowerCase(); return { topic:key, explanation:ENGINE_GUIDE[key] || 'I can explain architecture, loop, physics, mobile constraints, or safety. Ask for a subsystem name and I will describe its data flow and integration boundaries.' }; }
function validateAction(action) { return action && GAME_ACTIONS.includes(action.type) && Number.isInteger(action.x) && Number.isInteger(action.y) && action.x>=0 && action.x<7 && action.y>=0 && action.y<7; }
module.exports = { ENGINE_GUIDE, GAME_ACTIONS, explain, validateAction };
