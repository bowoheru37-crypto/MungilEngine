'use strict';
// Optional browser-side mount adapter. Host must bridge requests to the MCP stdio process.
(function(root){
  if(!root||root.customElements?.get('mungil-ai-assistant'))return;
  class MungilAIAssistant extends HTMLElement {
    connectedCallback(){
      if(this.shadowRoot)return;const s=this.attachShadow({mode:'open'});
      s.innerHTML=`<style>:host{font:14px system-ui;color:var(--mungil-agent-fg,#eef4ff)}.panel{background:var(--mungil-agent-bg,#1d293b);border:1px solid #40516b;border-radius:14px;padding:12px}.row{display:flex;gap:6px}input,button{min-height:40px;border-radius:9px;border:1px solid #52647d;padding:8px;background:#26384f;color:inherit}input{flex:1;min-width:0}button{font-weight:700}.answer{white-space:pre-wrap;line-height:1.5;color:#bdcce0;font-size:12px;margin-top:8px}</style><section class="panel"><b>MUNGIL AI Assistant</b><p style="font-size:12px;color:#aab8ca">Tanya tentang engine, physics, collision, project, atau debugging.</p><div class="row"><input aria-label="Pertanyaan" placeholder="Contoh: jelaskan fixed timestep"><button type="button">Tanya</button></div><div class="answer" role="status">MCP bridge belum tersambung.</div></section>`;
      const input=s.querySelector('input'),button=s.querySelector('button'),answer=s.querySelector('.answer');
      button.addEventListener('click',()=>{const prompt=input.value.trim();if(!prompt)return;answer.textContent='Mengirim permintaan ke host MCP…';const requestId='mungil-'+Date.now();const onResult=e=>{if(e.detail?.requestId!==requestId)return;root.removeEventListener('mungil:agent-result',onResult);answer.textContent=String(e.detail.text||'Tidak ada jawaban.')};root.addEventListener('mungil:agent-result',onResult);root.dispatchEvent(new CustomEvent('mungil:agent-request',{detail:{requestId,tool:'mungil.explain_engine',arguments:{topic:prompt}},bubbles:true,composed:true}));});
    }
  }
  root.customElements.define('mungil-ai-assistant',MungilAIAssistant);
})(typeof window!=='undefined'?window:null);
