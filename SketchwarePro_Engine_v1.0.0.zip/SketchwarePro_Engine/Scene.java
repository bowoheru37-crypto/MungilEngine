package com.sketchwarepro.engine.core;

/*
 * Sketchware Pro v7.0.0 — Scene Base Class
 * Abstract class untuk semua scene/game screen.
 * Lifecycle: onCreate → onResume → [update/render loop] → onPause → onDestroy
 */

import android.content.Context;
import android.graphics.Canvas;

public abstract class Scene {

    protected Context context;
    protected int screenWidth = 0;
    protected int screenHeight = 0;
    protected boolean isActive = false;

    /** Dipanggil sekali saat scene pertama kali dibuat */
    public void onCreate(Context ctx) {
        this.context = ctx;
    }

    /** Dipanggil saat scene menjadi aktif (masuk ke screen) */
    public void onResume() {
        isActive = true;
    }

    /** Dipanggil setiap frame untuk update logic */
    public abstract void update(float deltaTime);

    /** Dipanggil setiap frame untuk render grafik */
    public abstract void render(Canvas canvas);

    /** Dipanggil saat scene tidak lagi aktif */
    public void onPause() {
        isActive = false;
    }

    /** Dipanggil saat scene dihancurkan (cleanup memory) */
    public void onDestroy() {
        isActive = false;
        context = null;
    }

    /** Dipanggil saat ukuran screen berubah (rotate/resize) */
    public void onResize(int width, int height) {
        this.screenWidth = width;
        this.screenHeight = height;
    }

    /** Helper: cek apakah scene sedang aktif */
    public boolean isActive() {
        return isActive;
    }

    /** Helper: get screen center X */
    public float getCenterX() {
        return screenWidth / 2f;
    }

    /** Helper: get screen center Y */
    public float getCenterY() {
        return screenHeight / 2f;
    }
}
