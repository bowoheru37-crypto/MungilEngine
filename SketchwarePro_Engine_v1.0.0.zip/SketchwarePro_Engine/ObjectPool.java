package com.sketchwarepro.engine.pool;

/*
 * Sketchware Pro v7.0.0 — Object Pool
 * Generic object pool untuk mengurangi garbage collection pressure.
 * Sangat penting untuk game agar tidak lag saat GC berjalan.
 *
 * PENGGUNAAN:
 *   ObjectPool<Entity> pool = new ObjectPool<>(50, () -> new Entity());
 *   Entity e = pool.obtain();     // Ambil dari pool (atau buat baru)
 *   // ... gunakan entity ...
 *   pool.free(e);                  // Kembalikan ke pool (reset otomatis)
 */

import java.util.ArrayDeque;
import java.util.Queue;

public class ObjectPool<T extends Poolable> {

    private final Queue<T> pool;
    private final PoolFactory<T> factory;
    private final int maxSize;
    private int created = 0;
    private int obtained = 0;
    private int freed = 0;

    public ObjectPool(int initialSize, PoolFactory<T> factory) {
        this(initialSize, initialSize * 2, factory);
    }

    public ObjectPool(int initialSize, int maxSize, PoolFactory<T> factory) {
        this.maxSize = maxSize;
        this.factory = factory;
        this.pool = new ArrayDeque<>(initialSize);

        // Pre-warm pool
        for (int i = 0; i < initialSize; i++) {
            T obj = factory.create();
            obj.setPooled(true);
            pool.offer(obj);
            created++;
        }
    }

    /** Ambil objek dari pool. Jika pool kosong, buat objek baru. */
    public T obtain() {
        T obj = pool.poll();
        if (obj == null) {
            obj = factory.create();
            obj.setPooled(true);
            created++;
        }
        obj.reset();
        obj.setPooled(false);
        obtained++;
        return obj;
    }

    /** Kembalikan objek ke pool. */
    public void free(T obj) {
        if (obj == null) return;
        if (pool.size() < maxSize) {
            obj.reset();
            obj.setPooled(true);
            pool.offer(obj);
            freed++;
        }
        // Jika pool penuh, objek akan di-GC (tidak apa-apa)
    }

    /** Kembalikan banyak objek sekaligus. */
    public void freeAll(java.util.List<T> objects) {
        for (int i = 0; i < objects.size(); i++) {
            free(objects.get(i));
        }
    }

    /** Clear semua objek di pool. */
    public void clear() {
        pool.clear();
    }

    /** Jumlah objek yang tersedia di pool. */
    public int size() {
        return pool.size();
    }

    /** Jumlah objek yang pernah dibuat. */
    public int getCreated() {
        return created;
    }

    /** Jumlah objek yang pernah di-obtain. */
    public int getObtained() {
        return obtained;
    }

    /** Jumlah objek yang pernah di-free. */
    public int getFreed() {
        return freed;
    }

    /** Interface untuk factory. */
    public interface PoolFactory<T> {
        T create();
    }
}
