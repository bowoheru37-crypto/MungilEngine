package com.sketchwarepro.engine.core;

/*
 * Sketchware Pro v7.0.0 — Core Engine
 * Optimal | Stabil | Efisien | Praktis | Compact | Ringan
 * Versi: 1.0.0 | 2026-09-07 | MIT License
 *
 * DESKRIPSI:
 * CoreEngine adalah inti dari game engine. Menangani game loop,
 * rendering, FPS control, dan lifecycle. Dirancang untuk berjalan
 * mulus di device low-end hingga high-end.
 */

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.os.SystemClock;
import android.util.Log;
import android.view.Choreographer;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public final class CoreEngine implements Choreographer.FrameCallback, SurfaceHolder.Callback {

    private static final String TAG = "CoreEngine";
    public static final int FPS_30 = 30;
    public static final int FPS_60 = 60;
    public static final int FPS_120 = 120;
    public static final int FPS_UNLIMITED = 0;

    private static volatile CoreEngine instance;

    public static CoreEngine getInstance() {
        if (instance == null) {
            synchronized (CoreEngine.class) {
                if (instance == null) {
                    instance = new CoreEngine();
                }
            }
        }
        return instance;
    }

    private final AtomicBoolean isRunning = new AtomicBoolean(false);
    private final AtomicBoolean isPaused = new AtomicBoolean(false);
    private final AtomicInteger targetFPS = new AtomicInteger(FPS_60);
    private final AtomicBoolean showFPS = new AtomicBoolean(false);

    private long lastFrameTime = 0;
    private float deltaTime = 0f;
    private float accumulator = 0f;
    private final float fixedTimeStep = 1f / 60f;

    private int fps = 0;
    private int frameCount = 0;
    private long fpsTimer = 0;

    private Context context;
    private SurfaceView surfaceView;
    private SurfaceHolder surfaceHolder;
    private Choreographer choreographer;
    private Scene currentScene;
    private EngineCallbacks callbacks;

    private CoreEngine() {}

    public synchronized void init(Context ctx, SurfaceView sv) {
        if (this.context != null) return;
        this.context = ctx.getApplicationContext();
        this.surfaceView = sv;
        this.surfaceHolder = sv.getHolder();
        this.choreographer = Choreographer.getInstance();
        surfaceHolder.setFormat(PixelFormat.TRANSPARENT);
        surfaceHolder.addCallback(this);
        Log.i(TAG, "CoreEngine initialized");
    }

    public synchronized void setScene(Scene scene) {
        if (currentScene != null) {
            currentScene.onDestroy();
        }
        currentScene = scene;
        if (scene != null) {
            scene.onCreate(context);
        }
    }

    public void setTargetFPS(int fps) {
        targetFPS.set(fps);
    }

    public void setShowFPS(boolean show) {
        showFPS.set(show);
    }

    public void setCallbacks(EngineCallbacks cb) {
        this.callbacks = cb;
    }

    public synchronized void start() {
        if (isRunning.get()) return;
        isRunning.set(true);
        isPaused.set(false);
        lastFrameTime = SystemClock.elapsedRealtime();
        fpsTimer = lastFrameTime;
        choreographer.postFrameCallback(this);
        Log.i(TAG, "Engine started");
    }

    public synchronized void pause() {
        isPaused.set(true);
        choreographer.removeFrameCallback(this);
        if (currentScene != null) currentScene.onPause();
        Log.i(TAG, "Engine paused");
    }

    public synchronized void resume() {
        if (!isRunning.get()) return;
        isPaused.set(false);
        lastFrameTime = SystemClock.elapsedRealtime();
        choreographer.postFrameCallback(this);
        if (currentScene != null) currentScene.onResume();
        Log.i(TAG, "Engine resumed");
    }

    public synchronized void stop() {
        isRunning.set(false);
        isPaused.set(false);
        choreographer.removeFrameCallback(this);
        if (currentScene != null) {
            currentScene.onDestroy();
            currentScene = null;
        }
        Log.i(TAG, "Engine stopped");
    }

    @Override
    public void doFrame(long frameTimeNanos) {
        if (!isRunning.get() || isPaused.get()) return;

        long now = SystemClock.elapsedRealtime();
        deltaTime = (now - lastFrameTime) / 1000f;
        lastFrameTime = now;

        if (deltaTime > 0.25f) deltaTime = 0.25f;

        int target = targetFPS.get();
        if (target > 0) {
            long frameDuration = 1000L / target;
            long elapsed = now - lastFrameTime + (long)(deltaTime * 1000);
            if (elapsed < frameDuration) {
                try {
                    Thread.sleep(frameDuration - elapsed);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }

        update(deltaTime);
        render();

        frameCount++;
        if (now - fpsTimer >= 1000) {
            fps = frameCount;
            frameCount = 0;
            fpsTimer = now;
            if (showFPS.get()) {
                Log.d(TAG, "FPS: " + fps);
            }
        }

        if (isRunning.get() && !isPaused.get()) {
            choreographer.postFrameCallback(this);
        }
    }

    private void update(float dt) {
        if (currentScene != null) {
            accumulator += dt;
            while (accumulator >= fixedTimeStep) {
                currentScene.update(fixedTimeStep);
                accumulator -= fixedTimeStep;
            }
            currentScene.update(dt);
        }
        if (callbacks != null) callbacks.onUpdate(dt);
    }

    private void render() {
        if (surfaceHolder == null) return;
        Canvas canvas = null;
        try {
            canvas = surfaceHolder.lockCanvas();
            if (canvas != null) {
                canvas.drawColor(0, PorterDuff.Mode.CLEAR);
                if (currentScene != null) {
                    currentScene.render(canvas);
                }
                if (showFPS.get()) {
                    renderFPS(canvas);
                }
                if (callbacks != null) callbacks.onRender(canvas);
            }
        } catch (Exception e) {
            Log.e(TAG, "Render error", e);
        } finally {
            if (canvas != null) {
                try {
                    surfaceHolder.unlockCanvasAndPost(canvas);
                } catch (Exception e) {
                    Log.e(TAG, "Unlock canvas error", e);
                }
            }
        }
    }

    private void renderFPS(Canvas canvas) {
        android.graphics.Paint paint = new android.graphics.Paint();
        paint.setColor(android.graphics.Color.GREEN);
        paint.setTextSize(40);
        paint.setShadowLayer(2, 1, 1, android.graphics.Color.BLACK);
        canvas.drawText("FPS: " + fps, 20, 50, paint);
    }

    public float getDeltaTime() { return deltaTime; }
    public int getFPS() { return fps; }
    public boolean isRunning() { return isRunning.get(); }
    public boolean isPaused() { return isPaused.get(); }
    public Scene getCurrentScene() { return currentScene; }
    public Context getContext() { return context; }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        Log.i(TAG, "Surface created");
        if (isRunning.get() && isPaused.get()) {
            resume();
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        Log.i(TAG, "Surface changed: " + width + "x" + height);
        if (currentScene != null) {
            currentScene.onResize(width, height);
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        Log.i(TAG, "Surface destroyed");
        pause();
    }

    public interface EngineCallbacks {
        void onUpdate(float deltaTime);
        void onRender(Canvas canvas);
    }
}
