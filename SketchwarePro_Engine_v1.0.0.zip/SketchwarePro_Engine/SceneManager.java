package com.sketchwarepro.engine.core;

/*
 * Sketchware Pro v7.0.0 — Scene Manager
 * Manajemen navigasi antar scene dengan transition support.
 * Stack-based scene management (push/pop/peek).
 */

import android.content.Context;
import java.util.ArrayDeque;
import java.util.Deque;

public class SceneManager {

    private static volatile SceneManager instance;

    public static SceneManager getInstance() {
        if (instance == null) {
            synchronized (SceneManager.class) {
                if (instance == null) {
                    instance = new SceneManager();
                }
            }
        }
        return instance;
    }

    private final Deque<Scene> sceneStack = new ArrayDeque<>();
    private Scene currentScene;
    private Context context;
    private CoreEngine engine;

    private SceneManager() {}

    public void init(Context ctx, CoreEngine eng) {
        this.context = ctx.getApplicationContext();
        this.engine = eng;
    }

    /** Ganti scene (tidak menambah ke stack) */
    public void changeScene(Scene newScene) {
        if (currentScene != null) {
            currentScene.onPause();
            currentScene.onDestroy();
        }
        currentScene = newScene;
        if (newScene != null) {
            newScene.onCreate(context);
            newScene.onResume();
        }
        if (engine != null) {
            engine.setScene(newScene);
        }
    }

    /** Push scene ke stack (overlay) */
    public void pushScene(Scene newScene) {
        if (currentScene != null) {
            currentScene.onPause();
            sceneStack.push(currentScene);
        }
        currentScene = newScene;
        if (newScene != null) {
            newScene.onCreate(context);
            newScene.onResume();
        }
        if (engine != null) {
            engine.setScene(newScene);
        }
    }

    /** Pop scene dari stack (kembali ke scene sebelumnya) */
    public void popScene() {
        if (currentScene != null) {
            currentScene.onPause();
            currentScene.onDestroy();
        }
        if (!sceneStack.isEmpty()) {
            currentScene = sceneStack.pop();
            currentScene.onResume();
        } else {
            currentScene = null;
        }
        if (engine != null) {
            engine.setScene(currentScene);
        }
    }

    /** Pop semua scene dan ganti ke scene baru */
    public void popAllAndChange(Scene newScene) {
        while (!sceneStack.isEmpty()) {
            Scene s = sceneStack.pop();
            s.onDestroy();
        }
        if (currentScene != null) {
            currentScene.onDestroy();
        }
        changeScene(newScene);
    }

    /** Cek apakah ada scene di stack */
    public boolean hasPreviousScene() {
        return !sceneStack.isEmpty();
    }

    /** Get scene aktif */
    public Scene getCurrentScene() {
        return currentScene;
    }

    /** Get jumlah scene di stack */
    public int getStackSize() {
        return sceneStack.size();
    }

    /** Clear semua scene */
    public void clear() {
        while (!sceneStack.isEmpty()) {
            sceneStack.pop().onDestroy();
        }
        if (currentScene != null) {
            currentScene.onDestroy();
            currentScene = null;
        }
    }
}
