package com.sketchwarepro.engine.entity;

/*
 * Sketchware Pro v7.0.0 — Sprite Component
 * Komponen untuk render bitmap/image pada Entity.
 * Support: flip, tint, alpha, custom pivot.
 */

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

public class SpriteComponent extends Component {

    private Bitmap bitmap;
    private Rect srcRect;
    private RectF dstRect;
    private float pivotX = 0.5f; // 0 = left, 0.5 = center, 1 = right
    private float pivotY = 0.5f; // 0 = top, 0.5 = center, 1 = bottom
    private boolean flipX = false;
    private boolean flipY = false;

    public SpriteComponent() {
        dstRect = new RectF();
    }

    public SpriteComponent(Bitmap bitmap) {
        this();
        setBitmap(bitmap);
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
        if (bitmap != null) {
            srcRect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
            if (owner != null) {
                owner.width = bitmap.getWidth();
                owner.height = bitmap.getHeight();
            }
        }
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setPivot(float x, float y) {
        this.pivotX = x;
        this.pivotY = y;
    }

    public void setFlip(boolean x, boolean y) {
        this.flipX = x;
        this.flipY = y;
    }

    @Override
    public void update(Entity entity, float deltaTime) {
        // Sprite tidak perlu update logic
    }

    @Override
    public void render(Entity entity, Canvas canvas, Paint paint) {
        if (bitmap == null || bitmap.isRecycled()) return;

        float w = entity.width * entity.scaleX;
        float h = entity.height * entity.scaleY;
        float x = -w * pivotX;
        float y = -h * pivotY;

        dstRect.set(x, y, x + w, y + h);

        canvas.save();
        if (flipX || flipY) {
            canvas.scale(flipX ? -1 : 1, flipY ? -1 : 1, 0, 0);
        }
        canvas.drawBitmap(bitmap, srcRect, dstRect, paint);
        canvas.restore();
    }
}
