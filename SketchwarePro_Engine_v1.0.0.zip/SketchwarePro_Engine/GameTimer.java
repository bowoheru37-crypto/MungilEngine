package com.sketchwarepro.engine.util;

/*
 * Sketchware Pro v7.0.0 — Game Timer
 * Timer untuk cooldown, delay, countdown, dan interval.
 * Frame-independent: menggunakan delta time.
 */

public class GameTimer {

    private float elapsed = 0f;
    private float duration = 0f;
    private boolean running = false;
    private boolean loop = false;
    private boolean completed = false;
    private Runnable onComplete;

    public GameTimer() {}

    public GameTimer(float duration) {
        this.duration = duration;
    }

    // ===== CONTROL =====

    public void start(float duration) {
        this.duration = duration;
        this.elapsed = 0f;
        this.running = true;
        this.completed = false;
    }

    public void start() {
        this.elapsed = 0f;
        this.running = true;
        this.completed = false;
    }

    public void stop() {
        this.running = false;
    }

    public void pause() {
        this.running = false;
    }

    public void resume() {
        if (!completed && elapsed < duration) {
            this.running = true;
        }
    }

    public void reset() {
        this.elapsed = 0f;
        this.completed = false;
    }

    // ===== UPDATE (panggil setiap frame) =====

    public void update(float deltaTime) {
        if (!running || completed) return;

        elapsed += deltaTime;

        if (elapsed >= duration) {
            elapsed = duration;
            completed = true;
            running = loop; // Jika loop, continue running

            if (onComplete != null) {
                onComplete.run();
            }

            if (loop) {
                elapsed = 0f;
                completed = false;
            }
        }
    }

    // ===== GETTERS =====

    public float getElapsed() {
        return elapsed;
    }

    public float getDuration() {
        return duration;
    }

    public float getRemaining() {
        return Math.max(0f, duration - elapsed);
    }

    public float getProgress() {
        if (duration <= 0) return 1f;
        return Math.min(1f, elapsed / duration);
    }

    public boolean isRunning() {
        return running;
    }

    public boolean isCompleted() {
        return completed;
    }

    public boolean isLooping() {
        return loop;
    }

    // ===== SETTERS =====

    public void setDuration(float duration) {
        this.duration = duration;
    }

    public void setLoop(boolean loop) {
        this.loop = loop;
    }

    public void setOnComplete(Runnable runnable) {
        this.onComplete = runnable;
    }

    @Override
    public String toString() {
        return String.format("Timer[%.2f/%.2f, %.0f%%]", elapsed, duration, getProgress() * 100);
    }
}
