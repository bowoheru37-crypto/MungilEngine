package com.sketchwarepro.engine.input;

/*
 * Sketchware Pro v7.0.0 — Input Handler
 * Menangani touch input, gesture detection, dan virtual joystick.
 * Single-touch dan multi-touch support.
 * Memory-efficient: tidak allocate objek baru saat runtime.
 */

import android.view.MotionEvent;
import android.view.View;
import com.sketchwarepro.engine.math.Vector2D;
import java.util.ArrayList;
import java.util.List;

public class InputHandler implements View.OnTouchListener {

    // ===== SINGLETON =====
    private static volatile InputHandler instance;

    public static InputHandler getInstance() {
        if (instance == null) {
            synchronized (InputHandler.class) {
                if (instance == null) {
                    instance = new InputHandler();
                }
            }
        }
        return instance;
    }

    // ===== STATE =====
    private final Vector2D touchPos = new Vector2D();
    private final Vector2D previousTouchPos = new Vector2D();
    private final Vector2D deltaPos = new Vector2D();

    private boolean isTouching = false;
    private boolean wasTouching = false;
    private boolean isTouchDown = false;
    private boolean isTouchUp = false;
    private boolean isTouchDragged = false;

    // ===== GESTURE =====
    private long touchStartTime = 0;
    private float touchStartX = 0;
    private float touchStartY = 0;
    private static final float TAP_THRESHOLD = 20f;
    private static final long TAP_TIME_THRESHOLD = 200;

    // ===== MULTI-TOUCH =====
    private final List<Vector2D> touchPoints = new ArrayList<>();
    private int pointerCount = 0;

    // ===== LISTENERS =====
    private final List<InputListener> listeners = new ArrayList<>();

    private InputHandler() {
        for (int i = 0; i < 10; i++) {
            touchPoints.add(new Vector2D());
        }
    }

    // ===== ATTACH =====

    public void attachTo(View view) {
        view.setOnTouchListener(this);
    }

    // ===== UPDATE (panggil di awal setiap frame) =====

    public void update() {
        isTouchDown = isTouching && !wasTouching;
        isTouchUp = !isTouching && wasTouching;
        isTouchDragged = isTouching && wasTouching && deltaPos.len2() > 0.1f;
        wasTouching = isTouching;
        deltaPos.set(0, 0);
    }

    // ===== TOUCH LISTENER =====

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        pointerCount = event.getPointerCount();

        // Update semua touch points
        for (int i = 0; i < pointerCount && i < touchPoints.size(); i++) {
            touchPoints.get(i).set(event.getX(i), event.getY(i));
        }

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                isTouching = true;
                touchPos.set(event.getX(), event.getY());
                previousTouchPos.set(touchPos);
                touchStartX = touchPos.x;
                touchStartY = touchPos.y;
                touchStartTime = System.currentTimeMillis();
                notifyTouchDown(touchPos.x, touchPos.y);
                break;

            case MotionEvent.ACTION_MOVE:
                previousTouchPos.set(touchPos);
                touchPos.set(event.getX(), event.getY());
                deltaPos.set(touchPos.x - previousTouchPos.x, touchPos.y - previousTouchPos.y);
                notifyTouchDragged(touchPos.x, touchPos.y, deltaPos.x, deltaPos.y);
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_CANCEL:
                float dx = touchPos.x - touchStartX;
                float dy = touchPos.y - touchStartY;
                long dt = System.currentTimeMillis() - touchStartTime;

                // Detect tap
                if (Math.abs(dx) < TAP_THRESHOLD && Math.abs(dy) < TAP_THRESHOLD
                        && dt < TAP_TIME_THRESHOLD) {
                    notifyTap(touchPos.x, touchPos.y);
                }

                isTouching = false;
                notifyTouchUp(touchPos.x, touchPos.y);
                break;
        }

        return true;
    }

    // ===== GETTERS =====

    public float getX() { return touchPos.x; }
    public float getY() { return touchPos.y; }
    public float getDeltaX() { return deltaPos.x; }
    public float getDeltaY() { return deltaPos.y; }
    public boolean isTouching() { return isTouching; }
    public boolean isTouchDown() { return isTouchDown; }
    public boolean isTouchUp() { return isTouchUp; }
    public boolean isTouchDragged() { return isTouchDragged; }
    public int getPointerCount() { return pointerCount; }

    public Vector2D getTouchPos() {
        return touchPos;
    }

    public Vector2D getTouchPoint(int index) {
        if (index >= 0 && index < touchPoints.size()) {
            return touchPoints.get(index);
        }
        return touchPos;
    }

    /** Cek apakah touch berada di dalam area */
    public boolean isTouchInRect(float x, float y, float width, float height) {
        return touchPos.x >= x && touchPos.x <= x + width
                && touchPos.y >= y && touchPos.y <= y + height;
    }

    /** Cek apakah tap terjadi di dalam area */
    public boolean isTapInRect(float x, float y, float width, float height) {
        return isTouchDown && isTouchInRect(x, y, width, height);
    }

    // ===== LISTENER MANAGEMENT =====

    public void addListener(InputListener listener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public void removeListener(InputListener listener) {
        listeners.remove(listener);
    }

    private void notifyTouchDown(float x, float y) {
        for (int i = listeners.size() - 1; i >= 0; i--) {
            listeners.get(i).onTouchDown(x, y);
        }
    }

    private void notifyTouchUp(float x, float y) {
        for (int i = listeners.size() - 1; i >= 0; i--) {
            listeners.get(i).onTouchUp(x, y);
        }
    }

    private void notifyTouchDragged(float x, float y, float dx, float dy) {
        for (int i = listeners.size() - 1; i >= 0; i--) {
            listeners.get(i).onTouchDragged(x, y, dx, dy);
        }
    }

    private void notifyTap(float x, float y) {
        for (int i = listeners.size() - 1; i >= 0; i--) {
            listeners.get(i).onTap(x, y);
        }
    }

    // ===== LISTENER INTERFACE =====

    public interface InputListener {
        void onTouchDown(float x, float y);
        void onTouchUp(float x, float y);
        void onTouchDragged(float x, float y, float dx, float dy);
        void onTap(float x, float y);
    }
}
