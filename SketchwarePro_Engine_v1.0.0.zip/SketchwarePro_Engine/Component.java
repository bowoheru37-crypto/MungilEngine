package com.sketchwarepro.engine.entity;

/*
 * Sketchware Pro v7.0.0 — Component Base Class
 * Base class untuk semua komponen Entity.
 * Komponen adalah unit behavior yang reusable.
 */

import android.graphics.Canvas;
import android.graphics.Paint;

public abstract class Component {

    protected Entity owner;
    protected boolean active = true;

    public void setOwner(Entity entity) {
        this.owner = entity;
    }

    public Entity getOwner() {
        return owner;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    /** Dipanggil setiap frame saat update */
    public abstract void update(Entity entity, float deltaTime);

    /** Dipanggil setiap frame saat render */
    public abstract void render(Entity entity, Canvas canvas, Paint paint);

    /** Dipanggil saat komponen di-attach ke entity */
    public void onAttach() {}

    /** Dipanggil saat komponen di-detach dari entity */
    public void onDetach() {}
}
