package com.sketchwarepro.engine.entity;

/*
 * Sketchware Pro v7.0.0 — Text Component
 * Komponen untuk render text pada Entity.
 * Support: alignment, shadow, outline, multi-line.
 */

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;

public class TextComponent extends Component {

    private String text = "";
    private float textSize = 32f;
    private int textColor = 0xFFFFFFFF;
    private Typeface typeface;
    private Paint.Align align = Paint.Align.CENTER;
    private boolean shadow = false;
    private float shadowRadius = 3f;
    private int shadowColor = 0xFF000000;
    private boolean outline = false;
    private float outlineWidth = 2f;
    private int outlineColor = 0xFF000000;

    public TextComponent() {}

    public TextComponent(String text) {
        this.text = text;
    }

    public void setText(String text) {
        this.text = text != null ? text : "";
    }

    public String getText() {
        return text;
    }

    public void setTextSize(float size) {
        this.textSize = size;
    }

    public void setTextColor(int color) {
        this.textColor = color;
    }

    public void setAlign(Paint.Align align) {
        this.align = align;
    }

    public void setTypeface(Typeface tf) {
        this.typeface = tf;
    }

    public void setShadow(boolean enabled, float radius, int color) {
        this.shadow = enabled;
        this.shadowRadius = radius;
        this.shadowColor = color;
    }

    public void setOutline(boolean enabled, float width, int color) {
        this.outline = enabled;
        this.outlineWidth = width;
        this.outlineColor = color;
    }

    @Override
    public void update(Entity entity, float deltaTime) {
        // Text tidak perlu update logic
    }

    @Override
    public void render(Entity entity, Canvas canvas, Paint paint) {
        if (text.isEmpty()) return;

        paint.setTextSize(textSize);
        paint.setColor(textColor);
        paint.setTextAlign(align);
        paint.setTypeface(typeface);

        float x = 0;
        float y = paint.descent() - paint.ascent();
        y /= 2;
        y -= paint.descent();

        if (shadow) {
            paint.setShadowLayer(shadowRadius, 1, 1, shadowColor);
        }

        if (outline) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(outlineWidth);
            paint.setColor(outlineColor);
            canvas.drawText(text, x, y, paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(textColor);
        }

        canvas.drawText(text, x, y, paint);

        if (shadow) {
            paint.clearShadowLayer();
        }
    }
}
