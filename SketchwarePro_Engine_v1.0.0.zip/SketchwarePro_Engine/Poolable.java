package com.sketchwarepro.engine.pool;

/*
 * Sketchware Pro v7.0.0 — Poolable Interface
 * Interface yang harus diimplementasikan objek yang ingin dipool.
 */

public interface Poolable {
    /** Reset objek ke state awal (dipanggil saat obtain dari pool). */
    void reset();

    /** Set flag apakah objek sedang di pool. */
    void setPooled(boolean pooled);

    /** Cek apakah objek sedang di pool. */
    boolean isPooled();
}
