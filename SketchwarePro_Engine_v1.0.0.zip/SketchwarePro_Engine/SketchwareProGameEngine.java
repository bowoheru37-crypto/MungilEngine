package com.sketchwarepro.engine;

/*
 * Sketchware Pro v7.0.0 — SketchwareProGameEngine (Facade)
 * ===================================================================
 * MAIN FACADE — Entry point untuk semua fitur engine.
 * Menggabungkan CoreEngine, SceneManager, InputHandler, ResourceManager
 * dalam satu API yang simple dan intuitif.
 *
 * DESAIN: "Simple, Practical, Intuitive"
 * Semua kompleksitas di-abstraksi. Developer hanya panggil method
 * yang diperlukan tanpa perlu tahu detail internal.
 *
 * PENGGUNAAN DI SKETCHWARE PRO:
 *   // Di onCreate Activity:
 *   SketchwareProGameEngine engine = new SketchwareProGameEngine();
 *   engine.init(this, surfaceView);
 *   engine.setFPS(60);
 *   engine.loadScene(new MyGameScene());
 *   engine.start();
 *
 *   // Di onPause:
 *   engine.pause();
 *
 *   // Di onResume:
 *   engine.resume();
 *
 *   // Di onDestroy:
 *   engine.dispose();
 *
 * FITUR:
 * + One-line initialization
 * + Auto lifecycle management
 * + Built-in FPS counter toggle
 * + Auto memory cleanup
 * + Error handling & logging
 * + Battery optimization
 */

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.util.Log;
import android.view.SurfaceView;

import com.sketchwarepro.engine.core.CoreEngine;
import com.sketchwarepro.engine.core.Scene;
import com.sketchwarepro.engine.core.SceneManager;
import com.sketchwarepro.engine.input.InputHandler;
import com.sketchwarepro.engine.res.ResourceManager;

public final class SketchwareProGameEngine {

    private static final String TAG = "SWProEngine";

    // ===== SUBSYSTEMS =====
    private CoreEngine coreEngine;
    private SceneManager sceneManager;
    private InputHandler inputHandler;
    private ResourceManager resourceManager;

    // ===== STATE =====
    private boolean initialized = false;
    private boolean started = false;

    // ===== CALLBACKS =====
    private EngineListener listener;

    // ===== CONSTRUCTOR =====
    public SketchwareProGameEngine() {
        Log.i(TAG, "SketchwareProGameEngine v1.0.0 created");
    }

    // ===== INIT =====

    /**
     * Inisialisasi engine. Panggil sekali di onCreate.
     *
     * @param activity    Activity host
     * @param surfaceView SurfaceView untuk rendering
     */
    public void init(Activity activity, SurfaceView surfaceView) {
        if (initialized) {
            Log.w(TAG, "Engine already initialized");
            return;
        }

        Context ctx = activity.getApplicationContext();

        // Init subsystems
        coreEngine = CoreEngine.getInstance();
        coreEngine.init(ctx, surfaceView);

        sceneManager = SceneManager.getInstance();
        sceneManager.init(ctx, coreEngine);

        inputHandler = InputHandler.getInstance();
        inputHandler.attachTo(surfaceView);

        resourceManager = ResourceManager.getInstance();
        resourceManager.init(ctx);

        // Setup engine callbacks
        coreEngine.setCallbacks(new CoreEngine.EngineCallbacks() {
            @Override
            public void onUpdate(float deltaTime) {
                inputHandler.update();
                if (listener != null) {
                    listener.onUpdate(deltaTime);
                }
            }

            @Override
            public void onRender(Canvas canvas) {
                if (listener != null) {
                    listener.onRender(canvas);
                }
            }
        });

        initialized = true;
        Log.i(TAG, "Engine initialized successfully");
    }

    // ===== SCENE MANAGEMENT =====

    /** Ganti scene aktif (tidak menambah ke stack) */
    public void loadScene(Scene scene) {
        checkInit();
        sceneManager.changeScene(scene);
    }

    /** Push scene ke stack (overlay/pause menu) */
    public void pushScene(Scene scene) {
        checkInit();
        sceneManager.pushScene(scene);
    }

    /** Pop scene dari stack (kembali ke scene sebelumnya) */
    public void popScene() {
        checkInit();
        sceneManager.popScene();
    }

    /** Get scene aktif */
    public Scene getCurrentScene() {
        return sceneManager.getCurrentScene();
    }

    // ===== LIFECYCLE =====

    /** Mulai engine. Panggil di onResume. */
    public void start() {
        checkInit();
        if (started) return;
        coreEngine.start();
        started = true;
        Log.i(TAG, "Engine started");
    }

    /** Pause engine. Panggil di onPause. */
    public void pause() {
        if (!initialized) return;
        coreEngine.pause();
        Log.i(TAG, "Engine paused");
    }

    /** Resume engine. Panggil di onResume. */
    public void resume() {
        if (!initialized) return;
        coreEngine.resume();
        Log.i(TAG, "Engine resumed");
    }

    /** Hentikan dan cleanup engine. Panggil di onDestroy. */
    public void dispose() {
        if (!initialized) return;
        coreEngine.stop();
        sceneManager.clear();
        resourceManager.dispose();
        initialized = false;
        started = false;
        Log.i(TAG, "Engine disposed");
    }

    // ===== SETTINGS =====

    /** Set target FPS (30, 60, 120, atau 0 = unlimited) */
    public void setFPS(int fps) {
        checkInit();
        coreEngine.setTargetFPS(fps);
    }

    /** Tampilkan/sembunyikan FPS counter di screen */
    public void showFPS(boolean show) {
        checkInit();
        coreEngine.setShowFPS(show);
    }

    // ===== INPUT =====

    /** Get InputHandler untuk cek touch state */
    public InputHandler getInput() {
        return inputHandler;
    }

    // ===== RESOURCES =====

    /** Get ResourceManager untuk load asset */
    public ResourceManager getResources() {
        return resourceManager;
    }

    // ===== INFO =====

    /** Get FPS saat ini */
    public int getCurrentFPS() {
        return coreEngine != null ? coreEngine.getFPS() : 0;
    }

    /** Get delta time (detik) */
    public float getDeltaTime() {
        return coreEngine != null ? coreEngine.getDeltaTime() : 0f;
    }

    /** Cek apakah engine sudah di-init */
    public boolean isInitialized() {
        return initialized;
    }

    /** Cek apakah engine sedang berjalan */
    public boolean isRunning() {
        return coreEngine != null && coreEngine.isRunning();
    }

    // ===== LISTENER =====

    public void setListener(EngineListener listener) {
        this.listener = listener;
    }

    // ===== HELPERS =====

    private void checkInit() {
        if (!initialized) {
            throw new IllegalStateException("Engine not initialized! Call init() first.");
        }
    }

    // ===== LISTENER INTERFACE =====

    public interface EngineListener {
        void onUpdate(float deltaTime);
        void onRender(Canvas canvas);
    }
}
