package com.sketchwarepro.engine.entity;

/*
 * Sketchware Pro v7.0.0 — Entity Component System (ECS)
 * ECS ringan untuk manajemen objek game.
 * Setiap Entity memiliki posisi, rotasi, scale, dan komponen opsional.
 *
 * DESAIN: Minimal allocation, object pooling friendly.
 */

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import com.sketchwarepro.engine.math.Vector2D;
import java.util.ArrayList;
import java.util.List;

public class Entity {

    // ===== TRANSFORM =====
    public final Vector2D position = new Vector2D();
    public final Vector2D velocity = new Vector2D();
    public final Vector2D acceleration = new Vector2D();
    public float rotation = 0f;
    public float scaleX = 1f;
    public float scaleY = 1f;

    // ===== PROPERTIES =====
    public float width = 0f;
    public float height = 0f;
    public boolean visible = true;
    public boolean active = true;
    public String tag = "";
    public int layer = 0;

    // ===== RENDERING =====
    private Paint paint;
    private int color = 0xFFFFFFFF;
    private float alpha = 1f;

    // ===== COMPONENTS =====
    private final List<Component> components = new ArrayList<>();

    // ===== POOLING =====
    public boolean isPooled = false;

    public Entity() {}

    public Entity(float x, float y) {
        position.set(x, y);
    }

    // ===== LIFECYCLE =====

    public void update(float deltaTime) {
        if (!active) return;

        // Physics update
        velocity.x += acceleration.x * deltaTime;
        velocity.y += acceleration.y * deltaTime;
        position.x += velocity.x * deltaTime;
        position.y += velocity.y * deltaTime;

        // Update components
        for (int i = 0; i < components.size(); i++) {
            Component c = components.get(i);
            if (c.isActive()) {
                c.update(this, deltaTime);
            }
        }
    }

    public void render(Canvas canvas) {
        if (!visible || !active || paint == null) return;

        paint.setAlpha((int)(alpha * 255));

        canvas.save();
        canvas.translate(position.x, position.y);
        canvas.rotate(rotation);
        canvas.scale(scaleX, scaleY);

        // Render components
        for (int i = 0; i < components.size(); i++) {
            Component c = components.get(i);
            if (c.isActive()) {
                c.render(this, canvas, paint);
            }
        }

        canvas.restore();
    }

    // ===== COMPONENT MANAGEMENT =====

    public <T extends Component> T addComponent(T component) {
        component.setOwner(this);
        components.add(component);
        return component;
    }

    @SuppressWarnings("unchecked")
    public <T extends Component> T getComponent(Class<T> type) {
        for (int i = 0; i < components.size(); i++) {
            Component c = components.get(i);
            if (type.isInstance(c)) {
                return (T) c;
            }
        }
        return null;
    }

    public <T extends Component> boolean hasComponent(Class<T> type) {
        return getComponent(type) != null;
    }

    public <T extends Component> void removeComponent(Class<T> type) {
        for (int i = components.size() - 1; i >= 0; i--) {
            if (type.isInstance(components.get(i))) {
                components.remove(i);
                return;
            }
        }
    }

    public void clearComponents() {
        components.clear();
    }

    // ===== COLLISION =====

    public RectF getBounds() {
        return new RectF(
            position.x - width / 2,
            position.y - height / 2,
            position.x + width / 2,
            position.y + height / 2
        );
    }

    public boolean intersects(Entity other) {
        return getBounds().intersect(other.getBounds());
    }

    public boolean contains(float x, float y) {
        return getBounds().contains(x, y);
    }

    // ===== RENDERING HELPERS =====

    public void setColor(int color) {
        this.color = color;
        if (paint == null) paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(color);
    }

    public int getColor() {
        return color;
    }

    public void setAlpha(float alpha) {
        this.alpha = Math.max(0f, Math.min(1f, alpha));
    }

    public float getAlpha() {
        return alpha;
    }

    public Paint getPaint() {
        if (paint == null) paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        return paint;
    }

    // ===== RESET (untuk object pooling) =====

    public void reset() {
        position.set(0, 0);
        velocity.set(0, 0);
        acceleration.set(0, 0);
        rotation = 0f;
        scaleX = 1f;
        scaleY = 1f;
        width = 0f;
        height = 0f;
        visible = true;
        active = true;
        tag = "";
        layer = 0;
        alpha = 1f;
        color = 0xFFFFFFFF;
        components.clear();
        isPooled = false;
    }

    @Override
    public String toString() {
        return "Entity[pos=" + position + ", tag=" + tag + ", active=" + active + "]";
    }
}
