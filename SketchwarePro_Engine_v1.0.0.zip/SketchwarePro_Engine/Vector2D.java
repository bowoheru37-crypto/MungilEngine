package com.sketchwarepro.engine.math;

/*
 * Sketchware Pro v7.0.0 — Vector2D Math Utility
 * 2D Vector operations: add, sub, mul, div, dot, cross, normalize, lerp.
 * Zero-allocation design: semua method modify objek ini (tidak buat objek baru).
 * Untuk operasi yang butuh hasil baru, gunakan static methods.
 */

public final class Vector2D {

    public float x;
    public float y;

    public Vector2D() {
        this.x = 0f;
        this.y = 0f;
    }

    public Vector2D(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public Vector2D(Vector2D v) {
        this.x = v.x;
        this.y = v.y;
    }

    // ===== SET =====

    public Vector2D set(float x, float y) {
        this.x = x;
        this.y = y;
        return this;
    }

    public Vector2D set(Vector2D v) {
        this.x = v.x;
        this.y = v.y;
        return this;
    }

    // ===== ADD (modify this) =====

    public Vector2D add(float x, float y) {
        this.x += x;
        this.y += y;
        return this;
    }

    public Vector2D add(Vector2D v) {
        this.x += v.x;
        this.y += v.y;
        return this;
    }

    // ===== SUB (modify this) =====

    public Vector2D sub(float x, float y) {
        this.x -= x;
        this.y -= y;
        return this;
    }

    public Vector2D sub(Vector2D v) {
        this.x -= v.x;
        this.y -= v.y;
        return this;
    }

    // ===== MUL (modify this) =====

    public Vector2D mul(float scalar) {
        this.x *= scalar;
        this.y *= scalar;
        return this;
    }

    public Vector2D mul(float x, float y) {
        this.x *= x;
        this.y *= y;
        return this;
    }

    // ===== DIV (modify this) =====

    public Vector2D div(float scalar) {
        if (scalar != 0) {
            this.x /= scalar;
            this.y /= scalar;
        }
        return this;
    }

    // ===== SCALE =====

    public Vector2D scale(float scalar) {
        return mul(scalar);
    }

    // ===== NEGATE =====

    public Vector2D negate() {
        this.x = -this.x;
        this.y = -this.y;
        return this;
    }

    // ===== LENGTH =====

    public float len() {
        return (float) Math.sqrt(x * x + y * y);
    }

    public float len2() {
        return x * x + y * y;
    }

    // ===== DISTANCE =====

    public float dist(float x, float y) {
        float dx = this.x - x;
        float dy = this.y - y;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    public float dist(Vector2D v) {
        return dist(v.x, v.y);
    }

    public float dist2(float x, float y) {
        float dx = this.x - x;
        float dy = this.y - y;
        return dx * dx + dy * dy;
    }

    public float dist2(Vector2D v) {
        return dist2(v.x, v.y);
    }

    // ===== NORMALIZE =====

    public Vector2D normalize() {
        float len = len();
        if (len > 0) {
            this.x /= len;
            this.y /= len;
        }
        return this;
    }

    public Vector2D nor() {
        return normalize();
    }

    // ===== DOT PRODUCT =====

    public float dot(float x, float y) {
        return this.x * x + this.y * y;
    }

    public float dot(Vector2D v) {
        return dot(v.x, v.y);
    }

    // ===== CROSS PRODUCT (2D scalar) =====

    public float cross(float x, float y) {
        return this.x * y - this.y * x;
    }

    public float cross(Vector2D v) {
        return cross(v.x, v.y);
    }

    // ===== ANGLE =====

    public float angle() {
        return (float) Math.atan2(y, x);
    }

    public float angle(Vector2D v) {
        return (float) Math.atan2(cross(v), dot(v));
    }

    public Vector2D setAngle(float radians) {
        float len = len();
        this.x = len * (float) Math.cos(radians);
        this.y = len * (float) Math.sin(radians);
        return this;
    }

    public Vector2D rotate(float radians) {
        float cos = (float) Math.cos(radians);
        float sin = (float) Math.sin(radians);
        float nx = x * cos - y * sin;
        float ny = x * sin + y * cos;
        this.x = nx;
        this.y = ny;
        return this;
    }

    // ===== CLAMP =====

    public Vector2D clamp(float maxLength) {
        float len2 = len2();
        if (len2 > maxLength * maxLength) {
            float len = (float) Math.sqrt(len2);
            this.x = (this.x / len) * maxLength;
            this.y = (this.y / len) * maxLength;
        }
        return this;
    }

    // ===== LERP =====

    public Vector2D lerp(Vector2D target, float alpha) {
        this.x += (target.x - this.x) * alpha;
        this.y += (target.y - this.y) * alpha;
        return this;
    }

    public Vector2D lerp(float x, float y, float alpha) {
        this.x += (x - this.x) * alpha;
        this.y += (y - this.y) * alpha;
        return this;
    }

    // ===== ZERO / ONE =====

    public Vector2D zero() {
        this.x = 0f;
        this.y = 0f;
        return this;
    }

    public boolean isZero() {
        return x == 0f && y == 0f;
    }

    public boolean isUnit() {
        return Math.abs(len2() - 1f) < 0.0001f;
    }

    // ===== EQUALS =====

    public boolean equals(float x, float y) {
        return this.x == x && this.y == y;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Vector2D v = (Vector2D) obj;
        return Float.compare(v.x, x) == 0 && Float.compare(v.y, y) == 0;
    }

    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }

    // ===== STATIC METHODS (allocate new Vector2D) =====

    public static Vector2D add(Vector2D a, Vector2D b) {
        return new Vector2D(a.x + b.x, a.y + b.y);
    }

    public static Vector2D sub(Vector2D a, Vector2D b) {
        return new Vector2D(a.x - b.x, a.y - b.y);
    }

    public static Vector2D mul(Vector2D v, float scalar) {
        return new Vector2D(v.x * scalar, v.y * scalar);
    }

    public static float dst(float x1, float y1, float x2, float y2) {
        float dx = x2 - x1;
        float dy = y2 - y1;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    public static float dst2(float x1, float y1, float x2, float y2) {
        float dx = x2 - x1;
        float dy = y2 - y1;
        return dx * dx + dy * dy;
    }

    public static Vector2D fromAngle(float radians) {
        return new Vector2D((float) Math.cos(radians), (float) Math.sin(radians));
    }
}
