package com.sketchwarepro.engine.res;

/*
 * Sketchware Pro v7.0.0 — Resource Manager
 * Manajemen asset dengan LRU cache, memory-efficient.
 * Support: Bitmap, Drawable, Sound, String resource.
 * Auto-dispose saat memory pressure.
 */

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.media.SoundPool;
import android.os.Build;
import android.util.Log;
import android.util.LruCache;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ResourceManager {

    private static final String TAG = "ResourceManager";
    private static volatile ResourceManager instance;

    public static ResourceManager getInstance() {
        if (instance == null) {
            synchronized (ResourceManager.class) {
                if (instance == null) {
                    instance = new ResourceManager();
                }
            }
        }
        return instance;
    }

    // ===== CONTEXT =====
    private Context context;

    // ===== BITMAP CACHE (LRU) =====
    private LruCache<String, Bitmap> bitmapCache;

    // ===== SOUND POOL =====
    private SoundPool soundPool;
    private final Map<String, Integer> soundMap = new HashMap<>();
    private final Map<Integer, Integer> streamMap = new HashMap<>();

    // ===== DRAWABLE CACHE =====
    private final Map<String, Drawable> drawableCache = new HashMap<>();

    // ===== STATE =====
    private boolean initialized = false;

    private ResourceManager() {}

    // ===== INIT =====

    public void init(Context ctx) {
        if (initialized) return;
        this.context = ctx.getApplicationContext();

        // Bitmap cache: 1/8 dari max memory
        int maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1024);
        int cacheSize = maxMemory / 8;
        bitmapCache = new LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount() / 1024;
            }
            @Override
            public void entryRemoved(boolean evicted, String key, Bitmap oldValue, Bitmap newValue) {
                if (oldValue != null && !oldValue.isRecycled()) {
                    oldValue.recycle();
                }
            }
        };

        // SoundPool
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            android.media.AudioAttributes attrs = new android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_GAME)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            soundPool = new SoundPool.Builder()
                    .setMaxStreams(16)
                    .setAudioAttributes(attrs)
                    .build();
        } else {
            soundPool = new SoundPool(16, android.media.AudioManager.STREAM_MUSIC, 0);
        }

        initialized = true;
        Log.i(TAG, "ResourceManager initialized. Cache size: " + cacheSize + "KB");
    }

    // ===== BITMAP =====

    public Bitmap getBitmap(String path) {
        if (!initialized) return null;

        Bitmap bmp = bitmapCache.get(path);
        if (bmp != null && !bmp.isRecycled()) {
            return bmp;
        }

        try {
            bmp = BitmapFactory.decodeStream(context.getAssets().open(path));
            if (bmp != null) {
                bitmapCache.put(path, bmp);
            }
        } catch (IOException e) {
            Log.e(TAG, "Failed to load bitmap: " + path, e);
        }
        return bmp;
    }

    public Bitmap getBitmap(int resId) {
        String key = "res_" + resId;
        Bitmap bmp = bitmapCache.get(key);
        if (bmp != null && !bmp.isRecycled()) {
            return bmp;
        }

        bmp = BitmapFactory.decodeResource(context.getResources(), resId);
        if (bmp != null) {
            bitmapCache.put(key, bmp);
        }
        return bmp;
    }

    public void removeBitmap(String path) {
        Bitmap bmp = bitmapCache.remove(path);
        if (bmp != null && !bmp.isRecycled()) {
            bmp.recycle();
        }
    }

    // ===== DRAWABLE =====

    public Drawable getDrawable(int resId) {
        String key = "drawable_" + resId;
        Drawable d = drawableCache.get(key);
        if (d != null) return d;

        d = context.getResources().getDrawable(resId);
        if (d != null) {
            drawableCache.put(key, d);
        }
        return d;
    }

    // ===== SOUND =====

    public int loadSound(String path) {
        if (!initialized || soundPool == null) return -1;

        Integer id = soundMap.get(path);
        if (id != null) return id;

        try {
            int soundId = soundPool.load(context.getAssets().openFd(path), 1);
            soundMap.put(path, soundId);
            return soundId;
        } catch (IOException e) {
            Log.e(TAG, "Failed to load sound: " + path, e);
            return -1;
        }
    }

    public int playSound(int soundId, float volume, boolean loop) {
        if (soundPool == null || soundId == -1) return -1;
        int streamId = soundPool.play(soundId, volume, volume, 1, loop ? -1 : 0, 1f);
        streamMap.put(soundId, streamId);
        return streamId;
    }

    public void stopSound(int soundId) {
        if (soundPool == null) return;
        Integer streamId = streamMap.get(soundId);
        if (streamId != null) {
            soundPool.stop(streamId);
        }
    }

    public void stopAllSounds() {
        if (soundPool == null) return;
        for (Integer streamId : streamMap.values()) {
            soundPool.stop(streamId);
        }
    }

    // ===== STRING =====

    public String getString(int resId) {
        return context.getString(resId);
    }

    public String getString(int resId, Object... formatArgs) {
        return context.getString(resId, formatArgs);
    }

    // ===== MEMORY MANAGEMENT =====

    public void clearBitmapCache() {
        if (bitmapCache != null) {
            bitmapCache.evictAll();
        }
    }

    public void clearDrawableCache() {
        drawableCache.clear();
    }

    public void clearSoundMap() {
        if (soundPool != null) {
            soundPool.release();
        }
        soundMap.clear();
        streamMap.clear();
    }

    public void dispose() {
        clearBitmapCache();
        clearDrawableCache();
        clearSoundMap();
        if (soundPool != null) {
            soundPool.release();
            soundPool = null;
        }
        initialized = false;
        Log.i(TAG, "ResourceManager disposed");
    }

    public long getBitmapCacheSize() {
        return bitmapCache != null ? bitmapCache.size() : 0;
    }

    public long getMaxBitmapCacheSize() {
        return bitmapCache != null ? bitmapCache.maxSize() : 0;
    }
}
