import { useEffect, useRef, useState } from "react";
import { Crosshair, Footprints, Gem, Heart, Sparkles, Swords, Volume2, VolumeX } from "lucide-react";
import { CHAMPS, CHAMP_ORDER, ITEMS, type ChampId, type ItemId } from "@/game/content";
import { createGame, type EndStats, type GameHandle, type HudEls, type RecordStats } from "@/game/createGame";
import type { Phase } from "@/game/sim";
import type { GraphicsMode } from "@/game/performance";

const SWATCH: Record<ChampId, string> = {
  vanguard: "bg-primary text-primary-fg",
  arcanist: "bg-mana text-bg",
  ranger: "bg-ranger text-bg",
};

const ICONS = {
  vanguard: Swords,
  arcanist: Sparkles,
  ranger: Crosshair,
} as const;

const ITEM_ICONS = [Swords, Heart, Gem, Footprints] as const;

function emptyHud(): HudEls {
  return {
    hp: null,
    hpText: null,
    mp: null,
    mpText: null,
    gold: null,
    level: null,
    name: null,
    timer: null,
    kda: null,
    cs: null,
    dawn: null,
    dusk: null,
    objective: null,
    fountain: null,
    buff: null,
    respawn: null,
    shopGold: null,
    shopNote: null,
    cds: [null, null, null, null],
    shades: [null, null, null, null],
    counts: [null, null, null, null],
    minimap: null,
  };
}

export function RiftApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);
  const hud = useRef<HudEls>(emptyHud());
  const gameRef = useRef<GameHandle | null>(null);
  const [phase, setPhase] = useState<Phase>("menu");
  const [champ, setChamp] = useState<ChampId>("vanguard");
  const [shop, setShop] = useState(false);
  const [muted, setMuted] = useState(false);
  const [graphicsMode, setGraphicsMode] = useState<GraphicsMode>("auto");
  const [graphicsPreferenceReady, setGraphicsPreferenceReady] = useState(false);
  const [banner, setBanner] = useState("Three lanes cut a wild rift. Break the far conduit.");
  const [feed, setFeed] = useState<string[]>([]);
  const [record, setRecord] = useState<RecordStats>({ wins: 0, bestKills: 0, bestCs: 0 });
  const [end, setEnd] = useState<EndStats | null>(null);
  const champRef = useRef(champ);
  champRef.current = champ;

  useEffect(() => {
    try {
      const saved = localStorage.getItem("aetherfall-graphics-v1");
      if (saved === "auto" || saved === "eco" || saved === "balanced") setGraphicsMode(saved);
    } catch {
      // Settings remain session-local when browser storage is unavailable.
    }
    setGraphicsPreferenceReady(true);
  }, []);

  useEffect(() => {
    if (!graphicsPreferenceReady) return;
    try {
      localStorage.setItem("aetherfall-graphics-v1", graphicsMode);
    } catch {
      // Gameplay settings are still applied for the current session.
    }
    gameRef.current?.setQuality(graphicsMode);
  }, [graphicsMode, graphicsPreferenceReady]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const overlay = overlayRef.current;
    if (!canvas || !overlay) return;
    const game = createGame(canvas, overlay, hud, {
      onPhase: (next) => {
        setPhase(next);
        if (next === "menu") setShop(false);
      },
      onAnnounce: (text) => {
        if (!text) return;
        setBanner(text);
      },
      onFeed: (text) => {
        setFeed((prev) => [text, ...prev].slice(0, 4));
      },
      onRecord: setRecord,
      onEnd: setEnd,
      onShop: () => setShop((open) => !open),
    });
    gameRef.current = game;
    return () => {
      game.dispose();
      gameRef.current = null;
    };
  }, []);

  const def = CHAMPS[champ];
  const playing = phase === "play" || phase === "pause";

  return (
    <main className="relative h-dvh w-full overflow-hidden bg-bg text-fg">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full touch-none" aria-label="Aetherfall battlefield" />
      <div ref={overlayRef} className="pointer-events-none absolute inset-0 overflow-hidden" />

      {phase === "menu" && (
        <div className="absolute inset-0 flex items-end justify-center px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 md:items-stretch md:justify-start md:p-6">
          <section className="pointer-events-auto flex max-h-[82%] w-full flex-col gap-4 overflow-y-auto rounded-2xl border border-border bg-surface/92 p-4 shadow-lg backdrop-blur-md md:max-h-none md:w-[26rem] md:p-6">
            <header>
              <p className="text-xs font-semibold tracking-widest text-primary uppercase">Open-world rift</p>
              <h1 className="font-display mt-1 text-4xl text-fg">Aetherfall</h1>
              <p className="mt-2 text-sm leading-relaxed text-muted">
                Three siege lanes, jungle shrines, and a roaming colossus shape this living battlefield. Choose a
                champion, then break the enemy conduit. Original score: Light Beyond the Veil.
              </p>
            </header>
            <div className="grid gap-2">
              {CHAMP_ORDER.map((id) => {
                const c = CHAMPS[id];
                const Icon = ICONS[id];
                const on = id === champ;
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => {
                      setChamp(id);
                      gameRef.current?.preview(id);
                    }}
                    className={`flex items-center gap-3 rounded-xl border px-3 py-3 text-left ${on ? "border-primary bg-surface-2" : "border-border bg-bg/40"}`}
                  >
                    <span className={`flex h-11 w-11 items-center justify-center rounded-lg ${SWATCH[id]}`}>
                      <Icon className="size-5" aria-hidden />
                    </span>
                    <span className="min-w-0">
                      <span className="block font-display text-lg leading-tight">{c.name}</span>
                      <span className="block text-xs text-muted">
                        {c.title} · {c.role}
                      </span>
                    </span>
                  </button>
                );
              })}
            </div>
            <p className="text-sm leading-relaxed text-fg">{def.blurb}</p>
            <ul className="grid grid-cols-2 gap-2 text-xs text-muted">
              {def.abilities.map((ab) => (
                <li key={ab.key} className="rounded-lg border border-border bg-bg/50 px-2 py-2">
                  <span className="font-semibold text-primary">{ab.key}</span> {ab.name}
                </li>
              ))}
            </ul>
            <div className="rounded-xl border border-border bg-bg/45 p-3">
              <div className="mb-2 flex items-center justify-between gap-3">
                <span className="text-sm font-semibold text-fg">Graphics profile</span>
                <span className="text-[11px] text-muted">Saved on this device</span>
              </div>
              <div className="grid grid-cols-3 gap-2" role="group" aria-label="Graphics quality">
                {([
                  ["auto", "Auto"],
                  ["eco", "Eco"],
                  ["balanced", "Balanced"],
                ] as const).map(([value, label]) => (
                  <button
                    key={value}
                    type="button"
                    aria-pressed={graphicsMode === value}
                    onClick={() => setGraphicsMode(value)}
                    className={`min-h-11 rounded-lg border px-2 text-xs font-semibold ${graphicsMode === value ? "border-primary bg-primary/15 text-primary" : "border-border bg-surface text-muted"}`}
                  >
                    {label}
                  </button>
                ))}
              </div>
              <p className="mt-2 text-xs leading-relaxed text-muted">
                Auto detects device capability. Eco targets about 30 FPS at 1× render scale with shadows off. Balanced enables shadows and a higher render scale.
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                setFeed([]);
                setEnd(null);
                setShop(false);
                gameRef.current?.start(champRef.current);
              }}
              className="min-h-12 rounded-xl bg-primary px-4 py-3 font-display text-lg text-primary-fg"
            >
              Start Battle
            </button>
            <p className="text-xs leading-relaxed text-muted">
              WASD moves · drag to orbit · Q/E/R/F abilities · B shop. On phones, use the stick and touch buttons.
            </p>
            <p className="text-xs text-muted">
              Victories {record.wins} · best kills {record.bestKills} · best farm {record.bestCs}
            </p>
          </section>
        </div>
      )}

      {playing && (
        <>
          <header className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-2 px-3 pb-3 pt-[max(0.75rem,env(safe-area-inset-top))] md:p-4">
            <div className="pointer-events-auto rounded-xl border border-border bg-surface/85 px-3 py-2 backdrop-blur-md">
              <p className="text-xs tracking-widest text-primary uppercase">Dawn</p>
              <p ref={(el) => { hud.current.dawn = el; }} className="font-display text-2xl leading-none">0</p>
            </div>
            <div className="pointer-events-none max-w-xs text-center">
              <p ref={(el) => { hud.current.timer = el; }} className="font-display text-lg">0:00</p>
              <p ref={(el) => { hud.current.objective = el; }} className="text-xs text-muted">Dusk towers</p>
              <p className="mt-1 hidden text-sm text-fg md:block">{banner}</p>
            </div>
            <div className="flex items-start gap-2">
              <div className="pointer-events-auto rounded-xl border border-border bg-surface/85 px-3 py-2 text-right backdrop-blur-md">
                <p className="text-xs tracking-widest text-accent uppercase">Dusk</p>
                <p ref={(el) => { hud.current.dusk = el; }} className="font-display text-2xl leading-none">0</p>
              </div>
              <button
                type="button"
                className="pointer-events-auto flex h-11 w-11 items-center justify-center rounded-xl border border-border bg-surface/85 text-fg"
                aria-label={muted ? "Unmute" : "Mute"}
                onClick={() => {
                  const next = gameRef.current?.toggleMute() ?? false;
                  setMuted(next);
                }}
              >
                {muted ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
              </button>
            </div>
          </header>

          <canvas
            ref={(el) => { hud.current.minimap = el; }}
            width={168}
            height={168}
            className="pointer-events-none absolute top-28 left-3 h-24 w-24 rounded-xl border border-border bg-surface md:top-24 md:left-auto md:right-3 md:h-40 md:w-40"
            aria-hidden
          />

          <ul className="pointer-events-none absolute top-36 left-3 hidden max-w-xs flex-col gap-1 md:flex">
            {feed.map((line, i) => (
              <li key={`${line}-${i}`} className="rounded-md bg-surface/80 px-2 py-1 text-xs text-fg">
                {line}
              </li>
            ))}
          </ul>

          <div
            ref={(el) => { hud.current.respawn = el; }}
            className="pointer-events-none absolute inset-x-0 top-1/3 hidden items-center justify-center"
          >
            <p className="rounded-xl border border-border bg-surface/90 px-5 py-4 text-center">
              <span className="block text-sm text-muted">Slain. Returning in</span>
              <strong className="font-display text-4xl text-primary">5</strong>
            </p>
          </div>

          <footer className="pointer-events-none absolute inset-x-0 bottom-0 z-10 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 md:p-4">
            <div className="flex items-end gap-3 md:flex-col md:items-center">
              <div className="pointer-events-auto flex shrink-0 flex-col gap-2 md:hidden">
                <Stick onChange={(x, y) => gameRef.current?.setStick(x, y)} />
                <div className="flex gap-2">
                  <CamButton label="Orbit left" onHold={(v) => gameRef.current?.setCamTurn(v ? -1 : 0)} />
                  <CamButton label="Orbit right" onHold={(v) => gameRef.current?.setCamTurn(v ? 1 : 0)} flip />
                </div>
              </div>

              <div className="pointer-events-auto flex min-w-0 flex-1 flex-col gap-2 md:w-full md:max-w-lg md:items-center">
                <p ref={(el) => { hud.current.buff = el; }} className="h-4 text-right text-xs text-primary md:text-center" />
                <div className="w-full rounded-2xl border border-border bg-surface/88 px-3 py-2 backdrop-blur-md">
                  <div className="mb-1 flex items-baseline justify-between gap-2 text-xs">
                    <span className="truncate">
                      Lv <span ref={(el) => { hud.current.level = el; }}>1</span>{" "}
                      <span ref={(el) => { hud.current.name = el; }} className="font-display text-sm text-fg">Kael</span>
                    </span>
                    <span className="shrink-0 text-muted">
                      <span ref={(el) => { hud.current.kda = el; }}>0 / 0 / 0</span>
                      {" · "}
                      <span ref={(el) => { hud.current.cs = el; }}>0 cs</span>
                    </span>
                  </div>
                  <div className="h-4 overflow-hidden rounded-full bg-bg">
                    <div ref={(el) => { hud.current.hp = el; }} className="h-full w-full origin-left bg-accent" />
                  </div>
                  <div className="mt-1 flex justify-between gap-2 text-xs text-muted">
                    <span ref={(el) => { hud.current.hpText = el; }} className="shrink-0">0 / 0</span>
                    <span ref={(el) => { hud.current.fountain = el; }} className="truncate">Roam the rift.</span>
                  </div>
                  <div className="mt-1 h-3 overflow-hidden rounded-full bg-bg">
                    <div ref={(el) => { hud.current.mp = el; }} className="h-full w-full origin-left bg-mana" />
                  </div>
                  <div className="mt-1 flex items-center justify-between gap-2 text-xs">
                    <span ref={(el) => { hud.current.mpText = el; }} className="text-muted">0 / 0</span>
                    <span className="flex items-center gap-2">
                      <span className="rounded-full border border-border bg-bg/70 px-2 py-1 text-primary">
                        <span ref={(el) => { hud.current.gold = el; }}>500</span> g
                      </span>
                      <button
                        type="button"
                        onClick={() => setShop((open) => !open)}
                        className="min-h-11 rounded-full border border-border bg-surface px-3 py-2 text-fg"
                      >
                        Shop
                      </button>
                    </span>
                  </div>
                </div>
                <div className="grid grid-cols-3 justify-items-end gap-2 md:flex md:justify-center">
                  {def.abilities.map((ab, i) => (
                    <button
                      key={ab.key}
                      type="button"
                      title={`${ab.name}: ${ab.blurb}`}
                      onClick={() => gameRef.current?.cast(i)}
                      className="relative h-11 w-11 overflow-hidden rounded-xl border border-border bg-surface-2 text-fg md:h-16 md:w-16"
                    >
                      <span className="font-display text-lg leading-none">{ab.key}</span>
                      <span className="hidden truncate px-1 text-xs text-muted md:block">{ab.name.split(" ")[0]}</span>
                      <span
                        ref={(el) => { hud.current.shades[i] = el; }}
                        className="absolute inset-0 origin-bottom bg-bg/75"
                        style={{ transform: "scaleY(0)" }}
                      />
                      <span
                        ref={(el) => { hud.current.cds[i] = el; }}
                        className="absolute inset-0 flex items-center justify-center text-xs font-semibold"
                      />
                    </button>
                  ))}
                  <button
                    type="button"
                    className="flex h-11 w-11 flex-col items-center justify-center rounded-xl bg-primary text-primary-fg md:hidden"
                    onPointerDown={(e) => {
                      e.currentTarget.setPointerCapture(e.pointerId);
                      gameRef.current?.setAttackHeld(true);
                    }}
                    onPointerUp={(e) => {
                      if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
                      gameRef.current?.setAttackHeld(false);
                    }}
                    onPointerCancel={() => gameRef.current?.setAttackHeld(false)}
                    onLostPointerCapture={() => gameRef.current?.setAttackHeld(false)}
                  >
                    <Swords className="size-4" />
                    <span className="text-xs">Hit</span>
                  </button>
                </div>
              </div>
            </div>
          </footer>

          {shop && (
            <div className="absolute inset-x-3 top-20 z-20 mx-auto max-w-lg rounded-2xl border border-border bg-surface p-4 shadow-lg md:inset-x-auto md:top-auto md:right-6 md:bottom-6 md:w-96">
              <div className="mb-3 flex items-center justify-between">
                <div>
                  <h2 className="font-display text-xl">Quartermaster</h2>
                  <p ref={(el) => { hud.current.shopNote = el; }} className="text-xs text-muted">Fountain</p>
                </div>
                <div className="text-right">
                  <p ref={(el) => { hud.current.shopGold = el; }} className="text-sm text-primary">500 gold</p>
                  <button type="button" className="text-xs text-muted" onClick={() => setShop(false)}>
                    Close
                  </button>
                </div>
              </div>
              <ul className="grid gap-2">
                {ITEMS.map((item, i) => {
                  const Icon = ITEM_ICONS[i] ?? Swords;
                  return (
                    <li key={item.id}>
                      <button
                        type="button"
                        onClick={() => gameRef.current?.buy(item.id as ItemId)}
                        className="flex min-h-12 w-full items-center gap-3 rounded-xl border border-border bg-bg/40 px-3 py-2 text-left"
                      >
                        <Icon className="size-5 text-primary" aria-hidden />
                        <span className="min-w-0 flex-1">
                          <span className="block text-sm">{item.name}</span>
                          <span className="block text-xs text-muted">{item.blurb}</span>
                        </span>
                        <span className="text-right text-xs">
                          <span className="block text-primary">{item.cost}g</span>
                          <span ref={(el) => { hud.current.counts[i] = el; }} className="text-muted">0/3</span>
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          )}
        </>
      )}

      {phase === "pause" && (
        <div className="absolute inset-0 flex items-center justify-center bg-bg/55 p-4">
          <div className="w-full max-w-sm rounded-2xl border border-border bg-surface p-6 text-center">
            <h2 className="font-display text-3xl">Hold</h2>
            <p className="mt-2 text-sm text-muted">The rift waits.</p>
            <button
              type="button"
              className="mt-4 min-h-12 w-full rounded-xl bg-primary text-primary-fg"
              onClick={() => gameRef.current?.togglePause()}
            >
              Resume
            </button>
            <button
              type="button"
              className="mt-2 min-h-12 w-full rounded-xl border border-border"
              onClick={() => gameRef.current?.toMenu()}
            >
              Leave the rift
            </button>
          </div>
        </div>
      )}

      {(phase === "victory" || phase === "defeat") && (
        <div className="absolute inset-0 flex items-center justify-center bg-bg/60 p-4">
          <div className="w-full max-w-sm rounded-2xl border border-border bg-surface p-6 text-center">
            <p className="text-xs tracking-widest text-primary uppercase">{phase === "victory" ? "Dawn holds" : "Dusk holds"}</p>
            <h2 className="font-display mt-1 text-4xl">{phase === "victory" ? "Victory" : "Defeat"}</h2>
            {end && (
              <p className="mt-3 text-sm text-muted">
                {end.name} · level {end.level}
                <br />
                {end.kills} / {end.deaths} / {end.assists} · {end.cs} farm · {end.gold} gold
              </p>
            )}
            <button
              type="button"
              className="mt-5 min-h-12 w-full rounded-xl bg-primary font-display text-lg text-primary-fg"
              onClick={() => {
                setEnd(null);
                gameRef.current?.start(champRef.current);
              }}
            >
              Rematch
            </button>
            <button
              type="button"
              className="mt-2 min-h-12 w-full rounded-xl border border-border"
              onClick={() => gameRef.current?.toMenu()}
            >
              Choose another champion
            </button>
          </div>
        </div>
      )}
    </main>
  );
}

function Stick({ onChange }: { onChange: (x: number, y: number) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const knobRef = useRef<HTMLSpanElement>(null);

  function reset() {
    if (knobRef.current) knobRef.current.style.transform = "translate3d(0, 0, 0)";
    onChange(0, 0);
  }

  function apply(clientX: number, clientY: number) {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const max = r.width * 0.34;
    let dx = clientX - (r.left + r.width / 2);
    let dy = clientY - (r.top + r.height / 2);
    const len = Math.hypot(dx, dy) || 1;
    if (len > max) {
      dx = (dx / len) * max;
      dy = (dy / len) * max;
    }
    if (knobRef.current) knobRef.current.style.transform = `translate3d(${dx}px, ${dy}px, 0)`;
    onChange(dx / max, -dy / max);
  }

  return (
    <div
      ref={ref}
      className="relative h-24 w-24 touch-none rounded-full border border-border bg-surface/80"
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        apply(e.clientX, e.clientY);
      }}
      onPointerMove={(e) => {
        if (e.currentTarget.hasPointerCapture(e.pointerId)) apply(e.clientX, e.clientY);
      }}
      onPointerUp={(e) => {
        if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
        reset();
      }}
      onPointerCancel={reset}
      onLostPointerCapture={reset}
      aria-label="Move"
      role="application"
    >
      <span
        ref={knobRef}
        className="absolute left-[calc(50%-1.375rem)] top-[calc(50%-1.375rem)] h-11 w-11 rounded-full bg-primary will-change-transform"
      />
    </div>
  );
}

function CamButton({ label, onHold, flip }: { label: string; onHold: (down: boolean) => void; flip?: boolean }) {
  return (
    <button
      type="button"
      aria-label={label}
      className="h-11 min-w-11 touch-none rounded-xl border border-border bg-surface/90 px-3 text-sm text-fg"
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        onHold(true);
      }}
      onPointerUp={(e) => {
        if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
        onHold(false);
      }}
      onPointerCancel={() => onHold(false)}
      onLostPointerCapture={() => onHold(false)}
    >
      {flip ? "Right" : "Left"}
    </button>
  );
}
