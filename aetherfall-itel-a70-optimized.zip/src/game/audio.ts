import { parseScore, type Score, type ScoreNote } from "@/game/score";

const ALBUM = [
  "/music/light-beyond-the-veil.mid",
  "/music/a-thousand-silent-stars.mid",
  "/music/where-the-heart-finds-quiet.mid",
  "/music/faith-beyond-the-visible.mid",
  "/music/the-light-we-walk-by.mid",
  "/music/in-every-horizon.mid",
  "/music/the-earth-within-us.mid",
  "/music/when-morning-finds-the-night.mid",
  "/music/when-truth-arrives.mid",
  "/music/light-upon-the-heart.mid",
];

export interface AudioBus {
  unlock: () => void;
  suspend: () => void;
  resume: () => void;
  setMuted: (muted: boolean) => void;
  toggleMuted: () => boolean;
  muted: () => boolean;
  hit: (big?: boolean) => void;
  cast: (kind: string) => void;
  die: () => void;
  level: () => void;
  tower: () => void;
  end: (win: boolean) => void;
  ui: () => void;
  dispose: () => void;
}

export function createAudio(): AudioBus {
  let ctx: AudioContext | null = null;
  let master: GainNode | null = null;
  let music: GainNode | null = null;
  let sfx: GainNode | null = null;
  let isMuted = false;
  let musicStarted = false;
  let score: Score | null = null;
  let scoreOrigin = 0;
  let scoreIndex = 0;
  let pumpTimer = 0;
  let trackIndex = 0;
  let loadingTrack = false;
  let appActive = true;

  function ensure() {
    if (ctx) return;
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new AC({ latencyHint: "interactive" });
    master = ctx.createGain();
    music = ctx.createGain();
    sfx = ctx.createGain();
    music.gain.value = 0.16;
    sfx.gain.value = 0.55;
    master.gain.value = isMuted ? 0 : 0.85;
    music.connect(master);
    sfx.connect(master);
    master.connect(ctx.destination);
  }

  function playNote(note: ScoreNote, when: number) {
    if (!ctx || !music) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = note.wave;
    osc.frequency.setValueAtTime(note.freq, when);
    gain.gain.setValueAtTime(0.0001, when);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, note.gain), when + 0.018);
    gain.gain.exponentialRampToValueAtTime(0.0001, when + note.dur);
    osc.connect(gain);
    gain.connect(music);
    osc.start(when);
    osc.stop(when + note.dur + 0.03);
    osc.onended = () => {
      osc.disconnect();
      gain.disconnect();
    };
  }

  function stopPump() {
    if (pumpTimer) window.clearInterval(pumpTimer);
    pumpTimer = 0;
  }

  function ensurePump() {
    if (appActive && !isMuted && score && !pumpTimer) {
      pumpTimer = window.setInterval(pumpScore, 320);
    }
  }

  function pumpScore() {
    if (!ctx || !music || !score || isMuted) return;
    const now = ctx.currentTime;
    const local = now - scoreOrigin;
    if (local > score.duration) {
      advanceTrack();
      return;
    }
    const horizon = local + 1.15;
    while (scoreIndex < score.notes.length) {
      const note = score.notes[scoreIndex];
      if (!note || note.time > horizon) break;
      scoreIndex += 1;
      const when = scoreOrigin + note.time;
      if (when >= now - 0.03) playNote(note, Math.max(when, now + 0.01));
    }
  }

  function advanceTrack() {
    if (!ctx || loadingTrack) return;
    loadingTrack = true;
    trackIndex = (trackIndex + 1) % ALBUM.length;
    const url = ALBUM[trackIndex] ?? ALBUM[0]!;
    void fetch(url)
      .then((res) => {
        if (!res.ok) throw new Error("score");
        return res.arrayBuffer();
      })
      .then((buf) => {
        const next = parseScore(new Uint8Array(buf));
        if (!next.notes.length || !ctx) throw new Error("empty score");
        score = next;
        scoreOrigin = ctx.currentTime + 0.08;
        scoreIndex = 0;
        loadingTrack = false;
        ensurePump();
      })
      .catch(() => {
        loadingTrack = false;
      });
  }

  function startScore() {
    if (!ctx || !music || musicStarted) return;
    musicStarted = true;
    scoreOrigin = ctx.currentTime + 0.15;
    void fetch(ALBUM[0]!)
      .then((res) => res.arrayBuffer())
      .then((buf) => {
        score = parseScore(new Uint8Array(buf));
        if (!score.notes.length) throw new Error("empty score");
        pumpScore();
        ensurePump();
      })
      .catch(() => {
        musicStarted = false;
        startPad();
      });
  }

  function startPad() {
    if (!ctx || !music || musicStarted) return;
    musicStarted = true;
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 480;
    const g = ctx.createGain();
    g.gain.value = 0.22;
    const mk = (freq: number, type: OscillatorType, detune = 0) => {
      const o = ctx!.createOscillator();
      o.type = type;
      o.frequency.value = freq;
      o.detune.value = detune;
      o.connect(filter);
      o.start();
      return o;
    };
    mk(98, "triangle");
    mk(146.8, "sine", 6);
    mk(196, "sine", -4);
    filter.connect(g);
    g.connect(music);
  }

  function tone(freq: number, dur: number, type: OscillatorType, gain: number, slide = 0) {
    if (!ctx || !sfx || isMuted) return;
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + 0.015);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(sfx);
    o.start(t);
    o.stop(t + dur + 0.02);
    o.onended = () => {
      o.disconnect();
      g.disconnect();
    };
  }

  function noise(dur: number, gain: number) {
    if (!ctx || !sfx || isMuted) return;
    const t = ctx.currentTime;
    const len = Math.floor(ctx.sampleRate * dur);
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const g = ctx.createGain();
    const f = ctx.createBiquadFilter();
    f.type = "highpass";
    f.frequency.value = 400;
    g.gain.value = gain;
    src.connect(f);
    f.connect(g);
    g.connect(sfx);
    src.start(t);
    src.onended = () => {
      src.disconnect();
      g.disconnect();
      f.disconnect();
    };
  }

  return {
    unlock() {
      ensure();
      if (ctx && appActive && ctx.state === "suspended") {
        void ctx.resume().then(ensurePump).catch(() => undefined);
      }
      startScore();
    },
    suspend() {
      appActive = false;
      stopPump();
      if (ctx && ctx.state === "running") void ctx.suspend().catch(() => undefined);
    },
    resume() {
      appActive = true;
      if (!ctx) return;
      if (ctx.state === "suspended") {
        void ctx.resume().then(ensurePump).catch(() => undefined);
      } else {
        ensurePump();
      }
    },
    setMuted(m: boolean) {
      isMuted = m;
      if (master && ctx) master.gain.setTargetAtTime(m ? 0 : 0.85, ctx.currentTime, 0.03);
      if (m) stopPump();
      else if (ctx?.state === "suspended" && appActive) {
        void ctx.resume().then(ensurePump).catch(() => undefined);
      } else ensurePump();
    },
    toggleMuted() {
      this.setMuted(!isMuted);
      return isMuted;
    },
    muted: () => isMuted,
    hit(big) {
      noise(big ? 0.12 : 0.05, big ? 0.35 : 0.18);
      tone(big ? 140 : 220 + Math.random() * 40, big ? 0.16 : 0.07, "square", big ? 0.08 : 0.04, big ? -60 : -80);
    },
    cast(kind: string) {
      if (kind === "dash") tone(180, 0.18, "sawtooth", 0.05, 220);
      else if (kind === "rain" || kind === "aoe") tone(90, 0.28, "triangle", 0.08, -40);
      else tone(420 + Math.random() * 80, 0.12, "sine", 0.06, 140);
    },
    die() {
      tone(180, 0.3, "triangle", 0.08, -120);
    },
    level() {
      tone(523, 0.1, "sine", 0.06);
      tone(659, 0.14, "sine", 0.05);
    },
    tower() {
      tone(80, 0.35, "square", 0.07, -30);
      noise(0.2, 0.25);
    },
    end(win: boolean) {
      if (win) {
        tone(392, 0.15, "triangle", 0.07);
        tone(523, 0.18, "triangle", 0.07);
        tone(659, 0.28, "sine", 0.07);
      } else {
        tone(196, 0.3, "sawtooth", 0.05, -80);
      }
    },
    ui() {
      tone(640, 0.05, "sine", 0.04);
    },
    dispose() {
      stopPump();
      score = null;
      appActive = false;
      if (ctx && ctx.state !== "closed") void ctx.close().catch(() => undefined);
      ctx = null;
      master = null;
      music = null;
      sfx = null;
    },
  };
}
