import test from "node:test";
import assert from "node:assert/strict";
import {
  frameIntervalMs,
  isConstrainedDevice,
  pixelRatioCap,
  resolveGraphicsMode,
  shadowMapSize,
  terrainSegments,
} from "./performance.ts";

test("Auto selects Eco on a coarse-pointer entry-level device", () => {
  const device = { coarsePointer: true, hardwareConcurrency: 8, deviceMemory: 3 };
  assert.equal(isConstrainedDevice(device), true);
  assert.equal(resolveGraphicsMode("auto", device), "eco");
});

test("Auto remains conservative when memory information is unavailable", () => {
  const device = { coarsePointer: true, hardwareConcurrency: 8 };
  assert.equal(isConstrainedDevice(device), true);
  assert.equal(resolveGraphicsMode("auto", device), "eco");
});

test("Auto keeps Balanced on a desktop while explicit choices override detection", () => {
  const desktop = { coarsePointer: false, hardwareConcurrency: 4, deviceMemory: 4 };
  assert.equal(resolveGraphicsMode("auto", desktop), "balanced");
  assert.equal(resolveGraphicsMode("eco", desktop), "eco");
  assert.equal(resolveGraphicsMode("balanced", { coarsePointer: true, hardwareConcurrency: 8 }), "balanced");
});

test("Eco reduces render scale, terrain detail, shadows, and frame rate", () => {
  assert.equal(pixelRatioCap("eco", true), 1);
  assert.equal(terrainSegments("eco"), 56);
  assert.equal(shadowMapSize("eco", true), 0);
  assert.equal(frameIntervalMs("eco", "play", true), 33);
  assert.equal(frameIntervalMs("eco", "pause", true), 84);
});

test("Balanced restores detail and shadows within a mobile-safe render cap", () => {
  assert.equal(pixelRatioCap("balanced", true), 1.25);
  assert.equal(terrainSegments("balanced"), 72);
  assert.equal(shadowMapSize("balanced", true), 512);
  assert.equal(frameIntervalMs("balanced", "play", true), 22);
  assert.equal(frameIntervalMs("balanced", "play", false), 16);
});
