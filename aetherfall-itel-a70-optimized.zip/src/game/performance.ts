export type GraphicsMode = "auto" | "eco" | "balanced";
export type ResolvedGraphicsMode = "eco" | "balanced";
export type GamePhase = "menu" | "play" | "pause" | "victory" | "defeat";

export interface DeviceProfile {
  coarsePointer: boolean;
  hardwareConcurrency: number;
  deviceMemory?: number;
}

export function readDeviceProfile(): DeviceProfile {
  if (typeof window === "undefined" || typeof navigator === "undefined") {
    return { coarsePointer: false, hardwareConcurrency: 4 };
  }

  const nav = navigator as Navigator & { deviceMemory?: number };
  return {
    coarsePointer: window.matchMedia("(pointer: coarse)").matches,
    hardwareConcurrency: nav.hardwareConcurrency || 4,
    deviceMemory: nav.deviceMemory,
  };
}

export function isConstrainedDevice(device: DeviceProfile): boolean {
  if (!device.coarsePointer) return false;
  return (device.deviceMemory !== undefined && device.deviceMemory <= 4) || device.hardwareConcurrency <= 8;
}

export function resolveGraphicsMode(mode: GraphicsMode, device: DeviceProfile): ResolvedGraphicsMode {
  if (mode === "eco") return "eco";
  if (mode === "balanced") return "balanced";
  return isConstrainedDevice(device) ? "eco" : "balanced";
}

export function pixelRatioCap(mode: ResolvedGraphicsMode, coarsePointer: boolean): number {
  if (mode === "eco") return 1;
  return coarsePointer ? 1.25 : 1.5;
}

export function terrainSegments(mode: ResolvedGraphicsMode): number {
  return mode === "eco" ? 56 : 72;
}

export function shadowMapSize(mode: ResolvedGraphicsMode, coarsePointer: boolean): number {
  if (mode === "eco") return 0;
  return coarsePointer ? 512 : 1024;
}

export function frameIntervalMs(mode: ResolvedGraphicsMode, phase: GamePhase, coarsePointer: boolean): number {
  if (phase === "pause") return 84;
  if (phase === "menu") return mode === "eco" ? 40 : 33;
  if (phase === "victory" || phase === "defeat") return 50;
  if (mode === "eco") return 33;
  return coarsePointer ? 22 : 16;
}
