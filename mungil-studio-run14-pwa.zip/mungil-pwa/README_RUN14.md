# MUNGIL Run 14

Run 14 continues the existing MUNGIL project without replacing its core architecture. The standalone Studio is `../mungil-studio-run14.html`; runtime sources are in `aetherfall-workspace/src/game/runtime`; the same Studio and browser runtime are synchronized into the PWA and Android WebView assets.

## Delivered in this increment
- Bounded WebGL2 textured-sprite batching with atlas-backed frames in the existing 2D/2.5D renderer.
- Deterministic sprite-atlas packing/composition and sprite animation clip runtime (loop, once, ping-pong). Studio adds a one-page 512px PNG + JSON atlas export for up to 64 eligible Vault images.
- Bounded particle runtime and existing WebAudio bus/voice manager; clip decoding is capped at 4 MiB compressed, 30 seconds, and a 12 MiB decoded-buffer ceiling.
- Offline glTF 2.0 structural preflight integration; the official Khronos validator is a recommended build/CI adapter, not bundled into the browser runtime.
- Playable offline HTML5 2D platformer vertical-slice export with touch controls, CSP, safe JSON embedding and bounded node/output size. Arbitrary imported binary assets are not embedded.
- Sequential topological scheduling for local generation-agent tasks, with unknown-dependency, duplicate-id, cycle and abort handling.

## Validation
- Runtime unit tests: 84/84 passed.
- Strict TypeScript runtime entry check passed.
- Browser runtime bundle: 28 modules, 220,533 bytes; browser bundle smoke test passed.
- Standalone Studio inline scripts passed Node syntax checks.
- Android release script passed `bash -n`; actual release build is blocked because Android SDK Platform 36 / Build Tools 36.0.0, Gradle 9.6.0, signing and SDK prerequisites are not all present in the environment.

## Important scope limits
This is not a complete all-genre/all-art-style production engine. The preview renderer is 2D/2.5D; there is no complete perspective 3D scene renderer, 10,000-NPC simulation, full-body character system, full PBR pipeline, RTGI/ray tracing, Nanite/Lumen, 50GB virtual textures, advanced water/hair/skin, authoritative multiplayer, anti-cheat kernel, cloud world persistence, production crash telemetry, external LLM service or autonomous model training. The local knowledge base stores sources and agent outcomes; it does not train the model.

Android `minSdk 21` is an installation floor only. It does not guarantee modern WebView JavaScript/WebGL2 support on Android 5. The wrapper has a legacy Canvas2D planner fallback; actual Android 5 and itel A70 testing is still required. No APK/AAB is included in Run 14.
