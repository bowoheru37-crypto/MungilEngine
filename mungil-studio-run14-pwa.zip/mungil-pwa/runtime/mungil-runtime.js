(function(root){
'use strict';
var modules=Object.create(null),cache=Object.create(null);
modules["asset-pipeline.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateAssetBundle = validateAssetBundle;
exports.recommendAssetBuild = recommendAssetBuild;
exports.inspectAssetFiles = inspectAssetFiles;
const MIME_BY_KIND = {
    image: ["image/png", "image/jpeg", "image/webp", "image/avif", "image/gif"],
    texture: ["image/png", "image/jpeg", "image/webp", "image/ktx2", "image/basis"],
    audio: ["audio/ogg", "audio/opus", "audio/mpeg", "audio/wav", "audio/mp4"],
    model: ["model/gltf+json", "model/gltf-binary", "application/octet-stream"],
    font: ["font/woff2", "font/woff", "font/ttf", "application/font-sfnt"],
    data: ["application/json", "application/octet-stream", "text/plain"],
    video: ["video/mp4", "video/webm"],
};
const ID = /^[a-zA-Z0-9_-]{1,80}$/;
const SHA256 = /^[a-f0-9]{64}$/i;
function safeAssetPath(path) {
    if (!path || path.length > 240 || path.startsWith("/") || path.includes("\\") || path.includes("%") || /[\u0000-\u001f\u007f]/.test(path))
        return false;
    let decoded = path;
    for (let i = 0; i < 3; i++) {
        try {
            const next = decodeURIComponent(decoded);
            if (next === decoded)
                break;
            decoded = next;
        }
        catch {
            return false;
        }
    }
    if (decoded.includes("\\") || decoded.startsWith("/") || /[\u0000-\u001f\u007f]/.test(decoded))
        return false;
    const parts = decoded.split("/");
    return parts.every(part => part.length > 0 && part !== "." && part !== "..") && !/^[a-z][a-z0-9+.-]*:/i.test(decoded);
}
/** Validates untrusted imported metadata before any asset bytes are decoded or uploaded. */
function validateAssetBundle(value, budget) {
    var _a, _b, _c, _d, _e, _f;
    if (!Array.isArray(value) || !Number.isSafeInteger(budget.maxAssets) || budget.maxAssets < 1 || !Number.isSafeInteger(budget.maxTotalBytes) || budget.maxTotalBytes < 1 || !Number.isSafeInteger(budget.maxSingleBytes) || budget.maxSingleBytes < 1 || !Number.isSafeInteger(budget.maxTextureDimension) || budget.maxTextureDimension < 1)
        return { ok: false, error: "INVALID_ASSET_BUDGET_OR_LIST" };
    if (value.length > budget.maxAssets)
        return { ok: false, error: "ASSET_COUNT_LIMIT" };
    const ids = new Set();
    const paths = new Set();
    let totalBytes = 0;
    for (const raw of value) {
        if (!raw || typeof raw !== "object")
            return { ok: false, error: "INVALID_ASSET_DESCRIPTOR" };
        const asset = raw;
        if (typeof asset.id !== "string" || !ID.test(asset.id) || ids.has(asset.id))
            return { ok: false, error: "INVALID_OR_DUPLICATE_ASSET_ID" };
        if (typeof asset.path !== "string" || !safeAssetPath(asset.path) || paths.has(asset.path))
            return { ok: false, error: "INVALID_OR_DUPLICATE_ASSET_PATH" };
        if (typeof asset.kind !== "string" || !Object.prototype.hasOwnProperty.call(MIME_BY_KIND, asset.kind) || typeof asset.mime !== "string" || !MIME_BY_KIND[asset.kind].includes(asset.mime))
            return { ok: false, error: "ASSET_MIME_KIND_MISMATCH" };
        if (!Number.isSafeInteger(asset.bytes) || ((_a = asset.bytes) !== null && _a !== void 0 ? _a : 0) < 0 || ((_b = asset.bytes) !== null && _b !== void 0 ? _b : 0) > budget.maxSingleBytes)
            return { ok: false, error: "ASSET_SIZE_LIMIT" };
        if (asset.sha256 !== undefined && (typeof asset.sha256 !== "string" || !SHA256.test(asset.sha256)))
            return { ok: false, error: "INVALID_ASSET_HASH" };
        if (asset.compression !== undefined && !["none", "webp", "basis", "ktx2", "opus", "gzip"].includes(asset.compression))
            return { ok: false, error: "INVALID_ASSET_COMPRESSION" };
        if (asset.kind === "image" || asset.kind === "texture") {
            if (!Number.isSafeInteger(asset.width) || !Number.isSafeInteger(asset.height) || ((_c = asset.width) !== null && _c !== void 0 ? _c : 0) < 1 || ((_d = asset.height) !== null && _d !== void 0 ? _d : 0) < 1 || ((_e = asset.width) !== null && _e !== void 0 ? _e : 0) > budget.maxTextureDimension || ((_f = asset.height) !== null && _f !== void 0 ? _f : 0) > budget.maxTextureDimension)
                return { ok: false, error: "TEXTURE_DIMENSION_LIMIT" };
        }
        totalBytes += asset.bytes;
        if (!Number.isSafeInteger(totalBytes) || totalBytes > budget.maxTotalBytes)
            return { ok: false, error: "ASSET_BUNDLE_BYTE_LIMIT" };
        ids.add(asset.id);
        paths.add(asset.path);
    }
    return { ok: true, totalBytes, assets: value.length };
}
/** Emits a deterministic conversion manifest; actual transcoding is delegated to build-time tools. */
function recommendAssetBuild(assets, tier) {
    const output = [];
    for (const asset of assets) {
        if (asset.kind === "texture" || asset.kind === "image")
            output.push({ id: asset.id, source: asset.path, recommendedCompression: asset.kind === "texture" ? "basis" : "webp", reason: tier === 0 ? "Reduce mobile transfer and GPU memory; cap dimensions before transcoding." : "Use a modern compact image representation and preserve source for fallback." });
        else if (asset.kind === "audio")
            output.push({ id: asset.id, source: asset.path, recommendedCompression: "opus", reason: "Use streaming for long music and short decoded buffers for frequently triggered effects." });
        else if (asset.kind === "data")
            output.push({ id: asset.id, source: asset.path, recommendedCompression: "gzip", reason: "Compress text-like payloads at build time; keep runtime parsing bounded." });
    }
    return output;
}
const DEFAULT_IMPORT_LIMITS = Object.freeze({
    maxFiles: 64,
    maxSingleBytes: 32 * 1024 * 1024,
    maxTotalBytes: 96 * 1024 * 1024,
    maxImageDimension: 4096,
    maxJsonBytes: 2 * 1024 * 1024,
});
function ascii(bytes, offset, length) {
    return String.fromCharCode(...bytes.subarray(offset, offset + length));
}
function u32be(bytes, offset) {
    var _a, _b, _c, _d;
    return ((((_a = bytes[offset]) !== null && _a !== void 0 ? _a : 0) * 0x1000000) + (((_b = bytes[offset + 1]) !== null && _b !== void 0 ? _b : 0) << 16) + (((_c = bytes[offset + 2]) !== null && _c !== void 0 ? _c : 0) << 8) + ((_d = bytes[offset + 3]) !== null && _d !== void 0 ? _d : 0)) >>> 0;
}
function imageDimensions(bytes, mime) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0;
    if (mime === "image/png" && bytes.length >= 24 && ascii(bytes, 0, 8) === "\x89PNG\r\n\x1a\n" && ascii(bytes, 12, 4) === "IHDR")
        return { width: u32be(bytes, 16), height: u32be(bytes, 20) };
    if (mime === "image/gif" && bytes.length >= 10 && (ascii(bytes, 0, 6) === "GIF87a" || ascii(bytes, 0, 6) === "GIF89a"))
        return { width: ((_a = bytes[6]) !== null && _a !== void 0 ? _a : 0) | (((_b = bytes[7]) !== null && _b !== void 0 ? _b : 0) << 8), height: ((_c = bytes[8]) !== null && _c !== void 0 ? _c : 0) | (((_d = bytes[9]) !== null && _d !== void 0 ? _d : 0) << 8) };
    if (mime === "image/webp" && bytes.length >= 30 && ascii(bytes, 0, 4) === "RIFF" && ascii(bytes, 8, 4) === "WEBP") {
        const chunk = ascii(bytes, 12, 4);
        if (chunk === "VP8X")
            return { width: 1 + ((_e = bytes[24]) !== null && _e !== void 0 ? _e : 0) + (((_f = bytes[25]) !== null && _f !== void 0 ? _f : 0) << 8) + (((_g = bytes[26]) !== null && _g !== void 0 ? _g : 0) << 16), height: 1 + ((_h = bytes[27]) !== null && _h !== void 0 ? _h : 0) + (((_j = bytes[28]) !== null && _j !== void 0 ? _j : 0) << 8) + (((_k = bytes[29]) !== null && _k !== void 0 ? _k : 0) << 16) };
        if (chunk === "VP8L" && bytes.length >= 25 && bytes[20] === 0x2f) {
            const b1 = (_l = bytes[21]) !== null && _l !== void 0 ? _l : 0, b2 = (_m = bytes[22]) !== null && _m !== void 0 ? _m : 0, b3 = (_o = bytes[23]) !== null && _o !== void 0 ? _o : 0, b4 = (_p = bytes[24]) !== null && _p !== void 0 ? _p : 0;
            return { width: 1 + (((b2 & 0x3f) << 8) | b1), height: 1 + (((b4 & 0x0f) << 10) | (b3 << 2) | ((b2 & 0xc0) >> 6)) };
        }
        if (chunk === "VP8 " && bytes.length >= 30 && bytes[23] === 0x9d && bytes[24] === 0x01 && bytes[25] === 0x2a)
            return { width: ((((_q = bytes[27]) !== null && _q !== void 0 ? _q : 0) & 0x3f) << 8) | ((_r = bytes[26]) !== null && _r !== void 0 ? _r : 0), height: ((((_s = bytes[29]) !== null && _s !== void 0 ? _s : 0) & 0x3f) << 8) | ((_t = bytes[28]) !== null && _t !== void 0 ? _t : 0) };
    }
    if (mime === "image/jpeg" && bytes.length >= 4 && bytes[0] === 0xff && bytes[1] === 0xd8) {
        let offset = 2;
        while (offset + 4 < bytes.length) {
            if (bytes[offset] !== 0xff) {
                offset++;
                continue;
            }
            const marker = (_u = bytes[offset + 1]) !== null && _u !== void 0 ? _u : 0;
            offset += 2;
            if (marker === 0xd8 || marker === 0xd9 || (marker >= 0xd0 && marker <= 0xd7))
                continue;
            const length = (((_v = bytes[offset]) !== null && _v !== void 0 ? _v : 0) << 8) | ((_w = bytes[offset + 1]) !== null && _w !== void 0 ? _w : 0);
            if (length < 2 || offset + length > bytes.length)
                return null;
            if ([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf].includes(marker) && length >= 7)
                return { height: (((_x = bytes[offset + 3]) !== null && _x !== void 0 ? _x : 0) << 8) | ((_y = bytes[offset + 4]) !== null && _y !== void 0 ? _y : 0), width: (((_z = bytes[offset + 5]) !== null && _z !== void 0 ? _z : 0) << 8) | ((_0 = bytes[offset + 6]) !== null && _0 !== void 0 ? _0 : 0) };
            offset += length;
        }
    }
    return null;
}
function detectAsset(bytes, name) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
    if (bytes.length >= 12 && bytes[0] === 0xab && ascii(bytes, 1, 11) === "KTX 20\xbb\r\n\x1a\n") {
        const width = ((_a = bytes[20]) !== null && _a !== void 0 ? _a : 0) | (((_b = bytes[21]) !== null && _b !== void 0 ? _b : 0) << 8) | (((_c = bytes[22]) !== null && _c !== void 0 ? _c : 0) << 16) | (((_d = bytes[23]) !== null && _d !== void 0 ? _d : 0) << 24);
        const height = ((_e = bytes[24]) !== null && _e !== void 0 ? _e : 0) | (((_f = bytes[25]) !== null && _f !== void 0 ? _f : 0) << 8) | (((_g = bytes[26]) !== null && _g !== void 0 ? _g : 0) << 16) | (((_h = bytes[27]) !== null && _h !== void 0 ? _h : 0) << 24);
        if (bytes.length < 28 || width < 1 || height < 1)
            return null;
        return { kind: "texture", mime: "image/ktx2", width: width >>> 0, height: height >>> 0 };
    }
    if (bytes.length >= 8 && ascii(bytes, 0, 8) === "\x89PNG\r\n\x1a\n")
        return { kind: "image", mime: "image/png", ...imageDimensions(bytes, "image/png") };
    if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff)
        return { kind: "image", mime: "image/jpeg", ...imageDimensions(bytes, "image/jpeg") };
    if (bytes.length >= 12 && ascii(bytes, 0, 4) === "RIFF" && ascii(bytes, 8, 4) === "WEBP")
        return { kind: "image", mime: "image/webp", ...imageDimensions(bytes, "image/webp") };
    if (bytes.length >= 10 && (ascii(bytes, 0, 6) === "GIF87a" || ascii(bytes, 0, 6) === "GIF89a"))
        return { kind: "image", mime: "image/gif", ...imageDimensions(bytes, "image/gif") };
    if (bytes.length >= 12 && ascii(bytes, 0, 4) === "RIFF" && ascii(bytes, 8, 4) === "WAVE")
        return { kind: "audio", mime: "audio/wav" };
    if (bytes.length >= 4 && ascii(bytes, 0, 4) === "OggS")
        return { kind: "audio", mime: "audio/ogg" };
    if (bytes.length >= 3 && (ascii(bytes, 0, 3) === "ID3" || (bytes[0] === 0xff && (((_j = bytes[1]) !== null && _j !== void 0 ? _j : 0) & 0xe0) === 0xe0)))
        return { kind: "audio", mime: "audio/mpeg" };
    if (bytes.length >= 20 && ascii(bytes, 0, 4) === "glTF" && bytes[4] === 2 && (bytes[8] | (bytes[9] << 8) | (bytes[10] << 16) | (bytes[11] << 24)) >>> 0 === bytes.length)
        return { kind: "model", mime: "model/gltf-binary" };
    if (bytes.length >= 4 && ascii(bytes, 0, 4) === "wOF2")
        return { kind: "font", mime: "font/woff2" };
    if (bytes.length >= 4 && ascii(bytes, 0, 4) === "wOFF")
        return { kind: "font", mime: "font/woff" };
    if (bytes.length >= 4 && (ascii(bytes, 0, 4) === "OTTO" || ascii(bytes, 0, 4) === "true" || (bytes[0] === 0 && bytes[1] === 1 && bytes[2] === 0 && bytes[3] === 0)))
        return { kind: "font", mime: "font/ttf" };
    const ext = name.toLowerCase().split(".").pop();
    if (ext === "gltf" || ext === "json") {
        try {
            const parsed = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
            if (parsed && typeof parsed === "object" && "asset" in parsed && ((_k = parsed.asset) === null || _k === void 0 ? void 0 : _k.version) === "2.0")
                return { kind: "model", mime: "model/gltf+json" };
            if (parsed && typeof parsed === "object" && !Array.isArray(parsed))
                return { kind: "data", mime: "application/json" };
        }
        catch {
            return null;
        }
    }
    if (bytes.length >= 4 && ascii(bytes, 0, 4) === "\u001aE\u00df\u00a3")
        return { kind: "video", mime: "video/webm" };
    if (bytes.length >= 12 && ascii(bytes, 4, 4) === "ftyp")
        return { kind: "video", mime: "video/mp4" };
    return null;
}
/** Inspect untrusted files sequentially; metadata comes from file signatures, never the supplied MIME label. */
async function inspectAssetFiles(files, limits = {}, signal) {
    var _a, _b, _c;
    const budget = { ...DEFAULT_IMPORT_LIMITS, ...limits };
    if (!Number.isSafeInteger(budget.maxFiles) || budget.maxFiles < 1 || !Number.isSafeInteger(budget.maxSingleBytes) || budget.maxSingleBytes < 1 || !Number.isSafeInteger(budget.maxTotalBytes) || budget.maxTotalBytes < 1 || !Number.isSafeInteger(budget.maxImageDimension) || budget.maxImageDimension < 1 || !Number.isSafeInteger(budget.maxJsonBytes) || budget.maxJsonBytes < 1)
        return { ok: false, error: "INVALID_IMPORT_LIMITS" };
    if (!Array.isArray(files) || files.length > budget.maxFiles)
        return { ok: false, error: "IMPORT_FILE_COUNT_LIMIT" };
    if (!((_a = globalThis.crypto) === null || _a === void 0 ? void 0 : _a.subtle))
        return { ok: false, error: "CRYPTO_SUBTLE_UNAVAILABLE" };
    const output = [];
    const used = new Set();
    let total = 0;
    for (const file of files) {
        if (signal === null || signal === void 0 ? void 0 : signal.aborted)
            return { ok: false, error: "IMPORT_ABORTED", file: file === null || file === void 0 ? void 0 : file.name };
        if (!file || typeof file.name !== "string" || !file.name || file.name.length > 180 || /[\\/\u0000-\u001f]/.test(file.name) || !Number.isSafeInteger(file.size) || file.size < 1 || file.size > budget.maxSingleBytes)
            return { ok: false, error: "INVALID_FILE_OR_SIZE_LIMIT", file: file === null || file === void 0 ? void 0 : file.name };
        total += file.size;
        if (!Number.isSafeInteger(total) || total > budget.maxTotalBytes)
            return { ok: false, error: "IMPORT_TOTAL_SIZE_LIMIT", file: file.name };
        let buffer;
        try {
            buffer = await file.arrayBuffer();
        }
        catch {
            return { ok: false, error: "FILE_READ_FAILED", file: file.name };
        }
        if (signal === null || signal === void 0 ? void 0 : signal.aborted)
            return { ok: false, error: "IMPORT_ABORTED", file: file.name };
        if (buffer.byteLength !== file.size)
            return { ok: false, error: "FILE_SIZE_CHANGED_DURING_READ", file: file.name };
        const bytes = new Uint8Array(buffer);
        const detected = detectAsset(bytes, file.name);
        if (!detected)
            return { ok: false, error: "UNSUPPORTED_OR_INVALID_FILE_SIGNATURE", file: file.name };
        if (detected.kind === "image" && (!detected.width || !detected.height || detected.width > budget.maxImageDimension || detected.height > budget.maxImageDimension))
            return { ok: false, error: "IMAGE_DIMENSION_INVALID_OR_LIMIT", file: file.name };
        if ((detected.kind === "model" || detected.kind === "data") && file.size > budget.maxJsonBytes && detected.mime !== "model/gltf-binary")
            return { ok: false, error: "JSON_ASSET_SIZE_LIMIT", file: file.name };
        const hash = await globalThis.crypto.subtle.digest("SHA-256", buffer);
        const sha256 = Array.from(new Uint8Array(hash), value => value.toString(16).padStart(2, "0")).join("");
        const base = file.name.replace(/\.[^.]+$/, "").normalize("NFKD").replace(/[^A-Za-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 64) || "asset";
        let id = base;
        let suffix = 2;
        while (used.has(id))
            id = `${base}-${suffix++}`;
        used.add(id);
        output.push(Object.freeze({ id, path: `assets/${id}${(_c = (_b = file.name.match(/\.[^.]+$/)) === null || _b === void 0 ? void 0 : _b[0].toLowerCase()) !== null && _c !== void 0 ? _c : ""}`, kind: detected.kind, mime: detected.mime, bytes: file.size, sha256, ...(detected.width ? { width: detected.width } : {}), ...(detected.height ? { height: detected.height } : {}) }));
    }
    return { ok: true, assets: output, totalBytes: total };
}

};
modules["asset-preview.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fitImagePreview = fitImagePreview;
function fitImagePreview(width, height, options = {}) {
    var _a, _b;
    const maxDimension = (_a = options.maxDimension) !== null && _a !== void 0 ? _a : 384;
    const maxPixels = (_b = options.maxPixels) !== null && _b !== void 0 ? _b : 384 * 384;
    if (![width, height, maxDimension, maxPixels].every(Number.isSafeInteger) || width < 1 || height < 1 || maxDimension < 1 || maxPixels < 1)
        return null;
    const sourcePixels = width * height;
    if (!Number.isSafeInteger(sourcePixels))
        return null;
    const scale = Math.min(1, maxDimension / Math.max(width, height), Math.sqrt(maxPixels / sourcePixels));
    const outWidth = Math.max(1, Math.floor(width * scale));
    const outHeight = Math.max(1, Math.floor(height * scale));
    const pixels = outWidth * outHeight;
    if (!Number.isSafeInteger(pixels) || pixels > maxPixels)
        return null;
    const estimatedRgbaBytes = pixels * 4;
    if (!Number.isSafeInteger(estimatedRgbaBytes))
        return null;
    return Object.freeze({ width: outWidth, height: outHeight, estimatedRgbaBytes });
}

};
modules["asset-vault.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AssetVault = void 0;
exports.assetVaultLimits = assetVaultLimits;
exports.planAssetVaultEviction = planAssetVaultEviction;
const DEFAULT_LIMITS = Object.freeze({
    0: Object.freeze({ maxBytes: 24 * 1024 * 1024, maxSingleBytes: 8 * 1024 * 1024, maxEntries: 128 }),
    1: Object.freeze({ maxBytes: 48 * 1024 * 1024, maxSingleBytes: 16 * 1024 * 1024, maxEntries: 256 }),
    2: Object.freeze({ maxBytes: 96 * 1024 * 1024, maxSingleBytes: 32 * 1024 * 1024, maxEntries: 512 }),
});
const DB_NAME = "mungil-asset-vault";
const DB_VERSION = 1;
const STORE = "assets";
function assetVaultLimits(tier) { return DEFAULT_LIMITS[tier]; }
/** Pure bounded LRU planner. Pinned entries and the incoming asset are never evicted. */
function planAssetVaultEviction(entries, incoming, limits) {
    var _a;
    if (!Number.isSafeInteger(limits.maxBytes) || limits.maxBytes < 1 || !Number.isSafeInteger(limits.maxSingleBytes) || limits.maxSingleBytes < 1 || !Number.isSafeInteger(limits.maxEntries) || limits.maxEntries < 1 || !Number.isSafeInteger(incoming.bytes) || incoming.bytes < 0)
        return { ok: false, error: "INVALID_VAULT_LIMITS" };
    if (incoming.bytes > limits.maxSingleBytes || incoming.bytes > limits.maxBytes)
        return { ok: false, error: "VAULT_SINGLE_ASSET_LIMIT" };
    const seen = new Set();
    let total = 0;
    for (const entry of entries) {
        if (!entry || typeof entry.id !== "string" || !entry.id || seen.has(entry.id) || !Number.isSafeInteger(entry.bytes) || entry.bytes < 0 || !Number.isFinite(entry.lastAccessedAt))
            return { ok: false, error: "INVALID_VAULT_ENTRY" };
        seen.add(entry.id);
        total += entry.bytes;
        if (!Number.isSafeInteger(total))
            return { ok: false, error: "VAULT_SIZE_OVERFLOW" };
    }
    const replacing = entries.find(entry => entry.id === incoming.id);
    let projectedBytes = total - ((_a = replacing === null || replacing === void 0 ? void 0 : replacing.bytes) !== null && _a !== void 0 ? _a : 0) + incoming.bytes;
    let projectedEntries = entries.length + (replacing ? 0 : 1);
    const candidates = entries.filter(entry => entry.id !== incoming.id && !entry.pinned).slice().sort((a, b) => a.lastAccessedAt - b.lastAccessedAt || a.id.localeCompare(b.id));
    const evict = [];
    for (const candidate of candidates) {
        if (projectedBytes <= limits.maxBytes && projectedEntries <= limits.maxEntries)
            break;
        projectedBytes -= candidate.bytes;
        projectedEntries--;
        evict.push(candidate.id);
    }
    if (projectedBytes > limits.maxBytes || projectedEntries > limits.maxEntries)
        return { ok: false, error: "VAULT_CAPACITY_PINNED_OR_EXHAUSTED" };
    return { ok: true, value: Object.freeze(evict) };
}
function requestValue(request) {
    return new Promise((resolve, reject) => {
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => { var _a; return reject((_a = request.error) !== null && _a !== void 0 ? _a : new Error("INDEXEDDB_REQUEST_FAILED")); };
    });
}
function transactionDone(transaction) {
    return new Promise((resolve, reject) => {
        transaction.oncomplete = () => resolve();
        transaction.onabort = () => { var _a; return reject((_a = transaction.error) !== null && _a !== void 0 ? _a : new Error("INDEXEDDB_TRANSACTION_ABORTED")); };
        transaction.onerror = () => { var _a; return reject((_a = transaction.error) !== null && _a !== void 0 ? _a : new Error("INDEXEDDB_TRANSACTION_FAILED")); };
    });
}
function isValidImportedAsset(asset, blob, limits) {
    return !!asset && typeof asset.id === "string" && /^[A-Za-z0-9_-]{1,80}$/.test(asset.id) && typeof asset.path === "string" && asset.path.length <= 240 && !asset.path.includes("..") && !asset.path.startsWith("/") && Number.isSafeInteger(asset.bytes) && asset.bytes > 0 && asset.bytes <= limits.maxSingleBytes && blob.size === asset.bytes && typeof asset.sha256 === "string" && /^[a-f0-9]{64}$/i.test(asset.sha256) && typeof asset.mime === "string";
}
/** Offline IndexedDB blob vault. No network, URL fetching, or implicit upload is performed. */
class AssetVault {
    exclusive(work) {
        const result = this.writeQueue.then(work, work);
        this.writeQueue = result.then(() => undefined, () => undefined);
        return result;
    }
    constructor(options = {}) {
        var _a, _b, _c, _d, _e, _f;
        this.database = null;
        this.opening = null;
        this.writeQueue = Promise.resolve();
        this.limits = (_a = options.limits) !== null && _a !== void 0 ? _a : assetVaultLimits((_b = options.tier) !== null && _b !== void 0 ? _b : 0);
        this.indexedDBFactory = (_c = options.indexedDB) !== null && _c !== void 0 ? _c : globalThis.indexedDB;
        this.estimateStorage = (_d = options.estimateStorage) !== null && _d !== void 0 ? _d : (((_f = (_e = globalThis.navigator) === null || _e === void 0 ? void 0 : _e.storage) === null || _f === void 0 ? void 0 : _f.estimate) ? () => globalThis.navigator.storage.estimate() : undefined);
    }
    async db() {
        if (this.database)
            return this.database;
        if (!this.indexedDBFactory)
            throw new Error("INDEXEDDB_UNAVAILABLE");
        if (!this.opening)
            this.opening = new Promise((resolve, reject) => {
                const request = this.indexedDBFactory.open(DB_NAME, DB_VERSION);
                request.onupgradeneeded = () => {
                    const db = request.result;
                    if (!db.objectStoreNames.contains(STORE)) {
                        const store = db.createObjectStore(STORE, { keyPath: "id" });
                        store.createIndex("lastAccessedAt", "lastAccessedAt", { unique: false });
                    }
                };
                request.onsuccess = () => { this.database = request.result; this.database.onversionchange = () => this.close(); resolve(request.result); };
                request.onerror = () => { var _a; return reject((_a = request.error) !== null && _a !== void 0 ? _a : new Error("INDEXEDDB_OPEN_FAILED")); };
                request.onblocked = () => reject(new Error("INDEXEDDB_OPEN_BLOCKED"));
            }).finally(() => { this.opening = null; });
        const opening = this.opening;
        if (!opening)
            throw new Error("INDEXEDDB_OPEN_FAILED");
        return opening;
    }
    async put(asset, blob, options = {}) {
        if (!isValidImportedAsset(asset, blob, this.limits))
            return { ok: false, error: "INVALID_ASSET_OR_BLOB" };
        return this.exclusive(async () => {
            var _a, _b, _c, _d, _e;
            try {
                if (this.estimateStorage) {
                    const estimate = await this.estimateStorage();
                    if (Number.isFinite(estimate.quota) && Number.isFinite(estimate.usage) && (estimate.quota - estimate.usage < asset.bytes))
                        return { ok: false, error: "BROWSER_STORAGE_QUOTA_LOW" };
                }
                const db = await this.db();
                const readTx = db.transaction(STORE, "readonly");
                const existing = await requestValue(readTx.objectStore(STORE).getAll());
                await transactionDone(readTx);
                const plan = planAssetVaultEviction(existing, { id: asset.id, bytes: asset.bytes }, this.limits);
                if (!plan.ok)
                    return plan;
                const now = Date.now();
                const entry = Object.freeze({ id: asset.id, path: asset.path, kind: asset.kind, mime: asset.mime, bytes: asset.bytes, sha256: asset.sha256, ...(asset.width ? { width: asset.width } : {}), ...(asset.height ? { height: asset.height } : {}), createdAt: (_b = (_a = existing.find(item => item.id === asset.id)) === null || _a === void 0 ? void 0 : _a.createdAt) !== null && _b !== void 0 ? _b : now, lastAccessedAt: now, pinned: (_e = (_c = options.pinned) !== null && _c !== void 0 ? _c : (_d = existing.find(item => item.id === asset.id)) === null || _d === void 0 ? void 0 : _d.pinned) !== null && _e !== void 0 ? _e : false, blob });
                const tx = db.transaction(STORE, "readwrite");
                const store = tx.objectStore(STORE);
                for (const id of plan.value)
                    store.delete(id);
                store.put(entry);
                await transactionDone(tx);
                return { ok: true, value: entry };
            }
            catch (error) {
                return { ok: false, error: error instanceof Error ? error.message : "VAULT_WRITE_FAILED" };
            }
        });
    }
    async get(id) {
        if (typeof id !== "string" || !/^[A-Za-z0-9_-]{1,80}$/.test(id))
            return { ok: false, error: "INVALID_ASSET_ID" };
        try {
            const db = await this.db();
            const tx = db.transaction(STORE, "readwrite");
            const store = tx.objectStore(STORE);
            const entry = await requestValue(store.get(id));
            if (entry)
                store.put({ ...entry, lastAccessedAt: Date.now() });
            await transactionDone(tx);
            return { ok: true, value: entry !== null && entry !== void 0 ? entry : null };
        }
        catch (error) {
            return { ok: false, error: error instanceof Error ? error.message : "VAULT_READ_FAILED" };
        }
    }
    async list() {
        try {
            const db = await this.db();
            const tx = db.transaction(STORE, "readonly");
            const entries = await requestValue(tx.objectStore(STORE).getAll());
            await transactionDone(tx);
            return { ok: true, value: Object.freeze(entries.sort((a, b) => b.lastAccessedAt - a.lastAccessedAt).map(({ blob: _blob, ...metadata }) => Object.freeze(metadata))) };
        }
        catch (error) {
            return { ok: false, error: error instanceof Error ? error.message : "VAULT_LIST_FAILED" };
        }
    }
    async remove(id) {
        if (typeof id !== "string" || !/^[A-Za-z0-9_-]{1,80}$/.test(id))
            return { ok: false, error: "INVALID_ASSET_ID" };
        try {
            const db = await this.db();
            const tx = db.transaction(STORE, "readwrite");
            const store = tx.objectStore(STORE);
            const found = await requestValue(store.getKey(id));
            store.delete(id);
            await transactionDone(tx);
            return { ok: true, value: found !== undefined };
        }
        catch (error) {
            return { ok: false, error: error instanceof Error ? error.message : "VAULT_DELETE_FAILED" };
        }
    }
    async setPinned(id, pinned) {
        if (typeof id !== "string" || !/^[A-Za-z0-9_-]{1,80}$/.test(id) || typeof pinned !== "boolean")
            return { ok: false, error: "INVALID_PIN_REQUEST" };
        try {
            const db = await this.db();
            const tx = db.transaction(STORE, "readwrite");
            const store = tx.objectStore(STORE);
            const entry = await requestValue(store.get(id));
            if (entry)
                store.put({ ...entry, pinned });
            await transactionDone(tx);
            return { ok: true, value: !!entry };
        }
        catch (error) {
            return { ok: false, error: error instanceof Error ? error.message : "VAULT_PIN_FAILED" };
        }
    }
    /** Requests persistent origin storage only when the caller invokes it from an explicit user action. */
    async requestPersistentStorage() {
        var _a;
        try {
            const storage = (_a = globalThis.navigator) === null || _a === void 0 ? void 0 : _a.storage;
            if (!(storage === null || storage === void 0 ? void 0 : storage.persist))
                return { ok: false, error: "PERSISTENT_STORAGE_UNAVAILABLE" };
            return { ok: true, value: await storage.persist() };
        }
        catch (error) {
            return { ok: false, error: error instanceof Error ? error.message : "PERSISTENT_STORAGE_REQUEST_FAILED" };
        }
    }
    async summary() {
        try {
            const db = await this.db();
            const tx = db.transaction(STORE, "readonly");
            const entries = await requestValue(tx.objectStore(STORE).getAll());
            await transactionDone(tx);
            return { ok: true, value: Object.freeze({ entries: entries.length, bytes: entries.reduce((sum, entry) => sum + entry.bytes, 0), maxBytes: this.limits.maxBytes, maxEntries: this.limits.maxEntries }) };
        }
        catch (error) {
            return { ok: false, error: error instanceof Error ? error.message : "VAULT_SUMMARY_FAILED" };
        }
    }
    async clearUnpinned() {
        try {
            const db = await this.db();
            const tx = db.transaction(STORE, "readwrite");
            const store = tx.objectStore(STORE);
            const entries = await requestValue(store.getAll());
            const targets = entries.filter(entry => !entry.pinned);
            for (const entry of targets)
                store.delete(entry.id);
            await transactionDone(tx);
            return { ok: true, value: targets.length };
        }
        catch (error) {
            return { ok: false, error: error instanceof Error ? error.message : "VAULT_CLEAR_FAILED" };
        }
    }
    close() { var _a; (_a = this.database) === null || _a === void 0 ? void 0 : _a.close(); this.database = null; }
}
exports.AssetVault = AssetVault;

};
modules["browser-entry.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/** Browser entry for the standalone MUNGIL Studio website and Android WebView shell. */
const runtime = require("./index.js");
Object.defineProperty(window, "MUNGIL_RUNTIME", {
    configurable: false,
    enumerable: false,
    writable: false,
    value: Object.freeze(runtime),
});

};
modules["capabilities.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveRenderer = resolveRenderer;
/** Selects a backend without silently downgrading true 3D projects to a 2D canvas. */
function resolveRenderer(requested, projection, capabilities) {
    const available = {
        webgpu: capabilities.webgpu,
        webgl2: capabilities.webgl2,
        webgl1: capabilities.webgl1,
        canvas2d: capabilities.canvas2d,
    };
    const isPerspective3D = projection === "perspective-3d";
    if (requested !== "auto") {
        if (!available[requested])
            return { ok: false, error: `REQUESTED_RENDERER_UNAVAILABLE:${requested}` };
        if (isPerspective3D && requested === "canvas2d")
            return { ok: false, error: "CANVAS2D_CANNOT_RENDER_PERSPECTIVE_3D" };
        return { ok: true, renderer: requested };
    }
    // Prefer stable, broadly deployed APIs. WebGPU is opt-in until the adapter is explicitly validated.
    if (capabilities.webgl2)
        return { ok: true, renderer: "webgl2" };
    if (capabilities.webgl1)
        return { ok: true, renderer: "webgl1" };
    if (!isPerspective3D && capabilities.canvas2d)
        return { ok: true, renderer: "canvas2d" };
    if (capabilities.webgpu)
        return { ok: true, renderer: "webgpu" };
    return { ok: false, error: isPerspective3D ? "NO_COMPATIBLE_3D_RENDERER" : "NO_COMPATIBLE_RENDERER" };
}

};
modules["contracts.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateRuntimeManifest = validateRuntimeManifest;
function validateRuntimeManifest(value) {
    var _a, _b, _c, _d, _e, _f, _g;
    if (!value || typeof value !== "object")
        return { ok: false, error: "MANIFEST_NOT_OBJECT" };
    const m = value;
    if (!Number.isSafeInteger(m.schemaVersion) || ((_a = m.schemaVersion) !== null && _a !== void 0 ? _a : 0) < 1)
        return { ok: false, error: "INVALID_SCHEMA_VERSION" };
    if (typeof m.projectId !== "string" || !/^[a-zA-Z0-9_-]{1,80}$/.test(m.projectId))
        return { ok: false, error: "INVALID_PROJECT_ID" };
    if (typeof m.title !== "string" || !m.title.trim() || m.title.length > 120)
        return { ok: false, error: "INVALID_PROJECT_TITLE" };
    if (!["auto", "canvas2d", "webgl1", "webgl2", "webgpu"].includes((_b = m.renderer) !== null && _b !== void 0 ? _b : ""))
        return { ok: false, error: "INVALID_RENDERER" };
    if (!["orthographic-2d", "isometric-2.5d", "perspective-3d", "pseudo-3d-road", "grid-raycaster"].includes((_c = m.projection) !== null && _c !== void 0 ? _c : ""))
        return { ok: false, error: "INVALID_PROJECTION" };
    if (!Number.isInteger(m.simulationHz) || ((_d = m.simulationHz) !== null && _d !== void 0 ? _d : 0) < 10 || ((_e = m.simulationHz) !== null && _e !== void 0 ? _e : 0) > 120)
        return { ok: false, error: "INVALID_SIMULATION_RATE" };
    if (m.targetFps !== 30 && m.targetFps !== 60)
        return { ok: false, error: "INVALID_TARGET_FPS" };
    if (m.qualityTier !== "auto" && m.qualityTier !== 0 && m.qualityTier !== 1 && m.qualityTier !== 2)
        return { ok: false, error: "INVALID_QUALITY_TIER" };
    if (!Number.isSafeInteger(m.seed) || ((_f = m.seed) !== null && _f !== void 0 ? _f : -1) < 0 || ((_g = m.seed) !== null && _g !== void 0 ? _g : 0) > 0xffffffff)
        return { ok: false, error: "INVALID_PROJECT_SEED" };
    if (!Array.isArray(m.scenes) || m.scenes.length < 1 || m.scenes.length > 256)
        return { ok: false, error: "INVALID_SCENE_LIST" };
    const seen = new Set();
    for (const scene of m.scenes) {
        if (typeof scene !== "string" || !/^[a-zA-Z0-9_./-]{1,160}$/.test(scene) || scene.includes("..") || seen.has(scene))
            return { ok: false, error: "INVALID_SCENE_ID" };
        seen.add(scene);
    }
    if (!m.features || typeof m.features !== "object")
        return { ok: false, error: "INVALID_FEATURE_FLAGS" };
    const flags = ["physics2d", "physics3d", "skeletal2d", "skeletal3d", "particles", "navigation", "multiplayer", "postProcessing", "editorTools"];
    for (const key of flags)
        if (typeof m.features[key] !== "boolean")
            return { ok: false, error: `INVALID_FEATURE_${key}` };
    return { ok: true };
}

};
modules["core.js"]=function(module,exports,require){
"use strict";
/**
 * MUNGIL Runtime Primitives
 * Dependency-free runtime building blocks for 2D, 2.5D and 3D projects.
 * Keep engine-specific renderers, physics solvers and editors behind adapters.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.StateMachine = exports.SeededRandom = exports.QualityGovernor = exports.ResourceScope = exports.FixedStepClock = void 0;
exports.clamp = clamp;
exports.createDeviceProfile = createDeviceProfile;
exports.validateAssetManifest = validateAssetManifest;
exports.readJsonStorage = readJsonStorage;
exports.writeJsonStorage = writeJsonStorage;
function clamp(value, min, max) {
    if (!Number.isFinite(value))
        return min;
    return value < min ? min : value > max ? max : value;
}
function createDeviceProfile(hints = {}) {
    const memory = Number.isFinite(hints.deviceMemory) ? hints.deviceMemory : 6;
    const cores = Number.isFinite(hints.hardwareConcurrency) ? hints.hardwareConcurrency : 6;
    const coarse = hints.coarsePointer === true;
    const pixels = Number.isFinite(hints.viewportPixels) ? hints.viewportPixels : 0;
    const unknownMemoryOnTouch = hints.deviceMemory === undefined && coarse;
    const weak = memory <= 4 || cores <= 4 || unknownMemoryOnTouch || (coarse && pixels > 2500000) || hints.webgl2 === false;
    const strong = memory >= 8 && cores >= 8 && !coarse;
    const tier = weak ? 0 : strong ? 2 : 1;
    return Object.freeze({
        tier,
        targetFps: tier === 0 ? 30 : 60,
        maxPixelRatio: tier === 0 ? 1 : tier === 1 ? 1.25 : 1.6,
        antialias: tier === 2,
        shadows: tier > 0,
        shadowMapSize: tier === 0 ? 256 : tier === 1 ? 512 : 1024,
        maxSubSteps: tier === 0 ? 3 : 4,
    });
}
/** Fixed-step clock with bounded catch-up and explicit backlog dropping. */
class FixedStepClock {
    constructor(options = {}) {
        var _a, _b, _c;
        this.lastMs = null;
        this.accumulator = 0;
        this.delta = 0;
        this.paused = false;
        this.totalSteps = 0;
        this.dropped = 0;
        this.stepSeconds = (_a = options.stepSeconds) !== null && _a !== void 0 ? _a : 1 / 60;
        this.maxFrameSeconds = (_b = options.maxFrameSeconds) !== null && _b !== void 0 ? _b : 0.05;
        this.maxSubSteps = (_c = options.maxSubSteps) !== null && _c !== void 0 ? _c : 4;
        if (!Number.isFinite(this.stepSeconds) || this.stepSeconds <= 0 ||
            !Number.isFinite(this.maxFrameSeconds) || this.maxFrameSeconds < this.stepSeconds ||
            !Number.isInteger(this.maxSubSteps) || this.maxSubSteps < 1 || this.maxSubSteps > 8) {
            throw new RangeError("INVALID_FIXED_STEP_CONFIGURATION");
        }
    }
    beginFrame(nowMs) {
        if (!Number.isFinite(nowMs))
            return 0;
        if (this.lastMs === null) {
            this.lastMs = nowMs;
            this.delta = 0;
            return 0;
        }
        const raw = Math.max(0, (nowMs - this.lastMs) / 1000);
        this.lastMs = nowMs;
        if (this.paused) {
            this.delta = 0;
            this.accumulator = 0;
            return 0;
        }
        this.delta = Math.min(raw, this.maxFrameSeconds);
        this.dropped += Math.max(0, raw - this.delta);
        this.accumulator += this.delta;
        return this.delta;
    }
    runFixed(update) {
        if (this.paused)
            return 0;
        let steps = 0;
        while (this.accumulator + 1e-9 >= this.stepSeconds && steps < this.maxSubSteps) {
            update(this.stepSeconds, this.totalSteps);
            this.accumulator -= this.stepSeconds;
            if (this.accumulator < 0)
                this.accumulator = 0;
            this.totalSteps += 1;
            steps += 1;
        }
        if (this.accumulator >= this.stepSeconds) {
            const remainder = this.accumulator % this.stepSeconds;
            this.dropped += this.accumulator - remainder;
            this.accumulator = remainder;
        }
        return steps;
    }
    clearAccumulator() { this.accumulator = 0; }
    reset(nowMs) {
        this.lastMs = Number.isFinite(nowMs) ? nowMs : null;
        this.accumulator = 0;
        this.delta = 0;
    }
    pause() { this.paused = true; this.accumulator = 0; }
    resume(nowMs) { this.paused = false; this.reset(nowMs); }
    get deltaSeconds() { return this.delta; }
    get alpha() { return this.accumulator / this.stepSeconds; }
    get tick() { return this.totalSteps; }
    get droppedSeconds() { return this.dropped; }
    get isPaused() { return this.paused; }
}
exports.FixedStepClock = FixedStepClock;
/** Idempotent owner for listeners, timers and GPU/resource cleanup callbacks. */
class ResourceScope {
    constructor() {
        this.cleanups = [];
        this.disposed = false;
    }
    defer(cleanup) {
        if (typeof cleanup !== "function")
            return () => undefined;
        if (this.disposed) {
            try {
                cleanup();
            }
            catch { /* cleanup is best effort */ }
            return () => undefined;
        }
        let active = true;
        const once = () => {
            if (!active)
                return;
            active = false;
            try {
                cleanup();
            }
            catch { /* cleanup is best effort */ }
        };
        this.cleanups.push(once);
        return once;
    }
    listen(target, type, listener, options) {
        target.addEventListener(type, listener, options);
        return this.defer(() => target.removeEventListener(type, listener, options));
    }
    dispose() {
        var _a, _b;
        if (this.disposed)
            return;
        this.disposed = true;
        for (let i = this.cleanups.length - 1; i >= 0; i--)
            (_b = (_a = this.cleanups)[i]) === null || _b === void 0 ? void 0 : _b.call(_a);
        this.cleanups.length = 0;
    }
    get isDisposed() { return this.disposed; }
    get size() { return this.cleanups.length; }
}
exports.ResourceScope = ResourceScope;
/** Hysteretic quality controller; it changes tiers only after sustained evidence. */
class QualityGovernor {
    constructor(initialTier, options = {}) {
        this.cursor = 0;
        this.count = 0;
        this.sum = 0;
        this.slowWindows = 0;
        this.fastWindows = 0;
        this.sinceEvaluation = 0;
        const requestedSamples = Number.isFinite(options.sampleCount) ? Math.floor(options.sampleCount) : 45;
        const n = Math.max(12, Math.min(240, requestedSamples));
        this.samples = new Float32Array(n);
        this.tier = initialTier === 0 ? 0 : initialTier === 2 ? 2 : 1;
        this.downMs = Number.isFinite(options.downMs) && options.downMs > 0 ? options.downMs : 25;
        this.upMs = Number.isFinite(options.upMs) && options.upMs > 0 ? Math.min(options.upMs, this.downMs) : 17;
        this.allowUpgrade = options.allowUpgrade === true;
    }
    sample(frameWorkMs) {
        if (!Number.isFinite(frameWorkMs) || frameWorkMs < 0 || frameWorkMs > 1000)
            return this.tier;
        if (this.count === this.samples.length)
            this.sum -= this.samples[this.cursor];
        else
            this.count += 1;
        this.samples[this.cursor] = frameWorkMs;
        this.sum += frameWorkMs;
        this.cursor = (this.cursor + 1) % this.samples.length;
        if (this.count < this.samples.length)
            return this.tier;
        this.sinceEvaluation += 1;
        if (this.sinceEvaluation < this.samples.length)
            return this.tier;
        this.sinceEvaluation = 0;
        const avg = this.sum / this.count;
        if (avg > this.downMs) {
            this.slowWindows += 1;
            this.fastWindows = 0;
        }
        else if (avg < this.upMs) {
            this.fastWindows += 1;
            this.slowWindows = 0;
        }
        else {
            this.slowWindows = 0;
            this.fastWindows = 0;
        }
        if (this.slowWindows >= 2 && this.tier > 0) {
            this.tier = (this.tier - 1);
            this.slowWindows = 0;
        }
        if (this.allowUpgrade && this.fastWindows >= 5 && this.tier < 2) {
            this.tier = (this.tier + 1);
            this.fastWindows = 0;
        }
        return this.tier;
    }
    get currentTier() { return this.tier; }
    get averageMs() { return this.count ? this.sum / this.count : 0; }
}
exports.QualityGovernor = QualityGovernor;
/** Small deterministic RNG for procedural content and reproducible test cases. */
class SeededRandom {
    constructor(seed) {
        if (!Number.isSafeInteger(seed))
            throw new RangeError("INVALID_RANDOM_SEED");
        this.state = seed >>> 0 || 0x6d2b79f5;
    }
    nextUint() {
        let x = this.state;
        x ^= x << 13;
        x ^= x >>> 17;
        x ^= x << 5;
        this.state = x >>> 0;
        return this.state;
    }
    next() { return this.nextUint() / 0x100000000; }
    snapshot() { return this.state >>> 0; }
    restore(state) {
        if (!Number.isSafeInteger(state) || state < 0 || state > 0xffffffff)
            return false;
        this.state = state >>> 0 || 0x6d2b79f5;
        return true;
    }
}
exports.SeededRandom = SeededRandom;
/** Table-driven FSM; transition order is stable and explicit. */
class StateMachine {
    constructor(initial, states, transitions) {
        this.elapsed = 0;
        this.transitionCount = 0;
        this.valid = new Set(states);
        if (!this.valid.has(initial))
            throw new TypeError("FSM_INITIAL_STATE_MISSING");
        for (const t of transitions) {
            if (!this.valid.has(t.from) || !this.valid.has(t.to) || typeof t.when !== "function")
                throw new TypeError("FSM_INVALID_TRANSITION");
        }
        this.state = initial;
        this.previous = initial;
        this.transitions = transitions.slice();
    }
    update(context, dt) {
        var _a;
        if (!Number.isFinite(dt) || dt < 0)
            return false;
        for (const t of this.transitions) {
            if (t.from !== this.state)
                continue;
            let match = false;
            try {
                match = t.when(context) === true;
            }
            catch {
                match = false;
            }
            if (!match)
                continue;
            this.previous = this.state;
            this.state = t.to;
            this.elapsed = 0;
            this.transitionCount += 1;
            try {
                (_a = t.onEnter) === null || _a === void 0 ? void 0 : _a.call(t, context);
            }
            catch { /* state transition remains committed */ }
            return true;
        }
        this.elapsed += dt;
        return false;
    }
    force(next) {
        if (!this.valid.has(next))
            return false;
        if (next !== this.state) {
            this.previous = this.state;
            this.state = next;
            this.elapsed = 0;
            this.transitionCount += 1;
        }
        return true;
    }
}
exports.StateMachine = StateMachine;
function validateAssetManifest(assets, options = {}) {
    var _a, _b, _c, _d;
    const maxAssets = (_a = options.maxAssets) !== null && _a !== void 0 ? _a : 4096;
    const maxBytes = (_b = options.maxBytes) !== null && _b !== void 0 ? _b : 128 * 1024 * 1024;
    const maxPathLength = (_c = options.maxPathLength) !== null && _c !== void 0 ? _c : 240;
    const allowed = new Set((_d = options.allowedTypes) !== null && _d !== void 0 ? _d : ["image", "audio", "json", "binary", "model", "font", "video"]);
    if (!Number.isSafeInteger(maxAssets) || maxAssets < 0 || !Number.isSafeInteger(maxBytes) || maxBytes < 0 ||
        !Number.isSafeInteger(maxPathLength) || maxPathLength < 1)
        return { ok: false, error: "INVALID_ASSET_LIMITS" };
    if (!Array.isArray(assets) || assets.length > maxAssets)
        return { ok: false, error: "INVALID_ASSET_LIST" };
    const ids = new Set();
    let total = 0;
    for (let i = 0; i < assets.length; i++) {
        const a = assets[i];
        let decodedPath = "";
        try {
            decodedPath = typeof (a === null || a === void 0 ? void 0 : a.path) === "string" ? decodeURIComponent(a.path) : "";
        }
        catch {
            return { ok: false, error: `INVALID_ASSET_${i}` };
        }
        if (!a || typeof a.id !== "string" || !/^[a-zA-Z0-9_-]{1,96}$/.test(a.id) || ids.has(a.id) || typeof a.path !== "string" ||
            !a.path || a.path.length > maxPathLength || decodedPath.length > maxPathLength || a.path.startsWith("/") || /^[a-zA-Z]:/.test(a.path) ||
            a.path.includes("\\") || decodedPath.includes("\\") || /[\0-\x1f\x7f]/.test(decodedPath) ||
            /^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(decodedPath) || decodedPath.split("/").some((part) => part === ".." || part === ".") ||
            !allowed.has(a.type) || !Number.isSafeInteger(a.bytes) || a.bytes < 0)
            return { ok: false, error: `INVALID_ASSET_${i}` };
        ids.add(a.id);
        total += a.bytes;
        if (!Number.isSafeInteger(total) || total > maxBytes)
            return { ok: false, error: "ASSET_BUDGET_EXCEEDED" };
    }
    return { ok: true, totalBytes: total };
}
const MAX_STORAGE_KEY_LENGTH = 128;
const MAX_STORAGE_PAYLOAD_LENGTH = 1048576;
function readJsonStorage(storage, key, fallback, validate) {
    if (!storage || typeof key !== "string" || !key || key.length > MAX_STORAGE_KEY_LENGTH || typeof validate !== "function")
        return fallback;
    try {
        const raw = storage.getItem(key);
        if (!raw || raw.length > MAX_STORAGE_PAYLOAD_LENGTH)
            return fallback;
        const value = JSON.parse(raw);
        return validate(value) ? value : fallback;
    }
    catch {
        return fallback;
    }
}
function writeJsonStorage(storage, key, value) {
    if (!storage || typeof key !== "string" || !key || key.length > MAX_STORAGE_KEY_LENGTH)
        return false;
    try {
        const serialized = JSON.stringify(value);
        if (typeof serialized !== "string" || serialized.length > MAX_STORAGE_PAYLOAD_LENGTH)
            return false;
        storage.setItem(key, serialized);
        return true;
    }
    catch {
        return false;
    }
}

};
modules["generator/agent-pipeline.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createGenerationPlan = createGenerationPlan;
exports.executeGenerationPlan = executeGenerationPlan;
const MAX_PROMPT = 4000;
const MAX_TASKS = 24;
const SAFE_ID = /^[a-z0-9-]{1,48}$/;
function pick(text, patterns, fallback) {
    for (const [pattern, value] of patterns)
        if (pattern.test(text))
            return value;
    return fallback;
}
/** Makes a bounded, editable production plan; generated content still requires an AI provider and human review. */
function createGenerationPlan(prompt, target = "mobile-low") {
    if (typeof prompt !== "string" || !prompt.trim() || prompt.length > MAX_PROMPT)
        return { ok: false, error: "INVALID_PROMPT" };
    if (!["mobile-low", "mobile", "desktop", "web"].includes(target))
        return { ok: false, error: "INVALID_TARGET" };
    const normalized = prompt.toLowerCase();
    const dimension = /\b(3d|three[- ]dimensional|first person|fps|third person)\b/.test(normalized) ? "3d" : /\b(isometric|pseudo[- ]?3d|2\.5d|diagonal)\b/.test(normalized) ? "2.5d" : "2d";
    const genre = pick(normalized, [[/rpg|role[- ]playing/, "rpg"], [/platformer|platform game/, "platformer"], [/racing|race car|kart/, "racing"], [/tower defense|td game/, "tower-defense"], [/puzzle|match[- ]?3/, "puzzle"], [/shooter|fps|bullet hell/, "shooter"], [/strategy|rts|tactics/, "strategy"], [/simulation|simulator|tycoon/, "simulation"], [/survival|crafting/, "survival"], [/roguelike|roguelite/, "roguelike"]], "arcade");
    const style = pick(normalized, [[/pixel|8[- ]bit|16[- ]bit|retro/, "pixel-retro"], [/low[- ]poly|voxel/, "low-poly"], [/hand[- ]drawn|illustrat/, "hand-drawn"], [/anime|manga/, "anime"], [/realistic|photoreal/, "realistic"], [/cartoon|toon/, "cartoon"], [/vector|flat design/, "vector-flat"], [/isometric/, "isometric"], [/neon|cyberpunk/, "neon-cyberpunk"]], "stylized");
    const definitions = [
        { id: "brief", role: "producer", title: "Resolve game brief", description: "Extract core loop, audience, scope, constraints and acceptance criteria.", dependsOn: [] },
        { id: "design", role: "designer", title: "Design gameplay system", description: `Define ${genre} mechanics, progression, controls and feedback loops.`, dependsOn: ["brief"] },
        { id: "architecture", role: "engineer", title: "Choose runtime architecture", description: `Select ${dimension} rendering path and bounded device budgets for ${target}.`, dependsOn: ["brief"] },
        { id: "scene", role: "engineer", title: "Build scene graph", description: "Create scene hierarchy, entities, camera and interaction hooks.", dependsOn: ["design", "architecture"] },
        { id: "art", role: "artist", title: "Create visual direction", description: `Apply ${style} art direction, palette, asset list and animation plan.`, dependsOn: ["design"] },
        { id: "audio", role: "audio", title: "Compose audio plan", description: "Define music layers, ambience, UI feedback and SFX event map.", dependsOn: ["design"] },
        { id: "controls", role: "designer", title: "Configure input scheme", description: "Generate editable touch, keyboard and gamepad action bindings.", dependsOn: ["design"] },
        { id: "assemble", role: "engineer", title: "Assemble playable slice", description: "Connect scenes, gameplay, assets, audio and input using runtime contracts.", dependsOn: ["scene", "art", "audio", "controls"] },
        { id: "qa", role: "qa", title: "Validate and test", description: "Check project schema, missing assets, input reachability and failure paths.", dependsOn: ["assemble"] },
        { id: "optimize", role: "optimizer", title: "Optimize target build", description: "Budget draw calls, textures, audio voices, particles, memory and frame pacing.", dependsOn: ["qa"] },
    ];
    if (definitions.length > MAX_TASKS)
        return { ok: false, error: "TASK_LIMIT_EXCEEDED" };
    return { ok: true, plan: { schemaVersion: 1, prompt: prompt.trim(), genre, style, dimension, target, tasks: definitions.map(task => ({ ...task, state: "queued" })) } };
}
const MAX_OUTPUT_BYTES = 65536;
function sanitizeAgentOutput(value) {
    let budget = MAX_OUTPUT_BYTES;
    const visit = (input, depth) => {
        if (depth > 12)
            throw new TypeError("OUTPUT_DEPTH_LIMIT");
        if (input === null || typeof input === "boolean") {
            budget -= 5;
            return input;
        }
        if (typeof input === "number") {
            if (!Number.isFinite(input))
                throw new TypeError("OUTPUT_NON_FINITE_NUMBER");
            budget -= 16;
            return input;
        }
        if (typeof input === "string") {
            if (input.length > 8192)
                throw new TypeError("OUTPUT_STRING_LIMIT");
            budget -= input.length * 2 + 2;
            return input;
        }
        if (Array.isArray(input)) {
            if (input.length > 512)
                throw new TypeError("OUTPUT_ARRAY_LIMIT");
            const result = [];
            for (const item of input)
                result.push(visit(item, depth + 1));
            return result;
        }
        if (typeof input !== "object")
            throw new TypeError("OUTPUT_TYPE_UNSUPPORTED");
        const proto = Object.getPrototypeOf(input);
        if (proto !== Object.prototype && proto !== null)
            throw new TypeError("OUTPUT_OBJECT_PROTOTYPE");
        const descriptors = Object.getOwnPropertyDescriptors(input);
        const keys = Object.keys(descriptors);
        if (keys.length > 128)
            throw new TypeError("OUTPUT_OBJECT_KEY_LIMIT");
        const result = Object.create(null);
        for (const key of keys) {
            if (key === "__proto__" || key === "prototype" || key === "constructor")
                throw new TypeError("OUTPUT_DANGEROUS_KEY");
            const descriptor = descriptors[key];
            if (!("value" in descriptor) || descriptor.get || descriptor.set)
                throw new TypeError("OUTPUT_ACCESSOR_REJECTED");
            budget -= key.length * 2 + 4;
            result[key] = visit(descriptor.value, depth + 1);
        }
        return result;
    };
    try {
        const sanitized = visit(value, 0);
        if (!sanitized || typeof sanitized !== "object" || Array.isArray(sanitized) || budget < 0)
            return null;
        const encoded = JSON.stringify(sanitized);
        if (encoded.length * 2 > MAX_OUTPUT_BYTES)
            return null;
        return sanitized;
    }
    catch {
        return null;
    }
}
/** Sequential scheduler: one task at a time to bound resource use on low-end devices. */
async function executeGenerationPlan(plan, provider, signal, onEvent = () => undefined) {
    if (!plan || plan.schemaVersion !== 1 || typeof plan.prompt !== "string" || !plan.prompt.trim() || plan.prompt.length > MAX_PROMPT || typeof plan.genre !== "string" || plan.genre.length > 64 || typeof plan.style !== "string" || plan.style.length > 64 || !["2d", "2.5d", "3d"].includes(plan.dimension) || !["mobile-low", "mobile", "desktop", "web"].includes(plan.target) || !Array.isArray(plan.tasks) || plan.tasks.length < 1 || plan.tasks.length > MAX_TASKS || !provider || typeof provider.run !== "function" || !signal || typeof signal.aborted !== "boolean")
        return { ok: false, error: "INVALID_PLAN" };
    const tasks = plan.tasks;
    const known = new Set();
    for (const task of tasks) {
        if (!task || typeof task.id !== "string" || !SAFE_ID.test(task.id) || known.has(task.id) || !["producer", "designer", "engineer", "artist", "audio", "qa", "optimizer"].includes(task.role) || typeof task.title !== "string" || !task.title.trim() || task.title.length > 160 || typeof task.description !== "string" || task.description.length > 1000 || !["queued", "running", "done", "failed", "skipped"].includes(task.state) || !Array.isArray(task.dependsOn) || task.dependsOn.length > MAX_TASKS || !task.dependsOn.every(id => typeof id === "string" && SAFE_ID.test(id)) || new Set(task.dependsOn).size !== task.dependsOn.length || task.dependsOn.includes(task.id))
            return { ok: false, error: "INVALID_TASK_GRAPH" };
        known.add(task.id);
    }
    for (const task of tasks)
        if (!task.dependsOn.every(id => known.has(id)))
            return { ok: false, error: "INVALID_TASK_GRAPH" };
    // Sequential stable topological scheduler: independent tasks run in authored order,
    // but a task may safely appear before one of its dependencies in an imported plan.
    const pending = tasks.slice();
    const completed = new Set();
    const outputs = Object.create(null);
    const emit = (event) => { try {
        onEvent(event);
    }
    catch { /* UI event handlers must not abort provider work. */ } };
    const skipRemaining = (reason) => { for (const task of pending)
        emit({ taskId: task.id, state: "skipped", error: reason }); };
    while (pending.length) {
        if (signal.aborted) {
            skipRemaining("ABORTED");
            return { ok: false, error: "ABORTED" };
        }
        const readyIndex = pending.findIndex(task => task.dependsOn.every(id => completed.has(id)));
        if (readyIndex < 0) {
            skipRemaining("DEPENDENCY_CYCLE_OR_BLOCKED");
            return { ok: false, error: "TASK_GRAPH_CYCLE" };
        }
        const [task] = pending.splice(readyIndex, 1);
        if (!task)
            return { ok: false, error: "INVALID_TASK_GRAPH" };
        emit({ taskId: task.id, state: "running" });
        try {
            const outputSnapshot = Object.freeze({ ...outputs });
            const activePlan = { ...plan, outputs: outputSnapshot };
            const rawOutput = await provider.run(task, activePlan, signal);
            if (signal.aborted) {
                emit({ taskId: task.id, state: "skipped", error: "ABORTED" });
                skipRemaining("ABORTED");
                return { ok: false, error: "ABORTED" };
            }
            const output = sanitizeAgentOutput(rawOutput);
            if (!output) {
                emit({ taskId: task.id, state: "failed", error: "INVALID_AGENT_OUTPUT" });
                skipRemaining("UPSTREAM_TASK_FAILED");
                return { ok: false, error: `INVALID_AGENT_OUTPUT:${task.id}` };
            }
            outputs[task.id] = output;
            completed.add(task.id);
            emit({ taskId: task.id, state: "done", output });
        }
        catch (error) {
            const message = error instanceof Error ? error.message.slice(0, 240) : "AGENT_FAILED";
            emit({ taskId: task.id, state: "failed", error: message });
            skipRemaining("UPSTREAM_TASK_FAILED");
            return { ok: false, error: `TASK_FAILED:${task.id}` };
        }
    }
    return { ok: true, plan: { ...plan, outputs: Object.freeze({ ...outputs }), tasks: tasks.map(task => ({ ...task, state: "done" })) } };
}

};
modules["generator/audio-manager.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebAudioMixer = void 0;
const SAFE_ID = /^[a-zA-Z0-9_-]{1,80}$/;
function decodeBuffer(context, data) {
    return new Promise((resolve, reject) => {
        let settled = false;
        const success = (buffer) => { if (!settled) {
            settled = true;
            resolve(buffer);
        } };
        const failure = (error) => { if (!settled) {
            settled = true;
            reject(error);
        } };
        try {
            const result = context.decodeAudioData(data, success, failure);
            if (result && typeof result.then === "function")
                result.then(success, failure);
        }
        catch (error) {
            failure(error instanceof DOMException ? error : new DOMException("AUDIO_DECODE_FAILED", "EncodingError"));
        }
    });
}
class WebAudioMixer {
    constructor(maxTotalVoices = 24) {
        this.context = null;
        this.master = null;
        this.buses = new Map();
        this.clips = new Map();
        this.voices = new Map();
        this.voiceCounts = new Map();
        this.nextHandle = 1;
        this.disposed = false;
        if (!Number.isInteger(maxTotalVoices) || maxTotalVoices < 1 || maxTotalVoices > 128)
            throw new RangeError("INVALID_VOICE_LIMIT");
        this.maxTotalVoices = maxTotalVoices;
    }
    ensureContext() {
        if (this.disposed)
            return null;
        if (this.context)
            return this.context;
        const Constructor = typeof window !== "undefined" ? (window.AudioContext || window.webkitAudioContext) : undefined;
        if (!Constructor)
            return null;
        try {
            this.context = new Constructor();
            this.master = this.context.createGain();
            this.master.connect(this.context.destination);
            for (const name of ["music", "sfx", "ambience", "ui"]) {
                const gain = this.context.createGain();
                gain.connect(this.master);
                this.buses.set(name, gain);
            }
            return this.context;
        }
        catch {
            this.context = null;
            this.master = null;
            this.buses.clear();
            return null;
        }
    }
    /** Must be invoked from a user gesture on browsers that gate audio playback. */
    unlock() {
        const context = this.ensureContext();
        if (!context)
            return false;
        if (context.state === "suspended")
            void context.resume().catch(() => undefined);
        return true;
    }
    register(clip) {
        if (this.disposed || !clip || !SAFE_ID.test(clip.id) || !clip.buffer || !Number.isFinite(clip.buffer.duration) || clip.buffer.duration <= 0 || clip.buffer.duration > 600 || !Number.isInteger(clip.buffer.numberOfChannels) || clip.buffer.numberOfChannels < 1 || clip.buffer.numberOfChannels > 8 || !Number.isFinite(clip.buffer.sampleRate) || clip.buffer.sampleRate < 8000 || clip.buffer.sampleRate > 192000 || clip.maxVoices !== undefined && (!Number.isInteger(clip.maxVoices) || clip.maxVoices < 1 || clip.maxVoices > 32) || clip.bus !== undefined && !(["music", "sfx", "ambience", "ui"].includes(clip.bus)))
            return false;
        if (this.clips.size >= 512 && !this.clips.has(clip.id))
            return false;
        this.clips.set(clip.id, clip);
        return true;
    }
    /** Decode one bounded file at a time. It does not fetch URLs or bypass the browser's user-consent model. */
    async decodeAndRegister(id, blob, options = {}, signal) {
        var _a, _b, _c, _d, _e, _f;
        const maxBytes = (_a = options.maxBytes) !== null && _a !== void 0 ? _a : 4 * 1024 * 1024;
        const maxDuration = (_b = options.maxDurationSeconds) !== null && _b !== void 0 ? _b : 30;
        const maxDecodedBytes = (_c = options.maxDecodedBytes) !== null && _c !== void 0 ? _c : 12 * 1024 * 1024;
        if (this.disposed || !SAFE_ID.test(id) || !blob || !Number.isSafeInteger(blob.size) || blob.size < 1 || !Number.isSafeInteger(maxBytes) || maxBytes < 1 || maxBytes > 32 * 1024 * 1024 || blob.size > maxBytes || !Number.isFinite(maxDuration) || maxDuration <= 0 || maxDuration > 180 || !Number.isSafeInteger(maxDecodedBytes) || maxDecodedBytes < 1024 || maxDecodedBytes > 64 * 1024 * 1024 || (signal === null || signal === void 0 ? void 0 : signal.aborted))
            return false;
        const context = this.ensureContext();
        if (!context)
            return false;
        let data;
        try {
            data = await blob.arrayBuffer();
        }
        catch {
            return false;
        }
        if ((signal === null || signal === void 0 ? void 0 : signal.aborted) || data.byteLength !== blob.size)
            return false;
        let buffer;
        try {
            buffer = await decodeBuffer(context, data);
        }
        catch {
            return false;
        }
        const decodedBytes = buffer.length * buffer.numberOfChannels * 4;
        if ((signal === null || signal === void 0 ? void 0 : signal.aborted) || buffer.duration > maxDuration || !Number.isSafeInteger(decodedBytes) || decodedBytes > maxDecodedBytes)
            return false;
        return this.register({ id, buffer, bus: (_d = options.bus) !== null && _d !== void 0 ? _d : "sfx", loop: (_e = options.loop) !== null && _e !== void 0 ? _e : false, maxVoices: (_f = options.maxVoices) !== null && _f !== void 0 ? _f : 8 });
    }
    play(id, options = {}) {
        var _a, _b, _c, _d, _e, _f, _g;
        const clip = this.clips.get(id);
        if (!clip || !this.unlock() || !this.context)
            return null;
        const bus = (_a = clip.bus) !== null && _a !== void 0 ? _a : "sfx";
        const target = this.buses.get(bus);
        if (!target)
            return null;
        const cap = Math.max(1, Math.min(32, (_b = clip.maxVoices) !== null && _b !== void 0 ? _b : 8));
        if (this.voices.size >= this.maxTotalVoices || ((_c = this.voiceCounts.get(id)) !== null && _c !== void 0 ? _c : 0) >= cap)
            return null;
        const volume = Number.isFinite(options.volume) ? Math.max(0, Math.min(1, options.volume)) : 1;
        const source = this.context.createBufferSource();
        const gain = this.context.createGain();
        source.buffer = clip.buffer;
        source.loop = (_e = (_d = options.loop) !== null && _d !== void 0 ? _d : clip.loop) !== null && _e !== void 0 ? _e : false;
        gain.gain.value = volume;
        source.connect(gain);
        gain.connect(target);
        let handle = this.nextHandle++;
        if (!Number.isSafeInteger(this.nextHandle) || this.nextHandle > Number.MAX_SAFE_INTEGER)
            this.nextHandle = 1;
        while (this.voices.has(handle)) {
            handle = this.nextHandle++;
            if (!Number.isSafeInteger(this.nextHandle) || this.nextHandle > Number.MAX_SAFE_INTEGER)
                this.nextHandle = 1;
        }
        this.voices.set(handle, { source, gain, bus, clipId: id });
        this.voiceCounts.set(id, ((_f = this.voiceCounts.get(id)) !== null && _f !== void 0 ? _f : 0) + 1);
        source.onended = () => { var _a; const voice = this.voices.get(handle); if (!voice)
            return; this.voices.delete(handle); const count = ((_a = this.voiceCounts.get(id)) !== null && _a !== void 0 ? _a : 1) - 1; if (count <= 0)
            this.voiceCounts.delete(id);
        else
            this.voiceCounts.set(id, count); try {
            source.disconnect();
            gain.disconnect();
        }
        catch { /* already disconnected */ } };
        try {
            source.start();
            return handle;
        }
        catch {
            this.voices.delete(handle);
            const count = ((_g = this.voiceCounts.get(id)) !== null && _g !== void 0 ? _g : 1) - 1;
            if (count <= 0)
                this.voiceCounts.delete(id);
            else
                this.voiceCounts.set(id, count);
            try {
                source.disconnect();
                gain.disconnect();
            }
            catch { /* no-op */ }
            return null;
        }
    }
    stop(handle, fadeSeconds = 0.04) {
        const voice = this.voices.get(handle);
        if (!voice || !this.context)
            return;
        const now = this.context.currentTime;
        const fade = Number.isFinite(fadeSeconds) ? Math.max(0, Math.min(1, fadeSeconds)) : 0;
        voice.gain.gain.cancelScheduledValues(now);
        voice.gain.gain.setValueAtTime(voice.gain.gain.value, now);
        voice.gain.gain.linearRampToValueAtTime(0, now + fade);
        try {
            voice.source.stop(now + fade + 0.005);
        }
        catch {
            try {
                voice.source.stop();
            }
            catch { /* already stopped */ }
        }
    }
    stopBus(bus, fadeSeconds = 0.04) { for (const [handle, voice] of this.voices)
        if (voice.bus === bus)
            this.stop(handle, fadeSeconds); }
    setBusVolume(bus, volume) {
        var _a, _b;
        const target = bus === "master" ? this.master : this.buses.get(bus);
        if (!target || !Number.isFinite(volume))
            return;
        target.gain.setTargetAtTime(Math.max(0, Math.min(1, volume)), (_b = (_a = this.context) === null || _a === void 0 ? void 0 : _a.currentTime) !== null && _b !== void 0 ? _b : 0, 0.015);
    }
    suspend() { var _a; if (((_a = this.context) === null || _a === void 0 ? void 0 : _a.state) === "running")
        void this.context.suspend().catch(() => undefined); }
    resume() { var _a; if (((_a = this.context) === null || _a === void 0 ? void 0 : _a.state) === "suspended")
        void this.context.resume().catch(() => undefined); }
    dispose() {
        var _a;
        if (this.disposed)
            return;
        this.disposed = true;
        for (const voice of this.voices.values()) {
            try {
                voice.source.stop();
                voice.source.disconnect();
                voice.gain.disconnect();
            }
            catch { /* best effort */ }
        }
        this.voices.clear();
        this.voiceCounts.clear();
        this.clips.clear();
        this.buses.clear();
        (_a = this.master) === null || _a === void 0 ? void 0 : _a.disconnect();
        this.master = null;
        if (this.context)
            void this.context.close().catch(() => undefined);
        this.context = null;
    }
    get activeVoices() { return this.voices.size; }
    get registeredClips() { return this.clips.size; }
}
exports.WebAudioMixer = WebAudioMixer;

};
modules["generator/controller-map.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_CONTROLLER_MAP = void 0;
exports.validateControllerMap = validateControllerMap;
exports.remapAction = remapAction;
exports.normalizeAxis = normalizeAxis;
exports.readGamepadActions = readGamepadActions;
const ACTION = /^[a-zA-Z][a-zA-Z0-9_.-]{0,47}$/;
const CODE = /^[a-zA-Z0-9_.:-]{1,64}$/;
function validateControllerMap(value) {
    if (!value || typeof value !== "object")
        return false;
    const map = value;
    if (map.schemaVersion !== 1 || !Number.isFinite(map.deadzone) || map.deadzone < 0 || map.deadzone > 0.5 || !Array.isArray(map.actions) || map.actions.length > 128)
        return false;
    const actions = new Set();
    for (const entry of map.actions) {
        if (!entry || !ACTION.test(entry.action) || actions.has(entry.action) || !Array.isArray(entry.bindings) || entry.bindings.length > 12)
            return false;
        actions.add(entry.action);
        for (const binding of entry.bindings)
            if (!binding || !["touch", "keyboard", "gamepad"].includes(binding.device) || !CODE.test(binding.code) || (binding.scale !== undefined && (!Number.isFinite(binding.scale) || Math.abs(binding.scale) > 1)))
                return false;
    }
    return true;
}
function remapAction(map, action, bindings) {
    if (!validateControllerMap(map) || !ACTION.test(action))
        return null;
    const next = map.actions.some(item => item.action === action)
        ? map.actions.map(item => item.action === action ? { ...item, bindings: [...bindings] } : item)
        : [...map.actions, { action, bindings: [...bindings] }];
    const candidate = { ...map, actions: next };
    return validateControllerMap(candidate) ? candidate : null;
}
function normalizeAxis(value, deadzone) {
    if (!Number.isFinite(value) || !Number.isFinite(deadzone) || deadzone < 0 || deadzone > 0.5)
        return 0;
    const clamped = Math.max(-1, Math.min(1, value));
    const magnitude = Math.abs(clamped);
    return magnitude <= deadzone ? 0 : Math.sign(clamped) * ((magnitude - deadzone) / (1 - deadzone));
}
exports.DEFAULT_CONTROLLER_MAP = {
    schemaVersion: 1, deadzone: 0.18,
    actions: [
        { action: "move.left", bindings: [{ device: "keyboard", code: "ArrowLeft" }, { device: "touch", code: "virtual-left" }, { device: "gamepad", code: "axis-0-negative" }] },
        { action: "move.right", bindings: [{ device: "keyboard", code: "ArrowRight" }, { device: "touch", code: "virtual-right" }, { device: "gamepad", code: "axis-0-positive" }] },
        { action: "jump", bindings: [{ device: "keyboard", code: "Space" }, { device: "touch", code: "button-a" }, { device: "gamepad", code: "button-0" }] },
        { action: "action.primary", bindings: [{ device: "keyboard", code: "Enter" }, { device: "touch", code: "button-primary" }, { device: "gamepad", code: "button-1" }] },
    ],
};
/** Read a standard-mapped Gamepad snapshot into logical actions; call from the host input loop. */
function readGamepadActions(map, gamepad) {
    var _a;
    const active = new Set();
    if (!validateControllerMap(map) || gamepad.mapping !== "standard")
        return active;
    for (const entry of map.actions) {
        for (const binding of entry.bindings) {
            if (binding.device !== "gamepad")
                continue;
            const button = /^button-(\d+)$/.exec(binding.code);
            const axis = /^axis-(\d+)-(negative|positive)$/.exec(binding.code);
            if (button) {
                const state = gamepad.buttons[Number(button[1])];
                if (state && (state.pressed || state.value >= 0.5)) {
                    active.add(entry.action);
                    break;
                }
            }
            else if (axis) {
                const value = (_a = gamepad.axes[Number(axis[1])]) !== null && _a !== void 0 ? _a : 0;
                const normalized = normalizeAxis(value, map.deadzone);
                if ((axis[2] === "negative" && normalized < -0.1) || (axis[2] === "positive" && normalized > 0.1)) {
                    active.add(entry.action);
                    break;
                }
            }
        }
    }
    return active;
}

};
modules["gltf-preflight.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.preflightGltf = preflightGltf;
exports.validateGltfWithKhronos = validateGltfWithKhronos;
const MAX_BYTES = 32 * 1024 * 1024;
const MAX_JSON_DEPTH = 64;
const MAX_ELEMENTS = 100000;
function u32(data, offset) { return (data[offset] | (data[offset + 1] << 8) | (data[offset + 2] << 16) | (data[offset + 3] << 24)) >>> 0; }
function issue(list, severity, code, path, message) { list.push(Object.freeze({ severity, code, path, message })); }
function plainObject(value) { return !!value && typeof value === "object" && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null); }
function checkDepth(value, depth = 0, seen = new Set()) {
    if (depth > MAX_JSON_DEPTH)
        return false;
    if (!value || typeof value !== "object")
        return true;
    if (seen.has(value))
        return false;
    seen.add(value);
    let valid = true;
    if (Array.isArray(value)) {
        if (value.length > MAX_ELEMENTS)
            valid = false;
        else
            for (const item of value)
                if (!checkDepth(item, depth + 1, seen)) {
                    valid = false;
                    break;
                }
    }
    else {
        const descriptors = Object.getOwnPropertyDescriptors(value);
        const keys = Object.keys(descriptors);
        if (keys.length > MAX_ELEMENTS)
            valid = false;
        else
            for (const key of keys) {
                const descriptor = descriptors[key];
                if (key === "__proto__" || key === "constructor" || !("value" in descriptor) || descriptor.get || descriptor.set || !checkDepth(descriptor.value, depth + 1, seen)) {
                    valid = false;
                    break;
                }
            }
    }
    seen.delete(value);
    return valid;
}
function parseContainer(bytes) {
    if (bytes.length >= 4 && bytes[0] === 0x67 && bytes[1] === 0x6c && bytes[2] === 0x54 && bytes[3] === 0x46) {
        if (bytes.length < 20 || u32(bytes, 4) !== 2 || u32(bytes, 8) !== bytes.length)
            return { format: "glb", json: null, binBytes: 0 };
        let offset = 12;
        let json = null;
        let binBytes = 0;
        let chunks = 0;
        while (offset + 8 <= bytes.length && chunks++ < 32) {
            const length = u32(bytes, offset);
            const type = u32(bytes, offset + 4);
            offset += 8;
            if (length % 4 !== 0 || length > bytes.length - offset)
                return { format: "glb", json: null, binBytes: 0 };
            if (chunks === 1 && type !== 0x4e4f534a)
                return { format: "glb", json: null, binBytes: 0 };
            if (type === 0x4e4f534a && json === null) {
                try {
                    json = new TextDecoder("utf-8", { fatal: true }).decode(bytes.subarray(offset, offset + length)).replace(/[\u0000\u0020]+$/g, "");
                }
                catch {
                    return { format: "glb", json: null, binBytes: 0 };
                }
            }
            else if (type === 0x004e4942)
                binBytes += length;
            offset += length;
        }
        return offset === bytes.length && json !== null ? { format: "glb", json, binBytes } : { format: "glb", json: null, binBytes: 0 };
    }
    try {
        return { format: "gltf-json", json: new TextDecoder("utf-8", { fatal: true }).decode(bytes), binBytes: 0 };
    }
    catch {
        return { format: "unknown", json: null, binBytes: 0 };
    }
}
function preflightGltf(bytes) {
    var _a, _b, _c, _d, _e;
    const issues = [];
    const emptyStats = Object.freeze({ nodes: 0, meshes: 0, materials: 0, accessors: 0, buffers: 0 });
    if (!(bytes instanceof Uint8Array) || bytes.byteLength < 1 || bytes.byteLength > MAX_BYTES) {
        issue(issues, "error", "GLTF_FILE_SIZE_LIMIT", "", "Input must be a Uint8Array of 1 byte to 32 MiB.");
        return Object.freeze({ ok: false, format: "unknown", bytes: (_a = bytes === null || bytes === void 0 ? void 0 : bytes.byteLength) !== null && _a !== void 0 ? _a : 0, issues: Object.freeze(issues), stats: emptyStats });
    }
    const container = parseContainer(bytes);
    if (!container.json) {
        issue(issues, "error", "GLTF_CONTAINER_INVALID", "", "Invalid glTF JSON or GLB 2.0 header/chunk structure.");
        return Object.freeze({ ok: false, format: container.format, bytes: bytes.byteLength, issues: Object.freeze(issues), stats: emptyStats });
    }
    let root;
    try {
        root = JSON.parse(container.json);
    }
    catch {
        issue(issues, "error", "GLTF_JSON_INVALID", "", "JSON parsing failed.");
    }
    if (!root || !plainObject(root) || !checkDepth(root)) {
        issue(issues, "error", "GLTF_ROOT_INVALID", "", "Root must be a bounded plain JSON object without excessive depth or accessors.");
        return Object.freeze({ ok: false, format: container.format, bytes: bytes.byteLength, issues: Object.freeze(issues), stats: emptyStats });
    }
    const gltf = root;
    const asset = plainObject(gltf.asset) ? gltf.asset : null;
    if (!asset || asset.version !== "2.0")
        issue(issues, "error", "GLTF_VERSION_UNSUPPORTED", "/asset/version", "Only glTF 2.0 assets are accepted.");
    const list = (key) => {
        const value = gltf[key];
        if (value === undefined)
            return [];
        if (!Array.isArray(value) || value.length > MAX_ELEMENTS) {
            issue(issues, "error", "GLTF_ARRAY_LIMIT", `/${key}`, "Expected a bounded array.");
            return [];
        }
        return value;
    };
    const buffers = list("buffers");
    const views = list("bufferViews");
    const accessors = list("accessors");
    const nodes = list("nodes");
    const meshes = list("meshes");
    const materials = list("materials");
    const bufferLengths = [];
    for (let i = 0; i < buffers.length; i++) {
        const buffer = buffers[i];
        if (!plainObject(buffer) || !Number.isSafeInteger(buffer.byteLength) || Number(buffer.byteLength) < 0) {
            issue(issues, "error", "GLTF_BUFFER_INVALID", `/buffers/${i}`, "Buffer byteLength must be a non-negative safe integer.");
            bufferLengths.push(0);
            continue;
        }
        bufferLengths.push(Number(buffer.byteLength));
        if (typeof buffer.uri === "string") {
            if (/^(?:https?:|file:|javascript:|data:)/i.test(buffer.uri))
                issue(issues, "warning", "GLTF_EXTERNAL_OR_EMBEDDED_URI", `/buffers/${i}/uri`, "External or embedded buffer URI requires a separate controlled resource pipeline.");
            else if (container.format === "glb")
                issue(issues, "warning", "GLB_BUFFER_URI_PRESENT", `/buffers/${i}/uri`, "GLB buffer URI is unusual; validate resource mapping with Khronos Validator.");
        }
        else if (container.format === "gltf-json")
            issue(issues, "warning", "GLTF_BUFFER_RESOURCE_MISSING", `/buffers/${i}/uri`, "JSON glTF buffer has no URI; standalone binary data is not embedded.");
    }
    if (container.format === "glb" && buffers.length > 0) {
        const primary = buffers[0];
        if (plainObject(primary) && primary.uri === undefined) {
            const declared = Number(primary.byteLength);
            if (container.binBytes < declared || container.binBytes - declared > 3)
                issue(issues, "error", "GLB_BINARY_CHUNK_LENGTH_MISMATCH", "/buffers/0/byteLength", "GLB BIN chunk length must cover the primary buffer with at most three padding bytes.");
        }
        else if (container.binBytes > 0)
            issue(issues, "warning", "GLB_BINARY_CHUNK_UNREFERENCED", "/buffers", "A BIN chunk exists but the primary buffer does not declare the expected implicit resource.");
        if (buffers.length > 1)
            issue(issues, "warning", "GLB_MULTIPLE_BUFFERS", "/buffers", "Additional buffers need explicit resource mapping outside the single GLB BIN chunk.");
    }
    for (let i = 0; i < views.length; i++) {
        const view = views[i];
        if (!plainObject(view) || !Number.isInteger(view.buffer) || Number(view.buffer) < 0 || Number(view.buffer) >= bufferLengths.length || !Number.isSafeInteger(view.byteLength) || Number(view.byteLength) < 0 || !Number.isSafeInteger((_b = view.byteOffset) !== null && _b !== void 0 ? _b : 0) || Number((_c = view.byteOffset) !== null && _c !== void 0 ? _c : 0) < 0) {
            issue(issues, "error", "GLTF_BUFFER_VIEW_INVALID", `/bufferViews/${i}`, "Buffer view indices, offsets and lengths are invalid.");
            continue;
        }
        const end = Number((_d = view.byteOffset) !== null && _d !== void 0 ? _d : 0) + Number(view.byteLength);
        if (!Number.isSafeInteger(end) || end > bufferLengths[Number(view.buffer)])
            issue(issues, "error", "GLTF_BUFFER_VIEW_OUT_OF_RANGE", `/bufferViews/${i}`, "Buffer view exceeds its referenced buffer length.");
    }
    for (let i = 0; i < accessors.length; i++) {
        const accessor = accessors[i];
        if (!plainObject(accessor) || !Number.isSafeInteger(accessor.count) || Number(accessor.count) < 1 || ![5120, 5121, 5122, 5123, 5125, 5126].includes(Number(accessor.componentType)) || !["SCALAR", "VEC2", "VEC3", "VEC4", "MAT2", "MAT3", "MAT4"].includes(String(accessor.type)))
            issue(issues, "error", "GLTF_ACCESSOR_INVALID", `/accessors/${i}`, "Accessor count, componentType or type is invalid.");
        if (plainObject(accessor) && accessor.bufferView !== undefined && (!Number.isInteger(accessor.bufferView) || Number(accessor.bufferView) < 0 || Number(accessor.bufferView) >= views.length))
            issue(issues, "error", "GLTF_ACCESSOR_VIEW_MISSING", `/accessors/${i}/bufferView`, "Accessor references a missing buffer view.");
    }
    const childOwners = new Map();
    const nodeEdges = Array.from({ length: nodes.length }, () => []);
    for (let i = 0; i < nodes.length; i++) {
        const node = nodes[i];
        if (!plainObject(node)) {
            issue(issues, "error", "GLTF_NODE_INVALID", `/nodes/${i}`, "Node must be an object.");
            continue;
        }
        if (node.mesh !== undefined && (!Number.isInteger(node.mesh) || Number(node.mesh) < 0 || Number(node.mesh) >= meshes.length))
            issue(issues, "error", "GLTF_NODE_MESH_MISSING", `/nodes/${i}/mesh`, "Node references a missing mesh.");
        if (node.children !== undefined) {
            if (!Array.isArray(node.children) || node.children.length > MAX_ELEMENTS)
                issue(issues, "error", "GLTF_NODE_CHILDREN_INVALID", `/nodes/${i}/children`, "Children must be a bounded array.");
            else
                for (const child of node.children) {
                    if (!Number.isInteger(child) || Number(child) < 0 || Number(child) >= nodes.length)
                        issue(issues, "error", "GLTF_NODE_CHILD_MISSING", `/nodes/${i}/children`, "Node references a missing child.");
                    else {
                        const childIndex = Number(child);
                        childOwners.set(childIndex, ((_e = childOwners.get(childIndex)) !== null && _e !== void 0 ? _e : 0) + 1);
                        nodeEdges[i].push(childIndex);
                    }
                }
        }
    }
    for (const [child, owners] of childOwners)
        if (owners > 1)
            issue(issues, "error", "GLTF_NODE_MULTIPLE_PARENTS", `/nodes/${child}`, "A node cannot have more than one parent.");
    const nodeColor = new Uint8Array(nodes.length);
    for (let rootIndex = 0; rootIndex < nodes.length; rootIndex++) {
        if (nodeColor[rootIndex] !== 0)
            continue;
        const stackNodes = [rootIndex], stackOffsets = [0];
        nodeColor[rootIndex] = 1;
        while (stackNodes.length) {
            const top = stackNodes.length - 1, current = stackNodes[top], children = nodeEdges[current];
            if (stackOffsets[top] >= children.length) {
                nodeColor[current] = 2;
                stackNodes.pop();
                stackOffsets.pop();
                continue;
            }
            const child = children[stackOffsets[top]];
            stackOffsets[top] = stackOffsets[top] + 1;
            if (nodeColor[child] === 1) {
                issue(issues, "error", "GLTF_NODE_CYCLE", `/nodes/${current}/children`, `Node hierarchy contains a cycle through node ${child}.`);
            }
            else if (nodeColor[child] === 0) {
                nodeColor[child] = 1;
                stackNodes.push(child);
                stackOffsets.push(0);
            }
        }
    }
    for (let i = 0; i < meshes.length; i++)
        if (!plainObject(meshes[i]) || !Array.isArray(meshes[i].primitives))
            issue(issues, "error", "GLTF_MESH_INVALID", `/meshes/${i}`, "Mesh must contain a primitives array.");
    const errors = issues.some(item => item.severity === "error");
    return Object.freeze({ ok: !errors, format: container.format, bytes: bytes.byteLength, issues: Object.freeze(issues), stats: Object.freeze({ nodes: nodes.length, meshes: meshes.length, materials: materials.length, accessors: accessors.length, buffers: buffers.length }) });
}
/** Uses the official Khronos validator when injected by a build/host adapter, without bundling it into the mobile runtime. */
async function validateGltfWithKhronos(bytes, adapter) {
    var _a, _b, _c, _d;
    const base = preflightGltf(bytes);
    if (!base.ok)
        return base;
    if (!adapter || typeof adapter.validateBytes !== "function")
        return Object.freeze({ ...base, issues: Object.freeze([...base.issues, Object.freeze({ severity: "warning", code: "KHRONOS_VALIDATOR_NOT_CONFIGURED", path: "", message: "Structural preflight passed; full Khronos glTF Validator was not provided." })]) });
    try {
        const result = await adapter.validateBytes(bytes);
        const issues = [...base.issues];
        for (const item of (_a = result.issues) !== null && _a !== void 0 ? _a : [])
            issues.push(Object.freeze({ severity: item.severity === 0 ? "error" : "warning", code: String((_b = item.code) !== null && _b !== void 0 ? _b : "KHRONOS_ISSUE").slice(0, 80), path: String((_c = item.pointer) !== null && _c !== void 0 ? _c : "").slice(0, 512), message: String((_d = item.message) !== null && _d !== void 0 ? _d : "Validation issue").slice(0, 1000) }));
        const ok = !issues.some(item => item.severity === "error");
        return Object.freeze({ ...base, ok, issues: Object.freeze(issues) });
    }
    catch {
        return Object.freeze({ ...base, issues: Object.freeze([...base.issues, Object.freeze({ severity: "warning", code: "KHRONOS_VALIDATOR_FAILED", path: "", message: "Khronos validator execution failed; structural preflight report retained." })]) });
    }
}

};
modules["html5-export.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildPlayableHtml5Export = buildPlayableHtml5Export;
const project_document_ts_1 = require("./project-document.js");
const MAX_EXPORTED_NODES = 512;
const MAX_EXPORT_BYTES = 1500000;
function readNumber(props, key, fallback, min, max) {
    const value = props[key];
    return typeof value === "number" && Number.isFinite(value) ? Math.max(min, Math.min(max, value)) : fallback;
}
function safeColor(value, fallback) { return typeof value === "string" && /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i.test(value) ? value : fallback; }
function jsonForScript(value) { return JSON.stringify(value).replace(/</g, "\\u003c").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029"); }
/** Produces an offline, keyboard/touch playable 2D prototype. Imported binary assets are not embedded yet. */
function buildPlayableHtml5Export(input, options = {}) {
    var _a, _b, _c;
    const checked = (0, project_document_ts_1.validateProjectDocument)(input);
    if (!checked.ok)
        return { ok: false, error: checked.error };
    const project = checked.value;
    if (project.nodes.length > MAX_EXPORTED_NODES)
        return { ok: false, error: "HTML5_EXPORT_NODE_LIMIT" };
    const width = (_a = options.width) !== null && _a !== void 0 ? _a : 720, height = (_b = options.height) !== null && _b !== void 0 ? _b : 1280;
    if (!Number.isInteger(width) || !Number.isInteger(height) || width < 320 || height < 320 || width > 2048 || height > 2048)
        return { ok: false, error: "INVALID_EXPORT_VIEWPORT" };
    const exported = [];
    let player = null;
    let excludedAssetCount = 0;
    for (const node of project.nodes) {
        const props = node.props;
        if (typeof props.assetId === "string")
            excludedAssetCount++;
        const rawType = (node.type + " " + node.name).toLowerCase();
        const x = readNumber(props, "x", 80, -100000, 100000);
        const y = readNumber(props, "y", height - 180, -100000, 100000);
        const w = readNumber(props, "width", rawType.includes("player") ? 34 : 48, 1, 4096);
        const h = readNumber(props, "height", rawType.includes("player") ? 48 : 48, 1, 4096);
        const color = safeColor(props.color, rawType.includes("enemy") ? "#e85d75" : rawType.includes("coin") ? "#ffd166" : "#4e9ee8");
        if (rawType.includes("player")) {
            if (!player)
                player = { x, y, w, h, color };
            continue;
        }
        let kind = "decor";
        if (/platform|ground|floor|wall|block/.test(rawType) || props.solid === true)
            kind = "platform";
        else if (/coin|pickup|collectible|gem/.test(rawType) || props.collectible === true)
            kind = "coin";
        else if (/hazard|spike|trap/.test(rawType) || props.hazard === true)
            kind = "hazard";
        else if (/enemy|mob|monster/.test(rawType))
            kind = "enemy";
        else if (/goal|exit|finish|portal/.test(rawType))
            kind = "goal";
        exported.push(Object.freeze({ id: node.id, kind, x, y, w, h, color, solid: kind === "platform", vx: readNumber(props, "vx", kind === "enemy" ? 40 : 0, -500, 500), vy: readNumber(props, "vy", 0, -500, 500) }));
    }
    const defaultPlayer = player !== null && player !== void 0 ? player : { x: Math.min(96, width * 0.2), y: height - 190, w: 34, h: 48, color: "#6fe3c1" };
    const hasFloor = exported.some(entity => entity.kind === "platform" && entity.y >= height * 0.65);
    if (!hasFloor)
        exported.push(Object.freeze({ id: "__floor", kind: "platform", x: 0, y: height - 56, w: width, h: 56, color: "#29364b", solid: true, vx: 0, vy: 0 }));
    if (!exported.some(entity => entity.kind === "platform")) {
        exported.push(Object.freeze({ id: "__platform_a", kind: "platform", x: width * 0.18, y: height * 0.7, w: width * 0.34, h: 18, color: "#3b5975", solid: true, vx: 0, vy: 0 }));
        exported.push(Object.freeze({ id: "__platform_b", kind: "platform", x: width * 0.58, y: height * 0.54, w: width * 0.26, h: 18, color: "#3b5975", solid: true, vx: 0, vy: 0 }));
    }
    if (!exported.some(entity => entity.kind === "coin"))
        exported.push(Object.freeze({ id: "__coin", kind: "coin", x: width * 0.7, y: height * 0.45, w: 24, h: 24, color: "#ffd166", solid: false, vx: 0, vy: 0 }));
    const payload = { title: project.title, width, height, genre: String((_c = options.genre) !== null && _c !== void 0 ? _c : "arcade").slice(0, 40), player: defaultPlayer, entities: exported };
    const data = jsonForScript(payload);
    const touch = options.includeTouchControls !== false;
    const html = `<!doctype html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"><meta name="theme-color" content="#101827"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data: blob:; media-src data: blob:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'"><title>${project.title.replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]))}</title>
<style>*{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;overflow:hidden;background:#0b1220;color:#eef4ff;font:14px system-ui,sans-serif;touch-action:none}main{height:100vh;height:100dvh;display:grid;grid-template-rows:auto 1fr auto;gap:8px;padding:max(8px,env(safe-area-inset-top)) max(8px,env(safe-area-inset-right)) max(8px,env(safe-area-inset-bottom)) max(8px,env(safe-area-inset-left))}.top,.bottom{display:flex;align-items:center;justify-content:space-between;gap:8px}.top strong{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.top span,.bottom{color:#aab8ce;font-size:12px}#stage{min-height:0;display:flex;align-items:center;justify-content:center;position:relative}canvas{display:block;max-width:100%;max-height:100%;width:auto;height:auto;aspect-ratio:${width}/${height};background:#121d30;border:1px solid #33435a;border-radius:12px;touch-action:none}.controls{display:flex;justify-content:center;gap:12px}.controls button,.top button{border:1px solid #405574;border-radius:14px;background:#1a2a43;color:white;min-width:64px;min-height:48px;font-weight:700;font-size:16px;touch-action:none}.top button{min-width:auto;min-height:34px;padding:5px 12px;font-size:12px}.controls button:active{background:#31527a}.muted{opacity:.65}.overlay{position:absolute;inset:0;display:grid;place-items:center;pointer-events:none}.overlay b{background:#0c1524e8;padding:12px 18px;border:1px solid #50627d;border-radius:12px;text-align:center;max-width:80%}@media(orientation:landscape){main{grid-template-rows:auto 1fr auto}.controls button{min-width:58px}}</style></head>
<body><main><header class="top"><strong id="title"></strong><span id="score">Score 0</span><button id="restart" type="button">Restart</button></header><section id="stage"><canvas id="game" width="${width}" height="${height}" aria-label="Playable game"></canvas><div class="overlay" id="overlay"></div></section>${touch ? '<nav class="controls" aria-label="Touch controls"><button data-key="left" aria-label="Move left">◀</button><button data-key="right" aria-label="Move right">▶</button><button data-key="jump" aria-label="Jump">JUMP</button></nav>' : '<footer class="bottom">Arrow keys / A-D to move · Space to jump · R to restart</footer>'}<footer class="bottom"><span>Offline HTML5 prototype</span><span>Move · Jump · Collect · Reach the exit</span></footer></main>
<script>'use strict';(()=>{const DATA=${data};const canvas=document.getElementById('game'),ctx=canvas.getContext('2d',{alpha:false});if(!ctx)return;const W=DATA.width,H=DATA.height;document.getElementById('title').textContent=DATA.title;let entities=[],player,score=0,won=false,paused=false,last=0,acc=0,keys=new Set();const spawn=()=>{entities=DATA.entities.map(e=>({...e,visible:true,originX:e.x,dir:1}));player={...DATA.player,vx:0,vy:0,onGround:false};score=0;won=false;document.getElementById('overlay').replaceChildren();updateScore()};function updateScore(){document.getElementById('score').textContent='Score '+score}function overlap(a,b){return a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y}function step(dt){if(won)return;const speed=260;player.vx=(keys.has('left')?-1:0)+(keys.has('right')?1:0);player.vx*=speed;if(keys.has('jump')&&player.onGround){player.vy=-560;player.onGround=false}player.vy=Math.min(1100,player.vy+1400*dt);player.x=Math.max(0,Math.min(W-player.w,player.x+player.vx*dt));const oldY=player.y;player.y+=player.vy*dt;player.onGround=false;if(player.vy>=0){for(const e of entities){if(e.visible&&e.kind==='platform'&&oldY+player.h<=e.y+8&&player.y+player.h>=e.y&&player.x<e.x+e.w&&player.x+player.w>e.x){player.y=e.y-player.h;player.vy=0;player.onGround=true}}}if(player.y>H+80){spawn();return}for(const e of entities){if(!e.visible)continue;if(e.kind==='enemy'){e.x+=e.vx*e.dir*dt;if(e.x<e.originX-55||e.x>e.originX+55)e.dir*=-1}if(!overlap(player,e))continue;if(e.kind==='coin'){e.visible=false;score+=10;updateScore()}else if(e.kind==='hazard'||e.kind==='enemy'){spawn();return}else if(e.kind==='goal'){won=true;const label=document.createElement('b');label.textContent='LEVEL COMPLETE · Score '+score;document.getElementById('overlay').append(label)}}}
function draw(){ctx.fillStyle='#111d31';ctx.fillRect(0,0,W,H);const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,'#172944');g.addColorStop(1,'#0b1424');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);ctx.strokeStyle='rgba(150,190,230,.07)';ctx.lineWidth=1;for(let y=0;y<H;y+=64){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}for(const e of entities){if(!e.visible)continue;ctx.fillStyle=e.color;if(e.kind==='coin'){ctx.beginPath();ctx.arc(e.x+e.w/2,e.y+e.h/2,Math.min(e.w,e.h)/2,0,Math.PI*2);ctx.fill()}else{ctx.fillRect(e.x,e.y,e.w,e.h);if(e.kind==='goal'){ctx.strokeStyle='#f7f4aa';ctx.strokeRect(e.x-3,e.y-3,e.w+6,e.h+6)}}}ctx.fillStyle=player.color;ctx.fillRect(player.x,player.y,player.w,player.h);ctx.fillStyle='#eaf5ff';ctx.fillRect(player.x+player.w*.62,player.y+10,4,4)}function frame(now){if(paused){last=now;requestAnimationFrame(frame);return}if(!last)last=now;const dt=Math.min(.1,(now-last)/1000);last=now;acc+=dt;let n=0;while(acc>=1/60&&n<4){step(1/60);acc-=1/60;n++}if(n===4&&acc>1/60)acc=0;draw();requestAnimationFrame(frame)}function key(e,down){const map={ArrowLeft:'left',KeyA:'left',ArrowRight:'right',KeyD:'right',Space:'jump',ArrowUp:'jump',KeyW:'jump'};const action=map[e.code];if(action){if(down)keys.add(action);else keys.delete(action);e.preventDefault()}if(down&&e.code==='KeyR')spawn()}window.addEventListener('keydown',e=>key(e,true));window.addEventListener('keyup',e=>key(e,false));document.querySelectorAll('[data-key]').forEach(button=>{const action=button.dataset.key;const down=e=>{e.preventDefault();keys.add(action)};const up=e=>{e.preventDefault();keys.delete(action)};button.addEventListener('pointerdown',down);button.addEventListener('pointerup',up);button.addEventListener('pointercancel',up);button.addEventListener('lostpointercapture',up)});document.getElementById('restart').addEventListener('click',spawn);document.addEventListener('visibilitychange',()=>{paused=document.hidden;last=0;acc=0;keys.clear()});spawn();requestAnimationFrame(frame)})();<\/script></body></html>`;
    const bytes = new TextEncoder().encode(html).byteLength;
    if (bytes > MAX_EXPORT_BYTES)
        return { ok: false, error: "HTML5_EXPORT_SIZE_LIMIT" };
    return Object.freeze({ ok: true, html, bytes, exportedNodes: exported.length, excludedAssetCount });
}

};
modules["index.js"]=function(module,exports,require){
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(require("./memory.js"), exports);
__exportStar(require("./profiles.js"), exports);
__exportStar(require("./capabilities.js"), exports);
__exportStar(require("./core.js"), exports);
__exportStar(require("./contracts.js"), exports);
__exportStar(require("./kernel.js"), exports);
__exportStar(require("./pool.js"), exports);
__exportStar(require("./projection.js"), exports);
__exportStar(require("./spatial.js"), exports);
__exportStar(require("./project-document.js"), exports);
__exportStar(require("./renderers/canvas2d.js"), exports);
__exportStar(require("./generator/agent-pipeline.js"), exports);
__exportStar(require("./generator/controller-map.js"), exports);
__exportStar(require("./generator/audio-manager.js"), exports);
__exportStar(require("./renderers/webgl2-2d.js"), exports);
__exportStar(require("./asset-pipeline.js"), exports);
__exportStar(require("./world-scale.js"), exports);
__exportStar(require("./scene-editor.js"), exports);
__exportStar(require("./knowledge-base.js"), exports);
__exportStar(require("./asset-vault.js"), exports);
__exportStar(require("./asset-preview.js"), exports);
__exportStar(require("./sprite-atlas.js"), exports);
__exportStar(require("./sprite-animation.js"), exports);
__exportStar(require("./particles.js"), exports);
__exportStar(require("./gltf-preflight.js"), exports);
__exportStar(require("./html5-export.js"), exports);

};
modules["kernel.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RuntimeKernel = void 0;
const core_ts_1 = require("./core.js");
/** Deterministic, bounded system orchestrator. Registration is setup-time only. */
class RuntimeKernel {
    constructor(options) {
        var _a, _b, _c;
        this.systems = [];
        this.resources = new core_ts_1.ResourceScope();
        this.state = "created";
        this.stepping = false;
        this.initializedCount = 0;
        this.frameCount = 0;
        this.fixedCount = 0;
        this.lastFault = "";
        this.context = options.context;
        this.context.qualityTier = options.device.tier;
        this.clock = new core_ts_1.FixedStepClock({
            stepSeconds: (_a = options.stepSeconds) !== null && _a !== void 0 ? _a : 1 / 60,
            maxFrameSeconds: (_b = options.maxFrameSeconds) !== null && _b !== void 0 ? _b : 0.05,
            maxSubSteps: (_c = options.maxSubSteps) !== null && _c !== void 0 ? _c : options.device.maxSubSteps,
        });
        this.onError = options.onError;
    }
    register(system) {
        if (this.state !== "created" || this.stepping || this.systems.length >= 64 || !system ||
            typeof system.id !== "string" || !system.id || this.systems.some((item) => item.id === system.id))
            return false;
        this.systems.push(system);
        return true;
    }
    start(nowMs = 0) {
        var _a;
        if (this.state !== "created")
            return false;
        this.systems.sort((a, b) => { var _a, _b; return ((_a = a.order) !== null && _a !== void 0 ? _a : 0) - ((_b = b.order) !== null && _b !== void 0 ? _b : 0); });
        this.clock.reset(nowMs);
        this.state = "running";
        for (const system of this.systems) {
            this.initializedCount += 1;
            try {
                (_a = system.init) === null || _a === void 0 ? void 0 : _a.call(system, this.context);
            }
            catch (error) {
                this.fail(system.id, error);
                return false;
            }
        }
        return true;
    }
    frame(nowMs) {
        var _a, _b;
        if (this.state !== "running" || this.stepping)
            return false;
        this.stepping = true;
        try {
            const dt = this.clock.beginFrame(nowMs);
            this.context.deltaSeconds = dt;
            this.clock.runFixed((stepSeconds, tick) => {
                var _a;
                this.context.tick = tick;
                for (const system of this.systems) {
                    try {
                        (_a = system.fixedUpdate) === null || _a === void 0 ? void 0 : _a.call(system, this.context, stepSeconds, tick);
                    }
                    catch (error) {
                        this.fail(system.id, error);
                        throw error;
                    }
                }
                this.fixedCount += 1;
            });
            this.context.interpolationAlpha = this.clock.alpha;
            for (const system of this.systems) {
                try {
                    (_a = system.update) === null || _a === void 0 ? void 0 : _a.call(system, this.context, dt);
                }
                catch (error) {
                    this.fail(system.id, error);
                    return false;
                }
            }
            for (const system of this.systems) {
                try {
                    (_b = system.render) === null || _b === void 0 ? void 0 : _b.call(system, this.context, this.context.interpolationAlpha);
                }
                catch (error) {
                    this.fail(system.id, error);
                    return false;
                }
            }
            this.frameCount += 1;
            return true;
        }
        catch (error) {
            if (this.state !== "faulted")
                this.fail("frame", error);
            return false;
        }
        finally {
            this.stepping = false;
        }
    }
    pause() {
        var _a;
        if (this.state !== "running")
            return false;
        this.clock.pause();
        this.state = "paused";
        for (const system of this.systems) {
            try {
                (_a = system.onSuspend) === null || _a === void 0 ? void 0 : _a.call(system, this.context);
            }
            catch (error) {
                this.notifyError(system.id, error);
            }
        }
        return true;
    }
    resume(nowMs = 0) {
        var _a;
        if (this.state !== "paused")
            return false;
        this.clock.resume(nowMs);
        this.state = "running";
        for (const system of this.systems) {
            try {
                (_a = system.onResume) === null || _a === void 0 ? void 0 : _a.call(system, this.context);
            }
            catch (error) {
                this.notifyError(system.id, error);
            }
        }
        return true;
    }
    own(cleanup) { return this.resources.defer(cleanup); }
    dispose() {
        var _a;
        if (this.state === "disposed")
            return;
        this.clock.pause();
        this.resources.dispose();
        for (let i = this.initializedCount - 1; i >= 0; i--) {
            const system = this.systems[i];
            try {
                (_a = system === null || system === void 0 ? void 0 : system.dispose) === null || _a === void 0 ? void 0 : _a.call(system);
            }
            catch (error) {
                if (system)
                    this.notifyError(system.id, error);
            }
        }
        this.systems.length = 0;
        this.initializedCount = 0;
        this.state = "disposed";
    }
    notifyError(systemId, error) {
        var _a;
        try {
            (_a = this.onError) === null || _a === void 0 ? void 0 : _a.call(this, systemId, error);
        }
        catch { /* error reporting must not recurse */ }
    }
    fail(systemId, error) {
        this.state = "faulted";
        this.lastFault = systemId;
        this.notifyError(systemId, error);
        this.disposeFaulted();
    }
    disposeFaulted() {
        var _a;
        this.clock.pause();
        this.resources.dispose();
        for (let i = this.initializedCount - 1; i >= 0; i--) {
            const system = this.systems[i];
            try {
                (_a = system === null || system === void 0 ? void 0 : system.dispose) === null || _a === void 0 ? void 0 : _a.call(system);
            }
            catch (error) {
                if (system)
                    this.notifyError(system.id, error);
            }
        }
        this.systems.length = 0;
        this.initializedCount = 0;
        this.state = "faulted";
    }
    get status() { return this.state; }
    get frames() { return this.frameCount; }
    get fixedTicks() { return this.fixedCount; }
    get droppedSeconds() { return this.clock.droppedSeconds; }
    get lastFaultSystem() { return this.lastFault; }
    get systemCount() { return this.systems.length; }
}
exports.RuntimeKernel = RuntimeKernel;

};
modules["knowledge-base.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentKnowledgeBase = void 0;
const ID = /^[A-Za-z0-9_-]{1,80}$/;
const KINDS = new Set(["fact", "decision", "pattern", "pitfall", "reference", "skill-note"]);
const DEFAULTS = Object.freeze({ maxEntries: 256, maxBytes: 256 * 1024, maxEntryBytes: 8192, maxTags: 16 });
function safeUrl(value) { try {
    const url = new URL(value);
    return (url.protocol === "https:" || url.protocol === "http:") && !url.username && !url.password;
}
catch {
    return false;
} }
function normalizedText(value, max) { return typeof value === "string" && value.trim().length > 0 && value.length <= max && !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(value); }
class AgentKnowledgeBase {
    constructor(limits = {}) {
        this.entries = new Map();
        this.limits = { ...DEFAULTS, ...limits };
        if (!Number.isInteger(this.limits.maxEntries) || this.limits.maxEntries < 1 || this.limits.maxEntries > 4096 || !Number.isInteger(this.limits.maxBytes) || this.limits.maxBytes < 1024 || !Number.isInteger(this.limits.maxEntryBytes) || this.limits.maxEntryBytes < 128 || this.limits.maxEntryBytes > this.limits.maxBytes || !Number.isInteger(this.limits.maxTags) || this.limits.maxTags < 1 || this.limits.maxTags > 64)
            throw new TypeError("INVALID_KNOWLEDGE_LIMITS");
    }
    get size() { return this.entries.size; }
    get bytes() { let total = 0; for (const entry of this.entries.values())
        total += this.entryBytes(entry); return total; }
    entryBytes(entry) { return JSON.stringify(entry).length * 2; }
    add(input) {
        var _a, _b, _c;
        if (!input || typeof input !== "object" || (Object.getPrototypeOf(input) !== Object.prototype && Object.getPrototypeOf(input) !== null))
            return { ok: false, error: "INVALID_KNOWLEDGE_ENTRY" };
        const descriptors = Object.getOwnPropertyDescriptors(input);
        const allowed = new Set(["id", "kind", "title", "content", "tags", "sourceUrl", "confidence", "createdAt", "updatedAt", "hits"]);
        if (Object.keys(descriptors).some(key => !allowed.has(key) || !("value" in descriptors[key]) || descriptors[key].get || descriptors[key].set))
            return { ok: false, error: "INVALID_KNOWLEDGE_ENTRY" };
        if (!ID.test(input.id) || !KINDS.has(input.kind) || !normalizedText(input.title, 160) || !normalizedText(input.content, 6000) || !Array.isArray(input.tags) || input.tags.length > this.limits.maxTags || input.tags.some(tag => !normalizedText(tag, 32)) || new Set(input.tags).size !== input.tags.length || !Number.isFinite(input.confidence) || input.confidence < 0 || input.confidence > 1 || !Number.isFinite(input.createdAt) || !Number.isFinite(input.updatedAt) || input.updatedAt < input.createdAt || (input.sourceUrl !== undefined && (typeof input.sourceUrl !== "string" || !safeUrl(input.sourceUrl))))
            return { ok: false, error: "INVALID_KNOWLEDGE_ENTRY" };
        const entry = Object.freeze({ ...input, tags: Object.freeze([...input.tags]), hits: Number.isSafeInteger((_a = input.hits) !== null && _a !== void 0 ? _a : 0) && ((_b = input.hits) !== null && _b !== void 0 ? _b : 0) >= 0 ? (_c = input.hits) !== null && _c !== void 0 ? _c : 0 : 0 });
        if (this.entryBytes(entry) > this.limits.maxEntryBytes)
            return { ok: false, error: "KNOWLEDGE_ENTRY_TOO_LARGE" };
        const previous = this.entries.get(entry.id);
        this.entries.delete(entry.id);
        this.entries.set(entry.id, entry);
        while (this.entries.size > this.limits.maxEntries || this.bytes > this.limits.maxBytes) {
            const oldest = this.entries.keys().next().value;
            if (!oldest || oldest === entry.id) {
                if (previous)
                    this.entries.set(previous.id, previous);
                else
                    this.entries.delete(entry.id);
                return { ok: false, error: "KNOWLEDGE_BUDGET_EXCEEDED" };
            }
            this.entries.delete(oldest);
        }
        return { ok: true, value: entry };
    }
    search(query, tags = [], limit = 8) {
        if (!normalizedText(query, 256) || !Array.isArray(tags) || tags.length > this.limits.maxTags || !Number.isInteger(limit) || limit < 1 || limit > 32)
            return [];
        const terms = query.toLowerCase().split(/[^a-z0-9_+-]+/).filter(Boolean);
        const ranked = [...this.entries.values()].map(entry => {
            const haystack = `${entry.title} ${entry.content} ${entry.tags.join(" ")}`.toLowerCase();
            const tagHits = tags.filter(tag => entry.tags.includes(tag)).length;
            const termHits = terms.reduce((score, term) => score + (haystack.includes(term) ? 1 : 0), 0);
            return { entry, score: termHits * 3 + tagHits * 5 + entry.confidence };
        }).filter(item => item.score > 0).sort((a, b) => b.score - a.score || b.entry.updatedAt - a.entry.updatedAt).slice(0, limit);
        for (const item of ranked) {
            this.entries.delete(item.entry.id);
            this.entries.set(item.entry.id, Object.freeze({ ...item.entry, hits: item.entry.hits + 1 }));
        }
        return ranked.map(item => this.entries.get(item.entry.id));
    }
    recordSkillOutcome(skillId, success, now = Date.now()) {
        var _a, _b, _c, _d, _e;
        if (!/^[A-Za-z0-9_-]{1,32}$/.test(skillId) || typeof success !== "boolean" || !Number.isFinite(now))
            return { ok: false, error: "INVALID_SKILL_OUTCOME" };
        const id = `skill-${skillId}`;
        const prior = this.entries.get(id);
        const priorScore = prior ? Number((_b = (_a = prior.content.match(/score=([0-9.]+)/)) === null || _a === void 0 ? void 0 : _a[1]) !== null && _b !== void 0 ? _b : 0.5) : 0.5;
        const score = Math.max(0, Math.min(1, priorScore * 0.8 + (success ? 1 : 0) * 0.2));
        const content = `score=${score.toFixed(4)}; observations=${((_c = prior === null || prior === void 0 ? void 0 : prior.hits) !== null && _c !== void 0 ? _c : 0) + 1}; last=${success ? "success" : "failure"}`;
        return this.add({ id, kind: "skill-note", title: `Skill outcome: ${skillId}`, content, tags: ["skill", skillId], confidence: 0.8, createdAt: (_d = prior === null || prior === void 0 ? void 0 : prior.createdAt) !== null && _d !== void 0 ? _d : now, updatedAt: now, hits: ((_e = prior === null || prior === void 0 ? void 0 : prior.hits) !== null && _e !== void 0 ? _e : 0) + 1 });
    }
    exportSnapshot() { return JSON.stringify({ schemaVersion: 1, entries: [...this.entries.values()] }); }
    importSnapshot(raw) {
        if (typeof raw !== "string" || raw.length > this.limits.maxBytes * 2)
            return { ok: false, error: "KNOWLEDGE_SNAPSHOT_LIMIT" };
        let parsed;
        try {
            parsed = JSON.parse(raw);
        }
        catch {
            return { ok: false, error: "KNOWLEDGE_SNAPSHOT_INVALID_JSON" };
        }
        if (!parsed || typeof parsed !== "object" || parsed.schemaVersion !== 1 || !Array.isArray(parsed.entries) || parsed.entries.length > this.limits.maxEntries)
            return { ok: false, error: "KNOWLEDGE_SNAPSHOT_SCHEMA" };
        const candidate = new AgentKnowledgeBase(this.limits);
        const seen = new Set();
        for (const entry of parsed.entries) {
            if (!entry || typeof entry.id !== "string" || seen.has(entry.id))
                return { ok: false, error: "KNOWLEDGE_SNAPSHOT_DUPLICATE_ID" };
            seen.add(entry.id);
            const result = candidate.add(entry);
            if (!result.ok)
                return { ok: false, error: `KNOWLEDGE_SNAPSHOT_ENTRY:${result.error}` };
        }
        this.entries.clear();
        for (const entry of candidate.entries.values())
            this.entries.set(entry.id, entry);
        return { ok: true, value: this.entries.size };
    }
    clear() { this.entries.clear(); }
}
exports.AgentKnowledgeBase = AgentKnowledgeBase;

};
modules["memory.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MemoryBudget = void 0;
class MemoryBudget {
    constructor(limitBytes) {
        this.entries = new Map();
        this.used = 0;
        this.clock = 0;
        this.disposed = false;
        if (!Number.isSafeInteger(limitBytes) || limitBytes < 1)
            throw new RangeError("INVALID_MEMORY_BUDGET");
        this.limitBytes = limitBytes;
    }
    register(id, kind, bytes, dispose, pinned = false) {
        if (this.disposed || typeof id !== "string" || !/^[a-zA-Z0-9:_-]{1,128}$/.test(id) || this.entries.has(id) ||
            !["texture", "mesh", "audio", "animation", "other"].includes(kind) || !Number.isSafeInteger(bytes) || bytes < 0 || bytes > this.limitBytes)
            return false;
        let pinnedBytes = 0;
        for (const entry of this.entries.values())
            if (entry.pinned)
                pinnedBytes += entry.bytes;
        if (pinnedBytes + bytes > this.limitBytes)
            return false;
        this.evictTo(this.limitBytes - bytes);
        if (this.used + bytes > this.limitBytes)
            return false;
        this.entries.set(id, { bytes, kind, pinned, stamp: ++this.clock, dispose });
        this.used += bytes;
        return true;
    }
    touch(id) {
        const entry = this.entries.get(id);
        if (!entry || this.disposed)
            return false;
        entry.stamp = ++this.clock;
        return true;
    }
    pin(id, pinned = true) {
        const entry = this.entries.get(id);
        if (!entry || this.disposed)
            return false;
        entry.pinned = pinned;
        return true;
    }
    release(id) {
        const entry = this.entries.get(id);
        if (!entry)
            return false;
        this.entries.delete(id);
        this.used -= entry.bytes;
        this.safeDispose(entry);
        return true;
    }
    evict(bytesToFree) {
        if (this.disposed || !Number.isSafeInteger(bytesToFree) || bytesToFree <= 0)
            return 0;
        const before = this.used;
        this.evictTo(Math.max(0, before - bytesToFree));
        return before - this.used;
    }
    evictTo(target) {
        while (this.used > target) {
            let candidateId;
            let oldest = Infinity;
            for (const [id, entry] of this.entries) {
                if (!entry.pinned && entry.stamp < oldest) {
                    oldest = entry.stamp;
                    candidateId = id;
                }
            }
            if (candidateId === undefined)
                break;
            const entry = this.entries.get(candidateId);
            this.entries.delete(candidateId);
            this.used -= entry.bytes;
            this.safeDispose(entry);
        }
    }
    safeDispose(entry) { var _a; try {
        (_a = entry.dispose) === null || _a === void 0 ? void 0 : _a.call(entry);
    }
    catch { /* continue releasing other resources */ } }
    dispose() {
        if (this.disposed)
            return;
        this.disposed = true;
        for (const entry of this.entries.values())
            this.safeDispose(entry);
        this.entries.clear();
        this.used = 0;
    }
    get usedBytes() { return this.used; }
    get availableBytes() { return Math.max(0, this.limitBytes - this.used); }
    get resourceCount() { return this.entries.size; }
    get isDisposed() { return this.disposed; }
}
exports.MemoryBudget = MemoryBudget;

};
modules["particles.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ParticleSystem = void 0;
const core_ts_1 = require("./core.js");
const MAX_CAPACITY = 4096;
const FLOATS_PER_PARTICLE = 6;
/** Data-oriented bounded particles; call update at a fixed simulation timestep. */
class ParticleSystem {
    constructor(capacity = 32, seed = 1) {
        this.activeCount = 0;
        this.droppedCount = 0;
        if (!Number.isInteger(capacity) || capacity < 1 || capacity > MAX_CAPACITY)
            throw new RangeError("INVALID_PARTICLE_CAPACITY");
        this.capacity = capacity;
        this.x = new Float32Array(capacity);
        this.y = new Float32Array(capacity);
        this.vx = new Float32Array(capacity);
        this.vy = new Float32Array(capacity);
        this.age = new Float32Array(capacity);
        this.life = new Float32Array(capacity);
        this.size = new Float32Array(capacity);
        this.rotation = new Float32Array(capacity);
        this.spin = new Float32Array(capacity);
        this.gravityX = new Float32Array(capacity);
        this.gravityY = new Float32Array(capacity);
        this.drag = new Float32Array(capacity);
        this.random = new core_ts_1.SeededRandom(seed);
    }
    emit(burst) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
        if (!burst || ![burst.x, burst.y].every(Number.isFinite) || !Number.isInteger(burst.count) || burst.count < 0 || burst.count > 65536)
            return 0;
        const speedMin = (_a = burst.speedMin) !== null && _a !== void 0 ? _a : 20, speedMax = (_b = burst.speedMax) !== null && _b !== void 0 ? _b : 80;
        const lifeMin = (_c = burst.lifeMin) !== null && _c !== void 0 ? _c : 0.25, lifeMax = (_d = burst.lifeMax) !== null && _d !== void 0 ? _d : 0.7;
        const sizeMin = (_e = burst.sizeMin) !== null && _e !== void 0 ? _e : 2, sizeMax = (_f = burst.sizeMax) !== null && _f !== void 0 ? _f : 5;
        const angle = (_g = burst.angle) !== null && _g !== void 0 ? _g : -Math.PI / 2, spread = (_h = burst.spread) !== null && _h !== void 0 ? _h : Math.PI * 2;
        const gravityX = (_j = burst.gravityX) !== null && _j !== void 0 ? _j : 0, gravityY = (_k = burst.gravityY) !== null && _k !== void 0 ? _k : 0, drag = (_l = burst.drag) !== null && _l !== void 0 ? _l : 0;
        if (![speedMin, speedMax, lifeMin, lifeMax, sizeMin, sizeMax, angle, spread, gravityX, gravityY, drag].every(Number.isFinite) || speedMin < 0 || speedMax < speedMin || speedMax > 100000 || lifeMin <= 0 || lifeMax < lifeMin || lifeMax > 120 || sizeMin < 0 || sizeMax < sizeMin || sizeMax > 4096 || spread < 0 || spread > Math.PI * 2 || drag < 0 || drag > 100)
            return 0;
        const available = this.capacity - this.activeCount;
        const count = Math.min(available, burst.count);
        this.droppedCount += burst.count - count;
        for (let i = 0; i < count; i++) {
            const index = this.activeCount++;
            const theta = angle + (this.random.next() - 0.5) * spread;
            const speed = speedMin + this.random.next() * (speedMax - speedMin);
            this.x[index] = burst.x;
            this.y[index] = burst.y;
            this.vx[index] = Math.cos(theta) * speed;
            this.vy[index] = Math.sin(theta) * speed;
            this.age[index] = 0;
            this.life[index] = lifeMin + this.random.next() * (lifeMax - lifeMin);
            this.size[index] = sizeMin + this.random.next() * (sizeMax - sizeMin);
            this.rotation[index] = this.random.next() * Math.PI * 2;
            this.spin[index] = (this.random.next() - 0.5) * 8;
            this.gravityX[index] = gravityX;
            this.gravityY[index] = gravityY;
            this.drag[index] = drag;
        }
        return count;
    }
    update(deltaSeconds) {
        if (!Number.isFinite(deltaSeconds) || deltaSeconds <= 0 || this.activeCount === 0)
            return;
        const dt = Math.min(deltaSeconds, 0.1);
        let index = 0;
        while (index < this.activeCount) {
            const age = this.age[index] + dt;
            if (age >= this.life[index]) {
                const last = --this.activeCount;
                if (index !== last)
                    this.copyParticle(last, index);
                continue;
            }
            this.age[index] = age;
            const damping = Math.exp(-this.drag[index] * dt);
            this.vx[index] = (this.vx[index] + this.gravityX[index] * dt) * damping;
            this.vy[index] = (this.vy[index] + this.gravityY[index] * dt) * damping;
            this.x[index] = this.x[index] + this.vx[index] * dt;
            this.y[index] = this.y[index] + this.vy[index] * dt;
            this.rotation[index] = this.rotation[index] + this.spin[index] * dt;
            index++;
        }
    }
    /** Writes x, y, size, rotation, normalized age and alpha. Returns particles written. */
    writeSnapshot(target) {
        const count = this.activeCount;
        if (!(target instanceof Float32Array) || target.length < count * FLOATS_PER_PARTICLE)
            throw new RangeError("PARTICLE_SNAPSHOT_BUFFER_TOO_SMALL");
        for (let i = 0; i < count; i++) {
            const offset = i * FLOATS_PER_PARTICLE;
            const normalizedAge = (0, core_ts_1.clamp)(this.age[i] / this.life[i], 0, 1);
            target[offset] = this.x[i];
            target[offset + 1] = this.y[i];
            target[offset + 2] = this.size[i];
            target[offset + 3] = this.rotation[i];
            target[offset + 4] = normalizedAge;
            target[offset + 5] = 1 - normalizedAge;
        }
        return count;
    }
    clear() { this.activeCount = 0; }
    get stats() { return Object.freeze({ active: this.activeCount, capacity: this.capacity, droppedEmissions: this.droppedCount }); }
    copyParticle(from, to) {
        this.x[to] = this.x[from];
        this.y[to] = this.y[from];
        this.vx[to] = this.vx[from];
        this.vy[to] = this.vy[from];
        this.age[to] = this.age[from];
        this.life[to] = this.life[from];
        this.size[to] = this.size[from];
        this.rotation[to] = this.rotation[from];
        this.spin[to] = this.spin[from];
        this.gravityX[to] = this.gravityX[from];
        this.gravityY[to] = this.gravityY[from];
        this.drag[to] = this.drag[from];
    }
}
exports.ParticleSystem = ParticleSystem;

};
modules["pool.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ObjectPool = void 0;
/** Fixed-capacity index pool. All object creation happens in the constructor. */
class ObjectPool {
    constructor(capacity, factory, reset) {
        this.activeCount = 0;
        this.disposed = false;
        this.reset = reset;
        if (!Number.isSafeInteger(capacity) || capacity < 1 || capacity > 262144 || typeof factory !== "function") {
            throw new RangeError("INVALID_POOL_CONFIGURATION");
        }
        this.values = new Array(capacity);
        this.free = new Int32Array(capacity);
        this.active = new Uint8Array(capacity);
        for (let i = 0; i < capacity; i++) {
            this.values[i] = factory(i);
            this.free[i] = capacity - 1 - i;
        }
        this.freeCount = capacity;
    }
    acquire() {
        if (this.disposed || this.freeCount === 0)
            return -1;
        const index = this.free[--this.freeCount];
        this.active[index] = 1;
        this.activeCount++;
        return index;
    }
    get(index) {
        return Number.isInteger(index) && index >= 0 && index < this.values.length && this.active[index] === 1
            ? this.values[index]
            : undefined;
    }
    release(index) {
        var _a;
        if (this.disposed || !Number.isInteger(index) || index < 0 || index >= this.values.length || this.active[index] !== 1)
            return false;
        const value = this.values[index];
        try {
            (_a = this.reset) === null || _a === void 0 ? void 0 : _a.call(this, value);
        }
        catch {
            return false;
        }
        this.active[index] = 0;
        this.free[this.freeCount++] = index;
        this.activeCount--;
        return true;
    }
    dispose(disposeValue) {
        if (this.disposed)
            return;
        this.disposed = true;
        if (disposeValue) {
            for (let i = 0; i < this.values.length; i++) {
                try {
                    disposeValue(this.values[i]);
                }
                catch { /* continue releasing remaining entries */ }
            }
        }
        this.active.fill(0);
        this.freeCount = 0;
        this.activeCount = 0;
    }
    get capacity() { return this.values.length; }
    get available() { return this.freeCount; }
    get inUse() { return this.activeCount; }
    get isDisposed() { return this.disposed; }
}
exports.ObjectPool = ObjectPool;

};
modules["profiles.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createArtBudget = createArtBudget;
exports.createGenreBudget = createGenreBudget;
const ART_BASE = {
    "pixel-art": { preferredRenderer: "canvas2d", nearestFiltering: true, maxBonesPerCharacter: 0, bakedLightingPreferred: true },
    "hand-drawn": { preferredRenderer: "canvas2d", nearestFiltering: false, maxBonesPerCharacter: 8, bakedLightingPreferred: true },
    vector: { preferredRenderer: "canvas2d", nearestFiltering: false, maxBonesPerCharacter: 8, bakedLightingPreferred: true },
    isometric: { preferredRenderer: "canvas2d", nearestFiltering: false, maxBonesPerCharacter: 8, bakedLightingPreferred: true },
    "retro-3d": { preferredRenderer: "webgl2", nearestFiltering: true, maxBonesPerCharacter: 8, bakedLightingPreferred: true },
    voxel: { preferredRenderer: "webgl2", nearestFiltering: false, maxBonesPerCharacter: 8, bakedLightingPreferred: true },
    toon: { preferredRenderer: "webgl2", nearestFiltering: false, maxBonesPerCharacter: 15, bakedLightingPreferred: true },
    "low-poly": { preferredRenderer: "webgl2", nearestFiltering: false, maxBonesPerCharacter: 15, bakedLightingPreferred: true },
    pbr: { preferredRenderer: "webgl2", nearestFiltering: false, maxBonesPerCharacter: 32, bakedLightingPreferred: true },
    photogrammetry: { preferredRenderer: "webgl2", nearestFiltering: false, maxBonesPerCharacter: 32, bakedLightingPreferred: true },
    "2d-skeletal": { preferredRenderer: "canvas2d", nearestFiltering: false, maxBonesPerCharacter: 15, bakedLightingPreferred: true },
    "3d-skeletal": { preferredRenderer: "webgl2", nearestFiltering: false, maxBonesPerCharacter: 32, bakedLightingPreferred: true },
};
function createArtBudget(style, tier) {
    const base = ART_BASE[style];
    if (!base)
        throw new TypeError("UNSUPPORTED_ART_DIRECTION");
    const low = tier === 0;
    const mid = tier === 1;
    const textureMaxDimension = low ? 512 : mid ? 1024 : 2048;
    const is2d = base.preferredRenderer === "canvas2d";
    return Object.freeze({
        ...base,
        textureMaxDimension,
        antialias: !low && !base.nearestFiltering,
        realtimeShadows: !low && !is2d && (style === "toon" || style === "low-poly" || style === "pbr" || style === "3d-skeletal"),
        dynamicLights: low ? 0 : mid ? 1 : style === "pbr" || style === "photogrammetry" ? 4 : 2,
        postProcessing: !low && tier === 2 && (style === "pbr" || style === "photogrammetry" || style === "3d-skeletal"),
    });
}
const COMPLEX_GENRES = new Set(["open-world", "sandbox", "simulation", "survival", "rpg", "jrpg"]);
const LOW_ENTITY_CAP = {
    platformer: 128, metroidvania: 160, racing: 64, fighting: 48, shooter: 96, rpg: 192, jrpg: 160, strategy: 256,
    "tower-defense": 192, survival: 192, sandbox: 256, "open-world": 256, puzzle: 64, rhythm: 48, "visual-novel": 32,
    sports: 96, horror: 96, simulation: 192, roguelike: 128, card: 32, educational: 64, "point-and-click": 48,
};
function createGenreBudget(genre, tier) {
    if (!(genre in LOW_ENTITY_CAP))
        throw new TypeError("UNSUPPORTED_GENRE");
    const base = LOW_ENTITY_CAP[genre];
    const scale = tier === 0 ? 1 : tier === 1 ? 2 : 4;
    return Object.freeze({
        simulationHz: tier === 0 ? 30 : 60,
        targetFps: tier === 0 ? 30 : 60,
        maxEntities: Math.min(4096, base * scale),
        maxActiveAI: Math.min(256, Math.max(4, Math.floor(base * scale * (COMPLEX_GENRES.has(genre) ? 0.18 : 0.12)))),
        maxParticles: tier === 0 ? 32 : tier === 1 ? 96 : 256,
        maxAudioVoices: tier === 0 ? 8 : tier === 1 ? 16 : 32,
        maxDynamicLights: tier === 0 ? 0 : tier === 1 ? 1 : 4,
    });
}

};
modules["project-document.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProjectHistory = exports.PROJECT_SCHEMA_VERSION = void 0;
exports.validateProjectDocument = validateProjectDocument;
exports.saveProject = saveProject;
exports.loadProject = loadProject;
/** Versioned, renderer-neutral project document and bounded undo/redo history. */
exports.PROJECT_SCHEMA_VERSION = 1;
const ID = /^[A-Za-z0-9_-]{1,80}$/;
const TYPE = /^[A-Za-z][A-Za-z0-9_.-]{0,63}$/;
const MAX_NODES = 20000;
const MAX_DOCUMENT_BYTES = 2 * 1024 * 1024;
const MAX_HISTORY = 32;
const MAX_HISTORY_BYTES = 4 * 1024 * 1024;
function isJsonValue(value, depth, seen) {
    if (value === null || typeof value === "string" || typeof value === "boolean")
        return true;
    if (typeof value === "number")
        return Number.isFinite(value);
    if (typeof value !== "object" || depth > 32 || seen.has(value))
        return false;
    seen.add(value);
    let valid = true;
    if (Array.isArray(value)) {
        if (value.length > 4096)
            valid = false;
        else
            for (const item of value)
                if (!isJsonValue(item, depth + 1, seen)) {
                    valid = false;
                    break;
                }
    }
    else {
        const proto = Object.getPrototypeOf(value);
        if (proto !== Object.prototype && proto !== null)
            valid = false;
        else {
            const entries = Object.entries(value);
            if (entries.length > 4096)
                valid = false;
            else
                for (const [key, item] of entries)
                    if (key === "__proto__" || key === "constructor" || !isJsonValue(item, depth + 1, seen)) {
                        valid = false;
                        break;
                    }
        }
    }
    seen.delete(value);
    return valid;
}
function validProps(value) {
    if (!value || typeof value !== "object" || Array.isArray(value) || !isJsonValue(value, 0, new Set()))
        return false;
    try {
        return JSON.stringify(value).length <= 32768;
    }
    catch {
        return false;
    }
}
function cloneJson(value) { return JSON.parse(JSON.stringify(value)); }
function validateProjectDocument(input) {
    var _a;
    if (!input || typeof input !== "object")
        return { ok: false, error: "PROJECT_NOT_OBJECT" };
    const p = input;
    if (p.schemaVersion !== exports.PROJECT_SCHEMA_VERSION)
        return { ok: false, error: "UNSUPPORTED_PROJECT_SCHEMA" };
    if (typeof p.projectId !== "string" || !ID.test(p.projectId))
        return { ok: false, error: "INVALID_PROJECT_ID" };
    if (typeof p.title !== "string" || !p.title.trim() || p.title.length > 120)
        return { ok: false, error: "INVALID_PROJECT_TITLE" };
    if (typeof p.activeSceneId !== "string" || !ID.test(p.activeSceneId))
        return { ok: false, error: "INVALID_ACTIVE_SCENE" };
    if (!Array.isArray(p.nodes) || p.nodes.length > MAX_NODES)
        return { ok: false, error: "INVALID_NODE_LIST" };
    if (!Number.isFinite(p.updatedAt))
        return { ok: false, error: "INVALID_UPDATED_AT" };
    const ids = new Set();
    for (const node of p.nodes) {
        if (!node || typeof node !== "object" || !ID.test(node.id) || !TYPE.test(node.type) || typeof node.name !== "string" || node.name.length > 120 || !(node.parentId === null || (typeof node.parentId === "string" && ID.test(node.parentId))) || !validProps(node.props) || ids.has(node.id))
            return { ok: false, error: "INVALID_PROJECT_NODE" };
        ids.add(node.id);
    }
    const parentById = new Map();
    for (const node of p.nodes) {
        if (node.parentId !== null && !ids.has(node.parentId))
            return { ok: false, error: "MISSING_PARENT_NODE" };
        parentById.set(node.id, node.parentId);
    }
    for (const node of p.nodes) {
        let cursor = node.id;
        let hops = 0;
        while (cursor !== null && hops++ <= p.nodes.length)
            cursor = (_a = parentById.get(cursor)) !== null && _a !== void 0 ? _a : null;
        if (hops > p.nodes.length + 1)
            return { ok: false, error: "PROJECT_HIERARCHY_CYCLE" };
    }
    try {
        if (JSON.stringify(p).length > MAX_DOCUMENT_BYTES)
            return { ok: false, error: "PROJECT_TOO_LARGE" };
    }
    catch {
        return { ok: false, error: "PROJECT_NOT_SERIALIZABLE" };
    }
    return { ok: true, value: p };
}
class ProjectHistory {
    pushBounded(stack, value, kind) {
        const bytes = JSON.stringify(value).length;
        stack.push(value);
        if (kind === "undo")
            this.undoBytes += bytes;
        else
            this.redoBytes += bytes;
        while (stack.length > MAX_HISTORY || (kind === "undo" ? this.undoBytes : this.redoBytes) > MAX_HISTORY_BYTES) {
            const removed = stack.shift();
            if (!removed)
                break;
            const removedBytes = JSON.stringify(removed).length;
            if (kind === "undo")
                this.undoBytes -= removedBytes;
            else
                this.redoBytes -= removedBytes;
        }
    }
    constructor(initial) {
        this.undoStack = [];
        this.redoStack = [];
        this.undoBytes = 0;
        this.redoBytes = 0;
        const checked = validateProjectDocument(initial);
        if (!checked.ok)
            throw new TypeError(checked.error);
        this.current = cloneJson(checked.value);
    }
    get document() { return this.current; }
    get canUndo() { return this.undoStack.length > 0; }
    get canRedo() { return this.redoStack.length > 0; }
    apply(operation, now = Date.now()) {
        var _a, _b;
        if (!operation || typeof operation !== "object" || !["add", "remove", "rename", "set-props", "set-parent"].includes(operation.kind))
            return { ok: false, error: "INVALID_PROJECT_OPERATION" };
        const nodes = this.current.nodes.slice();
        const index = operation.kind === "add" ? -1 : nodes.findIndex(n => n.id === operation.id);
        if (operation.kind !== "add" && index < 0)
            return { ok: false, error: "NODE_NOT_FOUND" };
        switch (operation.kind) {
            case "add":
                if (!operation.node || typeof operation.node !== "object" || nodes.length >= MAX_NODES || nodes.some(n => n.id === operation.node.id))
                    return { ok: false, error: "NODE_LIMIT_OR_DUPLICATE" };
                try {
                    nodes.push(cloneJson(operation.node));
                }
                catch {
                    return { ok: false, error: "INVALID_NODE_PAYLOAD" };
                }
                break;
            case "remove": {
                const removeIds = new Set([operation.id]);
                let changed = true;
                while (changed) {
                    changed = false;
                    for (let i = 0; i < nodes.length; i++) {
                        const node = nodes[i];
                        if (node.parentId !== null && removeIds.has(node.parentId) && !removeIds.has(node.id)) {
                            removeIds.add(node.id);
                            changed = true;
                        }
                    }
                }
                for (let i = nodes.length - 1; i >= 0; i--)
                    if (removeIds.has(nodes[i].id))
                        nodes.splice(i, 1);
                break;
            }
            case "rename":
                if (typeof operation.name !== "string" || !operation.name.trim() || operation.name.length > 120)
                    return { ok: false, error: "INVALID_NODE_NAME" };
                nodes[index] = { ...nodes[index], name: operation.name };
                break;
            case "set-props":
                if (!validProps(operation.props))
                    return { ok: false, error: "INVALID_NODE_PROPS" };
                nodes[index] = { ...nodes[index], props: cloneJson(operation.props) };
                break;
            case "set-parent": {
                if (operation.parentId === operation.id || (operation.parentId !== null && !nodes.some(n => n.id === operation.parentId)))
                    return { ok: false, error: "INVALID_PARENT" };
                let ancestor = operation.parentId;
                let hops = 0;
                while (ancestor !== null && hops++ <= nodes.length) {
                    if (ancestor === operation.id)
                        return { ok: false, error: "PARENT_CYCLE" };
                    ancestor = (_b = (_a = nodes.find(n => n.id === ancestor)) === null || _a === void 0 ? void 0 : _a.parentId) !== null && _b !== void 0 ? _b : null;
                }
                if (hops > nodes.length + 1)
                    return { ok: false, error: "PARENT_CYCLE" };
                nodes[index] = { ...nodes[index], parentId: operation.parentId };
                break;
            }
        }
        const next = { ...this.current, nodes, updatedAt: now };
        const checked = validateProjectDocument(next);
        if (!checked.ok)
            return checked;
        // History is only mutated after the candidate document passes all validation.
        this.pushBounded(this.undoStack, this.current, "undo");
        this.redoStack.length = 0;
        this.redoBytes = 0;
        this.current = checked.value;
        return { ok: true, value: this.current };
    }
    /** Applies a bounded command group as one undo/redo transaction. */
    applyBatch(operations, now = Date.now()) {
        if (!Array.isArray(operations) || operations.length < 1 || operations.length > 512)
            return { ok: false, error: "INVALID_OPERATION_BATCH" };
        const shadow = new ProjectHistory(this.current);
        for (const operation of operations) {
            if (!operation || typeof operation !== "object")
                return { ok: false, error: "INVALID_PROJECT_OPERATION" };
            const result = shadow.apply(operation, now);
            if (!result.ok)
                return result;
        }
        const checked = validateProjectDocument(shadow.document);
        if (!checked.ok)
            return checked;
        this.pushBounded(this.undoStack, this.current, "undo");
        this.redoStack.length = 0;
        this.redoBytes = 0;
        this.current = checked.value;
        return { ok: true, value: this.current };
    }
    undo() {
        const previous = this.undoStack.pop();
        if (!previous)
            return { ok: false, error: "NOTHING_TO_UNDO" };
        this.undoBytes -= JSON.stringify(previous).length;
        this.pushBounded(this.redoStack, this.current, "redo");
        this.current = previous;
        return { ok: true, value: this.current };
    }
    redo() {
        const next = this.redoStack.pop();
        if (!next)
            return { ok: false, error: "NOTHING_TO_REDO" };
        this.redoBytes -= JSON.stringify(next).length;
        this.pushBounded(this.undoStack, this.current, "undo");
        this.current = next;
        return { ok: true, value: this.current };
    }
}
exports.ProjectHistory = ProjectHistory;
function saveProject(storage, key, document) {
    if (!/^[A-Za-z0-9_-]{1,100}$/.test(key))
        return { ok: false, error: "INVALID_STORAGE_KEY" };
    const checked = validateProjectDocument(document);
    if (!checked.ok)
        return checked;
    try {
        const serialized = JSON.stringify(checked.value);
        if (serialized.length > MAX_DOCUMENT_BYTES)
            return { ok: false, error: "PROJECT_TOO_LARGE" };
        storage.set(key, serialized);
        return { ok: true, value: serialized.length };
    }
    catch {
        return { ok: false, error: "PROJECT_STORAGE_FAILED" };
    }
}
function loadProject(storage, key) {
    if (!/^[A-Za-z0-9_-]{1,100}$/.test(key))
        return { ok: false, error: "INVALID_STORAGE_KEY" };
    try {
        const raw = storage.get(key);
        if (raw === null)
            return { ok: false, error: "PROJECT_NOT_FOUND" };
        if (raw.length > MAX_DOCUMENT_BYTES)
            return { ok: false, error: "PROJECT_TOO_LARGE" };
        return validateProjectDocument(JSON.parse(raw));
    }
    catch {
        return { ok: false, error: "PROJECT_STORAGE_FAILED_OR_INVALID_JSON" };
    }
}

};
modules["projection.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.worldToIsometric = worldToIsometric;
exports.isometricToWorld = isometricToWorld;
exports.projectPseudo3D = projectPseudo3D;
exports.raycastGrid = raycastGrid;
function worldToIsometric(x, y, tileWidth, tileHeight, out) {
    if (![x, y, tileWidth, tileHeight].every(Number.isFinite) || tileWidth <= 0 || tileHeight <= 0 || !out)
        return false;
    out.x = (x - y) * tileWidth * 0.5;
    out.y = (x + y) * tileHeight * 0.5;
    return true;
}
function isometricToWorld(screenX, screenY, tileWidth, tileHeight, out) {
    if (![screenX, screenY, tileWidth, tileHeight].every(Number.isFinite) || tileWidth <= 0 || tileHeight <= 0 || !out)
        return false;
    const a = screenX / (tileWidth * 0.5);
    const b = screenY / (tileHeight * 0.5);
    out.x = (a + b) * 0.5;
    out.y = (b - a) * 0.5;
    return true;
}
function projectPseudo3D(worldX, worldY, worldZ, cameraX, cameraY, cameraZ, cameraDepth, focalLength, out) {
    if (![worldX, worldY, worldZ, cameraX, cameraY, cameraZ, cameraDepth, focalLength].every(Number.isFinite) || cameraDepth <= 0 || focalLength <= 0 || !out)
        return false;
    const depth = worldZ - cameraZ;
    if (depth <= 0.001)
        return false;
    const scale = focalLength / depth;
    out.x = (worldX - cameraX) * scale;
    out.y = (worldY - cameraY) * scale + cameraDepth;
    return Number.isFinite(out.x) && Number.isFinite(out.y);
}
/** Bounded DDA raycast against a caller-provided row-major integer tile grid. */
function raycastGrid(map, width, height, originX, originY, directionX, directionY, maxDistance, out) {
    if (!map || !Number.isSafeInteger(width) || !Number.isSafeInteger(height) || width < 1 || height < 1 || width * height > map.length ||
        ![originX, originY, directionX, directionY, maxDistance].every(Number.isFinite) || maxDistance <= 0 || !out)
        return false;
    const length = Math.hypot(directionX, directionY);
    if (length < 1e-9)
        return false;
    const dx = directionX / length;
    const dy = directionY / length;
    let cellX = Math.floor(originX);
    let cellY = Math.floor(originY);
    if (cellX < 0 || cellY < 0 || cellX >= width || cellY >= height)
        return false;
    if (map[cellY * width + cellX] !== 0) {
        out.hit = true;
        out.distance = 0;
        out.cellX = cellX;
        out.cellY = cellY;
        out.side = 0;
        return true;
    }
    const stepX = dx < 0 ? -1 : 1;
    const stepY = dy < 0 ? -1 : 1;
    const deltaX = Math.abs(dx) < 1e-12 ? Infinity : Math.abs(1 / dx);
    const deltaY = Math.abs(dy) < 1e-12 ? Infinity : Math.abs(1 / dy);
    let sideX = dx < 0 ? (originX - cellX) * deltaX : (cellX + 1 - originX) * deltaX;
    let sideY = dy < 0 ? (originY - cellY) * deltaY : (cellY + 1 - originY) * deltaY;
    let distance = 0;
    let side = 0;
    const maxSteps = Math.min(8192, width * height + width + height);
    for (let step = 0; step < maxSteps; step++) {
        if (sideX < sideY) {
            distance = sideX;
            sideX += deltaX;
            cellX += stepX;
            side = 0;
        }
        else {
            distance = sideY;
            sideY += deltaY;
            cellY += stepY;
            side = 1;
        }
        if (distance > maxDistance || cellX < 0 || cellY < 0 || cellX >= width || cellY >= height)
            break;
        if (map[cellY * width + cellX] !== 0) {
            out.hit = true;
            out.distance = distance;
            out.cellX = cellX;
            out.cellY = cellY;
            out.side = side;
            return true;
        }
    }
    out.hit = false;
    out.distance = Math.min(distance, maxDistance);
    out.cellX = cellX;
    out.cellY = cellY;
    out.side = side;
    return true;
}

};
modules["renderers/canvas2d.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Canvas2DRenderer = exports.Canvas2DScene = void 0;
/** Stable ordered scene: insertion order is preserved for equal layers. */
const MAX_SCENE_COMMANDS = 32768;
class Canvas2DScene {
    constructor() {
        this.drawCommands = [];
        this.clearColor = "#101018";
        this.cameraX = 0;
        this.cameraY = 0;
        this.zoom = 1;
    }
    get commands() { return this.drawCommands; }
    add(command) {
        var _a, _b;
        if (!isValidCommand(command))
            throw new TypeError("INVALID_CANVAS_COMMAND");
        if (this.drawCommands.length >= MAX_SCENE_COMMANDS)
            throw new RangeError("CANVAS_SCENE_COMMAND_LIMIT");
        this.drawCommands.push(command);
        // Stable insertion sort is cheap for editor/game scenes that append a few commands per update.
        let i = this.drawCommands.length - 1;
        const layer = (_a = command.layer) !== null && _a !== void 0 ? _a : 0;
        while (i > 0 && ((_b = this.drawCommands[i - 1].layer) !== null && _b !== void 0 ? _b : 0) > layer) {
            this.drawCommands[i] = this.drawCommands[i - 1];
            i--;
        }
        this.drawCommands[i] = command;
    }
    clear() { this.drawCommands.length = 0; }
}
exports.Canvas2DScene = Canvas2DScene;
function finite(v) { return Number.isFinite(v); }
function validStyle(c) {
    return typeof c.color === "string" && c.color.length > 0 && c.color.length <= 128 &&
        (c.alpha === undefined || (finite(c.alpha) && c.alpha >= 0 && c.alpha <= 1));
}
function isValidCommand(c) {
    var _a, _b;
    if (!c || typeof c !== "object")
        return false;
    if (c.layer !== undefined && (!finite(c.layer) || Math.abs(c.layer) > 1000000))
        return false;
    switch (c.kind) {
        case "rect": return validStyle(c) && [c.x, c.y, c.width, c.height].every(finite) && c.width >= 0 && c.height >= 0;
        case "circle": return validStyle(c) && [c.x, c.y, c.radius].every(finite) && c.radius >= 0;
        case "line": return validStyle(c) && [c.x1, c.y1, c.x2, c.y2, (_a = c.lineWidth) !== null && _a !== void 0 ? _a : 1].every(finite) && ((_b = c.lineWidth) !== null && _b !== void 0 ? _b : 1) >= 0;
        case "polygon": return validStyle(c) && c.points.length >= 3 && c.points.length <= 4096 && c.points.every(p => finite(p.x) && finite(p.y));
        case "text": return validStyle(c) && typeof c.text === "string" && c.text.length <= 8192 && finite(c.x) && finite(c.y) && (c.font === undefined || (typeof c.font === "string" && c.font.length <= 128));
        case "image": return finite(c.x) && finite(c.y) && finite(c.width) && finite(c.height) && c.width >= 0 && c.height >= 0 && (c.alpha === undefined || (finite(c.alpha) && c.alpha >= 0 && c.alpha <= 1));
    }
}
/** Canvas2D backend for 2D, isometric and pseudo-3D scenes; it is not a perspective 3D renderer. */
class Canvas2DRenderer {
    constructor() {
        this.kind = "canvas2d";
        this.canvas = null;
        this.context = null;
        this.lost = false;
        this.width = 1;
        this.height = 1;
        this.pixelRatio = 1;
        this.quality = 0;
        this.imageCache = new Map();
        this.onLost = (event) => { event.preventDefault(); this.lost = true; };
        this.onRestored = () => { var _a, _b; this.lost = false; this.context = (_b = (_a = this.canvas) === null || _a === void 0 ? void 0 : _a.getContext("2d", { alpha: false })) !== null && _b !== void 0 ? _b : null; };
    }
    initialize(host, profile) {
        if (this.canvas)
            throw new Error("CANVAS_RENDERER_ALREADY_INITIALIZED");
        const context = host.getContext("2d", { alpha: false, desynchronized: true });
        if (!context)
            throw new Error("CANVAS2D_CONTEXT_UNAVAILABLE");
        this.canvas = host;
        this.context = context;
        this.quality = profile.tier;
        host.addEventListener("contextlost", this.onLost);
        host.addEventListener("contextrestored", this.onRestored);
        this.resize(host.clientWidth || host.width || 1, host.clientHeight || host.height || 1, Math.min(profile.maxPixelRatio, 1));
    }
    createScene(_manifest) { return new Canvas2DScene(); }
    setImage(key, image) {
        if (!key || key.length > 160)
            throw new TypeError("INVALID_IMAGE_KEY");
        this.imageCache.set(key, image);
    }
    getImage(key) { return this.imageCache.get(key); }
    releaseImage(key) { this.imageCache.delete(key); }
    resize(width, height, pixelRatio) {
        if (!this.canvas)
            return;
        this.width = Math.max(1, Math.floor(finite(width) ? width : 1));
        this.height = Math.max(1, Math.floor(finite(height) ? height : 1));
        const tierCap = this.quality === 0 ? 1 : this.quality === 1 ? 1.25 : 1.5;
        this.pixelRatio = Math.max(0.5, Math.min(finite(pixelRatio) ? pixelRatio : 1, tierCap));
        const w = Math.max(1, Math.floor(this.width * this.pixelRatio));
        const h = Math.max(1, Math.floor(this.height * this.pixelRatio));
        if (this.canvas.width !== w)
            this.canvas.width = w;
        if (this.canvas.height !== h)
            this.canvas.height = h;
        this.context = this.canvas.getContext("2d", { alpha: false, desynchronized: true });
    }
    render(scene, _interpolationAlpha) {
        var _a, _b, _c;
        const ctx = this.context;
        if (!ctx || this.lost || !scene || !finite(scene.zoom) || scene.zoom <= 0)
            return;
        const dpr = this.pixelRatio;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.globalAlpha = 1;
        ctx.fillStyle = typeof scene.clearColor === "string" && scene.clearColor.length <= 128 ? scene.clearColor : "#101018";
        ctx.fillRect(0, 0, this.width, this.height);
        ctx.save();
        ctx.translate(this.width * 0.5, this.height * 0.5);
        ctx.scale(scene.zoom, scene.zoom);
        ctx.translate(-scene.cameraX, -scene.cameraY);
        for (let i = 0; i < scene.commands.length; i++) {
            const c = scene.commands[i];
            ctx.globalAlpha = c.alpha === undefined ? 1 : Math.max(0, Math.min(1, c.alpha));
            switch (c.kind) {
                case "rect":
                    ctx.fillStyle = c.color;
                    ctx.fillRect(c.x, c.y, c.width, c.height);
                    break;
                case "circle":
                    ctx.beginPath();
                    ctx.arc(c.x, c.y, c.radius, 0, Math.PI * 2);
                    ctx.fillStyle = c.color;
                    ctx.fill();
                    break;
                case "line":
                    ctx.beginPath();
                    ctx.moveTo(c.x1, c.y1);
                    ctx.lineTo(c.x2, c.y2);
                    ctx.strokeStyle = c.color;
                    ctx.lineWidth = (_a = c.lineWidth) !== null && _a !== void 0 ? _a : 1;
                    ctx.stroke();
                    break;
                case "polygon":
                    ctx.beginPath();
                    ctx.moveTo(c.points[0].x, c.points[0].y);
                    for (let p = 1; p < c.points.length; p++)
                        ctx.lineTo(c.points[p].x, c.points[p].y);
                    ctx.closePath();
                    ctx.fillStyle = c.color;
                    ctx.fill();
                    break;
                case "text":
                    ctx.fillStyle = c.color;
                    ctx.font = (_b = c.font) !== null && _b !== void 0 ? _b : "14px sans-serif";
                    ctx.textAlign = (_c = c.align) !== null && _c !== void 0 ? _c : "left";
                    ctx.fillText(c.text, c.x, c.y);
                    break;
                case "image":
                    ctx.drawImage(c.image, c.x, c.y, c.width, c.height);
                    break;
            }
        }
        ctx.restore();
        ctx.globalAlpha = 1;
    }
    setQuality(tier) {
        this.quality = tier;
        this.resize(this.width, this.height, this.pixelRatio);
    }
    disposeScene(scene) { scene.clear(); }
    dispose() {
        var _a, _b;
        (_a = this.canvas) === null || _a === void 0 ? void 0 : _a.removeEventListener("contextlost", this.onLost);
        (_b = this.canvas) === null || _b === void 0 ? void 0 : _b.removeEventListener("contextrestored", this.onRestored);
        this.imageCache.clear();
        this.context = null;
        this.canvas = null;
        this.lost = false;
    }
}
exports.Canvas2DRenderer = Canvas2DRenderer;

};
modules["renderers/webgl2-2d.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebGL2BatchRenderer = exports.WebGL2Scene = void 0;
exports.parseHexColor = parseHexColor;
exports.buildWebGL2Batches = buildWebGL2Batches;
exports.buildWebGL2Vertices = buildWebGL2Vertices;
const MAX_COMMANDS = 32768;
const MAX_VERTICES = 196608;
const FLOATS_PER_VERTEX = 8; // x, y, r, g, b, a, u, v
const VERTEX_SHADER = `#version 300 es
in vec2 a_position; in vec4 a_color; in vec2 a_uv; uniform vec2 u_resolution; uniform vec2 u_camera; uniform float u_zoom; out vec4 v_color; out vec2 v_uv;
void main(){ vec2 p=(a_position-u_camera)*u_zoom+u_resolution*0.5; vec2 clip=(p/u_resolution)*2.0-1.0; gl_Position=vec4(clip.x,-clip.y,0.0,1.0); v_color=a_color; v_uv=a_uv; }`;
const FRAGMENT_SHADER = `#version 300 es
precision mediump float; in vec4 v_color; in vec2 v_uv; uniform sampler2D u_texture; uniform float u_textured; out vec4 outColor;
void main(){ vec4 texel=mix(vec4(1.0),texture(u_texture,v_uv),u_textured); outColor=v_color*texel; }`;
class WebGL2Scene {
    constructor() {
        this.commands = [];
        this.clearColor = "#101018";
        this.cameraX = 0;
        this.cameraY = 0;
        this.zoom = 1;
    }
    add(command) {
        var _a, _b;
        if (!validCommand(command))
            throw new TypeError("INVALID_WEBGL2_COMMAND");
        if (this.commands.length >= MAX_COMMANDS)
            throw new RangeError("WEBGL2_SCENE_COMMAND_LIMIT");
        let i = this.commands.length;
        this.commands.push(command);
        const layer = (_a = command.layer) !== null && _a !== void 0 ? _a : 0;
        while (i > 0 && ((_b = this.commands[i - 1].layer) !== null && _b !== void 0 ? _b : 0) > layer) {
            this.commands[i] = this.commands[i - 1];
            i--;
        }
        this.commands[i] = command;
    }
    addSprite(command) { this.add({ kind: "sprite", ...command }); }
    addAtlasSprite(atlasId, atlas, frameId, sprite) {
        var _a, _b, _c;
        if (!/^[a-zA-Z0-9_-]{1,64}$/.test(atlasId) || !atlas || atlas.schemaVersion !== 1 || !Array.isArray(atlas.frames) || !Array.isArray(atlas.pages))
            return false;
        const frame = atlas.frames.find(item => item.id === frameId);
        if (!frame)
            return false;
        const page = atlas.pages[frame.page];
        if (!page)
            return false;
        try {
            this.add({ kind: "sprite", textureId: `${atlasId}-${frame.page}`, x: sprite.x, y: sprite.y, width: (_a = sprite.width) !== null && _a !== void 0 ? _a : frame.width, height: (_b = sprite.height) !== null && _b !== void 0 ? _b : frame.height, u0: frame.x / page.width, v0: frame.y / page.height, u1: (frame.x + frame.width) / page.width, v1: (frame.y + frame.height) / page.height, rotation: sprite.rotation, pivotX: sprite.pivotX, pivotY: sprite.pivotY, color: (_c = sprite.tint) !== null && _c !== void 0 ? _c : "#ffffff", alpha: sprite.alpha, layer: sprite.layer });
            return true;
        }
        catch {
            return false;
        }
    }
    clear() { this.commands.length = 0; }
}
exports.WebGL2Scene = WebGL2Scene;
function isConvexPolygon(points) {
    if (!Array.isArray(points) || points.length < 3 || points.length > 4096 || !points.every(p => p && Number.isFinite(p.x) && Number.isFinite(p.y)))
        return false;
    let sign = 0;
    for (let i = 0; i < points.length; i++) {
        const a = points[i], b = points[(i + 1) % points.length], c = points[(i + 2) % points.length];
        const cross = (b.x - a.x) * (c.y - b.y) - (b.y - a.y) * (c.x - b.x);
        if (Math.abs(cross) < 1e-9)
            continue;
        const next = cross > 0 ? 1 : -1;
        if (sign !== 0 && sign !== next)
            return false;
        sign = next;
    }
    return sign !== 0;
}
function validCommand(c) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y;
    if (!c || typeof c !== "object")
        return false;
    if (c.layer !== undefined && (!Number.isFinite(c.layer) || Math.abs(c.layer) > 1000000))
        return false;
    if (c.alpha !== undefined && (!Number.isFinite(c.alpha) || c.alpha < 0 || c.alpha > 1))
        return false;
    if (c.kind === "sprite") {
        const color = (_a = c.color) !== null && _a !== void 0 ? _a : "#ffffff";
        return /^[a-zA-Z0-9_-]{1,80}$/.test(c.textureId) && [c.x, c.y, c.width, c.height, (_b = c.u0) !== null && _b !== void 0 ? _b : 0, (_c = c.v0) !== null && _c !== void 0 ? _c : 0, (_d = c.u1) !== null && _d !== void 0 ? _d : 1, (_e = c.v1) !== null && _e !== void 0 ? _e : 1, (_f = c.rotation) !== null && _f !== void 0 ? _f : 0, (_g = c.pivotX) !== null && _g !== void 0 ? _g : 0.5, (_h = c.pivotY) !== null && _h !== void 0 ? _h : 0.5].every(Number.isFinite) && c.width >= 0 && c.height >= 0 && ((_j = c.u0) !== null && _j !== void 0 ? _j : 0) >= 0 && ((_k = c.v0) !== null && _k !== void 0 ? _k : 0) >= 0 && ((_l = c.u1) !== null && _l !== void 0 ? _l : 1) <= 1 && ((_m = c.v1) !== null && _m !== void 0 ? _m : 1) <= 1 && ((_o = c.u1) !== null && _o !== void 0 ? _o : 1) >= ((_p = c.u0) !== null && _p !== void 0 ? _p : 0) && ((_q = c.v1) !== null && _q !== void 0 ? _q : 1) >= ((_r = c.v0) !== null && _r !== void 0 ? _r : 0) && Math.abs((_s = c.rotation) !== null && _s !== void 0 ? _s : 0) <= Math.PI * 1000 && ((_t = c.pivotX) !== null && _t !== void 0 ? _t : 0.5) >= 0 && ((_u = c.pivotX) !== null && _u !== void 0 ? _u : 0.5) <= 1 && ((_v = c.pivotY) !== null && _v !== void 0 ? _v : 0.5) >= 0 && ((_w = c.pivotY) !== null && _w !== void 0 ? _w : 0.5) <= 1 && typeof color === "string" && color.length <= 32 && !!parseHexColor(color);
    }
    if (typeof c.color !== "string" || c.color.length > 32 || !parseHexColor(c.color))
        return false;
    switch (c.kind) {
        case "rect": return [c.x, c.y, c.width, c.height].every(Number.isFinite) && c.width >= 0 && c.height >= 0;
        case "circle": return [c.x, c.y, c.radius].every(Number.isFinite) && c.radius >= 0 && (c.segments === undefined || (Number.isInteger(c.segments) && c.segments >= 8 && c.segments <= 64));
        case "line": return [c.x1, c.y1, c.x2, c.y2, (_x = c.width) !== null && _x !== void 0 ? _x : 1].every(Number.isFinite) && ((_y = c.width) !== null && _y !== void 0 ? _y : 1) >= 0;
        case "polygon": return isConvexPolygon(c.points);
    }
}
/** Deliberately accepts only hex colors so parsing is deterministic and allocation-light. */
function parseHexColor(value) {
    if (typeof value !== "string")
        return null;
    const raw = value.startsWith("#") ? value.slice(1) : "";
    if (!/^(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(raw))
        return null;
    const expanded = raw.length === 3 ? raw.split("").map(c => c + c).join("") : raw;
    const r = Number.parseInt(expanded.slice(0, 2), 16) / 255;
    const g = Number.parseInt(expanded.slice(2, 4), 16) / 255;
    const b = Number.parseInt(expanded.slice(4, 6), 16) / 255;
    const a = expanded.length === 8 ? Number.parseInt(expanded.slice(6, 8), 16) / 255 : 1;
    return [r, g, b, a];
}
function createBatchOutput(data = new Float32Array(MAX_VERTICES * FLOATS_PER_VERTEX)) {
    return { data, count: 0, runCount: 0, runTextureIds: new Array(MAX_COMMANDS), runFirst: new Array(MAX_COMMANDS), runCounts: new Array(MAX_COMMANDS) };
}
/** CPU tessellation writes one reusable interleaved buffer and contiguous texture runs. */
function buildWebGL2Batches(scene, output = createBatchOutput()) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r;
    let cursor = 0;
    output.count = 0;
    output.runCount = 0;
    const push = (x, y, color, alpha, u = 0, v = 0) => {
        if (cursor + FLOATS_PER_VERTEX > output.data.length)
            throw new RangeError("WEBGL2_VERTEX_BUDGET_EXCEEDED");
        output.data[cursor++] = x;
        output.data[cursor++] = y;
        output.data[cursor++] = color[0];
        output.data[cursor++] = color[1];
        output.data[cursor++] = color[2];
        output.data[cursor++] = color[3] * alpha;
        output.data[cursor++] = u;
        output.data[cursor++] = v;
    };
    const tri = (a, b, c, color, alpha) => { push(a[0], a[1], color, alpha); push(b[0], b[1], color, alpha); push(c[0], c[1], color, alpha); };
    const quad = (x1, y1, x2, y2, x3, y3, x4, y4, color, alpha, uv) => {
        const [u0, v0, u1, v1] = uv !== null && uv !== void 0 ? uv : [0, 0, 0, 0];
        push(x1, y1, color, alpha, u0, v0);
        push(x2, y2, color, alpha, u1, v0);
        push(x3, y3, color, alpha, u1, v1);
        push(x1, y1, color, alpha, u0, v0);
        push(x3, y3, color, alpha, u1, v1);
        push(x4, y4, color, alpha, u0, v1);
    };
    let activeTexture;
    for (const c of scene.commands) {
        const textureId = c.kind === "sprite" ? c.textureId : null;
        if (textureId !== activeTexture) {
            if (output.runCount >= MAX_COMMANDS)
                throw new RangeError("WEBGL2_DRAW_RUN_LIMIT");
            const run = output.runCount++;
            output.runTextureIds[run] = textureId;
            output.runFirst[run] = cursor / FLOATS_PER_VERTEX;
            output.runCounts[run] = 0;
            activeTexture = textureId;
        }
        const run = output.runCount - 1;
        const color = parseHexColor(c.kind === "sprite" ? (_a = c.color) !== null && _a !== void 0 ? _a : "#ffffff" : c.color);
        const alpha = (_b = c.alpha) !== null && _b !== void 0 ? _b : 1;
        switch (c.kind) {
            case "rect":
                quad(c.x, c.y, c.x + c.width, c.y, c.x + c.width, c.y + c.height, c.x, c.y + c.height, color, alpha);
                break;
            case "sprite": {
                const px = c.x + c.width * ((_c = c.pivotX) !== null && _c !== void 0 ? _c : 0.5), py = c.y + c.height * ((_d = c.pivotY) !== null && _d !== void 0 ? _d : 0.5), angle = (_e = c.rotation) !== null && _e !== void 0 ? _e : 0, cs = Math.cos(angle), sn = Math.sin(angle);
                const left = -c.width * ((_f = c.pivotX) !== null && _f !== void 0 ? _f : 0.5), right = c.width * (1 - ((_g = c.pivotX) !== null && _g !== void 0 ? _g : 0.5)), top = -c.height * ((_h = c.pivotY) !== null && _h !== void 0 ? _h : 0.5), bottom = c.height * (1 - ((_j = c.pivotY) !== null && _j !== void 0 ? _j : 0.5));
                const u0 = (_k = c.u0) !== null && _k !== void 0 ? _k : 0, v0 = (_l = c.v0) !== null && _l !== void 0 ? _l : 0, u1 = (_m = c.u1) !== null && _m !== void 0 ? _m : 1, v1 = (_o = c.v1) !== null && _o !== void 0 ? _o : 1;
                const points = [[left, top, u0, v0], [right, top, u1, v0], [right, bottom, u1, v1], [left, bottom, u0, v1]];
                for (const index of [0, 1, 2, 0, 2, 3]) {
                    const point = points[index];
                    push(px + point[0] * cs - point[1] * sn, py + point[0] * sn + point[1] * cs, color, alpha, point[2], point[3]);
                }
                break;
            }
            case "circle": {
                const segments = (_p = c.segments) !== null && _p !== void 0 ? _p : 16;
                for (let i = 0; i < segments; i++) {
                    const a = i * Math.PI * 2 / segments, b = (i + 1) * Math.PI * 2 / segments;
                    tri([c.x, c.y], [c.x + Math.cos(a) * c.radius, c.y + Math.sin(a) * c.radius], [c.x + Math.cos(b) * c.radius, c.y + Math.sin(b) * c.radius], color, alpha);
                }
                break;
            }
            case "line": {
                const dx = c.x2 - c.x1, dy = c.y2 - c.y1, len = Math.hypot(dx, dy);
                if (len === 0 || ((_q = c.width) !== null && _q !== void 0 ? _q : 1) === 0)
                    break;
                const half = ((_r = c.width) !== null && _r !== void 0 ? _r : 1) * 0.5, nx = -dy / len * half, ny = dx / len * half;
                quad(c.x1 + nx, c.y1 + ny, c.x2 + nx, c.y2 + ny, c.x2 - nx, c.y2 - ny, c.x1 - nx, c.y1 - ny, color, alpha);
                break;
            }
            case "polygon": {
                const p = c.points[0];
                for (let i = 1; i < c.points.length - 1; i++) {
                    const b = c.points[i], d = c.points[i + 1];
                    tri([p.x, p.y], [b.x, b.y], [d.x, d.y], color, alpha);
                }
                break;
            }
        }
        output.runCounts[run] = cursor / FLOATS_PER_VERTEX - output.runFirst[run];
    }
    output.count = cursor / FLOATS_PER_VERTEX;
    return output;
}
/** Compatibility helper for primitive-only callers and existing tests. */
function buildWebGL2Vertices(scene, target = new Float32Array(MAX_VERTICES * FLOATS_PER_VERTEX)) {
    const output = buildWebGL2Batches(scene, createBatchOutput(target));
    return { data: output.data.subarray(0, output.count * FLOATS_PER_VERTEX), count: output.count };
}
function sourceSize(source) {
    const value = source;
    return { width: value.naturalWidth || value.videoWidth || value.width || 0, height: value.naturalHeight || value.videoHeight || value.height || 0 };
}
/** WebGL2 batch renderer for solid 2D/2.5D primitives and bounded atlas-backed sprites; not perspective 3D. */
class WebGL2BatchRenderer {
    constructor() {
        this.kind = "webgl2";
        this.canvas = null;
        this.gl = null;
        this.program = null;
        this.buffer = null;
        this.positionLocation = -1;
        this.colorLocation = -1;
        this.uvLocation = -1;
        this.resolutionLocation = null;
        this.cameraLocation = null;
        this.zoomLocation = null;
        this.textureLocation = null;
        this.texturedLocation = null;
        this.width = 1;
        this.height = 1;
        this.pixelRatio = 1;
        this.quality = 0;
        this.lost = false;
        this.vertices = new Float32Array(MAX_VERTICES * FLOATS_PER_VERTEX);
        this.batches = createBatchOutput(this.vertices);
        this.textures = new Map();
        this.textureBytes = 0;
        this.onLost = (event) => { event.preventDefault(); this.lost = true; this.releaseGpuObjects(); };
        this.onRestored = () => { try {
            if (this.canvas) {
                this.createGpuObjects();
                for (const record of this.textures.values())
                    this.uploadTexture(record);
            }
            this.lost = false;
        }
        catch {
            this.lost = true;
            this.releaseGpuObjects();
        } };
    }
    initialize(host, profile) {
        if (this.canvas)
            throw new Error("WEBGL2_RENDERER_ALREADY_INITIALIZED");
        const gl = host.getContext("webgl2", { alpha: false, antialias: profile.antialias, depth: false, stencil: false, powerPreference: "low-power", preserveDrawingBuffer: false });
        if (!gl)
            throw new Error("WEBGL2_CONTEXT_UNAVAILABLE");
        this.canvas = host;
        this.gl = gl;
        this.quality = profile.tier;
        host.addEventListener("webglcontextlost", this.onLost, false);
        host.addEventListener("webglcontextrestored", this.onRestored, false);
        try {
            this.createGpuObjects();
            this.resize(host.clientWidth || host.width || 1, host.clientHeight || host.height || 1, Math.min(profile.maxPixelRatio, 1));
        }
        catch (error) {
            host.removeEventListener("webglcontextlost", this.onLost);
            host.removeEventListener("webglcontextrestored", this.onRestored);
            this.releaseGpuObjects();
            this.gl = null;
            this.canvas = null;
            throw error;
        }
    }
    createScene(_manifest) { return new WebGL2Scene(); }
    resize(width, height, pixelRatio) {
        if (!this.canvas || !this.gl)
            return;
        this.width = Math.max(1, Math.floor(Number.isFinite(width) ? width : 1));
        this.height = Math.max(1, Math.floor(Number.isFinite(height) ? height : 1));
        const cap = this.quality === 0 ? 1 : this.quality === 1 ? 1.25 : 1.5;
        this.pixelRatio = Math.max(0.5, Math.min(Number.isFinite(pixelRatio) ? pixelRatio : 1, cap));
        const w = Math.max(1, Math.floor(this.width * this.pixelRatio)), h = Math.max(1, Math.floor(this.height * this.pixelRatio));
        if (this.canvas.width !== w)
            this.canvas.width = w;
        if (this.canvas.height !== h)
            this.canvas.height = h;
        this.gl.viewport(0, 0, w, h);
    }
    registerTexture(id, source) {
        if (this.lost || !this.gl || !/^[a-zA-Z0-9_-]{1,80}$/.test(id) || !source)
            return false;
        const size = sourceSize(source);
        const maxDimension = this.quality === 0 ? 1024 : this.quality === 1 ? 2048 : 4096;
        if (!Number.isSafeInteger(size.width) || !Number.isSafeInteger(size.height) || size.width < 1 || size.height < 1 || size.width > maxDimension || size.height > maxDimension)
            return false;
        const bytes = size.width * size.height * 4;
        const budget = this.quality === 0 ? 8 : this.quality === 1 ? 16 : 32;
        const previous = this.textures.get(id);
        if (previous)
            return previous.source === source;
        const maxTextures = this.quality === 0 ? 32 : this.quality === 1 ? 64 : 128;
        const total = this.textureBytes + bytes;
        if (!Number.isSafeInteger(bytes) || total > budget * 1024 * 1024 || this.textures.size >= maxTextures)
            return false;
        const record = { source, texture: null, width: size.width, height: size.height, bytes };
        try {
            this.uploadTexture(record);
        }
        catch {
            if (record.texture)
                this.gl.deleteTexture(record.texture);
            return false;
        }
        this.textureBytes = total;
        this.textures.set(id, record);
        return true;
    }
    removeTexture(id) {
        const record = this.textures.get(id);
        if (!record)
            return;
        if (record.texture && this.gl && !this.lost)
            this.gl.deleteTexture(record.texture);
        this.textureBytes -= record.bytes;
        this.textures.delete(id);
    }
    registerAtlasPage(atlasId, atlas, pageIndex, source) {
        if (!/^[a-zA-Z0-9_-]{1,64}$/.test(atlasId) || !atlas || atlas.schemaVersion !== 1 || !Number.isInteger(pageIndex) || !Array.isArray(atlas.pages) || !Array.isArray(atlas.frames))
            return false;
        const page = atlas.pages[pageIndex];
        if (!page || !Number.isSafeInteger(page.width) || !Number.isSafeInteger(page.height))
            return false;
        const size = sourceSize(source);
        if (size.width !== page.width || size.height !== page.height)
            return false;
        let frameCount = 0;
        for (const frame of atlas.frames)
            if (frame.page === pageIndex) {
                frameCount++;
                if (!/^[A-Za-z0-9_-]{1,80}$/.test(frame.id) || !Number.isSafeInteger(frame.x) || !Number.isSafeInteger(frame.y) || !Number.isSafeInteger(frame.width) || !Number.isSafeInteger(frame.height) || frame.x < 0 || frame.y < 0 || frame.width < 1 || frame.height < 1 || frame.x + frame.width > page.width || frame.y + frame.height > page.height)
                    return false;
            }
        return frameCount > 0 && this.registerTexture(`${atlasId}-${pageIndex}`, source);
    }
    render(scene, _interpolationAlpha) {
        var _a, _b, _c, _d, _e, _f;
        const gl = this.gl;
        const program = this.program;
        const buffer = this.buffer;
        if (!gl || !program || !buffer || this.lost || !scene || !Number.isFinite(scene.zoom) || scene.zoom <= 0)
            return;
        const clear = (_a = parseHexColor(scene.clearColor)) !== null && _a !== void 0 ? _a : [0.063, 0.063, 0.094, 1];
        gl.viewport(0, 0, (_c = (_b = this.canvas) === null || _b === void 0 ? void 0 : _b.width) !== null && _c !== void 0 ? _c : 1, (_e = (_d = this.canvas) === null || _d === void 0 ? void 0 : _d.height) !== null && _e !== void 0 ? _e : 1);
        gl.clearColor(clear[0], clear[1], clear[2], 1);
        gl.clear(gl.COLOR_BUFFER_BIT);
        const batch = buildWebGL2Batches(scene, this.batches);
        if (batch.count === 0)
            return;
        gl.useProgram(program);
        gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
        gl.bufferData(gl.ARRAY_BUFFER, batch.data.subarray(0, batch.count * FLOATS_PER_VERTEX), gl.DYNAMIC_DRAW);
        const stride = FLOATS_PER_VERTEX * 4;
        gl.enableVertexAttribArray(this.positionLocation);
        gl.vertexAttribPointer(this.positionLocation, 2, gl.FLOAT, false, stride, 0);
        gl.enableVertexAttribArray(this.colorLocation);
        gl.vertexAttribPointer(this.colorLocation, 4, gl.FLOAT, false, stride, 2 * 4);
        gl.enableVertexAttribArray(this.uvLocation);
        gl.vertexAttribPointer(this.uvLocation, 2, gl.FLOAT, false, stride, 6 * 4);
        gl.uniform2f(this.resolutionLocation, this.width, this.height);
        gl.uniform2f(this.cameraLocation, scene.cameraX, scene.cameraY);
        gl.uniform1f(this.zoomLocation, scene.zoom);
        gl.activeTexture(gl.TEXTURE0);
        gl.uniform1i(this.textureLocation, 0);
        gl.enable(gl.BLEND);
        gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
        for (let i = 0; i < batch.runCount; i++) {
            const textureId = batch.runTextureIds[i];
            const first = batch.runFirst[i];
            const count = batch.runCounts[i];
            if (count <= 0)
                continue;
            if (textureId !== null) {
                const texture = (_f = this.textures.get(textureId)) === null || _f === void 0 ? void 0 : _f.texture;
                if (!texture)
                    continue;
                gl.bindTexture(gl.TEXTURE_2D, texture);
                gl.uniform1f(this.texturedLocation, 1);
            }
            else {
                gl.bindTexture(gl.TEXTURE_2D, null);
                gl.uniform1f(this.texturedLocation, 0);
            }
            gl.drawArrays(gl.TRIANGLES, first, count);
        }
    }
    setQuality(tier) { this.quality = tier; this.resize(this.width, this.height, this.pixelRatio); }
    disposeScene(scene) { scene.clear(); }
    compile(type, source) {
        var _a;
        const gl = this.gl;
        const shader = gl.createShader(type);
        if (!shader)
            throw new Error("WEBGL2_SHADER_ALLOCATION_FAILED");
        gl.shaderSource(shader, source);
        gl.compileShader(shader);
        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
            const log = (_a = gl.getShaderInfoLog(shader)) !== null && _a !== void 0 ? _a : "unknown";
            gl.deleteShader(shader);
            throw new Error(`WEBGL2_SHADER_COMPILE_FAILED:${log.slice(0, 240)}`);
        }
        return shader;
    }
    createGpuObjects() {
        var _a;
        const gl = this.gl;
        const vs = this.compile(gl.VERTEX_SHADER, VERTEX_SHADER);
        let fs;
        try {
            fs = this.compile(gl.FRAGMENT_SHADER, FRAGMENT_SHADER);
        }
        catch (error) {
            gl.deleteShader(vs);
            throw error;
        }
        const program = gl.createProgram();
        if (!program) {
            gl.deleteShader(vs);
            gl.deleteShader(fs);
            throw new Error("WEBGL2_PROGRAM_ALLOCATION_FAILED");
        }
        gl.attachShader(program, vs);
        gl.attachShader(program, fs);
        gl.linkProgram(program);
        gl.deleteShader(vs);
        gl.deleteShader(fs);
        if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
            const log = (_a = gl.getProgramInfoLog(program)) !== null && _a !== void 0 ? _a : "unknown";
            gl.deleteProgram(program);
            throw new Error(`WEBGL2_PROGRAM_LINK_FAILED:${log.slice(0, 240)}`);
        }
        const buffer = gl.createBuffer();
        if (!buffer) {
            gl.deleteProgram(program);
            throw new Error("WEBGL2_BUFFER_ALLOCATION_FAILED");
        }
        this.program = program;
        this.buffer = buffer;
        this.positionLocation = gl.getAttribLocation(program, "a_position");
        this.colorLocation = gl.getAttribLocation(program, "a_color");
        this.uvLocation = gl.getAttribLocation(program, "a_uv");
        this.resolutionLocation = gl.getUniformLocation(program, "u_resolution");
        this.cameraLocation = gl.getUniformLocation(program, "u_camera");
        this.zoomLocation = gl.getUniformLocation(program, "u_zoom");
        this.textureLocation = gl.getUniformLocation(program, "u_texture");
        this.texturedLocation = gl.getUniformLocation(program, "u_textured");
        if (this.positionLocation < 0 || this.colorLocation < 0 || this.uvLocation < 0 || !this.resolutionLocation || !this.cameraLocation || !this.zoomLocation || !this.textureLocation || !this.texturedLocation) {
            this.releaseGpuObjects();
            throw new Error("WEBGL2_SHADER_INTERFACE_INVALID");
        }
    }
    uploadTexture(record) {
        const gl = this.gl;
        // Do not misattribute an earlier unrelated WebGL error to this upload.
        for (let i = 0; i < 8 && gl.getError() !== gl.NO_ERROR; i++) { /* drain bounded stale errors */ }
        const texture = gl.createTexture();
        if (!texture)
            throw new Error("WEBGL2_TEXTURE_ALLOCATION_FAILED");
        gl.bindTexture(gl.TEXTURE_2D, texture);
        try {
            gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, 1);
            gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, 1);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, record.source);
            const error = gl.getError();
            if (error !== gl.NO_ERROR)
                throw new Error(`WEBGL2_TEXTURE_UPLOAD_FAILED:${error}`);
            record.texture = texture;
        }
        catch (error) {
            gl.deleteTexture(texture);
            throw error;
        }
        finally {
            gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, 0);
            gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, 0);
            gl.bindTexture(gl.TEXTURE_2D, null);
        }
    }
    releaseGpuObjects() {
        const gl = this.gl;
        if (!gl)
            return;
        if (this.buffer)
            gl.deleteBuffer(this.buffer);
        if (this.program)
            gl.deleteProgram(this.program);
        for (const record of this.textures.values()) {
            if (record.texture)
                gl.deleteTexture(record.texture);
            record.texture = null;
        }
        this.buffer = null;
        this.program = null;
        this.positionLocation = -1;
        this.colorLocation = -1;
        this.uvLocation = -1;
        this.resolutionLocation = null;
        this.cameraLocation = null;
        this.zoomLocation = null;
        this.textureLocation = null;
        this.texturedLocation = null;
    }
    dispose() {
        var _a, _b;
        (_a = this.canvas) === null || _a === void 0 ? void 0 : _a.removeEventListener("webglcontextlost", this.onLost);
        (_b = this.canvas) === null || _b === void 0 ? void 0 : _b.removeEventListener("webglcontextrestored", this.onRestored);
        if (!this.lost)
            this.releaseGpuObjects();
        this.textures.clear();
        this.textureBytes = 0;
        this.gl = null;
        this.canvas = null;
        this.lost = false;
    }
    get residentTextureBytes() { return this.textureBytes; }
    get residentTextureCount() { return this.textures.size; }
}
exports.WebGL2BatchRenderer = WebGL2BatchRenderer;

};
modules["scene-editor.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SceneEditorSession = void 0;
const project_document_ts_1 = require("./project-document.js");
const DEFAULT_LIMITS = Object.freeze({ maxSelection: 256, maxDuplicateNodes: 512 });
const SAFE_ID = /^[A-Za-z0-9_-]{1,80}$/;
/** Renderer-neutral editor commands; persistence and undo remain owned by ProjectHistory. */
class SceneEditorSession {
    constructor(document, limits = {}) {
        this.selected = new Set();
        this.disposed = false;
        this.history = new project_document_ts_1.ProjectHistory(document);
        this.limits = { ...DEFAULT_LIMITS, ...limits };
        if (!Number.isInteger(this.limits.maxSelection) || this.limits.maxSelection < 1 || this.limits.maxSelection > 2048 || !Number.isInteger(this.limits.maxDuplicateNodes) || this.limits.maxDuplicateNodes < 1 || this.limits.maxDuplicateNodes > 4096)
            throw new TypeError("INVALID_SCENE_EDITOR_LIMITS");
    }
    get document() { return this.history.document; }
    get selection() { return [...this.selected]; }
    assertActive() { if (this.disposed)
        throw new Error("SCENE_EDITOR_DISPOSED"); }
    select(ids, additive = false) {
        this.assertActive();
        if (!Array.isArray(ids) || ids.length > this.limits.maxSelection || ids.some(id => typeof id !== "string" || !SAFE_ID.test(id)))
            return { ok: false, error: "INVALID_SELECTION" };
        const known = new Set(this.document.nodes.map(node => node.id));
        if (ids.some(id => !known.has(id)))
            return { ok: false, error: "SELECTION_NODE_NOT_FOUND" };
        if (!additive)
            this.selected.clear();
        for (const id of ids)
            this.selected.add(id);
        return { ok: true, value: this.selection };
    }
    tree() {
        var _a;
        this.assertActive();
        const nodes = this.document.nodes;
        const children = new Map();
        for (const node of nodes) {
            const list = (_a = children.get(node.parentId)) !== null && _a !== void 0 ? _a : [];
            list.push(node);
            children.set(node.parentId, list);
        }
        const output = [];
        const visited = new Set();
        const walk = (parent, depth) => {
            var _a, _b;
            for (const node of (_a = children.get(parent)) !== null && _a !== void 0 ? _a : []) {
                if (visited.has(node.id))
                    continue;
                visited.add(node.id);
                output.push({ id: node.id, name: node.name, type: node.type, depth, childCount: ((_b = children.get(node.id)) !== null && _b !== void 0 ? _b : []).length, selected: this.selected.has(node.id) });
                walk(node.id, depth + 1);
            }
        };
        walk(null, 0);
        // Invalid/disconnected nodes are not hidden; validation should prevent them, but fail visibly.
        for (const node of nodes)
            if (!visited.has(node.id))
                output.push({ id: node.id, name: node.name, type: node.type, depth: 0, childCount: 0, selected: this.selected.has(node.id) });
        return output;
    }
    add(node, now) { this.assertActive(); return this.history.apply({ kind: "add", node }, now); }
    rename(id, name, now) { this.assertActive(); return this.history.apply({ kind: "rename", id, name }, now); }
    setProperties(id, props, now) { this.assertActive(); return this.history.apply({ kind: "set-props", id, props }, now); }
    reparent(id, parentId, now) { this.assertActive(); return this.history.apply({ kind: "set-parent", id, parentId }, now); }
    remove(id, now) {
        this.assertActive();
        const descendants = new Set([id]);
        let changed = true;
        while (changed) {
            changed = false;
            for (const node of this.document.nodes)
                if (node.parentId !== null && descendants.has(node.parentId) && !descendants.has(node.id)) {
                    descendants.add(node.id);
                    changed = true;
                }
        }
        const result = this.history.apply({ kind: "remove", id }, now);
        if (result.ok)
            for (const selected of descendants)
                this.selected.delete(selected);
        return result;
    }
    duplicateSubtree(rootId, createId, now) {
        this.assertActive();
        const nodes = this.document.nodes;
        const root = nodes.find(node => node.id === rootId);
        if (!root)
            return { ok: false, error: "NODE_NOT_FOUND" };
        const subtree = [];
        const included = new Set([rootId]);
        let changed = true;
        while (changed) {
            changed = false;
            for (const node of nodes)
                if (node.parentId !== null && included.has(node.parentId) && !included.has(node.id)) {
                    included.add(node.id);
                    changed = true;
                }
        }
        for (const node of nodes)
            if (included.has(node.id))
                subtree.push(node);
        if (subtree.length > this.limits.maxDuplicateNodes)
            return { ok: false, error: "DUPLICATE_SUBTREE_LIMIT" };
        const remap = new Map();
        for (let i = 0; i < subtree.length; i++) {
            const id = createId(subtree[i].id, i);
            if (typeof id !== "string" || !SAFE_ID.test(id) || nodes.some(node => node.id === id) || [...remap.values()].includes(id))
                return { ok: false, error: "INVALID_DUPLICATE_ID" };
            remap.set(subtree[i].id, id);
        }
        const created = subtree.map(node => remap.get(node.id));
        const operations = subtree.map(node => { var _a, _b; return ({ kind: "add", node: { ...node, id: remap.get(node.id), name: `${node.name} Copy`, parentId: node.id === rootId ? root.parentId : (_b = remap.get((_a = node.parentId) !== null && _a !== void 0 ? _a : "")) !== null && _b !== void 0 ? _b : null } }); });
        const result = this.history.applyBatch(operations, now);
        if (!result.ok)
            return { ok: false, error: `DUPLICATE_FAILED:${result.error}` };
        this.selected.clear();
        for (const id of created)
            this.selected.add(id);
        return { ok: true, value: created };
    }
    undo() { this.assertActive(); const result = this.history.undo(); if (result.ok)
        this.pruneSelection(); return result; }
    redo() { this.assertActive(); const result = this.history.redo(); if (result.ok)
        this.pruneSelection(); return result; }
    pruneSelection() { const known = new Set(this.document.nodes.map(node => node.id)); for (const id of this.selected)
        if (!known.has(id))
            this.selected.delete(id); }
    dispose() { this.selected.clear(); this.disposed = true; }
}
exports.SceneEditorSession = SceneEditorSession;

};
modules["spatial.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UniformGrid2D = void 0;
class UniformGrid2D {
    constructor(originX, originY, cellSize, columns, rows, maxEntities, maxEntries, maxCellsPerEntity = 64) {
        this.entryCount = 0;
        this.queryStamp = 0;
        if (![originX, originY, cellSize].every(Number.isFinite) || cellSize <= 0 || !Number.isSafeInteger(columns) || columns < 1 || columns > 1024 ||
            !Number.isSafeInteger(rows) || rows < 1 || rows > 1024 || columns * rows > 262144 ||
            !Number.isSafeInteger(maxEntities) || maxEntities < 1 || maxEntities > 262144 ||
            !Number.isSafeInteger(maxEntries) || maxEntries < maxEntities || maxEntries > 2000000 ||
            !Number.isSafeInteger(maxCellsPerEntity) || maxCellsPerEntity < 1 || maxCellsPerEntity > 1024) {
            throw new RangeError("INVALID_SPATIAL_GRID_CONFIGURATION");
        }
        this.originX = originX;
        this.originY = originY;
        this.cellSize = cellSize;
        this.columns = columns;
        this.rows = rows;
        this.maxEntities = maxEntities;
        this.maxEntries = maxEntries;
        this.maxCellsPerEntity = maxCellsPerEntity;
        this.heads = new Int32Array(columns * rows);
        this.next = new Int32Array(maxEntries);
        this.ids = new Uint32Array(maxEntries);
        this.stamps = new Uint32Array(maxEntities);
        this.inserted = new Uint8Array(maxEntities);
        this.clear();
    }
    clear() { this.heads.fill(-1); this.entryCount = 0; this.inserted.fill(0); }
    insert(id, bounds) {
        if (!Number.isInteger(id) || id < 0 || id >= this.maxEntities || !this.validBounds(bounds) || this.inserted[id] === 1)
            return false;
        const worldMaxX = this.originX + this.columns * this.cellSize;
        const worldMaxY = this.originY + this.rows * this.cellSize;
        // Reject boxes wholly outside the grid before clamping. Without this check,
        // an AABB beginning exactly at the far edge is incorrectly placed in the last cell.
        if (bounds.maxX < this.originX || bounds.maxY < this.originY || bounds.minX >= worldMaxX || bounds.minY >= worldMaxY) {
            this.inserted[id] = 1;
            return true;
        }
        const minX = Math.max(0, Math.floor((bounds.minX - this.originX) / this.cellSize));
        const minY = Math.max(0, Math.floor((bounds.minY - this.originY) / this.cellSize));
        const maxX = Math.min(this.columns - 1, Math.floor((bounds.maxX - this.originX) / this.cellSize));
        const maxY = Math.min(this.rows - 1, Math.floor((bounds.maxY - this.originY) / this.cellSize));
        if (minX > maxX || minY > maxY)
            return true;
        const cellCount = (maxX - minX + 1) * (maxY - minY + 1);
        if (cellCount > this.maxCellsPerEntity || this.entryCount + cellCount > this.maxEntries)
            return false;
        this.inserted[id] = 1;
        for (let y = minY; y <= maxY; y++)
            for (let x = minX; x <= maxX; x++) {
                const cell = y * this.columns + x;
                const entry = this.entryCount++;
                this.ids[entry] = id;
                this.next[entry] = this.heads[cell];
                this.heads[cell] = entry;
            }
        return true;
    }
    query(bounds, output) {
        if (!this.validBounds(bounds) || !(output instanceof Uint32Array))
            return 0;
        const minX = Math.max(0, Math.floor((bounds.minX - this.originX) / this.cellSize));
        const minY = Math.max(0, Math.floor((bounds.minY - this.originY) / this.cellSize));
        const maxX = Math.min(this.columns - 1, Math.floor((bounds.maxX - this.originX) / this.cellSize));
        const maxY = Math.min(this.rows - 1, Math.floor((bounds.maxY - this.originY) / this.cellSize));
        if (minX > maxX || minY > maxY)
            return 0;
        this.queryStamp = (this.queryStamp + 1) >>> 0;
        if (this.queryStamp === 0) {
            this.stamps.fill(0);
            this.queryStamp = 1;
        }
        let count = 0;
        for (let y = minY; y <= maxY; y++)
            for (let x = minX; x <= maxX; x++) {
                let entry = this.heads[y * this.columns + x];
                while (entry !== -1) {
                    const id = this.ids[entry];
                    if (this.stamps[id] !== this.queryStamp) {
                        this.stamps[id] = this.queryStamp;
                        if (count < output.length)
                            output[count++] = id;
                    }
                    entry = this.next[entry];
                }
            }
        return count;
    }
    validBounds(b) {
        return !!b && Number.isFinite(b.minX) && Number.isFinite(b.minY) && Number.isFinite(b.maxX) && Number.isFinite(b.maxY) && b.minX <= b.maxX && b.minY <= b.maxY;
    }
    get entriesUsed() { return this.entryCount; }
}
exports.UniformGrid2D = UniformGrid2D;

};
modules["sprite-animation.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SpriteAnimator = void 0;
exports.createSpriteAnimationClip = createSpriteAnimationClip;
function createSpriteAnimationClip(id, frames, options = {}) {
    var _a, _b;
    if (typeof id !== "string" || !/^[A-Za-z0-9_-]{1,80}$/.test(id) || !Array.isArray(frames) || frames.length < 1 || frames.length > 1024)
        return { ok: false, error: "INVALID_ANIMATION_CLIP" };
    const copy = [];
    for (const frame of frames) {
        if (!frame || typeof frame.frameId !== "string" || !/^[A-Za-z0-9_-]{1,80}$/.test(frame.frameId) || !Number.isFinite(frame.durationMs) || frame.durationMs < 10 || frame.durationMs > 60000)
            return { ok: false, error: "INVALID_ANIMATION_FRAME" };
        copy.push(Object.freeze({ frameId: frame.frameId, durationMs: frame.durationMs }));
    }
    if (options.pingPong && copy.length < 2)
        return { ok: false, error: "PING_PONG_NEEDS_MULTIPLE_FRAMES" };
    return { ok: true, clip: Object.freeze({ id, frames: Object.freeze(copy), loop: (_a = options.loop) !== null && _a !== void 0 ? _a : true, pingPong: (_b = options.pingPong) !== null && _b !== void 0 ? _b : false }) };
}
class SpriteAnimator {
    constructor() {
        this.clipValue = null;
        this.frameIndexValue = 0;
        this.elapsedMs = 0;
        this.direction = 1;
        this.playingValue = false;
        this.completedValue = false;
    }
    get clip() { return this.clipValue; }
    get frameIndex() { return this.frameIndexValue; }
    get currentFrameId() { var _a, _b, _c; return (_c = (_b = (_a = this.clipValue) === null || _a === void 0 ? void 0 : _a.frames[this.frameIndexValue]) === null || _b === void 0 ? void 0 : _b.frameId) !== null && _c !== void 0 ? _c : null; }
    get isPlaying() { return this.playingValue; }
    get isComplete() { return this.completedValue; }
    play(clip, restart = true) {
        var _a;
        if (!clip || typeof clip.id !== "string" || !/^[A-Za-z0-9_-]{1,80}$/.test(clip.id) || !Array.isArray(clip.frames) || clip.frames.length < 1 || clip.frames.length > 1024 || typeof clip.loop !== "boolean" || typeof clip.pingPong !== "boolean" || (clip.pingPong && clip.frames.length < 2) || !clip.frames.every(frame => !!frame && typeof frame.frameId === "string" && /^[A-Za-z0-9_-]{1,80}$/.test(frame.frameId) && Number.isFinite(frame.durationMs) && frame.durationMs >= 10 && frame.durationMs <= 60000))
            return false;
        if (restart || ((_a = this.clipValue) === null || _a === void 0 ? void 0 : _a.id) !== clip.id) {
            this.frameIndexValue = 0;
            this.elapsedMs = 0;
            this.direction = 1;
            this.completedValue = false;
        }
        this.clipValue = clip;
        this.playingValue = true;
        return true;
    }
    pause() { this.playingValue = false; }
    stop() { this.playingValue = false; this.completedValue = false; this.elapsedMs = 0; this.frameIndexValue = 0; this.direction = 1; }
    update(deltaSeconds) {
        const clip = this.clipValue;
        if (!this.playingValue || !clip || this.completedValue || !Number.isFinite(deltaSeconds) || deltaSeconds <= 0)
            return false;
        // Bound catch-up after backgrounding. Frame durations are at least 10ms.
        this.elapsedMs += Math.min(deltaSeconds, 0.25) * 1000;
        let changed = false;
        let transitions = 0;
        while (this.elapsedMs >= clip.frames[this.frameIndexValue].durationMs && transitions < 64) {
            this.elapsedMs -= clip.frames[this.frameIndexValue].durationMs;
            if (clip.pingPong) {
                let next = this.frameIndexValue + this.direction;
                if (next >= clip.frames.length || next < 0) {
                    if (!clip.loop) {
                        this.completedValue = true;
                        this.playingValue = false;
                        this.elapsedMs = 0;
                        break;
                    }
                    this.direction = this.direction === 1 ? -1 : 1;
                    next = this.frameIndexValue + this.direction;
                }
                this.frameIndexValue = next;
            }
            else if (this.frameIndexValue + 1 < clip.frames.length)
                this.frameIndexValue++;
            else if (clip.loop)
                this.frameIndexValue = 0;
            else {
                this.completedValue = true;
                this.playingValue = false;
                this.elapsedMs = 0;
                break;
            }
            changed = true;
            transitions++;
        }
        if (transitions === 64)
            this.elapsedMs = 0;
        return changed;
    }
}
exports.SpriteAnimator = SpriteAnimator;

};
modules["sprite-atlas.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildSpriteAtlas = buildSpriteAtlas;
exports.composeSpriteAtlasPage = composeSpriteAtlasPage;
const ID = /^[A-Za-z0-9_-]{1,80}$/;
const MAX_SOURCES = 8192;
const MAX_ATLAS_SIZE = 4096;
/** Uses stable sort and first-fit shelves; no rotation, no hidden allocations per pixel. */
function buildSpriteAtlas(sources, options = {}) {
    var _a, _b, _c, _d;
    const maxSize = (_a = options.maxSize) !== null && _a !== void 0 ? _a : 1024;
    const maxPages = (_b = options.maxPages) !== null && _b !== void 0 ? _b : 16;
    const padding = (_c = options.padding) !== null && _c !== void 0 ? _c : 2;
    const maxTextureBytes = (_d = options.maxTextureBytes) !== null && _d !== void 0 ? _d : 8 * 1024 * 1024;
    if (!Array.isArray(sources) || sources.length > MAX_SOURCES)
        return { ok: false, error: "ATLAS_SOURCE_LIMIT" };
    if (!Number.isInteger(maxSize) || maxSize < 32 || maxSize > MAX_ATLAS_SIZE || !Number.isInteger(maxPages) || maxPages < 1 || maxPages > 64 || !Number.isInteger(padding) || padding < 0 || padding > 16 || !Number.isSafeInteger(maxTextureBytes) || maxTextureBytes < 4 || maxTextureBytes > 64 * 1024 * 1024)
        return { ok: false, error: "INVALID_ATLAS_OPTIONS" };
    const seen = new Set();
    const items = [];
    for (const source of sources) {
        if (!source || typeof source.id !== "string" || !ID.test(source.id) || seen.has(source.id) || !Number.isSafeInteger(source.width) || !Number.isSafeInteger(source.height) || source.width < 1 || source.height < 1)
            return { ok: false, error: "INVALID_ATLAS_SOURCE" };
        seen.add(source.id);
        const paddedWidth = source.width + padding * 2;
        const paddedHeight = source.height + padding * 2;
        if (!Number.isSafeInteger(paddedWidth) || !Number.isSafeInteger(paddedHeight) || paddedWidth > maxSize || paddedHeight > maxSize)
            return { ok: false, error: "ATLAS_FRAME_TOO_LARGE" };
        items.push({ ...source, paddedWidth, paddedHeight });
    }
    items.sort((a, b) => Math.max(b.paddedWidth, b.paddedHeight) - Math.max(a.paddedWidth, a.paddedHeight) || b.paddedWidth * b.paddedHeight - a.paddedWidth * a.paddedHeight || a.id.localeCompare(b.id));
    const pages = [];
    const frames = [];
    for (const item of items) {
        let placed = false;
        for (let pageIndex = 0; pageIndex < pages.length && !placed; pageIndex++) {
            const page = pages[pageIndex];
            for (const shelf of page.shelves) {
                if (item.paddedHeight <= shelf.height && shelf.x + item.paddedWidth <= maxSize) {
                    frames.push({ id: item.id, page: pageIndex, x: shelf.x + padding, y: shelf.y + padding, width: item.width, height: item.height });
                    shelf.x += item.paddedWidth;
                    page.usedWidth = Math.max(page.usedWidth, shelf.x);
                    page.usedHeight = Math.max(page.usedHeight, shelf.y + shelf.height);
                    page.ids.push(item.id);
                    placed = true;
                    break;
                }
            }
            if (placed)
                break;
            const y = page.usedHeight;
            if (y + item.paddedHeight <= maxSize) {
                const shelf = { y, height: item.paddedHeight, x: item.paddedWidth };
                page.shelves.push(shelf);
                frames.push({ id: item.id, page: pageIndex, x: padding, y: y + padding, width: item.width, height: item.height });
                page.usedWidth = Math.max(page.usedWidth, item.paddedWidth);
                page.usedHeight = y + item.paddedHeight;
                page.ids.push(item.id);
                placed = true;
            }
        }
        if (!placed) {
            if (pages.length >= maxPages)
                return { ok: false, error: "ATLAS_PAGE_LIMIT" };
            const page = { shelves: [{ y: 0, height: item.paddedHeight, x: item.paddedWidth }], usedWidth: item.paddedWidth, usedHeight: item.paddedHeight, ids: [item.id] };
            const pageIndex = pages.push(page) - 1;
            frames.push({ id: item.id, page: pageIndex, x: padding, y: padding, width: item.width, height: item.height });
        }
    }
    const estimatedBytes = pages.reduce((sum, page) => sum + page.usedWidth * page.usedHeight * 4, 0);
    if (!Number.isSafeInteger(estimatedBytes) || estimatedBytes > maxTextureBytes)
        return { ok: false, error: "ATLAS_MEMORY_BUDGET_EXCEEDED" };
    frames.sort((a, b) => a.id.localeCompare(b.id));
    const frozenPages = pages.map((page, index) => Object.freeze({ index, width: Math.max(1, page.usedWidth), height: Math.max(1, page.usedHeight), frameIds: Object.freeze(page.ids.slice().sort()) }));
    return { ok: true, atlas: Object.freeze({ schemaVersion: 1, padding, pages: Object.freeze(frozenPages), frames: Object.freeze(frames) }) };
}
/** Draws a packed page into a caller-provided canvas; source ownership remains with the caller. */
function composeSpriteAtlasPage(atlas, pageIndex, sources, createCanvas = (width, height) => {
    if (typeof document === "undefined")
        throw new Error("CANVAS_FACTORY_REQUIRED");
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    return canvas;
}) {
    const page = atlas.pages[pageIndex];
    if (!page || !sources || typeof sources.get !== "function")
        return null;
    const canvas = createCanvas(page.width, page.height);
    if (canvas.width !== page.width || canvas.height !== page.height)
        throw new RangeError("ATLAS_CANVAS_DIMENSION_MISMATCH");
    const context = canvas.getContext("2d", { alpha: true });
    if (!context)
        throw new Error("ATLAS_CANVAS_CONTEXT_UNAVAILABLE");
    context.clearRect(0, 0, page.width, page.height);
    for (const frame of atlas.frames) {
        if (frame.page !== pageIndex)
            continue;
        const source = sources.get(frame.id);
        if (!source)
            throw new Error("ATLAS_SOURCE_MISSING:" + frame.id);
        context.drawImage(source, frame.x, frame.y, frame.width, frame.height);
        const pad = atlas.padding;
        if (pad > 0) {
            // Edge extrusion protects adjacent atlas frames from linear-filter bleeding.
            context.drawImage(source, 0, 0, 1, frame.height, frame.x - pad, frame.y, pad, frame.height);
            context.drawImage(source, frame.width - 1, 0, 1, frame.height, frame.x + frame.width, frame.y, pad, frame.height);
            context.drawImage(source, 0, 0, frame.width, 1, frame.x, frame.y - pad, frame.width, pad);
            context.drawImage(source, 0, frame.height - 1, frame.width, 1, frame.x, frame.y + frame.height, frame.width, pad);
            context.drawImage(source, 0, 0, 1, 1, frame.x - pad, frame.y - pad, pad, pad);
            context.drawImage(source, frame.width - 1, 0, 1, 1, frame.x + frame.width, frame.y - pad, pad, pad);
            context.drawImage(source, 0, frame.height - 1, 1, 1, frame.x - pad, frame.y + frame.height, pad, pad);
            context.drawImage(source, frame.width - 1, frame.height - 1, 1, 1, frame.x + frame.width, frame.y + frame.height, pad, pad);
        }
    }
    return canvas;
}

};
modules["world-scale.js"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WorldOriginRebaser = exports.WORLD_CELL_METERS = void 0;
exports.worldPointFromMeters = worldPointFromMeters;
exports.translateWorldPoint = translateWorldPoint;
exports.relativeWorldPosition = relativeWorldPosition;
/** Cell-based world coordinates keep GPU-facing values local while retaining JS Number precision. */
exports.WORLD_CELL_METERS = 1000;
function normalizeAxis(cell, offset) {
    if (!Number.isSafeInteger(cell) || !Number.isFinite(offset))
        throw new RangeError("INVALID_WORLD_COORDINATE");
    const shift = Math.floor(offset / exports.WORLD_CELL_METERS);
    const nextCell = cell + shift;
    if (!Number.isSafeInteger(nextCell))
        throw new RangeError("WORLD_CELL_RANGE_EXCEEDED");
    let local = offset - shift * exports.WORLD_CELL_METERS;
    let finalCell = nextCell;
    if (local >= exports.WORLD_CELL_METERS) {
        local -= exports.WORLD_CELL_METERS;
        finalCell += 1;
    }
    if (local < 0) {
        local += exports.WORLD_CELL_METERS;
        finalCell -= 1;
    }
    if (!Number.isSafeInteger(finalCell) || !Number.isFinite(local) || local < 0 || local >= exports.WORLD_CELL_METERS)
        throw new RangeError("WORLD_COORDINATE_NORMALIZATION_FAILED");
    return [finalCell, local];
}
function worldPointFromMeters(x, y, z) {
    if (![x, y, z].every(Number.isFinite))
        throw new TypeError("WORLD_POSITION_MUST_BE_FINITE");
    const [cellX, offsetX] = normalizeAxis(0, x);
    const [cellY, offsetY] = normalizeAxis(0, y);
    const [cellZ, offsetZ] = normalizeAxis(0, z);
    return Object.freeze({ cellX, cellY, cellZ, offsetX, offsetY, offsetZ });
}
function translateWorldPoint(point, dx, dy, dz) {
    if (!point || ![dx, dy, dz, point.offsetX, point.offsetY, point.offsetZ].every(Number.isFinite))
        throw new TypeError("INVALID_WORLD_TRANSLATION");
    const [cellX, offsetX] = normalizeAxis(point.cellX, point.offsetX + dx);
    const [cellY, offsetY] = normalizeAxis(point.cellY, point.offsetY + dy);
    const [cellZ, offsetZ] = normalizeAxis(point.cellZ, point.offsetZ + dz);
    return Object.freeze({ cellX, cellY, cellZ, offsetX, offsetY, offsetZ });
}
/** Returns null rather than emitting imprecise or unbounded GPU-local coordinates. */
function relativeWorldPosition(point, origin, maxDistance = 1000000) {
    if (!point || !origin || !Number.isFinite(maxDistance) || maxDistance <= 0)
        return null;
    const axis = (cellA, offsetA, cellB, offsetB) => {
        const cellDelta = cellA - cellB;
        if (!Number.isSafeInteger(cellDelta) || Math.abs(cellDelta) > Math.ceil(maxDistance / exports.WORLD_CELL_METERS) + 1)
            return null;
        const value = cellDelta * exports.WORLD_CELL_METERS + offsetA - offsetB;
        return Number.isFinite(value) && Math.abs(value) <= maxDistance ? value : null;
    };
    const x = axis(point.cellX, point.offsetX, origin.cellX, origin.offsetX);
    const y = axis(point.cellY, point.offsetY, origin.cellY, origin.offsetY);
    const z = axis(point.cellZ, point.offsetZ, origin.cellZ, origin.offsetZ);
    return x === null || y === null || z === null ? null : Object.freeze({ x, y, z });
}
/** Re-centers the render origin around the active focus; world-space identity never changes. */
class WorldOriginRebaser {
    constructor(initialOrigin = worldPointFromMeters(0, 0, 0), thresholdMeters = 500) {
        if (!Number.isFinite(thresholdMeters) || thresholdMeters < 1 || thresholdMeters >= exports.WORLD_CELL_METERS * 100)
            throw new RangeError("INVALID_REBASE_THRESHOLD");
        this.current = initialOrigin;
        this.thresholdMeters = thresholdMeters;
    }
    get origin() { return this.current; }
    update(focus) {
        const relative = relativeWorldPosition(focus, this.current, this.thresholdMeters * 2);
        if (!relative) {
            this.current = focus;
            return true;
        }
        if (relative.x * relative.x + relative.y * relative.y + relative.z * relative.z > this.thresholdMeters * this.thresholdMeters) {
            this.current = focus;
            return true;
        }
        return false;
    }
    toLocal(point, maxDistance = this.thresholdMeters * 4) { return relativeWorldPosition(point, this.current, maxDistance); }
}
exports.WorldOriginRebaser = WorldOriginRebaser;

};
function resolve(from,request){if(request.charAt(0)!=='.')throw new Error('EXTERNAL_MODULE_BLOCKED:'+request);var parts=from.split('/');parts.pop();var incoming=request.split('/');for(var i=0;i<incoming.length;i++){var part=incoming[i];if(!part||part==='.')continue;if(part==='..')parts.pop();else parts.push(part);}var id=parts.join('/');if(!/\.js$/.test(id))id+='.js';if(!modules[id])throw new Error('MODULE_NOT_FOUND:'+id);return id;}
function load(id){if(cache[id])return cache[id].exports;if(!modules[id])throw new Error('MODULE_NOT_FOUND:'+id);var module={exports:{}};cache[id]=module;modules[id](module,module.exports,function(request){return load(resolve(id,request));});return module.exports;}
var api=load('browser-entry.js');if(!root.MUNGIL_RUNTIME)Object.defineProperty(root,'MUNGIL_RUNTIME',{configurable:false,enumerable:false,writable:false,value:Object.freeze(api)});
})(window);
