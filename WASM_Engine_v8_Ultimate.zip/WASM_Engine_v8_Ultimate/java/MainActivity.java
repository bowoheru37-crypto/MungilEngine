package com.sketchware.wasmengine;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * MainActivity v8.0 - Splash + Editor (View Manager)
 * Single-responsibility: UI orchestration only
 * All logic delegated to KERNEL/ENGINE/SYSTEMS
 */
public final class MainActivity extends AppCompatActivity {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private View splash, editor;
    private TextView splashStatus;
    private ProgressBar splashProgress;
    private GLSurfaceView glView;
    private WebView webView;
    private View leftRail, rightRail, gizmo;
    private ImageButton btnUndo, btnRedo, btnExport, btnMenu, btnMore, btnPlay;
    private TextView tvTimecode, tvFps;
    private SeekBar timelineSeek;
    private FloatingActionButton fabAdd;
    private TabLayout bottomTabs;
    private ViewPager2 bottomPager;
    private View bottomSheet;
    private BottomSheetBehavior<View> sheetBehavior;
    private ProgressBar memBar;

    private KERNEL kernel;
    private ENGINE engine;
    private SYSTEMS sys;
    private boolean playing = false;
    private Runnable tickLoop, fpsLoop;
    private long lastFrame = 0;

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.main);
        bindViews();
        initSplash();
    }

    private void bindViews() {
        splash = findViewById(R.id.splash_container);
        splashStatus = findViewById(R.id.splash_status);
        splashProgress = findViewById(R.id.splash_progress);
        editor = findViewById(R.id.editor_container);
        glView = findViewById(R.id.gl_surface_view);
        webView = findViewById(R.id.web_runtime);
        leftRail = findViewById(R.id.left_rail);
        rightRail = findViewById(R.id.right_rail);
        gizmo = findViewById(R.id.transform_gizmo);
        btnUndo = findViewById(R.id.btn_undo);
        btnRedo = findViewById(R.id.btn_redo);
        btnExport = findViewById(R.id.btn_export);
        btnMenu = findViewById(R.id.btn_menu);
        btnMore = findViewById(R.id.btn_more);
        btnPlay = findViewById(R.id.btn_play);
        tvTimecode = findViewById(R.id.tv_timecode);
        tvFps = findViewById(R.id.tv_fps);
        timelineSeek = findViewById(R.id.timeline_seekbar);
        fabAdd = findViewById(R.id.fab_add);
        bottomTabs = findViewById(R.id.bottom_tabs);
        bottomPager = findViewById(R.id.bottom_pager);
        bottomSheet = findViewById(R.id.bottom_sheet);
        memBar = findViewById(R.id.memory_bar);
    }

    private void initSplash() {
        Executors.newSingleThreadExecutor().execute(() -> {
            kernel = KERNEL.init(this);
            splash("Core");
            engine = new ENGINE(this, kernel);
            splash("Engine");
            sys = new SYSTEMS(this, kernel, engine);
            splash("Systems");
            ui.post(this::showEditor);
        });
    }

    private void splash(String m) {
        ui.post(() -> { splashStatus.setText(m); splashProgress.incrementProgressBy(14); });
        try { Thread.sleep(100); } catch(InterruptedException ignored) {}
    }

    private void showEditor() {
        AlphaAnimation a = new AlphaAnimation(1f, 0f);
        a.setDuration(250); a.setFillAfter(true);
        a.setAnimationListener(new Animation.AnimationListener() {
            public void onAnimationStart(Animation a) {}
            public void onAnimationEnd(Animation a) { splash.setVisibility(View.GONE); editor.setVisibility(View.VISIBLE); initEditor(); }
            public void onAnimationRepeat(Animation a) {}
        });
        splash.startAnimation(a);
    }

    private void initEditor() {
        engine.initGL(glView);
        findViewById(R.id.btn_mode_2d).setOnClickListener(v -> setMode(true));
        findViewById(R.id.btn_mode_3d).setOnClickListener(v -> setMode(false));
        findViewById(R.id.btn_view).setOnClickListener(v -> toggle(leftRail));
        findViewById(R.id.btn_cube).setOnClickListener(v -> { engine.addCube(); toast("Cube added"); });
        findViewById(R.id.btn_camera).setOnClickListener(v -> toast("Camera: Orbit/Pan/Zoom"));
        findViewById(R.id.btn_grid).setOnClickListener(v -> toast("Grid toggled"));
        findViewById(R.id.btn_crown).setOnClickListener(v -> toast("Premium templates"));
        btnPlay.setOnClickListener(v -> togglePlay());
        findViewById(R.id.btn_layers).setOnClickListener(v -> toast("Layers"));
        findViewById(R.id.btn_settings).setOnClickListener(v -> UI.settings(this, sys));
        findViewById(R.id.btn_skip_prev).setOnClickListener(v -> { engine.anim.setTime(0); updateTime(); });
        findViewById(R.id.btn_timeline_play).setOnClickListener(v -> togglePlay());
        findViewById(R.id.btn_skip_next).setOnClickListener(v -> { engine.anim.setTime(engine.anim.duration); updateTime(); });
        timelineSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean f) { if(f) { engine.anim.setTime((p/100f)*engine.anim.duration); updateTime(); } }
            public void onStartTrackingTouch(SeekBar s) { engine.anim.pause(); }
            public void onStopTrackingTouch(SeekBar s) { if(playing) engine.anim.play(); }
        });
        btnUndo.setOnClickListener(v -> { if(engine.undo.canUndo()) { engine.undo.undo(); toast("Undo"); } });
        btnRedo.setOnClickListener(v -> { if(engine.undo.canRedo()) { engine.undo.redo(); toast("Redo"); } });
        btnExport.setOnClickListener(v -> UI.export(this, sys));
        btnMenu.setOnClickListener(v -> showMenu());
        btnMore.setOnClickListener(v -> showMore());
        fabAdd.setOnClickListener(v -> showAddMenu());
        findViewById(R.id.viewport_chip).setOnClickListener(v -> showViewportMenu());

        sheetBehavior = BottomSheetBehavior.from(bottomSheet);
        sheetBehavior.setPeekHeight(40); sheetBehavior.setHideable(false);
        bottomPager.setAdapter(new UI.TabAdapter(this));
        bottomPager.setOffscreenPageLimit(1);
        new TabLayoutMediator(bottomTabs, bottomPager, (tab, pos) -> tab.setText(new String[]{"Object","Material","Anim","Physics","Logic","Script","Shader","Build"}[pos])).attach();
        bottomTabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            public void onTabSelected(TabLayout.Tab t) { if(t.getPosition() == 7) UI.build(MainActivity.this, sys); }
            public void onTabUnselected(TabLayout.Tab t) {}
            public void onTabReselected(TabLayout.Tab t) { if(t.getPosition() == 7) UI.build(MainActivity.this, sys); }
        });

        editor.setOnTouchListener((v, e) -> engine.input.onTouch(e));
        if(kernel.isLowMem()) { leftRail.setAlpha(0.85f); rightRail.setAlpha(0.85f); }
        setMode(false);
        startLoops();
        toast("Engine Ready");
    }

    private void setMode(boolean d2) {
        if(engine.is2D == d2) return;
        engine.setMode(d2);
        if(d2) { glView.setVisibility(View.GONE); gizmo.setVisibility(View.GONE); webView.setVisibility(View.VISIBLE); }
        else { webView.setVisibility(View.GONE); glView.setVisibility(View.VISIBLE); gizmo.setVisibility(View.VISIBLE); }
    }

    private void togglePlay() {
        playing = !playing;
        if(playing) { engine.play(); btnPlay.setImageResource(R.drawable.ic_pause); }
        else { engine.pause(); btnPlay.setImageResource(R.drawable.ic_play); }
    }

    private void updateTime() {
        float t = engine.anim.getTime(), d = engine.anim.duration;
        timelineSeek.setProgress((int)((t/d)*100f));
        tvTimecode.setText(String.format("%02d:%05.2f / %02d:%05.2f", (int)(t/60), t%60, (int)(d/60), d%60));
    }

    private void toggle(View v) {
        boolean vis = v.getVisibility() == View.VISIBLE;
        v.animate().alpha(vis?0:1).setDuration(100).withEndAction(() -> v.setVisibility(vis?View.GONE:View.VISIBLE)).start();
    }

    private void showMenu() {
        PopupMenu p = new PopupMenu(this, btnMenu);
        for(String i : new String[]{"New","Open","Save","Git History","Packages","Console","Profiler"}) p.getMenu().add(i);
        p.setOnMenuItemClickListener(item -> {
            String t = item.getTitle().toString();
            if(t.equals("Git History")) UI.git(this, sys);
            else if(t.equals("Packages")) UI.packages(this, sys);
            else if(t.equals("Console")) UI.console(this, kernel);
            else if(t.equals("Profiler")) UI.profiler(this, kernel);
            else toast(t);
            return true;
        });
        p.show();
    }

    private void showMore() {
        PopupMenu p = new PopupMenu(this, btnMore);
        for(String i : new String[]{"Build APK","Build Web","Export All","Run Script","Fullscreen","About"}) p.getMenu().add(i);
        p.setOnMenuItemClickListener(item -> {
            String t = item.getTitle().toString();
            if(t.equals("Build APK")) UI.build(this, sys);
            else if(t.equals("Build Web")) { sys.build.queueWeb(getFilesDir().getPath()+"/project", getExternalFilesDir(null)+"/web"); UI.buildProgress(this, sys); }
            else if(t.equals("Export All")) UI.export(this, sys);
            else if(t.equals("Run Script")) UI.script(this, sys);
            else if(t.equals("Fullscreen")) toggleFullscreen();
            else if(t.equals("About")) UI.about(this);
            return true;
        });
        p.show();
    }

    private void showAddMenu() {
        PopupMenu p = new PopupMenu(this, fabAdd);
        for(String i : new String[]{"Cube","Sphere","Plane","Light","Camera","Empty"}) p.getMenu().add(i);
        p.setOnMenuItemClickListener(item -> { toast("Added " + item.getTitle()); engine.requestRender(); return true; });
        p.show();
    }

    private void showViewportMenu() {
        PopupMenu p = new PopupMenu(this, findViewById(R.id.viewport_chip));
        for(String i : new String[]{"Perspective","Orthographic","Top","Front","Side"}) p.getMenu().add(i);
        p.setOnMenuItemClickListener(item -> { toast("Viewport: " + item.getTitle()); return true; });
        p.show();
    }

    private void toggleFullscreen() {
        View d = getWindow().getDecorView();
        d.setSystemUiVisibility(d.getSystemUiVisibility() ^ View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    private void startLoops() {
        lastFrame = SystemClock.elapsedRealtime();
        tickLoop = () -> {
            long now = SystemClock.elapsedRealtime();
            float dt = (now - lastFrame) / 1000f; lastFrame = now;
            if(playing) { engine.anim.update(dt); engine.physics.step(dt); engine.requestRender(); }
            ui.postDelayed(tickLoop, KERNEL.FRAME_MS);
        };
        fpsLoop = () -> {
            tvFps.setText(kernel.profiler.fps() + " FPS");
            int pct = (int)(100 - (kernel.freeMemMB() * 100 / 2048));
            memBar.setProgress(Math.max(0, Math.min(100, pct)));
            ui.postDelayed(fpsLoop, 1000);
        };
        ui.post(tickLoop); ui.post(fpsLoop);
    }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    @Override protected void onResume() { super.onResume(); engine.resumeGL(); if(!playing) { playing = true; engine.anim.play(); } lastFrame = SystemClock.elapsedRealtime(); }
    @Override protected void onPause() { super.onPause(); engine.pauseGL(); engine.anim.pause(); playing = false; }
    @Override protected void onDestroy() { ui.removeCallbacks(tickLoop); ui.removeCallbacks(fpsLoop); engine.destroy(); sys.destroy(); super.onDestroy(); }
    @Override public void onBackPressed() { if(sheetBehavior != null && sheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) { sheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED); return; } super.onBackPressed(); }
    @Override public void onTrimMemory(int l) { super.onTrimMemory(l); if(l >= TRIM_MEMORY_RUNNING_LOW) { bottomPager.setOffscreenPageLimit(0); engine.pauseGL(); } }
}
