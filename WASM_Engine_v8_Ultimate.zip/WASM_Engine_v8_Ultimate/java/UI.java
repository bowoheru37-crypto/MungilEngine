package com.sketchware.wasmengine;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import java.util.*;

/**
 * UI v8.0 - Unified Interface Controller
 * All dialogs, fragments, and menus in one cohesive unit
 */
public final class UI {

    // ============ TAB ADAPTER ============
    public static final class TabAdapter extends FragmentStateAdapter {
        private static final int[] LAYOUTS = {R.layout.tab_object, R.layout.tab_material, R.layout.tab_anim, R.layout.tab_physics, R.layout.tab_logic, R.layout.tab_script, R.layout.tab_shader, R.layout.tab_build};
        public TabAdapter(AppCompatActivity a) { super(a); }
        @NonNull @Override public Fragment createFragment(int p) { return TabFrag.newInstance(LAYOUTS[p]); }
        @Override public int getItemCount() { return LAYOUTS.length; }
    }

    public static final class TabFrag extends Fragment {
        private static final String ARG = "layout";
        static TabFrag newInstance(int l) { TabFrag f = new TabFrag(); Bundle a = new Bundle(); a.putInt(ARG, l); f.setArguments(a); return f; }
        @Override public View onCreateView(@NonNull LayoutInflater i, ViewGroup c, Bundle s) { return i.inflate(getArguments() != null ? getArguments().getInt(ARG, R.layout.tab_object) : R.layout.tab_object, c, false); }
    }

    // ============ BUILD DIALOG ============
    public static void build(AppCompatActivity a, SYSTEMS sys) {
        AlertDialog.Builder b = new AlertDialog.Builder(a); b.setTitle("Build Project");
        LinearLayout l = new LinearLayout(a); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(24, 16, 24, 16);
        String[] t = {"Android APK", "Android AAB", "Web/HTML5", "Windows", "Linux", "macOS"};
        boolean[] c = {true, false, false, false, false, false};
        for(int i = 0; i < t.length; i++) {
            CheckBox cb = new CheckBox(a); cb.setText(t[i]); cb.setChecked(c[i]);
            final int idx = i; cb.setOnCheckedChangeListener((v, ch) -> c[idx] = ch); l.addView(cb);
        }
        b.setView(l);
        b.setPositiveButton("Build", (d, w) -> {
            String o = a.getExternalFilesDir(null) + "/builds", p = a.getFilesDir().getPath() + "/project";
            if(c[0]) sys.build.queueAPK(p, o + "/apk"); if(c[1]) sys.build.queueAAB(p, o + "/aab");
            if(c[2]) sys.build.queueWeb(p, o + "/web"); if(c[3]) sys.build.queueDesktop(p, o + "/win", "win");
            if(c[4]) sys.build.queueDesktop(p, o + "/linux", "linux"); if(c[5]) sys.build.queueDesktop(p, o + "/mac", "mac");
            buildProgress(a, sys);
        });
        b.setNegativeButton("Cancel", null); b.setNeutralButton("Templates", (d, w) -> templates(a, sys)); b.show();
    }

    public static void buildProgress(AppCompatActivity a, SYSTEMS sys) {
        ProgressDialog pd = new ProgressDialog(a); pd.setTitle("Building..."); pd.setMessage("Initializing...");
        pd.setIndeterminate(false); pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL); pd.setMax(100); pd.setCancelable(false); pd.show();
        sys.build.start(new SYSTEMS.Build.Callback() {
            public void onProgress(String m) { a.runOnUiThread(() -> { pd.setMessage(m); pd.setProgress(pd.getProgress() + 15); }); }
            public void onArtifact(String t, String p) { a.runOnUiThread(() -> Toast.makeText(a, "Built: " + t, Toast.LENGTH_SHORT).show()); }
            public void onComplete(String m) { a.runOnUiThread(() -> { pd.dismiss(); Toast.makeText(a, m, Toast.LENGTH_SHORT).show(); }); }
            public void onError(String m) { a.runOnUiThread(() -> { pd.dismiss(); Toast.makeText(a, "Error: " + m, Toast.LENGTH_SHORT).show(); }); }
        });
    }

    // ============ EXPORT DIALOG ============
    public static void export(AppCompatActivity a, SYSTEMS sys) {
        AlertDialog.Builder b = new AlertDialog.Builder(a); b.setTitle("Export Scene");
        String[] f = {"GLB", "GLTF", "OBJ", "FBX", "JSON", "HTML5", "PNG Sequence", "WAV"};
        b.setItems(f, (d, w) -> {
            SYSTEMS.Export.Scene s = new SYSTEMS.Export.Scene(); s.name = "MyScene"; String r = "";
            switch(w) { case 0: r = sys.export.glb(s); break; case 1: r = sys.export.gltf(s); break; case 2: r = sys.export.obj(s); break; case 3: r = sys.export.fbx(s); break; case 4: r = sys.export.json(s); break; case 5: r = sys.export.html5(s); break; case 6: r = "PNG sequence"; break; case 7: r = "WAV audio"; break; }
            ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
            if(cm != null) cm.setPrimaryClip(ClipData.newPlainText("Export", r));
            Toast.makeText(a, "Exported to clipboard", Toast.LENGTH_SHORT).show();
        });
        b.setNegativeButton("Cancel", null); b.show();
    }

    // ============ TEMPLATES DIALOG ============
    public static void templates(AppCompatActivity a, SYSTEMS sys) {
        AlertDialog.Builder b = new AlertDialog.Builder(a); b.setTitle("Game Templates");
        ArrayList<SYSTEMS.Templates.Template> t = sys.templates.list();
        String[] n = new String[t.size()];
        for(int i = 0; i < t.size(); i++) n[i] = t.get(i).name + " - " + t.get(i).desc;
        b.setItems(n, (d, w) -> {
            SYSTEMS.Export.Scene s = new SYSTEMS.Export.Scene();
            sys.templates.apply(new ArrayList<>(sys.templates.data.keySet()).get(w), s);
            Toast.makeText(a, "Applied: " + t.get(w).name, Toast.LENGTH_SHORT).show();
        });
        b.show();
    }

    // ============ SETTINGS DIALOG ============
    public static void settings(AppCompatActivity a, SYSTEMS sys) {
        AlertDialog.Builder b = new AlertDialog.Builder(a); b.setTitle("Engine Settings");
        LinearLayout l = new LinearLayout(a); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(24, 16, 24, 16);
        addToggle(a, l, "Bloom", sys.postFX.bloom, (v, c) -> sys.postFX.setBloom(c));
        addToggle(a, l, "Tone Mapping", sys.postFX.tone, (v, c) -> sys.postFX.setTone(c));
        addToggle(a, l, "FXAA", sys.postFX.fxaa, (v, c) -> sys.postFX.setFXAA(c));
        addToggle(a, l, "Vignette", sys.postFX.vignette, (v, c) -> sys.postFX.setVignette(c));
        Button gitInit = new Button(a); gitInit.setText("Git Init"); gitInit.setOnClickListener(v -> { sys.git.init(); Toast.makeText(a, "Git repo initialized", Toast.LENGTH_SHORT).show(); }); l.addView(gitInit);
        Button gitCommit = new Button(a); gitCommit.setText("Git Commit"); gitCommit.setOnClickListener(v -> { sys.git.commit("Auto-save", "user"); Toast.makeText(a, "Committed", Toast.LENGTH_SHORT).show(); }); l.addView(gitCommit);
        b.setView(l); b.setPositiveButton("Close", null); b.show();
    }

    // ============ GIT HISTORY ============
    public static void git(AppCompatActivity a, SYSTEMS sys) {
        AlertDialog.Builder b = new AlertDialog.Builder(a); b.setTitle("Git History");
        TextView tv = new TextView(a); StringBuilder sb = new StringBuilder();
        for(SYSTEMS.Git.Commit c : sys.git.log()) sb.append(c.h).append(" ").append(c.m).append("\n");
        tv.setText(sb.toString()); tv.setPadding(16, 16, 16, 16); b.setView(tv); b.show();
    }

    // ============ PACKAGES ============
    public static void packages(AppCompatActivity a, SYSTEMS sys) {
        AlertDialog.Builder b = new AlertDialog.Builder(a); b.setTitle("Packages");
        ArrayList<SYSTEMS.Packages.Pkg> r = sys.pkg.registry();
        String[] n = new String[r.size()]; boolean[] c = new boolean[r.size()];
        for(int i = 0; i < r.size(); i++) { n[i] = r.get(i).n + " v" + r.get(i).v; c[i] = sys.pkg.isInstalled(r.get(i).n); }
        b.setMultiChoiceItems(n, c, (d, w, ch) -> { if(ch) sys.pkg.install(r.get(w).n); else sys.pkg.uninstall(r.get(w).n); });
        b.setPositiveButton("Done", null); b.show();
    }

    // ============ CONSOLE ============
    public static void console(AppCompatActivity a, KERNEL k) {
        AlertDialog.Builder b = new AlertDialog.Builder(a); b.setTitle("Engine Console");
        TextView tv = new TextView(a); tv.setText(KERNEL.LOG.get()); tv.setTextColor(0xFF4DB6AC); tv.setBackgroundColor(0xFF0A0A0A); tv.setPadding(16, 16, 16, 16); tv.setTextSize(10);
        b.setView(tv); b.setPositiveButton("Clear", (d, w) -> KERNEL.LOG.clear()); b.show();
    }

    // ============ PROFILER ============
    public static void profiler(AppCompatActivity a, KERNEL k) {
        AlertDialog.Builder b = new AlertDialog.Builder(a); b.setTitle("Profiler");
        b.setMessage("FPS: " + k.profiler.fps() + "\nMemory: " + k.freeMemMB() + "MB free"); b.show();
    }

    // ============ SCRIPT DIALOG ============
    public static void script(AppCompatActivity a, SYSTEMS sys) {
        AlertDialog.Builder b = new AlertDialog.Builder(a); b.setTitle("Run Script");
        EditText et = new EditText(a); et.setHint("console.log('Hello');"); b.setView(et);
        b.setPositiveButton("Run JS", (d, w) -> sys.script.run(et.getText().toString(), "js"));
        b.setNeutralButton("Run Python", (d, w) -> sys.script.run(et.getText().toString(), "py"));
        b.setNegativeButton("Run Lua", (d, w) -> sys.script.run(et.getText().toString(), "lua"));
        b.show();
    }

    // ============ ABOUT ============
    public static void about(AppCompatActivity a) {
        AlertDialog.Builder b = new AlertDialog.Builder(a); b.setTitle("WASM Engine OS v8.0-ULTIMATE");
        b.setMessage("Unified Graphics Engine OS\n\nTechnologies:\n• OpenGL ES 2.0 / WebGL / Canvas 2D\n• Physics: Rigidbody, AABB, Spatial Hash\n• Audio: Real-time Synthesis, Mixer\n• Script: JS, Python, Lua, C, C++, Rust\n• Build: APK, AAB, Web, Desktop\n• Export: GLB, GLTF, OBJ, FBX, JSON, HTML5\n• AI: A*, Behavior Trees, FSM, GOAP\n• Procedural: Noise, L-System, Dungeon\n• PostFX: Bloom, Tone Mapping, FXAA, Vignette\n• Versioning: Git-like commit graph\n• Security: SHA-256, Sandboxing\n• Templates: 10 game genres\n\nOptimized for Itel A70\nAlgorithmic Core: v8.0");
        b.show();
    }

    private static void addToggle(AppCompatActivity a, LinearLayout p, String l, boolean d, CompoundButton.OnCheckedChangeListener cb) {
        CheckBox c = new CheckBox(a); c.setText(l); c.setChecked(d); c.setOnCheckedChangeListener(cb); p.addView(c);
    }
}
