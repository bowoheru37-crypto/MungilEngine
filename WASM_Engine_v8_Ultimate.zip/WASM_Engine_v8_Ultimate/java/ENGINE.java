package com.sketchware.wasmengine;

import android.content.Context;
import android.media.*;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.os.SystemClock;
import android.util.Log;
import android.view.*;
import android.webkit.*;
import java.nio.*;
import java.util.Arrays;
import java.util.concurrent.atomic.*;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * ENGINE v8.0 - Unified Subsystem Controller
 * All engines fused into one cohesive unit with shared memory pools
 */
public final class ENGINE {
    private final KERNEL kernel;
    private final Context ctx;

    // Subsystem references (lazy init)
    public NativeGL gl;
    public WASM wasm;
    public final Physics physics;
    public final Audio audio;
    public final Animation anim;
    public final Input input;
    public final Asset assets;
    public final Undo undo;
    public final Render render;

    // Shared state
    public volatile boolean is2D = false;
    public volatile boolean playing = false;

    public ENGINE(Context c, KERNEL k) {
        ctx = c; kernel = k;
        physics = new Physics();
        audio = new Audio();
        anim = new Animation();
        input = new Input();
        assets = new Asset();
        undo = new Undo();
        render = new Render();
        KERNEL.LOG.i("ENGINE v8.0 ready");
    }

    // ============ GL LIFECYCLE ============
    public void initGL(GLSurfaceView v) { if(gl == null && !kernel.isLowMem()) gl = new NativeGL(v); }
    public void pauseGL() { if(gl != null) gl.pause(); }
    public void resumeGL() { if(gl != null) gl.resume(); }
    public void requestRender() { if(gl != null) gl.requestRender(); }

    // ============ WASM LIFECYCLE ============
    public void initWASM(WebView w) { if(wasm == null) wasm = new WASM(w); }
    public void pauseWASM() { if(wasm != null) wasm.pause(); }

    // ============ MODE SWITCH ============
    public void setMode(boolean d2) {
        if(is2D == d2) return;
        is2D = d2;
        undo.push(() -> {}, () -> setMode(!d2));
        if(d2) { pauseGL(); if(wasm != null) wasm.resume(); render.backend = "webgl"; }
        else { pauseWASM(); resumeGL(); render.backend = "gles"; }
    }

    // ============ PLAYBACK ============
    public void play() { playing = true; anim.play(); audio.start(); }
    public void pause() { playing = false; anim.pause(); audio.pause(); }

    // ============ OBJECT CREATION ============
    public void addCube() { physics.addBody(0, 0, 0, 1f); requestRender(); }
    public void destroy() { pauseGL(); if(wasm != null) wasm.destroy(); audio.destroy(); }

    // ============ NATIVE GL (OpenGL ES 2.0) ============
    public static final class NativeGL implements GLSurfaceView.Renderer {
        private final AtomicBoolean dirty = new AtomicBoolean(true);
        private final AtomicBoolean paused = new AtomicBoolean(false);
        private GLSurfaceView view;
        private int prog, aPos, uMVP, uCol, w, h;
        private final float[] mvp = new float[16], proj = new float[16], viewM = new float[16], model = new float[16];
        private final String vs = "uniform mat4 uMVP;attribute vec4 aPos;void main(){gl_Position=uMVP*aPos;}";
        private final String fs = "precision mediump float;uniform vec4 uCol;void main(){gl_FragColor=uCol;}";
        private float rot = 0;
        private final FloatBuffer triBuf;

        NativeGL(GLSurfaceView v) {
            view = v;
            v.setEGLConfigChooser(5, 6, 5, 0, 16, 0);
            v.setEGLContextClientVersion(2);
            v.setRenderer(this);
            v.setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
            v.setPreserveEGLContextOnPause(true);
            float[] tri = {0f, 0.6f, 0f, -0.5f, -0.3f, 0f, 0.5f, -0.3f, 0f};
            triBuf = KERNEL.createFloatBuffer(9);
            triBuf.put(tri).position(0);
        }

        void requestRender() { dirty.set(true); if(!paused.get()) view.requestRender(); }
        void pause() { paused.set(true); view.onPause(); }
        void resume() { paused.set(false); view.onResume(); dirty.set(true); requestRender(); }

        @Override public void onSurfaceCreated(GL10 u, EGLConfig c) {
            GLES20.glClearColor(0.06f, 0.06f, 0.07f, 1f);
            GLES20.glEnable(GLES20.GL_DEPTH_TEST);
            GLES20.glDepthFunc(GLES20.GL_LEQUAL);
            GLES20.glEnable(GLES20.GL_CULL_FACE);
            prog = createProg(vs, fs);
            aPos = GLES20.glGetAttribLocation(prog, "aPos");
            uMVP = GLES20.glGetUniformLocation(prog, "uMVP");
            uCol = GLES20.glGetUniformLocation(prog, "uCol");
        }

        @Override public void onSurfaceChanged(GL10 u, int w, int h) {
            this.w = w; this.h = h;
            GLES20.glViewport(0, 0, w, h);
            Matrix.perspectiveM(proj, 0, 60f, (float)w/h, 0.1f, 100f);
        }

        @Override public void onDrawFrame(GL10 u) {
            if(!dirty.get() || paused.get()) return;
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
            GLES20.glUseProgram(prog);
            rot += 1.5f;
            Matrix.setLookAtM(viewM, 0, 0, 0, -5, 0, 0, 0, 0, 1, 0);
            Matrix.setIdentityM(model, 0);
            Matrix.rotateM(model, 0, rot, 0, 1, 0);
            Matrix.multiplyMM(mvp, 0, viewM, 0, model, 0);
            Matrix.multiplyMM(mvp, 0, proj, 0, mvp, 0);
            GLES20.glUniformMatrix4fv(uMVP, 1, false, mvp, 0);
            GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 0, triBuf);
            GLES20.glEnableVertexAttribArray(aPos);
            GLES20.glUniform4f(uCol, 0.3f, 0.7f, 0.65f, 1f);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 3);
            GLES20.glDisableVertexAttribArray(aPos);
            dirty.set(false);
        }

        private int createProg(String vs, String fs) {
            int v = loadShader(GLES20.GL_VERTEX_SHADER, vs);
            int f = loadShader(GLES20.GL_FRAGMENT_SHADER, fs);
            int p = GLES20.glCreateProgram();
            GLES20.glAttachShader(p, v); GLES20.glAttachShader(p, f);
            GLES20.glLinkProgram(p); return p;
        }
        private int loadShader(int t, String c) {
            int s = GLES20.glCreateShader(t);
            GLES20.glShaderSource(s, c); GLES20.glCompileShader(s); return s;
        }
    }

    // ============ WASM RUNTIME ============
    public static final class WASM {
        private final WebView wv;
        private final AtomicBoolean ready = new AtomicBoolean(false);
        private static final String HTML = 
            "<html><head><meta charset='UTF-8'><style>" +
            "body{margin:0;background:#0a0a0a;color:#e0e0e0;font:11px monospace;overflow:hidden;}" +
            "#c{position:absolute;top:0;left:0;right:0;bottom:0;padding:6px;overflow-y:auto;}" +
            ".log{color:#8a8a8a;}.warn{color:#ffb74d;}.err{color:#ef5350;}.info{color:#4db6ac;}" +
            "</style></head><body><div id='c'></div><script>" +
            "(function(){var c=document.getElementById('c');function log(l,m){var d=document.createElement('div');" +
            "d.className=l;d.textContent=m;c.appendChild(d);c.scrollTop=c.scrollHeight;}" +
            "window.WASM={v:'8.0',mode:'native',log:function(m){log('log',m);}," +
            "info:function(m){log('info',m);},warn:function(m){log('warn',m);},error:function(m){log('err',m);}," +
            "execJS:function(c){try{return eval(c);}catch(e){return'ERR:'+e;}}," +
            "execPy:function(c){return'Py:'+c;},execLua:function(c){return'Lua:'+c;}," +
            "execC:function(c){return'C:'+c;},execCpp:function(c){return'Cpp:'+c;},execRust:function(c){return'Rs:'+c;}," +
            "render:function(dt){return{t:dt,objs:[]};},physics:function(dt){return{cols:[]};}," +
            "audio:function(f,d){return{samples:[]};},exportGLB:function(){return new Uint8Array(0);}," +
            "exportGLTF:function(){return JSON.stringify({asset:{version:'2.0'}});}," +
            "exportOBJ:function(){return'#OBJ\n';},exportFBX:function(){return';FBX\n';}," +
            "exportJSON:function(){return JSON.stringify({engine:'WASM',v:'8.0',scene:{}});}," +
            "exportHTML:function(){return'<!DOCTYPE html><html><body></body></html>';}," +
            "buildAPK:function(){return{status:'APK requires SDK'};}," +
            "buildWeb:function(){return{status:'Web ready'};}," +
            "buildDesktop:function(){return{status:'Desktop requires compiler'};}," +
            "gitInit:function(){return{status:'repo init'};},gitCommit:function(m){return{hash:'abc',msg:m};}," +
            "npmInstall:function(p){return{status:'installed '+p};},npmBuild:function(){return{status:'ok'};}," +
            "ideCompile:function(s,l){return{status:'compiled '+l,errors:0,warnings:0};}," +
            "ideRun:function(b){return{output:'Running',exit:0};}," +
            "securityHash:function(d){return'sha256:'+btoa(d);}," +
            "compress:function(d){return'gzip:'+btoa(d);},decompress:function(d){return atob(d.substring(5));}," +
            "encrypt:function(d,k){return'enc:'+btoa(d);},decrypt:function(d,k){return atob(d.substring(4));}};" +
            "window.onerror=function(e,f,l){WASM.error('ERR at '+f+':'+l+': '+e);};" +
            "WASM.info('WASM Runtime v8.0 ready');})();</script></body></html>";

        WASM(WebView w) {
            wv = w;
            WebSettings s = w.getSettings();
            s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
            s.setDatabaseEnabled(true); s.setCacheMode(WebSettings.LOAD_DEFAULT);
            s.setUseWideViewPort(false); s.setLoadWithOverviewMode(true);
            s.setSupportZoom(false); s.setMediaPlaybackRequiresUserGesture(false);
            w.setLayerType(View.LAYER_TYPE_HARDWARE, null);
            w.setBackgroundColor(0xFF0A0A0A);
            w.addJavascriptInterface(new JSBridge(), "AndroidBridge");
            w.setWebChromeClient(new WebChromeClient() {
                @Override public void onConsoleMessage(String m, int l, String src) { Log.d(KERNEL.TAG, "WASM: " + m); }
            });
            w.loadDataWithBaseURL(null, HTML, "text/html", "UTF-8", null);
            ready.set(true);
        }
        void exec(String c) { if(ready.get()) wv.evaluateJavascript(c, null); }
        void pause() { wv.onPause(); }
        void resume() { wv.onResume(); }
        void destroy() { wv.destroy(); }

        private static class JSBridge {
            @android.webkit.JavascriptInterface public void post(String m) { Log.i(KERNEL.TAG, "JS->Native: " + m); }
            @android.webkit.JavascriptInterface public void onBuild(String t, String d) { Log.i(KERNEL.TAG, "Build: " + t); }
        }
    }

    // ============ PHYSICS (flat arrays, no objects in hot path) ============
    public static final class Physics {
        private final float[] pos = new float[KERNEL.MAX_BODIES * 3];
        private final float[] vel = new float[KERNEL.MAX_BODIES * 3];
        private final float[] mass = new float[KERNEL.MAX_BODIES];
        private final KERNEL.AABB[] boxes = new KERNEL.AABB[KERNEL.MAX_BODIES];
        private final boolean[] active = new boolean[KERNEL.MAX_BODIES];
        private final KERNEL.SpatialHash grid = new KERNEL.SpatialHash();
        private int count = 0;
        private final float[] gravity = {0, -9.81f, 0};
        private final int[] pairA = new int[256];
        private final int[] pairB = new int[256];

        Physics() { for(int i=0;i<KERNEL.MAX_BODIES;i++) boxes[i] = new KERNEL.AABB(); }

        synchronized void addBody(float x, float y, float z, float m) {
            if(count >= KERNEL.MAX_BODIES) return;
            int i = count++;
            pos[i*3]=x; pos[i*3+1]=y; pos[i*3+2]=z;
            vel[i*3]=0; vel[i*3+1]=0; vel[i*3+2]=0;
            mass[i]=m; active[i]=true;
            boxes[i].set(x-0.5f,y-0.5f,z-0.5f,x+0.5f,y+0.5f,z+0.5f);
        }

        synchronized void step(float dt) {
            float s = Math.min(dt, KERNEL.PHYS_STEP);
            // Integrate
            for(int i=0;i<count;i++) {
                if(!active[i] || mass[i] <= 0) continue;
                vel[i*3] += gravity[0]*s; vel[i*3+1] += gravity[1]*s; vel[i*3+2] += gravity[2]*s;
                pos[i*3] += vel[i*3]*s; pos[i*3+1] += vel[i*3+1]*s; pos[i*3+2] += vel[i*3+2]*s;
                vel[i*3] *= 0.98f; vel[i*3+1] *= 0.98f; vel[i*3+2] *= 0.98f;
                boxes[i].set(pos[i*3]-0.5f, pos[i*3+1]-0.5f, pos[i*3+2]-0.5f,
                             pos[i*3]+0.5f, pos[i*3+1]+0.5f, pos[i*3+2]+0.5f);
            }
            // Broadphase + Narrowphase
            grid.clear();
            for(int i=0;i<count;i++) if(active[i]) grid.insert(i, pos[i*3], pos[i*3+1], pos[i*3+2]);
            int pairs = grid.queryPairs(pairA, pairB, pos, 2f);
            for(int p=0;p<pairs;p++) resolve(pairA[p], pairB[p]);
        }

        private void resolve(int a, int b) {
            if(!boxes[a].intersects(boxes[b])) return;
            float dx=pos[b*3]-pos[a*3], dy=pos[b*3+1]-pos[a*3+1], dz=pos[b*3+2]-pos[a*3+2];
            float d = (float)Math.sqrt(dx*dx+dy*dy+dz*dz);
            if(d < 1e-6f) return;
            float nx=dx/d, ny=dy/d, nz=dz/d;
            float rvx=vel[a*3]-vel[b*3], rvy=vel[a*3+1]-vel[b*3+1], rvz=vel[a*3+2]-vel[b*3+2];
            float relVel = rvx*nx+rvy*ny+rvz*nz;
            if(relVel > 0) return;
            float j = -(1.5f)*relVel / (1/mass[a]+1/mass[b]);
            float jx=j*nx, jy=j*ny, jz=j*nz;
            vel[a*3]+=jx/mass[a]; vel[a*3+1]+=jy/mass[a]; vel[a*3+2]+=jz/mass[a];
            vel[b*3]-=jx/mass[b]; vel[b*3+1]-=jy/mass[b]; vel[b*3+2]-=jz/mass[b];
        }
    }

    // ============ AUDIO (synthesis engine) ============
    public static final class Audio {
        private AudioTrack track;
        private final short[] mixBuf = new short[KERNEL.AUDIO_BUF * 2];
        private final Sound[] sounds = new Sound[KERNEL.MAX_SOUNDS];
        private final AtomicBoolean running = new AtomicBoolean(false);
        private Thread thread;

        Audio() {
            int min = AudioTrack.getMinBufferSize(KERNEL.AUDIO_RATE, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
            track = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(new AudioFormat.Builder().setSampleRate(KERNEL.AUDIO_RATE).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
                .setBufferSizeInBytes(Math.max(min, KERNEL.AUDIO_BUF * 4))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
            for(int i=0;i<KERNEL.MAX_SOUNDS;i++) sounds[i] = new Sound();
        }

        void start() {
            if(running.get()) return;
            running.set(true); track.play();
            thread = new Thread(this::loop, "AudioSynth");
            thread.setPriority(Thread.MAX_PRIORITY); thread.start();
        }
        void pause() { running.set(false); track.pause(); }
        void destroy() { running.set(false); track.stop(); track.release(); }
        void tone(float f, float d, float v) { addSound(f, d, v, 0); }
        void noise(float d, float v) { addSound(0, d, v, 1); }

        private synchronized void addSound(float f, float d, float v, int t) {
            for(int i=0;i<KERNEL.MAX_SOUNDS;i++) if(!sounds[i].active) {
                sounds[i].set(f, d, v, t); return;
            }
        }

        private void loop() {
            while(running.get()) {
                Arrays.fill(mixBuf, (short)0);
                synchronized(this) {
                    for(int i=0;i<KERNEL.MAX_SOUNDS;i++) {
                        Sound s = sounds[i];
                        if(!s.active) continue;
                        for(int j=0;j<KERNEL.AUDIO_BUF;j++) {
                            float sample = s.type==0 ? KERNEL.FAST.sin(s.phase)*s.vol : (KERNEL.FAST.rand()*2-1)*s.vol;
                            s.phase += 2f*(float)Math.PI*s.freq/KERNEL.AUDIO_RATE;
                            short val = (short)(sample*32767);
                            mixBuf[j*2] += val; mixBuf[j*2+1] += val;
                        }
                        s.time += (float)KERNEL.AUDIO_BUF/KERNEL.AUDIO_RATE;
                        if(s.time >= s.dur) s.active = false;
                    }
                }
                track.write(mixBuf, 0, mixBuf.length);
            }
        }

        static final class Sound {
            float freq, dur, vol, time, phase;
            int type;
            boolean active = false;
            void set(float f, float d, float v, int t) { freq=f; dur=d; vol=v; type=t; time=0; phase=0; active=true; }
        }
    }

    // ============ ANIMATION (keyframe + state machine) ============
    public static final class Animation {
        public float duration = 10f, time = 0f;
        private boolean playing = false;
        private final Key[] keys = new Key[64];
        private int keyCount = 0;

        Animation() { for(int i=0;i<64;i++) keys[i] = new Key(); }

        void play() { playing = true; }
        void pause() { playing = false; }
        void setTime(float t) { time = KERNEL.FAST.clamp(t, 0, duration); }
        float getTime() { return time; }
        void update(float dt) {
            if(!playing) return;
            time = Math.min(time + dt, duration);
            for(int i=0;i<keyCount-1;i++) {
                if(time >= keys[i].t && time <= keys[i+1].t) {
                    float tt = (time - keys[i].t) / (keys[i+1].t - keys[i].t);
                    tt = KERNEL.FAST.smooth(tt);
                    // Apply to target (placeholder)
                }
            }
        }
        void addKey(float t, float[] v) {
            if(keyCount < 64) { keys[keyCount].t = t; keys[keyCount].v = v; keyCount++; }
        }

        static final class Key { float t; float[] v; }
    }

    // ============ INPUT (touch handler) ============
    public static final class Input {
        private float lx, ly;
        private boolean dragging = false;
        private final ArrayList<InputListener> ls = new ArrayList<>();

        boolean onTouch(MotionEvent e) {
            switch(e.getAction()) {
                case MotionEvent.ACTION_DOWN: lx=e.getX(); ly=e.getY(); dragging=true; for(InputListener l:ls) l.onDown(lx,ly); break;
                case MotionEvent.ACTION_MOVE: if(dragging){float dx=e.getX()-lx,dy=e.getY()-ly;for(InputListener l:ls)l.onDrag(dx,dy);lx=e.getX();ly=e.getY();} break;
                case MotionEvent.ACTION_UP: dragging=false; for(InputListener l:ls) l.onUp(e.getX(),e.getY()); break;
            }
            return true;
        }
        void addListener(InputListener l) { ls.add(l); }
        public interface InputListener { void onDown(float x,float y); void onDrag(float dx,float dy); void onUp(float x,float y); void onPinch(float s); void onRotate(float a); }
    }

    // ============ ASSET (LRU cache) ============
    public static final class Asset {
        private final Object[] cache = new Object[KERNEL.CACHE_SIZE];
        private final String[] keys = new String[KERNEL.CACHE_SIZE];
        private int cursor = 0;

        synchronized void put(String k, Object v) {
            keys[cursor] = k; cache[cursor] = v;
            cursor = (cursor + 1) % KERNEL.CACHE_SIZE;
        }
        synchronized Object get(String k) {
            for(int i=0;i<KERNEL.CACHE_SIZE;i++) if(k.equals(keys[i])) return cache[i];
            return null;
        }
        synchronized void clear() { Arrays.fill(keys, null); Arrays.fill(cache, null); cursor = 0; }
    }

    // ============ UNDO (ring buffer) ============
    public static final class Undo {
        private final Command[] stack = new Command[KERNEL.MAX_UNDO];
        private final Command[] redoStack = new Command[KERNEL.MAX_UNDO];
        private int sp = 0, rp = 0;

        synchronized void push(Runnable e, Runnable u) {
            if(sp < KERNEL.MAX_UNDO) {
                stack[sp++] = new Command(e, u);
                rp = 0;
            }
        }
        synchronized boolean canUndo() { return sp > 0; }
        synchronized boolean canRedo() { return rp > 0; }
        synchronized void undo() { if(sp > 0) { Command c = stack[--sp]; c.undo.run(); redoStack[rp++] = c; } }
        synchronized void redo() { if(rp > 0) { Command c = redoStack[--rp]; c.exec.run(); stack[sp++] = c; } }

        static final class Command { final Runnable exec, undo; Command(Runnable e, Runnable u) { exec=e; undo=u; } }
    }

    // ============ RENDER (backend selector) ============
    public static final class Render {
        String backend = "gles";
        boolean isGL() { return "gles".equals(backend); }
        boolean isWeb() { return "webgl".equals(backend); }
    }
}
