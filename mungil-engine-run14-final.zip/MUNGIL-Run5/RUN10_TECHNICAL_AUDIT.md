# MUNGIL Run 10 — Technical Audit

## Architecture
Keep one versioned renderer-neutral project document and one bounded runtime. Scene editor commands operate through `ProjectHistory`; renderers remain adapters. Agent knowledge is a separate bounded data store and must never be treated as executable policy or trusted instructions.

## Correctness and security decisions
- Batch scene operations are validated in a shadow history before committing.
- Project hierarchy and JSON payload validation remain authoritative.
- Agent knowledge rejects accessors, exotic prototypes, invalid URLs, duplicate snapshot IDs and oversized snapshots.
- Retrieved knowledge is displayed as source-backed data; it is not injected as executable instructions.
- WebView local assets now use AndroidX WebViewAssetLoader on the reserved appassets origin. File and content access are disabled.
- External navigation is allow-routed to the system browser; no arbitrary JavaScript interface is exposed.

## Known residual risks
- `ProjectHistory` uses bounded full-document snapshots rather than compact deltas; at the 2 MiB document ceiling, history memory can still be several MiB. Future work should use validated inverse command records for large documents.
- Scene editor operations are renderer-neutral. Inspector changes do not yet update the visible preview scene in real time.
- Duplicate-subtree generation relies on caller-supplied ID creation; callers must provide collision-free IDs. Collisions are rejected.
- Knowledge search is lexical/tag-based, not vector retrieval. Knowledge persistence in Studio uses localStorage and can be cleared by browser/OS storage policies.
- Knowledge entries are seeded from a small curated set; the system does not autonomously crawl sources or verify that external pages remain current.
- AndroidX WebKit 1.14.0 is used for API21 compatibility. Do not upgrade to 1.15+ without changing minSdk strategy; release notes state later versions raise minimum API levels.
- The Android project has not been compiled in this environment. Java, Gradle, lint, signing, API21 compatibility, WebView behavior, and itel A70 performance remain unverified.

## Low-end policy
Keep generation sequential at Tier 0, cap scene node count and history, use lazy assets, use Canvas2D fallback for 2D, and keep WebGL2 optional. Do not equate extended RAM with physical RAM. No performance numbers are claimed without on-device measurement.

## Build status
No APK/AAB exists. The release script stopped at the missing Android SDK Platform 36 prerequisite. This is an environment block, not a successful build or a source compile result.
