# MUNGIL Run 14 — Final Validation Report

## Verified in this environment

| Validation | Status | Detail |
|---|---|---|
| Runtime test suite | PASS | 84 tests; 84 passed; 0 failed; 0 skipped |
| Strict TypeScript runtime entry | PASS | `tsc --noEmit --target ES2022 --module ESNext --moduleResolution bundler --lib ES2022,DOM --strict --skipLibCheck --allowImportingTsExtensions src/game/runtime/index.ts` |
| Browser bundle build | PASS | 28 modules, 220,533 bytes |
| Browser runtime smoke | PASS | Runtime API, generator, sprite atlas, animation, particles, audio, glTF preflight, HTML5 export and world-scale math |
| Standalone Studio inline script syntax | PASS | Extracted inline scripts passed Node `--check` |
| Android release script syntax | PASS | `bash -n android/build-android-release.sh` |
| ZIP integrity | PASS | Engine, runtime, PWA, Android scaffold archives |
| Studio source synchronization | PASS | Standalone Studio equals PWA `platform/index.html` and Android `assets/studio.html` |

## Not verified / blocked

- Native APK/AAB build: blocked immediately because Android SDK Platform 36 is not installed/configured (`ANDROID_HOME` / `ANDROID_SDK_ROOT`).
- Android Build Tools 36.0.0, Gradle 8.13 or wrapper executable, and `JAVA_HOME` still need to be supplied. Java 21 exists but `JAVA_HOME` is unset; the Gradle CLI and `gradlew` are not present.
- Local release signing keystore and its environment variables must be configured by the developer; do not place secrets in the repository.
- Browser-level IndexedDB persistence, actual sprite atlas button clicks, real image decoder pressure, visual layout, and touch behavior were not tested in an automated browser.
- No physical Android 5 or itel A70 install/performance/thermal test has been carried out.
- No full application build/test or complete website E2E pass is claimed; the verified TypeScript and tests are scoped to the game runtime.

## Source checksum

Standalone Studio SHA-256: `903220f154ca0779526551e2f2a0fbf0d70229de48c4d5d2b75a31c9203d0fcf`.

Package archives are integrity-checked during creation; current downloads are supplied separately with the final response.
