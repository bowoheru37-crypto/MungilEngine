# MUNGIL Run 13 — Bounded Image Preview & Sprite Asset Binding

## Implemented
- Added `fitImagePreview()` to calculate aspect-ratio-preserving preview dimensions under dimension and decoded-pixel ceilings. Source pixel and output RGBA byte arithmetic are checked for safe integers.
- Added tests for aspect ratio, pixel budget, invalid/unsafe dimensions and multiplication overflow.
- Added an image/texture asset selector to Sprite Inspector, populated from the offline Asset Vault.
- Assigned `assetId` is stored in the existing project node properties and therefore participates in project history/save.
- Added a sequential, single-selected-image preview loader. It prefers `createImageBitmap` with downscaling; older WebViews fall back to a temporary HTMLImageElement drawn into a bounded 384px canvas.
- Image preview uses the existing Canvas2D renderer fallback only when an image is assigned; it does not replace the WebGL2 renderer for normal preview.
- Added one-image ownership lifecycle: stale async loads are ignored, ImageBitmap is closed, object URLs are revoked, and the active image is released on pagehide or asset deselection.
- Asset Vault cards show at most six lazy thumbnails to bound concurrent decode and DOM memory.
- Android WebView Studio asset is synchronized from the same standalone Studio source.

## Validation
- Runtime tests: 69/69 passed across `src/game/runtime/*.test.ts`.
- TypeScript strict runtime index check passed.
- Browser runtime bundle build and smoke test passed.
- Standalone Studio inline scripts passed Node syntax checks.
- All four Run 13 ZIP archives passed integrity checks.

## Boundaries
- This increment previews one selected image asset at a time; it is not a full multi-sprite scene renderer or texture atlas.
- WebGL2 textured sprite batching is not implemented here. Assigning an image switches the Studio preview to Canvas2D; the underlying WebGL2 runtime renderer remains available for geometry.
- Audio, video and glTF model files remain stored/metadata-only; no decoder or renderer binding is claimed for those types.
- No Khronos glTF Validator CI integration, playable project export, remote LLM provider, cloud asset sync, Android build, APK/AAB signing or physical itel A70 test is included.
