# MUNGIL Run 13 — Reference Research

## Image decoding and lifecycle
- MDN `createImageBitmap()`: https://developer.mozilla.org/en-US/docs/Web/API/Window/createImageBitmap — supports decoding Blob/ImageData sources and resize options in compatible browsers. Feature-detect; keep a fallback for older WebViews.
- MDN `ImageBitmap.close()`: https://developer.mozilla.org/en-US/docs/Web/API/ImageBitmap/close — releases associated graphical resources. Close decoded bitmaps when replacing or disposing preview assets.
- MDN `URL.revokeObjectURL()`: https://developer.mozilla.org/en-US/docs/Web/API/URL/revokeObjectURL_static — release temporary Blob URLs after image decode or failure.
- MDN Canvas `drawImage()`: https://developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D/drawImage — downsample an image into a bounded canvas for a compatibility preview.

## Existing pipeline references retained
- Khronos glTF Validator: https://github.com/KhronosGroup/glTF-Validator — CI/build-time validation; not a runtime decoder.
- Khronos KTX-Software: https://github.com/KhronosGroup/KTX-Software — evaluate pinned versions and licenses before texture transcode integration.
- Android WebView memory management: https://developer.android.com/develop/ui/views/layout/webapps/manage-webview-memory — account for native and renderer process memory in addition to JS heap.

References are design guidance; no external package was added in Run 13.
