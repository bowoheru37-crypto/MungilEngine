# MUNGIL Run 12 — Reference Research

## Browser storage and offline assets
- MDN Storage quotas and eviction: https://developer.mozilla.org/en-US/docs/Web/API/Storage_API/Storage_quotas_and_eviction_criteria
  - IndexedDB and Cache are best-effort by default; browser quota is implementation/device-dependent. `navigator.storage.persist()` is the explicit opt-in path where supported.
- MDN Storage API: https://developer.mozilla.org/en-US/docs/Web/API/Storage_API
  - `navigator.storage.estimate()` returns estimated usage and quota, not a reservation. The implementation must still catch quota errors during writes.
- MDN IndexedDB API: https://developer.mozilla.org/en-US/docs/Web/API/IndexedDB_API
  - IndexedDB is suitable for structured metadata and binary blobs; transactions should remain short and errors must be handled.

## glTF validation
- Khronos glTF-Validator: https://github.com/KhronosGroup/glTF-Validator
  - Validates glTF 2.0 JSON/GLB, schema constraints, internal references, binary buffers/accessors, animations, images and supported extensions. Run in CI/build pipeline rather than on the low-memory runtime hot path.
- Khronos glTF ecosystem: https://github.com/KhronosGroup/glTF
  - Provides the specification, sample assets, test generators and viewer resources useful for importer QA.

## Android Go and WebView
- Android Developers — Develop for Android Go: https://developer.android.com/guide/topics/androidgo/develop
  - Detect low-RAM device class and adapt functionality/resource usage instead of assuming all Android devices have equivalent capacity.
- Android Developers — Manage and diagnose WebView memory: https://developer.android.com/develop/ui/views/layout/webapps/manage-webview-memory
  - WebView has multi-process/native memory considerations; unmanaged WebView lifecycles can cause memory leaks, OOM and degraded performance.
- Android Developers — Improve app performance: https://developer.android.com/topic/performance/improving-overview
  - Treat low-RAM testing as a first-class performance target and profile startup, rendering, memory, battery and app size.

## GitHub repositories to evaluate as clean-room references
- https://github.com/KhronosGroup/glTF-Validator — authoritative validation reference; Apache-2.0.
- https://github.com/KhronosGroup/KTX-Software — KTX/KTX2 tooling; inspect current release/license before build integration.
- https://github.com/phaserjs/phaser — HTML5 2D game framework patterns; evaluate package footprint and license before adoption.
- https://github.com/pixijs/pixijs — 2D rendering architecture; evaluate modules individually and avoid bundling unused renderer paths.
- https://github.com/mrdoob/three.js — browser 3D renderer and asset lifecycle patterns; not a complete game engine and not a low-end default.

These repositories are references, not copied source. No dependency was added from this list in Run 12. Any adoption requires version pinning, license review, Android/WebView compatibility checks and measured bundle/runtime cost.
