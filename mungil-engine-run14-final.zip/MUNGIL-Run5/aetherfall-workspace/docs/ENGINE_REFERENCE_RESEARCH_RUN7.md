# MUNGIL Engine — Research expansion (Run 7)

Snapshot: 2026-11-26. This document adds references to the Run 5/6 catalog. The references are candidates and design studies, not merged dependencies. Repository README excerpts were inspected through the connected GitHub source for the entries explicitly marked **README inspected**. Verify commit, license, dependency tree, maintenance and target-browser behavior before adoption.

## New references

### Lightweight Canvas2D / 2D architecture

| Project | What to study | Caveat / recommended use |
|---|---|---|
| [Litecanvas](https://github.com/litecanvas/game-engine) — README inspected, blob `b746cf2267edc3cfbd99424a6ad52ee47dc256dd` | Tiny Canvas2D API, plugin approach, minimal audio and offline playground | README labels project alpha; study small API boundaries, do not depend on it as production foundation without review |
| [Hex Engine](https://github.com/suchipi/hex-engine) — README inspected, blob `4d67cda72e76f0f2b6c27ca5eb6afbc39a8cb10d` | TypeScript ECS-like component composition, Canvas2D, inspector, asset-tool workflows | README says work in progress; useful architecture study, not a drop-in dependency |
| [hengine](https://github.com/SeunghwaCho/hengine) | Zero-dependency TypeScript Canvas2D plumbing, scene lifecycle, input, audio, persistence | Newer/smaller project; audit maturity and license before adoption |
| [Kontra](https://github.com/straker/kontra) | Modular minimal HTML5 game primitives | Good reference for tiny optional modules |
| [LittleJS](https://github.com/KilledByAPixel/LittleJS) | Hybrid Canvas2D/WebGL2 renderer, input, audio, physics and compact runtime | Strong reference for hybrid backend design; compare implementation and maintenance before porting |
| [Phaser](https://github.com/phaserjs/phaser) — README inspected, blob `15fb582058a775acce50d390dbabef4b2b5e19af` | Scene lifecycle, loader, input, camera, renderer architecture and WebGL node model | Full framework is not a default dependency; borrow isolated ideas |

### 2D / 2.5D / isometric

| Project | What to study | Caveat / recommended use |
|---|---|---|
| [Traviso.js](https://github.com/axaq/traviso.js) — README inspected, blob `eaf0cda2d8cf44e534de3bc4104f192811526eed` | Isometric world model, optimized map algorithms, camera controls and configurable data format | Its README targets Pixi 6/7; port math/data concepts rather than adding a legacy Pixi dependency |
| [html5-isometric-game-tile-engine](https://github.com/mopics/html5-isometric-game-tile-engine) | Isometric tile rendering and world interaction | Older project; use as historical algorithm reference only after source/license check |
| [IsometricMap](https://github.com/jesstelford/IsometricMap) | Isometric map coordinate conversion and tile layout | Narrow reference, not a general runtime |
| [rot.js](https://github.com/ondras/rot.js) | Roguelike map generation, FOV, scheduling and pathfinding | Optional genre toolkit; keep out of projects that do not need roguelike systems |
| [LDtk](https://github.com/deepnight/ldtk) | Data-driven level authoring and entity/layer schema | Study import format and authoring UX; do not force its schema to become the only MUNGIL scene model |
| [Tiled](https://github.com/mapeditor/tiled) | Mature tilemap authoring and interchange formats | Import/export compatibility is more valuable than embedding its editor |

### Browser editor, project data and undo/redo

| Project | What to study | Caveat / recommended use |
|---|---|---|
| [html5-game-editor](https://github.com/andvolodko/html5-game-editor) | Git-friendly JSON scenes, stable IDs, 2D/3D adapters, hierarchy/inspector, undo/redo and editor/player split | A close architectural comparator; independently verify source, license, build and current completeness before reuse |
| [o2](https://github.com/o2-engine/o2) | Scene editor, hierarchy, animation/state graphs, undo/redo, profiler, test driver | Native C++ architecture reference; do not import its native stack into the browser runtime |
| [GDevelop](https://github.com/4ian/GDevelop) | Visual event sheets, extension contracts, editor/player separation | Study workflows and event model, not the entire platform runtime |
| [PlayCanvas Engine](https://github.com/playcanvas/engine) | Component system, asset registry, runtime/editor split | 3D editor architecture reference |
| [Godot](https://github.com/godotengine/godot) | Scene/resource ownership, serialization and editor transactions | Broad reference; not a web runtime dependency |

### Rendering, browser APIs and mobile performance

| Reference | What it establishes | MUNGIL implication |
|---|---|---|
| [MDN Canvas 2D](https://developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D) | Widely available 2D drawing primitives | Use as the broad-compatibility 2D backend, while measuring actual device frame time |
| [MDN OffscreenCanvas](https://developer.mozilla.org/en-US/docs/Web/API/OffscreenCanvas) | Canvas work can be decoupled from DOM and moved to workers where supported | Optional optimization only; feature-detect and keep main-thread fallback |
| [MDN WebGL best practices](https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API/WebGL_best_practices) | GPU resource, texture format and state-management guidance | Batch, minimize texture switches, bound GPU allocations, test format extensions |
| [Android texture guidance](https://developer.android.com/games/optimize/textures) | Atlas usage reduces draw calls; texture choices affect memory/bandwidth | Prioritize atlas pipeline and device-supported compression variants |
| [Android material/shader guidance](https://developer.android.com/games/optimize/materials) | Texture sampler count and shader complexity affect bandwidth and power | Keep Tier 0 material sampler count low; prefer unlit/baked styles where appropriate |
| [Android CPU/GPU optimization](https://developer.android.com/games/optimize/optimization-tips) | Geometry, LOD, culling, texture formats and profiling are separate concerns | Profile the bottleneck before choosing a reduction technique |

## Findings from inspected source material

- Litecanvas explicitly presents itself as an alpha-stage lightweight Canvas2D engine; its tiny API is a design reference, not evidence of production readiness.
- Hex Engine's README describes a TypeScript browser 2D engine with Canvas rendering, composable ECS-like components, inspector, sprite animation, audio and Matter.js physics; its README also labels it work in progress.
- Traviso.js describes an isometric browser engine built on PixiJS and lists Pixi 6/7 compatibility; use its isometric world/data/camera concepts without binding MUNGIL to that older Pixi generation.
- Phaser's README documents Canvas and WebGL support for mobile/desktop web, a scene/loader/input/physics ecosystem, and a newer WebGL renderer architecture. Treat it as a source of patterns rather than a dependency to bundle wholesale.

## Updated MUNGIL implementation priorities

1. **P0 — renderer validation:** browser-test Canvas2D adapter on Android WebView/Chrome, add Canvas2D tilemap batching and dirty-region strategy only if measurements justify it.
2. **P0 — project/editor integration:** map the original MUNGIL editor's scene source, IDs, state mutations, undo boundaries and persistence. Integrate the versioned document through a reversible adapter; do not patch compiled/minified source blindly.
3. **P1 — WebGL2 backend:** implement minimal 2D/2.5D batching first, then a separate 3D adapter. Add GPU resource ownership and context restoration tests.
4. **P1 — asset pipeline:** import sprites/atlases/audio and glTF, validate manifests, produce target variants and preserve originals.
5. **P1 — genre modules:** tilemap/isometric, platformer kinematics, top-down, puzzle, racing pseudo-3D, visual novel, strategy and other genre kits as optional packages.
6. **P2 — legacy support:** implement WebGL1 only if target-browser measurements require it; keep Canvas2D as the fallback for 2D/retro and do not pretend it can render perspective 3D.
7. **P2 — high-end path:** WebGPU, advanced PBR, skeletal 3D, navmesh and multiplayer remain opt-in capabilities.

## Integrity and licensing

- No code from these repositories was copied into MUNGIL in Run 7.
- A README inspection is not a license audit. Check the repository `LICENSE`, assets, fonts, sample projects, codecs and transitive dependencies at the exact commit before copying or linking code.
- Keep the core runtime small. Use optional adapters and editor-only dependencies; never ship a full editor stack inside a player build by default.
