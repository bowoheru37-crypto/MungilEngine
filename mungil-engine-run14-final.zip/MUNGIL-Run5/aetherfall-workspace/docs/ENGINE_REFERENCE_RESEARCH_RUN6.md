# MUNGIL Engine — Expanded open-source reference catalog (Run 6)

Snapshot: 2026-11-25. This catalog expands Run 5's 60-reference shortlist. It is a research map, not a statement that all projects were cloned, exhaustively audited, license-cleared, benchmarked, or integrated. Before reuse: pin a commit, inspect the actual source and transitive dependencies, review the license and bundled assets, run security checks, then benchmark on target devices.

## Architecture rules

1. Keep one authoritative project format, scene graph/ECS boundary, simulation clock, asset manifest and input-action model.
2. Select a renderer per project and capability tier. Canvas2D is a first-class 2D/retro/pseudo-3D path; WebGL1 is a separate legacy adapter; WebGL2 is the main accelerated baseline; WebGPU is optional. A renderer must never silently downgrade perspective 3D to Canvas2D.
3. Do not bundle multiple complete game engines. Learn from them and port narrow ideas behind MUNGIL contracts.
4. Editor-only dependencies must not enter exported player builds. Genre-specific modules should be lazy-loaded and stripped when unused.
5. Preserve source assets and source IDs. Build derived variants rather than destructively replacing originals.
6. Profile cold start, first playable, frame-time distribution, memory, asset bytes, input latency, scene transitions, battery and thermal behavior on real devices.

## Expanded reference shortlist

### A. Runtime, rendering and engine architecture

| Project | Study target | Adoption assessment |
|---|---|---|
| [LittleJS](https://github.com/KilledByAPixel/LittleJS) | Small runtime, Canvas/WebGL split, loop, input, audio, physics | Strong compact-runtime reference; inspect renderer and lifecycle independently |
| [Phaser](https://github.com/phaserjs/phaser) | Scene lifecycle, camera, scale, loader, input, 2D physics | Strong 2D workflow reference; avoid importing the whole framework |
| [PixiJS](https://github.com/pixijs/pixijs) | Sprite batching, texture GC, renderer abstraction | Strong 2D renderer reference; profile its current renderer and module selection |
| [melonJS](https://github.com/melonjs/melonJS) | Tilemaps, isometric maps, camera and collision | Strong 2D/2.5D reference |
| [PlayCanvas Engine](https://github.com/playcanvas/engine) | Component lifecycle, asset registry, WebGL/WebGPU, editor/runtime split | Strong 3D web reference; study runtime/editor separation |
| [Babylon.js](https://github.com/BabylonJS/Babylon.js) | Scene optimizer, asset loading, material systems, WebGPU/WebGL | Broad 3D reference; only adopt narrow modules |
| [Three.js](https://github.com/mrdoob/three.js) | Scene graph, glTF, animation, GPU resource disposal | Existing Aetherfall dependency; WebGLRenderer uses WebGL2 only since r163 |
| [OGL](https://github.com/oframe/ogl) | Minimal WebGL abstraction | Candidate for separate compact 3D experiments |
| [regl](https://github.com/regl-project/regl) | Explicit WebGL command and resource model | Useful for a custom low-level renderer, not a default dependency |
| [twgl.js](https://github.com/greggman/twgl.js) | Minimal WebGL buffer/texture/uniform helpers | Useful if implementing a small WebGL1/2 adapter |
| [GDevelop](https://github.com/4ian/GDevelop) | Event sheets, behaviors, extension model, visual logic | Editor workflow reference; avoid its full runtime stack |
| [Godot](https://github.com/godotengine/godot) | Scene/resource architecture and renderer tiers | Architectural reference; Compatibility renderer is relevant for low-end/web |
| [Defold](https://github.com/defold/defold) | Small runtime philosophy, collections, atlases, lifecycle | Strong mobile runtime reference; inspect its license terms carefully |
| [Cocos Creator](https://github.com/cocos/cocos-engine) | Mobile-first 2D/3D components and asset pipeline | Candidate for workflow and mobile profiling patterns |
| [HaxeFlixel](https://github.com/HaxeFlixel/flixel) | Retro 2D camera, tilemap, animation and collision | Strong retro-game authoring reference |
| [Excalibur.js](https://github.com/excaliburjs/Excalibur) | TypeScript-first 2D actors, scenes, actions and physics | Candidate for 2D API ergonomics |
| [Kontra](https://github.com/straker/kontra) | Small modular HTML5 game framework | Useful size-conscious 2D reference |
| [Kiwi.js](https://github.com/gamelab/kiwi.js) | HTML5 game architecture and components | Historical reference; verify current maintenance before adoption |

### B. ECS, data layout and scheduling

| Project | Study target | Adoption assessment |
|---|---|---|
| [bitECS](https://github.com/NateTheGreatt/bitECS) | Typed-array ECS and query iteration | Candidate for high-entity projects; MPL-2.0 obligations need review |
| [Miniplex](https://github.com/hmans/miniplex) | Lightweight ECS and query ergonomics | Candidate where developer ergonomics matter more than maximum density |
| [ecsy](https://github.com/ecsyjs/ecsy) | Entity/component/system scheduling | Compare lifecycle and query design; verify maintenance |
| [bitecs](https://github.com/NateTheGreatt/bitECS) | Data-oriented component storage | Same upstream as bitECS; avoid duplicate listing as a dependency |
| [Bevy](https://github.com/bevyengine/bevy) | Schedule, change detection, asset server, ECS patterns | Architectural reference only; Rust/WASM stack not a default mobile-web choice |
| [Flecs](https://github.com/SanderMertens/flecs) | Archetype ECS, queries, observers | Native-side architecture reference |
| [EnTT](https://github.com/skypjack/entt) | Registry/storage and sparse-set ECS | Native-side data-layout reference |
| [Unity Entities](https://github.com/needle-mirror/com.unity.entities) | Archetype ECS and baking pipeline | Concept reference only; ecosystem/package constraints apply |

### C. Collision, physics and spatial queries

| Project | Study target | Adoption assessment |
|---|---|---|
| [Box2D](https://github.com/erincatto/box2d) | Contact lifecycle, CCD, sleeping, broadphase | Canonical 2D physics reference; native/WASM cost must be justified |
| [Planck.js](https://github.com/piqnt/planck.js) | Box2D-style 2D rigid bodies in JS | Leading optional 2D rigid-body adapter candidate |
| [Matter.js](https://github.com/liabru/matter-js) | Accessible 2D rigid body and constraints | Optional 2D physics; not needed for simple arcade kinematics |
| [p2-es](https://github.com/pmndrs/p2-es) | 2D contacts, constraints, friction and motors | Alternative 2D physics candidate; compare bundle and activity |
| [Rapier](https://github.com/dimforge/rapier) | High-performance 2D/3D physics and character controllers | Optional WASM physics; test startup, memory and browser support |
| [Jolt Physics](https://github.com/jrouwe/JoltPhysics) | High-performance 3D rigid body and character systems | Native/high-end reference; likely too heavy for base web runtime |
| [cannon-es](https://github.com/pmndrs/cannon-es) | Pure-JS 3D rigid body simulation | Candidate for small 3D physics projects |
| [ammo.js](https://github.com/kripken/ammo.js) | Bullet-to-WASM port | Legacy/compatibility reference; assess payload and maintenance |
| [dyn4j](https://github.com/dyn4j/dyn4j) | 2D collision and rigid-body design | Java/native architecture reference |
| [RBush](https://github.com/mourner/rbush) | Dynamic R-tree spatial index | Candidate for non-uniform spatial queries |
| [Flatbush](https://github.com/mourner/flatbush) | Static packed Hilbert R-tree | Strong read-mostly world/asset spatial index reference |
| [KDBush](https://github.com/mourner/kdbush) | Static point index | Useful for large static map points/POIs |

### D. Navigation, AI and behavior

| Project | Study target | Adoption assessment |
|---|---|---|
| [RecastNavigation](https://github.com/recastnavigation/recastnavigation) | Navmesh baking and Detour runtime queries | Bake offline; runtime path queries only for genres that need them |
| [PathFinding.js](https://github.com/qiao/PathFinding.js) | A*, Dijkstra, grid heuristics | Good grid-AI reference; enforce node/iteration caps |
| [Yuka](https://github.com/Mugen87/yuka) | Steering, state machines, entity management | Optional local AI reference; cap update frequency |
| [BehaviorTree.CPP](https://github.com/BehaviorTree/BehaviorTree.CPP) | Behavior tree structure and blackboard | Native reference; port concepts rather than dependency |
| [htn](https://github.com/kevinmehall/htn) | Hierarchical task planning | Candidate for strategy/simulation genres; profile branching |
| [GOAP](https://github.com/stolk/GOAP) | Goal-oriented action planning | Algorithm reference for complex NPC behavior |
| [navmesh](https://github.com/isaac-mason/navmesh) | JS navigation mesh query ideas | Candidate for browser navigation; validate current maintenance |
| [easy-star](https://github.com/prettymuchbryce/easy-star) | Grid A* with small API | Lightweight pathfinding reference |

### E. 2.5D, isometric, retro and specialized rendering

| Project | Study target | Adoption assessment |
|---|---|---|
| [javascript-racer](https://github.com/jakesgordon/javascript-racer) | Road-segment pseudo-3D projection | Math reference only; project itself warns of mobile performance concerns |
| [Pseudo-3d-Racer](https://github.com/ssusnic/Pseudo-3d-Racer) | Segment projection and clipping | Historical sample; port algorithms, not Phaser-era runtime |
| [Tiled](https://github.com/mapeditor/tiled) | Tilemap authoring and JSON/TMX interchange | Import/export reference; preserve MUNGIL editor UX |
| [LDtk](https://github.com/deepnight/ldtk) | Data-driven 2D level design and entity instances | Strong modern level-format reference |
| [rot.js](https://github.com/ondras/rot.js) | Roguelike maps, FOV, pathfinding and scheduling | Strong genre-specific toolkit reference |
| [PixiJS filters](https://github.com/pixijs/filters) | Stylized image effects | Optional, quality-tiered post effects; do not run all filters on low tier |
| [glsl-fast-gaussian-blur](https://github.com/Jam3/glsl-fast-gaussian-blur) | Efficient blur kernels | Shader reference; effect must be optional |
| [three-projected-material](https://github.com/marcofugaro/three-projected-material) | Texture projection | 3D art-style option; not baseline |
| [troika-three-text](https://github.com/protectwise/troika) | 3D text rendering | Optional UI/text reference; inspect package weight |

### F. Animation, skeletal systems and 2D rigs

| Project | Study target | Adoption assessment |
|---|---|---|
| [DragonBones](https://github.com/DragonBones/DragonBonesJS) | 2D skeletal animation and timeline | Historical reference; verify runtime compatibility and license |
| [Spine runtimes](https://github.com/EsotericSoftware/spine-runtimes) | 2D skeletal runtime architecture | Reference only; Spine editor/runtime licensing is not equivalent to open-source permissive |
| [Rive](https://github.com/rive-app/rive) | State-machine-driven vector animation | Evaluate runtime size and licensing for each target |
| [Lottie Web](https://github.com/airbnb/lottie-web) | Vector animation playback | UI/2D animation option; not a general game skeletal engine |
| [PixiJS Spine](https://github.com/pixijs/spine) | 2D skeletal integration | Optional renderer-specific adapter; licensing/version coupling matters |
| [three.js animation system](https://threejs.org/docs/#api/en/animation/AnimationMixer) | Animation clips, mixers and actions | Existing 3D path reference |
| [Ozz-animation](https://github.com/guillaumeblanc/ozz-animation) | Runtime skeletal animation data and sampling | Native reference; useful for future compact animation format design |

### G. Asset import, compression, validation and build tooling

| Project | Study target | Adoption assessment |
|---|---|---|
| [glTF Transform](https://github.com/donmccurdy/glTF-Transform) | Inspect, prune, deduplicate, quantize and compress glTF | High-priority offline build tool candidate |
| [meshoptimizer](https://github.com/zeux/meshoptimizer) | Vertex/index/meshlet optimization and compression | High-priority offline optimizer; runtime decoder must be budgeted |
| [Draco](https://github.com/google/draco) | Geometry compression | Optional codec; compare decode time vs download savings |
| [KTX-Software](https://github.com/KhronosGroup/KTX-Software) | KTX2 and Basis Universal texture pipeline | High-priority texture pipeline reference; validate device format support |
| [glTF Validator](https://github.com/KhronosGroup/glTF-Validator) | glTF conformance checks | Add to CI/import validation |
| [gltfpack](https://github.com/zeux/meshoptimizer) | glTF mesh/texture/instancing optimization | Offline build step; preserve named nodes when editor references them |
| [TexturePacker](https://github.com/CodeAndWeb/TexturePacker) | Atlas packing workflow | Commercial product; workflow reference, not assumed OSS |
| [Free Texture Packer](https://github.com/odrick/free-tex-packer) | Sprite atlas generation | Candidate; review current license and maintenance |
| [sharp](https://github.com/lovell/sharp) | Image resize/format conversion | Build-time only; never ship native image-processing dependency in player |
| [squoosh](https://github.com/GoogleChromeLabs/squoosh) | Image codec comparison | Research/tooling reference; verify project maintenance |
| [audiosprite](https://github.com/tonistiigi/audiosprite) | Audio sprite generation | Candidate to reduce requests for short SFX |
| [ffmpeg](https://github.com/FFmpeg/FFmpeg) | Audio/video transcode pipeline | Build-time pipeline only; licensing and codec configuration must be reviewed |

### H. Audio, UI, input and accessibility

| Project | Study target | Adoption assessment |
|---|---|---|
| [Howler.js](https://github.com/goldfire/howler.js) | Audio sprites, mobile playback and fallback | Optional audio adapter candidate |
| [ZzFX](https://github.com/KilledByAPixel/ZzFX) | Tiny procedural retro SFX | Excellent low-payload retro audio reference |
| [ZzFXM](https://github.com/keithclark/ZzFXM) | Procedural music sequencer | Optional retro music pipeline |
| [Tone.js](https://github.com/Tonejs/Tone.js) | Musical timing and synthesis | Rhythm/editor tooling; likely too broad for base player |
| [Pizzicato.js](https://github.com/alemangui/pizzicato) | WebAudio effect graph | Optional effects; avoid unneeded nodes on low-end |
| [nipplejs](https://github.com/yoannmoinet/nipplejs) | Virtual joystick controls | Touch UX reference; own control surface may be lighter |
| [Hammer.js](https://github.com/hammerjs/hammer.js) | Gesture normalization | Historical reference; Pointer Events preferred for new code |
| [Radix UI](https://github.com/radix-ui/primitives) | Accessible editor controls | Editor-only dependency; keep out of player bundle |
| [Open Props](https://github.com/argyleink/open-props) | Design tokens and responsive UI | Editor styling reference; avoid shipping unused CSS |
| [axe-core](https://github.com/dequelabs/axe-core) | Accessibility checks | Add editor/UI automated checks |

### I. Multiplayer, persistence, testing and profiling

| Project | Study target | Adoption assessment |
|---|---|---|
| [Colyseus](https://github.com/colyseus/colyseus) | Room state synchronization and matchmaking | Optional server integration; never bundle server code in client |
| [Nakama](https://github.com/heroiclabs/nakama) | Authoritative multiplayer, accounts and storage | Backend option; requires server deployment and security design |
| [Socket.IO](https://github.com/socketio/socket.io) | Realtime transport and reconnection | Optional transport; not authoritative game logic by itself |
| [PeerJS](https://github.com/peers/peerjs) | WebRTC peer connection ergonomics | Casual P2P only; NAT and cheating limitations apply |
| [Playwright](https://github.com/microsoft/playwright) | Browser input, lifecycle and regression tests | High-priority automated browser test tool |
| [Vitest](https://github.com/vitest-dev/vitest) | Unit/integration testing | Add when package/test environment is available |
| [fast-check](https://github.com/dubzzz/fast-check) | Property-based testing | High-priority for geometry, serialization and state invariants |
| [Benchmark.js](https://github.com/bestiejs/benchmark.js) | Microbenchmark harness | Use only with repeatable warmup and device context |
| [stats.js](https://github.com/mrdoob/stats.js) | Frame-time visualization | Debug-only; strip from production |
| [Spector.js](https://github.com/BabylonJS/Spector.js) | WebGL command/state inspection | Desktop diagnostics; not for end users or release runtime |
| [Web Vitals](https://github.com/GoogleChrome/web-vitals) | Web startup and responsiveness | Useful for editor/site, not a substitute for in-game FPS metrics |

## Important compatibility facts

- Current Three.js `WebGLRenderer` requires WebGL2; WebGL1 support was removed in r163. A legacy WebGL1 path must be a separate renderer implementation, not a setting passed to current Three.js. See the [Three.js WebGLRenderer docs](https://threejs.org/docs/pages/WebGLRenderer.html).
- Godot's renderer matrix is a useful example of capability tiers: Compatibility targets older hardware and web; Mobile/Forward+ require newer graphics APIs. Do not map these names directly onto MUNGIL without equivalent implementation. See [Godot renderer overview](https://docs.godotengine.org/en/stable/tutorials/rendering/renderers.html).
- Godot's system requirements distinguish native and web export targets; web export recommendations include 4 GB RAM in the current stable documentation. That is a warning against assuming every low-RAM Android WebView can run a full 3D editor/player. See [Godot system requirements](https://docs.godotengine.org/en/stable/about/system_requirements.html).
- Defold's optimization guide emphasizes bundle size, runtime speed, memory and battery as separate constraints. See [Defold optimization](https://defold.com/manuals/optimization/).
- glTF Transform supports offline geometry and texture optimization options; choose codecs only after checking runtime decoder availability and target GPU support. See [glTF Transform README](https://github.com/donmccurdy/glTF-Transform).

## Priority for MUNGIL

1. **P0 — correctness and integration:** source/scene schema map, stable IDs, validation, undo/redo transaction boundary, deterministic command dispatch, project save/load migration.
2. **P0 — low-end runtime:** Canvas2D renderer adapter for 2D/retro, WebGL2 adapter, explicit WebGL1 legacy adapter if required, context-loss recovery, memory-aware asset cache, bounded diagnostics.
3. **P1 — content pipeline:** atlas packer, image/audio transcode, glTF validation and optimization, import dependency graph, reproducible export manifest.
4. **P1 — genre systems:** 2D kinematics, 2D rigid-body optional adapter, tilemap/isometric authoring, raycaster/pseudo-3D renderer, animation FSM and event timeline.
5. **P2 — advanced 3D:** skeletal animation, 3D physics, navmesh, LOD/impostors, instancing, optional WebGPU.
6. **P2 — online features:** multiplayer authority, rollback/prediction, cloud saves and moderation/security only when a real backend exists.

## What is not claimed

No repository in this list is claimed as cloned into MUNGIL. A shortlist entry is not a dependency decision. No Android 5+ support, itel A70 FPS, thermal, battery or memory result is claimed without physical-device testing. No renderer or asset pipeline is considered production-ready merely because its interface exists.
