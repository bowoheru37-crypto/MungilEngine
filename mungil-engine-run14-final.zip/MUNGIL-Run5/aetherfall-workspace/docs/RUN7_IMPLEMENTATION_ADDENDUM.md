# MUNGIL / Runtime Foundation — Run 7 Implementation Addendum

Date: 2026-11-26

## Scope delivered

Run 7 continues the Run 6 archive. It does not replace the original HTML baseline, the MUNGIL editor sidecar, Aetherfall, or the Archipelago sample.

### 1. Canvas2D renderer adapter

Added `src/game/runtime/renderers/canvas2d.ts`.

- Implements the existing `RendererAdapter<Canvas2DScene>` contract.
- Supports ordered rectangle, circle, line, polygon, text and image commands.
- Supports camera translation, zoom, alpha, layer ordering, resize and quality-tier pixel-ratio caps.
- Uses a stable insertion order for equal layers.
- Rejects invalid geometry/style/alpha and bounded text/polygon inputs; caps each scene at 32,768 draw commands.
- Owns an image cache with explicit set/get/release and clears it on disposal.
- Handles canvas context loss/restoration events when the browser exposes them.
- Explicitly targets orthographic 2D, isometric 2.5D and pseudo-3D draw commands. It is not a perspective 3D renderer and does not pretend to replace the existing Three.js renderer.

### 2. Renderer-neutral project document

Added `src/game/runtime/project-document.ts`.

- Defines versioned JSON project documents and stable node IDs.
- Validates schema version, node limits, parent references, hierarchy cycles, JSON-only properties and a 2 MiB serialized document cap.
- Supports add/remove subtree/rename/set-props/set-parent operations.
- Operations validate the candidate document before mutating history.
- Adds undo/redo with a maximum of 32 history entries and a 4 MiB aggregate history budget per stack.
- Adds bounded storage-key and save/load helpers that fail closed on malformed data or storage errors.
- Uses JSON cloning rather than requiring `structuredClone`, improving compatibility with older browser runtimes.

### 3. Exports and tests

- Exported renderer and project-document modules from `src/game/runtime/index.ts`.
- Runtime tests: 35/35 pass.
- Strict TypeScript check for the runtime module set: pass.
- MUNGIL sidecar `tests/run.js`: pass.
- MUNGIL sidecar `tests/mcp-smoke.js`: pass.

## Research additions

Additional inspected references and repository entry points are recorded in `ENGINE_REFERENCE_RESEARCH_RUN7.md`. Selected README files were fetched through the connected GitHub source:

- `phaserjs/phaser` README blob `15fb582058a775acce50d390dbabef4b2b5e19af`.
- `litecanvas/game-engine` README blob `b746cf2267edc3cfbd99424a6ad52ee47dc256dd`.
- `suchipi/hex-engine` README blob `4d67cda72e76f0f2b6c27ca5eb6afbc39a8cb10d`.
- `axaq/traviso.js` README blob `eaf0cda2d8cf44e534de3bc4104f192811526eed`.

These are reference inspections, not clones or dependencies added to MUNGIL.

## Preservation checks

- Original MUNGIL HTML SHA-256: `bd12f920c02c487cee9cc8617f2272dd57ddf489b232edd75c58ea8dffca8a53` — unchanged.
- Original Archipelago HTML SHA-256: `a4a56f2e6cc516c0bdbf8e255782252d62358227d450853b60af2ca677d98911` — unchanged.

## Not performed / not claimed

- No WebGL2 or WebGL1 adapter was implemented in Run 7.
- No perspective-3D renderer was replaced; Aetherfall continues to use its existing Three.js renderer.
- No integration of the sidecar with the original compiled MUNGIL editor state, inspector, hierarchy, undo system or persistence seam has been proven.
- No full application build, browser automation, APK/AAB build, or physical itel A70 test was performed.
- Canvas2D renderer tests use a deterministic mock context; they do not establish real-device rendering performance or browser GPU behavior.
- No GitHub repository was cloned or merged.
