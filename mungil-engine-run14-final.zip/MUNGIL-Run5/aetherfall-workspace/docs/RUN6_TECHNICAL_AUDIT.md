# MUNGIL Run 6 — Technical audit

## Changed file

`workspace/workspace/src/game/runtime/spatial.ts`

### Defect addressed

The previous grid clamped cell coordinates before confirming that an AABB overlapped the grid. An AABB starting exactly at the far edge (`minX = originX + columns * cellSize`) could be clamped into the last valid cell despite being outside the grid. Re-inserting an entity ID also added a second set of cell links while the previous links remained, which could create stale broadphase candidates after an update.

### New behavior

- One ID can be inserted once per grid build.
- A fully out-of-grid AABB is accepted as an intentionally non-indexed entity, but contributes zero entries.
- An AABB that overlaps the grid is clipped to valid cell coordinates and inserted as before.
- Capacity failures remain fail-closed and do not partially add entries.
- `clear()` resets heads, entry count and insertion marks.

### Known semantics

- `query()` is a broadphase candidate query. It deduplicates entity IDs but does not perform exact AABB intersection; the narrowphase must still validate candidates.
- Callers must call `clear()` before rebuilding a frame's dynamic broadphase. Duplicate insertion is rejected rather than silently replacing prior memberships.
- Grid dimensions and entry capacities remain bounded by constructor validation.

## Verification results

| Check | Result |
|---|---|
| Runtime tests | 26 passed, 0 failed |
| Strict TypeScript check of runtime modules | Passed |
| Full app build | Not run |
| Full app test suite | Not run in Run 6 |
| Browser test | Not run |
| Android package build | Not run |
| itel A70 device benchmark | Not run |

## Risk / next work

1. Add property-based tests for spatial boundaries, duplicate IDs and capacity rollback.
2. Add a benchmark harness for grid rebuild/query vs naive scan across realistic low-end workloads.
3. Implement actual Canvas2D and WebGL2 renderer adapters behind `RendererAdapter`; keep WebGL1 isolated.
4. Map editor state/serialization/undo seams before integrating sidecar modules.
5. Test Android WebView versions and GPU behavior on physical hardware.
