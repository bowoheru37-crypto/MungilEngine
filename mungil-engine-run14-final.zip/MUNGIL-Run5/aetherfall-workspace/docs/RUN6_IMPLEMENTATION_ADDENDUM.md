# MUNGIL Run 6 — Implementation addendum

## Scope delivered in this increment

- Continued from Run 5 without replacing the Aetherfall workspace, MUNGIL sidecar, or original HTML baseline.
- Hardened `src/game/runtime/spatial.ts` uniform-grid insertion semantics:
  - tracks IDs already inserted in the current grid build;
  - rejects duplicate insertion of the same entity ID, preventing stale cell memberships when callers rebuild incorrectly;
  - rejects AABBs fully outside the far grid boundary before clamping, fixing the exact `minX === worldMaxX` / `minY === worldMaxY` case that could previously be assigned to the last cell;
  - resets per-entity insertion marks on `clear()`.
- Expanded the existing spatial broadphase test to cover duplicate IDs, far-boundary clipping, clearing and reinsertion.
- Added the expanded Run 6 research catalog with additional references across rendering, ECS, physics, spatial indexes, AI, pseudo-3D, animation, asset tooling, audio, UI/accessibility, multiplayer, tests and profiling.

## Verification

- Runtime unit tests: 26/26 pass (`node --experimental-strip-types --test src/game/runtime/core.test.ts`).
- Strict TypeScript check for the runtime module set: pass.
- This is a narrow hardening increment, not a full integration or engine completion claim.

## Not performed / remaining

- No browser/Playwright test in this increment.
- No complete workspace build or full repository test suite; previous Run 5 known dependency/fixture failures remain unresolved.
- No Android APK/AAB build or itel A70 physical-device profiling.
- No renderer implementation added here: `resolveRenderer()` remains a capability selector, not Canvas2D/WebGL1/WebGL2 renderer adapters.
- No upstream repository cloned or code merged. License, commit and dependency audits are still required before adoption.
- The MUNGIL editor sidecar is still separate from the compiled original editor; no safe state/undo/persistence integration seam has yet been proven.
