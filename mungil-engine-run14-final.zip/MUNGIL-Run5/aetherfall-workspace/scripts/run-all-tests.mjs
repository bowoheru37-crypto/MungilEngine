import { spawnSync } from "node:child_process";

const suites = [
  ["scripts/**/*.test.mjs"],
  [
    "src/lib/app-data/app-data.test.ts",
    "src/lib/app-data/readiness-schedule.test.ts",
    "src/lib/auth/gate-identity.test.ts",
    "src/lib/auth/sign-in-gate.test.ts",
    "src/lib/preview-path-prefix.test.ts",
    "src/game/runtime/core.test.ts",
  ],
];

let failed = false;
for (let index = 0; index < suites.length; index += 1) {
  const args = index === 0
    ? ["--test", suites[index][0]]
    : ["--experimental-strip-types", "--test", ...suites[index]];
  const result = spawnSync(process.execPath, args, { stdio: "inherit" });
  if (result.error) {
    console.error(`Test suite ${index + 1} could not start:`, result.error);
    failed = true;
  } else if (result.status !== 0) {
    failed = true;
  }
}
process.exitCode = failed ? 1 : 0;
