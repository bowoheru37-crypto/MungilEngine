import { spawnSync } from "node:child_process";
import { mkdtempSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const source = path.join(root, "src/game/runtime/browser-entry.ts");
const output = path.join(root, "platform/runtime/mungil-runtime.js");
const temporary = mkdtempSync(path.join(tmpdir(), "mungil-runtime-"));
const tsc = process.env.TSC_BIN || "tsc";

function collect(directory, base = directory) {
  const files = [];
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const full = path.join(directory, entry.name);
    if (entry.isDirectory()) files.push(...collect(full, base));
    else if (entry.isFile() && entry.name.endsWith(".js")) files.push({ id: path.relative(base, full).split(path.sep).join("/"), source: readFileSync(full, "utf8") });
  }
  return files;
}

try {
  const compile = spawnSync(tsc, ["--target", "ES2019", "--module", "commonjs", "--lib", "ES2022,DOM", "--strict", "--skipLibCheck", "--allowImportingTsExtensions", "--rewriteRelativeImportExtensions", "--outDir", temporary, source], { cwd: root, encoding: "utf8" });
  if (compile.status !== 0) throw new Error((compile.stdout + compile.stderr).slice(0, 6000) || "TYPESCRIPT_COMPILE_FAILED");
  const modules = collect(temporary).sort((a, b) => a.id.localeCompare(b.id));
  if (!modules.length || !modules.some(module => module.id === "browser-entry.js")) throw new Error("RUNTIME_ENTRY_NOT_EMITTED");
  const factories = modules.map(module => `modules[${JSON.stringify(module.id)}]=function(module,exports,require){\n${module.source}\n};`).join("\n");
  const bundle = `(function(root){\n'use strict';\nvar modules=Object.create(null),cache=Object.create(null);\n${factories}\nfunction resolve(from,request){if(request.charAt(0)!=='.')throw new Error('EXTERNAL_MODULE_BLOCKED:'+request);var parts=from.split('/');parts.pop();var incoming=request.split('/');for(var i=0;i<incoming.length;i++){var part=incoming[i];if(!part||part==='.')continue;if(part==='..')parts.pop();else parts.push(part);}var id=parts.join('/');if(!/\\.js$/.test(id))id+='.js';if(!modules[id])throw new Error('MODULE_NOT_FOUND:'+id);return id;}\nfunction load(id){if(cache[id])return cache[id].exports;if(!modules[id])throw new Error('MODULE_NOT_FOUND:'+id);var module={exports:{}};cache[id]=module;modules[id](module,module.exports,function(request){return load(resolve(id,request));});return module.exports;}\nvar api=load('browser-entry.js');if(!root.MUNGIL_RUNTIME)Object.defineProperty(root,'MUNGIL_RUNTIME',{configurable:false,enumerable:false,writable:false,value:Object.freeze(api)});\n})(window);\n`;
  mkdirSync(path.dirname(output), { recursive: true });
  writeFileSync(output, bundle, "utf8");
  process.stdout.write(`Built browser runtime: ${modules.length} modules, ${Buffer.byteLength(bundle)} bytes\n`);
} finally {
  rmSync(temporary, { recursive: true, force: true });
}
