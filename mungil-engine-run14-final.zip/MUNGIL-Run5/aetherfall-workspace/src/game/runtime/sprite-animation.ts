/** Fixed-step sprite animation with bounded clips and no per-frame allocations. */
export type SpriteAnimationFrame = Readonly<{ frameId: string; durationMs: number }>;
export type SpriteAnimationClip = Readonly<{ id: string; frames: readonly SpriteAnimationFrame[]; loop: boolean; pingPong: boolean }>;
export type SpriteAnimationResult = Readonly<{ ok: true; clip: SpriteAnimationClip }> | Readonly<{ ok: false; error: string }>;

export function createSpriteAnimationClip(id: string, frames: readonly SpriteAnimationFrame[], options: { loop?: boolean; pingPong?: boolean } = {}): SpriteAnimationResult {
  if (typeof id !== "string" || !/^[A-Za-z0-9_-]{1,80}$/.test(id) || !Array.isArray(frames) || frames.length < 1 || frames.length > 1024) return { ok: false, error: "INVALID_ANIMATION_CLIP" };
  const copy: SpriteAnimationFrame[] = [];
  for (const frame of frames) {
    if (!frame || typeof frame.frameId !== "string" || !/^[A-Za-z0-9_-]{1,80}$/.test(frame.frameId) || !Number.isFinite(frame.durationMs) || frame.durationMs < 10 || frame.durationMs > 60_000) return { ok: false, error: "INVALID_ANIMATION_FRAME" };
    copy.push(Object.freeze({ frameId: frame.frameId, durationMs: frame.durationMs }));
  }
  if (options.pingPong && copy.length < 2) return { ok: false, error: "PING_PONG_NEEDS_MULTIPLE_FRAMES" };
  return { ok: true, clip: Object.freeze({ id, frames: Object.freeze(copy), loop: options.loop ?? true, pingPong: options.pingPong ?? false }) };
}

export class SpriteAnimator {
  private clipValue: SpriteAnimationClip | null = null;
  private frameIndexValue = 0;
  private elapsedMs = 0;
  private direction: 1 | -1 = 1;
  private playingValue = false;
  private completedValue = false;
  get clip(): SpriteAnimationClip | null { return this.clipValue; }
  get frameIndex(): number { return this.frameIndexValue; }
  get currentFrameId(): string | null { return this.clipValue?.frames[this.frameIndexValue]?.frameId ?? null; }
  get isPlaying(): boolean { return this.playingValue; }
  get isComplete(): boolean { return this.completedValue; }
  play(clip: SpriteAnimationClip, restart = true): boolean {
    if (!clip || typeof clip.id !== "string" || !/^[A-Za-z0-9_-]{1,80}$/.test(clip.id) || !Array.isArray(clip.frames) || clip.frames.length < 1 || clip.frames.length > 1024 || typeof clip.loop !== "boolean" || typeof clip.pingPong !== "boolean" || (clip.pingPong && clip.frames.length < 2) || !clip.frames.every(frame => !!frame && typeof frame.frameId === "string" && /^[A-Za-z0-9_-]{1,80}$/.test(frame.frameId) && Number.isFinite(frame.durationMs) && frame.durationMs >= 10 && frame.durationMs <= 60_000)) return false;
    if (restart || this.clipValue?.id !== clip.id) { this.frameIndexValue = 0; this.elapsedMs = 0; this.direction = 1; this.completedValue = false; }
    this.clipValue = clip; this.playingValue = true; return true;
  }
  pause(): void { this.playingValue = false; }
  stop(): void { this.playingValue = false; this.completedValue = false; this.elapsedMs = 0; this.frameIndexValue = 0; this.direction = 1; }
  update(deltaSeconds: number): boolean {
    const clip = this.clipValue;
    if (!this.playingValue || !clip || this.completedValue || !Number.isFinite(deltaSeconds) || deltaSeconds <= 0) return false;
    // Bound catch-up after backgrounding. Frame durations are at least 10ms.
    this.elapsedMs += Math.min(deltaSeconds, 0.25) * 1000;
    let changed = false; let transitions = 0;
    while (this.elapsedMs >= clip.frames[this.frameIndexValue]!.durationMs && transitions < 64) {
      this.elapsedMs -= clip.frames[this.frameIndexValue]!.durationMs;
      if (clip.pingPong) {
        let next = this.frameIndexValue + this.direction;
        if (next >= clip.frames.length || next < 0) {
          if (!clip.loop) { this.completedValue = true; this.playingValue = false; this.elapsedMs = 0; break; }
          this.direction = this.direction === 1 ? -1 : 1;
          next = this.frameIndexValue + this.direction;
        }
        this.frameIndexValue = next;
      } else if (this.frameIndexValue + 1 < clip.frames.length) this.frameIndexValue++;
      else if (clip.loop) this.frameIndexValue = 0;
      else { this.completedValue = true; this.playingValue = false; this.elapsedMs = 0; break; }
      changed = true; transitions++;
    }
    if (transitions === 64) this.elapsedMs = 0;
    return changed;
  }
}
