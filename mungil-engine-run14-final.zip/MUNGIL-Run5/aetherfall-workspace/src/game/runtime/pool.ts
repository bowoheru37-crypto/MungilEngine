/** Fixed-capacity index pool. All object creation happens in the constructor. */
export class ObjectPool<T> {
  private readonly values: T[];
  private readonly free: Int32Array;
  private readonly active: Uint8Array;
  private freeCount: number;
  private activeCount = 0;
  private disposed = false;
  private readonly reset?: (value: T) => void;

  constructor(capacity: number, factory: (index: number) => T, reset?: (value: T) => void) {
    this.reset = reset;
    if (!Number.isSafeInteger(capacity) || capacity < 1 || capacity > 262_144 || typeof factory !== "function") {
      throw new RangeError("INVALID_POOL_CONFIGURATION");
    }
    this.values = new Array<T>(capacity);
    this.free = new Int32Array(capacity);
    this.active = new Uint8Array(capacity);
    for (let i = 0; i < capacity; i++) {
      this.values[i] = factory(i);
      this.free[i] = capacity - 1 - i;
    }
    this.freeCount = capacity;
  }

  acquire(): number {
    if (this.disposed || this.freeCount === 0) return -1;
    const index = this.free[--this.freeCount]!;
    this.active[index] = 1;
    this.activeCount++;
    return index;
  }

  get(index: number): T | undefined {
    return Number.isInteger(index) && index >= 0 && index < this.values.length && this.active[index] === 1
      ? this.values[index]
      : undefined;
  }

  release(index: number): boolean {
    if (this.disposed || !Number.isInteger(index) || index < 0 || index >= this.values.length || this.active[index] !== 1) return false;
    const value = this.values[index]!;
    try { this.reset?.(value); } catch { return false; }
    this.active[index] = 0;
    this.free[this.freeCount++] = index;
    this.activeCount--;
    return true;
  }

  dispose(disposeValue?: (value: T) => void): void {
    if (this.disposed) return;
    this.disposed = true;
    if (disposeValue) {
      for (let i = 0; i < this.values.length; i++) {
        try { disposeValue(this.values[i]!); } catch { /* continue releasing remaining entries */ }
      }
    }
    this.active.fill(0);
    this.freeCount = 0;
    this.activeCount = 0;
  }

  get capacity(): number { return this.values.length; }
  get available(): number { return this.freeCount; }
  get inUse(): number { return this.activeCount; }
  get isDisposed(): boolean { return this.disposed; }
}
