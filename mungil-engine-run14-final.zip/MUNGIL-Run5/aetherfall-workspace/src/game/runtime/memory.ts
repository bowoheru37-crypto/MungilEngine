/** Explicit, byte-accounted resource budget. Register/touch/release are setup or lifecycle operations. */
export type ResourceKind = "texture" | "mesh" | "audio" | "animation" | "other";
type Entry = { bytes: number; kind: ResourceKind; pinned: boolean; stamp: number; dispose?: () => void };

export class MemoryBudget {
  private readonly entries = new Map<string, Entry>();
  private used = 0;
  private clock = 0;
  private disposed = false;
  readonly limitBytes: number;

  constructor(limitBytes: number) {
    if (!Number.isSafeInteger(limitBytes) || limitBytes < 1) throw new RangeError("INVALID_MEMORY_BUDGET");
    this.limitBytes = limitBytes;
  }

  register(id: string, kind: ResourceKind, bytes: number, dispose?: () => void, pinned = false): boolean {
    if (this.disposed || typeof id !== "string" || !/^[a-zA-Z0-9:_-]{1,128}$/.test(id) || this.entries.has(id) ||
      !["texture", "mesh", "audio", "animation", "other"].includes(kind) || !Number.isSafeInteger(bytes) || bytes < 0 || bytes > this.limitBytes) return false;
    let pinnedBytes = 0;
    for (const entry of this.entries.values()) if (entry.pinned) pinnedBytes += entry.bytes;
    if (pinnedBytes + bytes > this.limitBytes) return false;
    this.evictTo(this.limitBytes - bytes);
    if (this.used + bytes > this.limitBytes) return false;
    this.entries.set(id, { bytes, kind, pinned, stamp: ++this.clock, dispose });
    this.used += bytes;
    return true;
  }

  touch(id: string): boolean {
    const entry = this.entries.get(id);
    if (!entry || this.disposed) return false;
    entry.stamp = ++this.clock;
    return true;
  }

  pin(id: string, pinned = true): boolean {
    const entry = this.entries.get(id);
    if (!entry || this.disposed) return false;
    entry.pinned = pinned;
    return true;
  }

  release(id: string): boolean {
    const entry = this.entries.get(id);
    if (!entry) return false;
    this.entries.delete(id);
    this.used -= entry.bytes;
    this.safeDispose(entry);
    return true;
  }

  evict(bytesToFree: number): number {
    if (this.disposed || !Number.isSafeInteger(bytesToFree) || bytesToFree <= 0) return 0;
    const before = this.used;
    this.evictTo(Math.max(0, before - bytesToFree));
    return before - this.used;
  }

  private evictTo(target: number): void {
    while (this.used > target) {
      let candidateId: string | undefined;
      let oldest = Infinity;
      for (const [id, entry] of this.entries) {
        if (!entry.pinned && entry.stamp < oldest) { oldest = entry.stamp; candidateId = id; }
      }
      if (candidateId === undefined) break;
      const entry = this.entries.get(candidateId)!;
      this.entries.delete(candidateId);
      this.used -= entry.bytes;
      this.safeDispose(entry);
    }
  }

  private safeDispose(entry: Entry): void { try { entry.dispose?.(); } catch { /* continue releasing other resources */ } }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    for (const entry of this.entries.values()) this.safeDispose(entry);
    this.entries.clear();
    this.used = 0;
  }

  get usedBytes(): number { return this.used; }
  get availableBytes(): number { return Math.max(0, this.limitBytes - this.used); }
  get resourceCount(): number { return this.entries.size; }
  get isDisposed(): boolean { return this.disposed; }
}
