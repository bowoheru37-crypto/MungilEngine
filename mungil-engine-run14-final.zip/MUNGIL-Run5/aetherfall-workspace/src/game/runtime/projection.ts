/** Projection helpers shared by orthographic, isometric, pseudo-3D and raycaster genres. */
export type Point2 = { x: number; y: number };
export type RayHit = { hit: boolean; distance: number; cellX: number; cellY: number; side: 0 | 1 };

export function worldToIsometric(x: number, y: number, tileWidth: number, tileHeight: number, out: Point2): boolean {
  if (![x, y, tileWidth, tileHeight].every(Number.isFinite) || tileWidth <= 0 || tileHeight <= 0 || !out) return false;
  out.x = (x - y) * tileWidth * 0.5; out.y = (x + y) * tileHeight * 0.5; return true;
}
export function isometricToWorld(screenX: number, screenY: number, tileWidth: number, tileHeight: number, out: Point2): boolean {
  if (![screenX, screenY, tileWidth, tileHeight].every(Number.isFinite) || tileWidth <= 0 || tileHeight <= 0 || !out) return false;
  const a = screenX / (tileWidth * 0.5); const b = screenY / (tileHeight * 0.5);
  out.x = (a + b) * 0.5; out.y = (b - a) * 0.5; return true;
}
export function projectPseudo3D(worldX: number, worldY: number, worldZ: number, cameraX: number, cameraY: number, cameraZ: number, cameraDepth: number, focalLength: number, out: Point2): boolean {
  if (![worldX, worldY, worldZ, cameraX, cameraY, cameraZ, cameraDepth, focalLength].every(Number.isFinite) || cameraDepth <= 0 || focalLength <= 0 || !out) return false;
  const depth = worldZ - cameraZ; if (depth <= 0.001) return false;
  const scale = focalLength / depth;
  out.x = (worldX - cameraX) * scale; out.y = (worldY - cameraY) * scale + cameraDepth;
  return Number.isFinite(out.x) && Number.isFinite(out.y);
}
/** Bounded DDA raycast against a caller-provided row-major integer tile grid. */
export function raycastGrid(map: Uint8Array, width: number, height: number, originX: number, originY: number, directionX: number, directionY: number, maxDistance: number, out: RayHit): boolean {
  if (!map || !Number.isSafeInteger(width) || !Number.isSafeInteger(height) || width < 1 || height < 1 || width * height > map.length ||
    ![originX, originY, directionX, directionY, maxDistance].every(Number.isFinite) || maxDistance <= 0 || !out) return false;
  const length = Math.hypot(directionX, directionY); if (length < 1e-9) return false;
  const dx = directionX / length; const dy = directionY / length;
  let cellX = Math.floor(originX); let cellY = Math.floor(originY);
  if (cellX < 0 || cellY < 0 || cellX >= width || cellY >= height) return false;
  if (map[cellY * width + cellX] !== 0) { out.hit = true; out.distance = 0; out.cellX = cellX; out.cellY = cellY; out.side = 0; return true; }
  const stepX = dx < 0 ? -1 : 1; const stepY = dy < 0 ? -1 : 1;
  const deltaX = Math.abs(dx) < 1e-12 ? Infinity : Math.abs(1 / dx);
  const deltaY = Math.abs(dy) < 1e-12 ? Infinity : Math.abs(1 / dy);
  let sideX = dx < 0 ? (originX - cellX) * deltaX : (cellX + 1 - originX) * deltaX;
  let sideY = dy < 0 ? (originY - cellY) * deltaY : (cellY + 1 - originY) * deltaY;
  let distance = 0; let side: 0 | 1 = 0;
  const maxSteps = Math.min(8192, width * height + width + height);
  for (let step = 0; step < maxSteps; step++) {
    if (sideX < sideY) { distance = sideX; sideX += deltaX; cellX += stepX; side = 0; }
    else { distance = sideY; sideY += deltaY; cellY += stepY; side = 1; }
    if (distance > maxDistance || cellX < 0 || cellY < 0 || cellX >= width || cellY >= height) break;
    if (map[cellY * width + cellX] !== 0) { out.hit = true; out.distance = distance; out.cellX = cellX; out.cellY = cellY; out.side = side; return true; }
  }
  out.hit = false; out.distance = Math.min(distance, maxDistance); out.cellX = cellX; out.cellY = cellY; out.side = side; return true;
}
