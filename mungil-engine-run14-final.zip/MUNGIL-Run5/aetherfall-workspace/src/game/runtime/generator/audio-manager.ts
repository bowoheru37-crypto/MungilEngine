/** Small Web Audio mixer with explicit gesture unlock, bounded decode, bus gain and voice accounting. */
export type AudioBusName = "master" | "music" | "sfx" | "ambience" | "ui";
export type AudioClip = Readonly<{ id: string; buffer: AudioBuffer; bus?: Exclude<AudioBusName, "master">; loop?: boolean; maxVoices?: number }>;
type Voice = { source: AudioBufferSourceNode; gain: GainNode; bus: AudioBusName; clipId: string };
export type AudioDecodeOptions = Readonly<{ bus?: Exclude<AudioBusName, "master">; loop?: boolean; maxVoices?: number; maxBytes?: number; maxDurationSeconds?: number; maxDecodedBytes?: number }>;
const SAFE_ID = /^[a-zA-Z0-9_-]{1,80}$/;

function decodeBuffer(context: AudioContext, data: ArrayBuffer): Promise<AudioBuffer> {
  return new Promise((resolve,reject)=>{
    let settled=false;
    const success=(buffer:AudioBuffer)=>{if(!settled){settled=true;resolve(buffer);}};
    const failure=(error:DOMException)=>{if(!settled){settled=true;reject(error);}};
    try {
      const result=context.decodeAudioData(data,success,failure);
      if(result && typeof result.then==="function") result.then(success,failure);
    } catch(error) { failure(error instanceof DOMException?error:new DOMException("AUDIO_DECODE_FAILED","EncodingError")); }
  });
}

export class WebAudioMixer {
  private context: AudioContext | null = null;
  private master: GainNode | null = null;
  private readonly buses = new Map<AudioBusName, GainNode>();
  private readonly clips = new Map<string, AudioClip>();
  private readonly voices = new Map<number, Voice>();
  private readonly voiceCounts = new Map<string, number>();
  private nextHandle = 1;
  private disposed = false;
  private readonly maxTotalVoices: number;
  constructor(maxTotalVoices = 24) { if (!Number.isInteger(maxTotalVoices) || maxTotalVoices < 1 || maxTotalVoices > 128) throw new RangeError("INVALID_VOICE_LIMIT"); this.maxTotalVoices = maxTotalVoices; }

  private ensureContext(): AudioContext | null {
    if(this.disposed)return null;
    if(this.context)return this.context;
    const Constructor=typeof window!=="undefined"?(window.AudioContext|| (window as Window & {webkitAudioContext?:typeof AudioContext}).webkitAudioContext):undefined;
    if(!Constructor)return null;
    try {
      this.context=new Constructor();this.master=this.context.createGain();this.master.connect(this.context.destination);
      for(const name of ["music","sfx","ambience","ui"] as const){const gain=this.context.createGain();gain.connect(this.master);this.buses.set(name,gain);}
      return this.context;
    } catch { this.context=null;this.master=null;this.buses.clear();return null; }
  }
  /** Must be invoked from a user gesture on browsers that gate audio playback. */
  unlock(): boolean {
    const context=this.ensureContext();if(!context)return false;
    if(context.state==="suspended")void context.resume().catch(()=>undefined);
    return true;
  }
  register(clip: AudioClip): boolean {
    if(this.disposed||!clip||!SAFE_ID.test(clip.id)||!clip.buffer||!Number.isFinite(clip.buffer.duration)||clip.buffer.duration<=0||clip.buffer.duration>600||!Number.isInteger(clip.buffer.numberOfChannels)||clip.buffer.numberOfChannels<1||clip.buffer.numberOfChannels>8||!Number.isFinite(clip.buffer.sampleRate)||clip.buffer.sampleRate<8000||clip.buffer.sampleRate>192000||clip.maxVoices!==undefined&&(!Number.isInteger(clip.maxVoices)||clip.maxVoices<1||clip.maxVoices>32)||clip.bus!==undefined&&!(["music","sfx","ambience","ui"].includes(clip.bus)))return false;
    if(this.clips.size>=512&&!this.clips.has(clip.id))return false;
    this.clips.set(clip.id,clip);return true;
  }
  /** Decode one bounded file at a time. It does not fetch URLs or bypass the browser's user-consent model. */
  async decodeAndRegister(id: string, blob: Blob, options: AudioDecodeOptions = {}, signal?: AbortSignal): Promise<boolean> {
    const maxBytes=options.maxBytes??4*1024*1024;const maxDuration=options.maxDurationSeconds??30;const maxDecodedBytes=options.maxDecodedBytes??12*1024*1024;
    if(this.disposed||!SAFE_ID.test(id)||!blob||!Number.isSafeInteger(blob.size)||blob.size<1||!Number.isSafeInteger(maxBytes)||maxBytes<1||maxBytes>32*1024*1024||blob.size>maxBytes||!Number.isFinite(maxDuration)||maxDuration<=0||maxDuration>180||!Number.isSafeInteger(maxDecodedBytes)||maxDecodedBytes<1024||maxDecodedBytes>64*1024*1024||signal?.aborted)return false;
    const context=this.ensureContext();if(!context)return false;
    let data:ArrayBuffer;
    try{data=await blob.arrayBuffer();}catch{return false;}
    if(signal?.aborted||data.byteLength!==blob.size)return false;
    let buffer:AudioBuffer;
    try{buffer=await decodeBuffer(context,data);}catch{return false;}
    const decodedBytes=buffer.length*buffer.numberOfChannels*4;
    if(signal?.aborted||buffer.duration>maxDuration||!Number.isSafeInteger(decodedBytes)||decodedBytes>maxDecodedBytes)return false;
    return this.register({id,buffer,bus:options.bus??"sfx",loop:options.loop??false,maxVoices:options.maxVoices??8});
  }
  play(id: string, options: { volume?: number; loop?: boolean } = {}): number | null {
    const clip=this.clips.get(id);if(!clip||!this.unlock()||!this.context)return null;
    const bus=clip.bus??"sfx";const target=this.buses.get(bus);if(!target)return null;
    const cap=Math.max(1,Math.min(32,clip.maxVoices??8));if(this.voices.size>=this.maxTotalVoices||(this.voiceCounts.get(id)??0)>=cap)return null;
    const volume=Number.isFinite(options.volume)?Math.max(0,Math.min(1,options.volume!)):1;
    const source=this.context.createBufferSource();const gain=this.context.createGain();source.buffer=clip.buffer;source.loop=options.loop??clip.loop??false;gain.gain.value=volume;
    source.connect(gain);gain.connect(target);
    let handle=this.nextHandle++;if(!Number.isSafeInteger(this.nextHandle)||this.nextHandle>Number.MAX_SAFE_INTEGER)this.nextHandle=1;
    while(this.voices.has(handle)){handle=this.nextHandle++;if(!Number.isSafeInteger(this.nextHandle)||this.nextHandle>Number.MAX_SAFE_INTEGER)this.nextHandle=1;}
    this.voices.set(handle,{source,gain,bus,clipId:id});this.voiceCounts.set(id,(this.voiceCounts.get(id)??0)+1);
    source.onended=()=>{const voice=this.voices.get(handle);if(!voice)return;this.voices.delete(handle);const count=(this.voiceCounts.get(id)??1)-1;if(count<=0)this.voiceCounts.delete(id);else this.voiceCounts.set(id,count);try{source.disconnect();gain.disconnect();}catch{/* already disconnected */}};
    try{source.start();return handle;}catch{this.voices.delete(handle);const count=(this.voiceCounts.get(id)??1)-1;if(count<=0)this.voiceCounts.delete(id);else this.voiceCounts.set(id,count);try{source.disconnect();gain.disconnect();}catch{/* no-op */}return null;}
  }
  stop(handle: number, fadeSeconds = 0.04): void {
    const voice=this.voices.get(handle);if(!voice||!this.context)return;
    const now=this.context.currentTime;const fade=Number.isFinite(fadeSeconds)?Math.max(0,Math.min(1,fadeSeconds)):0;
    voice.gain.gain.cancelScheduledValues(now);voice.gain.gain.setValueAtTime(voice.gain.gain.value,now);voice.gain.gain.linearRampToValueAtTime(0,now+fade);
    try{voice.source.stop(now+fade+0.005);}catch{try{voice.source.stop();}catch{/* already stopped */}}
  }
  stopBus(bus: AudioBusName, fadeSeconds = 0.04): void { for(const [handle,voice] of this.voices)if(voice.bus===bus)this.stop(handle,fadeSeconds); }
  setBusVolume(bus: AudioBusName, volume: number): void {
    const target=bus==="master"?this.master:this.buses.get(bus);if(!target||!Number.isFinite(volume))return;
    target.gain.setTargetAtTime(Math.max(0,Math.min(1,volume)),this.context?.currentTime??0,0.015);
  }
  suspend(): void {if(this.context?.state==="running")void this.context.suspend().catch(()=>undefined);}
  resume(): void {if(this.context?.state==="suspended")void this.context.resume().catch(()=>undefined);}
  dispose(): void {
    if(this.disposed)return;this.disposed=true;
    for(const voice of this.voices.values()){try{voice.source.stop();voice.source.disconnect();voice.gain.disconnect();}catch{/* best effort */}}
    this.voices.clear();this.voiceCounts.clear();this.clips.clear();this.buses.clear();this.master?.disconnect();this.master=null;
    if(this.context)void this.context.close().catch(()=>undefined);this.context=null;
  }
  get activeVoices(): number{return this.voices.size;}
  get registeredClips(): number{return this.clips.size;}
}
