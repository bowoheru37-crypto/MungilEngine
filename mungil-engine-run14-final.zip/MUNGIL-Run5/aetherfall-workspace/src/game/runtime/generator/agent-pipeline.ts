/** Deterministic prompt-to-project planning. AI providers plug into the typed interfaces; no provider or network is assumed. */
export type AgentRole = "producer" | "designer" | "engineer" | "artist" | "audio" | "qa" | "optimizer";
export type TaskState = "queued" | "running" | "done" | "failed" | "skipped";
export type GenerationTask = Readonly<{ id: string; role: AgentRole; title: string; description: string; dependsOn: readonly string[]; state: TaskState }>;
export type GenerationPlan = Readonly<{ schemaVersion: 1; prompt: string; genre: string; style: string; dimension: "2d" | "2.5d" | "3d"; target: "mobile-low" | "mobile" | "desktop" | "web"; tasks: readonly GenerationTask[]; outputs?: Readonly<Record<string, Readonly<Record<string, unknown>>>> }>;
export type PlanResult = { ok: true; plan: GenerationPlan } | { ok: false; error: string };
const MAX_PROMPT = 4000;
const MAX_TASKS = 24;
const SAFE_ID = /^[a-z0-9-]{1,48}$/;

function pick(text: string, patterns: readonly [RegExp, string][], fallback: string): string {
  for (const [pattern, value] of patterns) if (pattern.test(text)) return value;
  return fallback;
}
/** Makes a bounded, editable production plan; generated content still requires an AI provider and human review. */
export function createGenerationPlan(prompt: string, target: GenerationPlan["target"] = "mobile-low"): PlanResult {
  if (typeof prompt !== "string" || !prompt.trim() || prompt.length > MAX_PROMPT) return { ok: false, error: "INVALID_PROMPT" };
  if (!["mobile-low","mobile","desktop","web"].includes(target)) return { ok: false, error: "INVALID_TARGET" };
  const normalized = prompt.toLowerCase();
  const dimension = /\b(3d|three[- ]dimensional|first person|fps|third person)\b/.test(normalized) ? "3d" : /\b(isometric|pseudo[- ]?3d|2\.5d|diagonal)\b/.test(normalized) ? "2.5d" : "2d";
  const genre = pick(normalized, [[/rpg|role[- ]playing/, "rpg"], [/platformer|platform game/, "platformer"], [/racing|race car|kart/, "racing"], [/tower defense|td game/, "tower-defense"], [/puzzle|match[- ]?3/, "puzzle"], [/shooter|fps|bullet hell/, "shooter"], [/strategy|rts|tactics/, "strategy"], [/simulation|simulator|tycoon/, "simulation"], [/survival|crafting/, "survival"], [/roguelike|roguelite/, "roguelike"]], "arcade");
  const style = pick(normalized, [[/pixel|8[- ]bit|16[- ]bit|retro/, "pixel-retro"], [/low[- ]poly|voxel/, "low-poly"], [/hand[- ]drawn|illustrat/, "hand-drawn"], [/anime|manga/, "anime"], [/realistic|photoreal/, "realistic"], [/cartoon|toon/, "cartoon"], [/vector|flat design/, "vector-flat"], [/isometric/, "isometric"], [/neon|cyberpunk/, "neon-cyberpunk"]], "stylized");
  const definitions: Array<Omit<GenerationTask, "state">> = [
    { id: "brief", role: "producer", title: "Resolve game brief", description: "Extract core loop, audience, scope, constraints and acceptance criteria.", dependsOn: [] },
    { id: "design", role: "designer", title: "Design gameplay system", description: `Define ${genre} mechanics, progression, controls and feedback loops.`, dependsOn: ["brief"] },
    { id: "architecture", role: "engineer", title: "Choose runtime architecture", description: `Select ${dimension} rendering path and bounded device budgets for ${target}.`, dependsOn: ["brief"] },
    { id: "scene", role: "engineer", title: "Build scene graph", description: "Create scene hierarchy, entities, camera and interaction hooks.", dependsOn: ["design", "architecture"] },
    { id: "art", role: "artist", title: "Create visual direction", description: `Apply ${style} art direction, palette, asset list and animation plan.`, dependsOn: ["design"] },
    { id: "audio", role: "audio", title: "Compose audio plan", description: "Define music layers, ambience, UI feedback and SFX event map.", dependsOn: ["design"] },
    { id: "controls", role: "designer", title: "Configure input scheme", description: "Generate editable touch, keyboard and gamepad action bindings.", dependsOn: ["design"] },
    { id: "assemble", role: "engineer", title: "Assemble playable slice", description: "Connect scenes, gameplay, assets, audio and input using runtime contracts.", dependsOn: ["scene", "art", "audio", "controls"] },
    { id: "qa", role: "qa", title: "Validate and test", description: "Check project schema, missing assets, input reachability and failure paths.", dependsOn: ["assemble"] },
    { id: "optimize", role: "optimizer", title: "Optimize target build", description: "Budget draw calls, textures, audio voices, particles, memory and frame pacing.", dependsOn: ["qa"] },
  ];
  if (definitions.length > MAX_TASKS) return { ok: false, error: "TASK_LIMIT_EXCEEDED" };
  return { ok: true, plan: { schemaVersion: 1, prompt: prompt.trim(), genre, style, dimension, target, tasks: definitions.map(task => ({ ...task, state: "queued" })) } };
}
export interface AgentProvider { run(task: GenerationTask, plan: GenerationPlan, signal: AbortSignal): Promise<Readonly<Record<string, unknown>>>; }
export type PipelineEvent = Readonly<{ taskId: string; state: TaskState; output?: Readonly<Record<string, unknown>>; error?: string }>;
const MAX_OUTPUT_BYTES = 65_536;
function sanitizeAgentOutput(value: unknown): Readonly<Record<string, unknown>> | null {
  let budget = MAX_OUTPUT_BYTES;
  const visit = (input: unknown, depth: number): unknown => {
    if (depth > 12) throw new TypeError("OUTPUT_DEPTH_LIMIT");
    if (input === null || typeof input === "boolean") { budget -= 5; return input; }
    if (typeof input === "number") { if (!Number.isFinite(input)) throw new TypeError("OUTPUT_NON_FINITE_NUMBER"); budget -= 16; return input; }
    if (typeof input === "string") { if (input.length > 8192) throw new TypeError("OUTPUT_STRING_LIMIT"); budget -= input.length * 2 + 2; return input; }
    if (Array.isArray(input)) {
      if (input.length > 512) throw new TypeError("OUTPUT_ARRAY_LIMIT");
      const result: unknown[] = []; for (const item of input) result.push(visit(item, depth + 1)); return result;
    }
    if (typeof input !== "object") throw new TypeError("OUTPUT_TYPE_UNSUPPORTED");
    const proto = Object.getPrototypeOf(input);
    if (proto !== Object.prototype && proto !== null) throw new TypeError("OUTPUT_OBJECT_PROTOTYPE");
    const descriptors = Object.getOwnPropertyDescriptors(input);
    const keys = Object.keys(descriptors);
    if (keys.length > 128) throw new TypeError("OUTPUT_OBJECT_KEY_LIMIT");
    const result: Record<string, unknown> = Object.create(null);
    for (const key of keys) {
      if (key === "__proto__" || key === "prototype" || key === "constructor") throw new TypeError("OUTPUT_DANGEROUS_KEY");
      const descriptor = descriptors[key]!;
      if (!("value" in descriptor) || descriptor.get || descriptor.set) throw new TypeError("OUTPUT_ACCESSOR_REJECTED");
      budget -= key.length * 2 + 4; result[key] = visit(descriptor.value, depth + 1);
    }
    return result;
  };
  try {
    const sanitized = visit(value, 0);
    if (!sanitized || typeof sanitized !== "object" || Array.isArray(sanitized) || budget < 0) return null;
    const encoded = JSON.stringify(sanitized);
    if (encoded.length * 2 > MAX_OUTPUT_BYTES) return null;
    return sanitized as Readonly<Record<string, unknown>>;
  } catch { return null; }
}

/** Sequential scheduler: one task at a time to bound resource use on low-end devices. */
export async function executeGenerationPlan(plan: GenerationPlan, provider: AgentProvider, signal: AbortSignal, onEvent: (event: PipelineEvent) => void = () => undefined): Promise<PlanResult> {
  if (!plan || plan.schemaVersion !== 1 || typeof plan.prompt !== "string" || !plan.prompt.trim() || plan.prompt.length > MAX_PROMPT || typeof plan.genre !== "string" || plan.genre.length > 64 || typeof plan.style !== "string" || plan.style.length > 64 || !["2d","2.5d","3d"].includes(plan.dimension) || !["mobile-low","mobile","desktop","web"].includes(plan.target) || !Array.isArray(plan.tasks) || plan.tasks.length < 1 || plan.tasks.length > MAX_TASKS || !provider || typeof provider.run !== "function" || !signal || typeof signal.aborted !== "boolean") return { ok: false, error: "INVALID_PLAN" };
  const tasks = plan.tasks as readonly GenerationTask[];
  const known = new Set<string>();
  for (const task of tasks) {
    if (!task || typeof task.id !== "string" || !SAFE_ID.test(task.id) || known.has(task.id) || !["producer","designer","engineer","artist","audio","qa","optimizer"].includes(task.role) || typeof task.title !== "string" || !task.title.trim() || task.title.length > 160 || typeof task.description !== "string" || task.description.length > 1000 || !["queued","running","done","failed","skipped"].includes(task.state) || !Array.isArray(task.dependsOn) || task.dependsOn.length > MAX_TASKS || !task.dependsOn.every(id => typeof id === "string" && SAFE_ID.test(id)) || new Set(task.dependsOn).size !== task.dependsOn.length || task.dependsOn.includes(task.id)) return { ok: false, error: "INVALID_TASK_GRAPH" };
    known.add(task.id);
  }
  for (const task of tasks) if (!task.dependsOn.every(id => known.has(id))) return { ok: false, error: "INVALID_TASK_GRAPH" };

  // Sequential stable topological scheduler: independent tasks run in authored order,
  // but a task may safely appear before one of its dependencies in an imported plan.
  const pending = tasks.slice();
  const completed = new Set<string>();
  const outputs: Record<string, Readonly<Record<string, unknown>>> = Object.create(null);
  const emit = (event: PipelineEvent) => { try { onEvent(event); } catch { /* UI event handlers must not abort provider work. */ } };
  const skipRemaining = (reason: string) => { for (const task of pending) emit({ taskId: task.id, state: "skipped", error: reason }); };

  while (pending.length) {
    if (signal.aborted) { skipRemaining("ABORTED"); return { ok: false, error: "ABORTED" }; }
    const readyIndex = pending.findIndex(task => task.dependsOn.every(id => completed.has(id)));
    if (readyIndex < 0) {
      skipRemaining("DEPENDENCY_CYCLE_OR_BLOCKED");
      return { ok: false, error: "TASK_GRAPH_CYCLE" };
    }
    const [task] = pending.splice(readyIndex, 1);
    if (!task) return { ok: false, error: "INVALID_TASK_GRAPH" };
    emit({ taskId: task.id, state: "running" });
    try {
      const outputSnapshot = Object.freeze({ ...outputs });
      const activePlan: GenerationPlan = { ...plan, outputs: outputSnapshot };
      const rawOutput = await provider.run(task, activePlan, signal);
      if (signal.aborted) { emit({ taskId: task.id, state: "skipped", error: "ABORTED" }); skipRemaining("ABORTED"); return { ok: false, error: "ABORTED" }; }
      const output = sanitizeAgentOutput(rawOutput);
      if (!output) { emit({ taskId: task.id, state: "failed", error: "INVALID_AGENT_OUTPUT" }); skipRemaining("UPSTREAM_TASK_FAILED"); return { ok: false, error: `INVALID_AGENT_OUTPUT:${task.id}` }; }
      outputs[task.id] = output;
      completed.add(task.id);
      emit({ taskId: task.id, state: "done", output });
    } catch (error) {
      const message = error instanceof Error ? error.message.slice(0, 240) : "AGENT_FAILED";
      emit({ taskId: task.id, state: "failed", error: message });
      skipRemaining("UPSTREAM_TASK_FAILED");
      return { ok: false, error: `TASK_FAILED:${task.id}` };
    }
  }
  return { ok: true, plan: { ...plan, outputs: Object.freeze({ ...outputs }), tasks: tasks.map(task => ({ ...task, state: "done" })) } };
}
