/** Serializable, editable action map shared by touch, keyboard and gamepad adapters. */
export type InputDevice = "touch" | "keyboard" | "gamepad";
export type InputBinding = Readonly<{ device: InputDevice; code: string; scale?: number }>;
export type ActionBinding = Readonly<{ action: string; bindings: readonly InputBinding[] }>;
export type ControllerMap = Readonly<{ schemaVersion: 1; deadzone: number; actions: readonly ActionBinding[] }>;
const ACTION = /^[a-zA-Z][a-zA-Z0-9_.-]{0,47}$/;
const CODE = /^[a-zA-Z0-9_.:-]{1,64}$/;
export function validateControllerMap(value: unknown): value is ControllerMap {
  if (!value || typeof value !== "object") return false;
  const map = value as ControllerMap;
  if (map.schemaVersion !== 1 || !Number.isFinite(map.deadzone) || map.deadzone < 0 || map.deadzone > 0.5 || !Array.isArray(map.actions) || map.actions.length > 128) return false;
  const actions = new Set<string>();
  for (const entry of map.actions) {
    if (!entry || !ACTION.test(entry.action) || actions.has(entry.action) || !Array.isArray(entry.bindings) || entry.bindings.length > 12) return false;
    actions.add(entry.action);
    for (const binding of entry.bindings) if (!binding || !["touch", "keyboard", "gamepad"].includes(binding.device) || !CODE.test(binding.code) || (binding.scale !== undefined && (!Number.isFinite(binding.scale) || Math.abs(binding.scale) > 1))) return false;
  }
  return true;
}
export function remapAction(map: ControllerMap, action: string, bindings: readonly InputBinding[]): ControllerMap | null {
  if (!validateControllerMap(map) || !ACTION.test(action)) return null;
  const next = map.actions.some(item => item.action === action)
    ? map.actions.map(item => item.action === action ? { ...item, bindings: [...bindings] } : item)
    : [...map.actions, { action, bindings: [...bindings] }];
  const candidate = { ...map, actions: next };
  return validateControllerMap(candidate) ? candidate : null;
}
export function normalizeAxis(value: number, deadzone: number): number {
  if (!Number.isFinite(value) || !Number.isFinite(deadzone) || deadzone < 0 || deadzone > 0.5) return 0;
  const clamped = Math.max(-1, Math.min(1, value));
  const magnitude = Math.abs(clamped);
  return magnitude <= deadzone ? 0 : Math.sign(clamped) * ((magnitude - deadzone) / (1 - deadzone));
}
export const DEFAULT_CONTROLLER_MAP: ControllerMap = {
  schemaVersion: 1, deadzone: 0.18,
  actions: [
    { action: "move.left", bindings: [{ device: "keyboard", code: "ArrowLeft" }, { device: "touch", code: "virtual-left" }, { device: "gamepad", code: "axis-0-negative" }] },
    { action: "move.right", bindings: [{ device: "keyboard", code: "ArrowRight" }, { device: "touch", code: "virtual-right" }, { device: "gamepad", code: "axis-0-positive" }] },
    { action: "jump", bindings: [{ device: "keyboard", code: "Space" }, { device: "touch", code: "button-a" }, { device: "gamepad", code: "button-0" }] },
    { action: "action.primary", bindings: [{ device: "keyboard", code: "Enter" }, { device: "touch", code: "button-primary" }, { device: "gamepad", code: "button-1" }] },
  ],
};

/** Read a standard-mapped Gamepad snapshot into logical actions; call from the host input loop. */
export function readGamepadActions(map: ControllerMap, gamepad: Pick<Gamepad, "buttons" | "axes" | "mapping">): ReadonlySet<string> {
  const active = new Set<string>();
  if (!validateControllerMap(map) || gamepad.mapping !== "standard") return active;
  for (const entry of map.actions) {
    for (const binding of entry.bindings) {
      if (binding.device !== "gamepad") continue;
      const button = /^button-(\d+)$/.exec(binding.code);
      const axis = /^axis-(\d+)-(negative|positive)$/.exec(binding.code);
      if (button) {
        const state = gamepad.buttons[Number(button[1])];
        if (state && (state.pressed || state.value >= 0.5)) { active.add(entry.action); break; }
      } else if (axis) {
        const value = gamepad.axes[Number(axis[1])] ?? 0;
        const normalized = normalizeAxis(value, map.deadzone);
        if ((axis[2] === "negative" && normalized < -0.1) || (axis[2] === "positive" && normalized > 0.1)) { active.add(entry.action); break; }
      }
    }
  }
  return active;
}
