/** Offline glTF 2.0 envelope and reference preflight. Full Khronos validation is injectable. */
export type GltfIssue = Readonly<{ severity: "error" | "warning"; code: string; path: string; message: string }>;
export type GltfPreflightReport = Readonly<{ ok: boolean; format: "gltf-json" | "glb" | "unknown"; bytes: number; issues: readonly GltfIssue[]; stats: Readonly<{ nodes: number; meshes: number; materials: number; accessors: number; buffers: number }> }>;
export type KhronosValidationMessage = Readonly<{ code?: string; message?: string; severity?: number; pointer?: string }>;
export interface KhronosGltfValidatorAdapter { validateBytes(bytes: Uint8Array, options?: Readonly<Record<string, unknown>>): Promise<Readonly<{ issues?: readonly KhronosValidationMessage[]; errors?: number; warnings?: number }>>; }
const MAX_BYTES = 32 * 1024 * 1024;
const MAX_JSON_DEPTH = 64;
const MAX_ELEMENTS = 100_000;

function u32(data: Uint8Array, offset: number): number { return (data[offset]! | (data[offset+1]! << 8) | (data[offset+2]! << 16) | (data[offset+3]! << 24)) >>> 0; }
function issue(list: GltfIssue[], severity: GltfIssue["severity"], code: string, path: string, message: string): void { list.push(Object.freeze({ severity, code, path, message })); }
function plainObject(value: unknown): value is Record<string, unknown> { return !!value && typeof value === "object" && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null); }
function checkDepth(value: unknown, depth = 0, seen = new Set<object>()): boolean {
  if (depth > MAX_JSON_DEPTH) return false;
  if (!value || typeof value !== "object") return true;
  if (seen.has(value)) return false;
  seen.add(value);
  let valid = true;
  if (Array.isArray(value)) {
    if (value.length > MAX_ELEMENTS) valid = false;
    else for (const item of value) if (!checkDepth(item, depth + 1, seen)) { valid = false; break; }
  } else {
    const descriptors = Object.getOwnPropertyDescriptors(value);
    const keys = Object.keys(descriptors);
    if (keys.length > MAX_ELEMENTS) valid = false;
    else for (const key of keys) {
      const descriptor = descriptors[key]!;
      if (key === "__proto__" || key === "constructor" || !("value" in descriptor) || descriptor.get || descriptor.set || !checkDepth(descriptor.value, depth + 1, seen)) { valid = false; break; }
    }
  }
  seen.delete(value);
  return valid;
}
function parseContainer(bytes: Uint8Array): { format: GltfPreflightReport["format"]; json: string | null; binBytes: number } {
  if (bytes.length >= 4 && bytes[0] === 0x67 && bytes[1] === 0x6c && bytes[2] === 0x54 && bytes[3] === 0x46) {
    if (bytes.length < 20 || u32(bytes,4) !== 2 || u32(bytes,8) !== bytes.length) return { format: "glb", json: null, binBytes: 0 };
    let offset = 12; let json: string | null = null; let binBytes = 0; let chunks = 0;
    while (offset + 8 <= bytes.length && chunks++ < 32) {
      const length = u32(bytes,offset); const type = u32(bytes,offset+4); offset += 8;
      if (length % 4 !== 0 || length > bytes.length - offset) return { format: "glb", json: null, binBytes: 0 };
      if (chunks === 1 && type !== 0x4e4f534a) return { format: "glb", json: null, binBytes: 0 };
      if (type === 0x4e4f534a && json === null) {
        try { json = new TextDecoder("utf-8", { fatal: true }).decode(bytes.subarray(offset,offset+length)).replace(/[\u0000\u0020]+$/g, ""); } catch { return { format: "glb", json: null, binBytes: 0 }; }
      } else if (type === 0x004e4942) binBytes += length;
      offset += length;
    }
    return offset === bytes.length && json !== null ? { format: "glb", json, binBytes } : { format: "glb", json: null, binBytes: 0 };
  }
  try { return { format: "gltf-json", json: new TextDecoder("utf-8", { fatal: true }).decode(bytes), binBytes: 0 }; }
  catch { return { format: "unknown", json: null, binBytes: 0 }; }
}

export function preflightGltf(bytes: Uint8Array): GltfPreflightReport {
  const issues: GltfIssue[] = [];
  const emptyStats = Object.freeze({ nodes: 0, meshes: 0, materials: 0, accessors: 0, buffers: 0 });
  if (!(bytes instanceof Uint8Array) || bytes.byteLength < 1 || bytes.byteLength > MAX_BYTES) {
    issue(issues,"error","GLTF_FILE_SIZE_LIMIT","","Input must be a Uint8Array of 1 byte to 32 MiB.");
    return Object.freeze({ ok:false, format:"unknown", bytes:bytes?.byteLength ?? 0, issues:Object.freeze(issues), stats:emptyStats });
  }
  const container = parseContainer(bytes);
  if (!container.json) {
    issue(issues,"error","GLTF_CONTAINER_INVALID","","Invalid glTF JSON or GLB 2.0 header/chunk structure.");
    return Object.freeze({ ok:false, format:container.format, bytes:bytes.byteLength, issues:Object.freeze(issues), stats:emptyStats });
  }
  let root: unknown;
  try { root = JSON.parse(container.json); } catch { issue(issues,"error","GLTF_JSON_INVALID","","JSON parsing failed."); }
  if (!root || !plainObject(root) || !checkDepth(root)) {
    issue(issues,"error","GLTF_ROOT_INVALID","","Root must be a bounded plain JSON object without excessive depth or accessors.");
    return Object.freeze({ ok:false, format:container.format, bytes:bytes.byteLength, issues:Object.freeze(issues), stats:emptyStats });
  }
  const gltf = root as Record<string, unknown>;
  const asset = plainObject(gltf.asset) ? gltf.asset : null;
  if (!asset || asset.version !== "2.0") issue(issues,"error","GLTF_VERSION_UNSUPPORTED","/asset/version","Only glTF 2.0 assets are accepted.");
  const list = (key: string): unknown[] => {
    const value = gltf[key];
    if (value === undefined) return [];
    if (!Array.isArray(value) || value.length > MAX_ELEMENTS) { issue(issues,"error","GLTF_ARRAY_LIMIT",`/${key}`,"Expected a bounded array."); return []; }
    return value;
  };
  const buffers = list("buffers"); const views = list("bufferViews"); const accessors = list("accessors");
  const nodes = list("nodes"); const meshes = list("meshes"); const materials = list("materials");
  const bufferLengths: number[] = [];
  for (let i=0;i<buffers.length;i++) {
    const buffer = buffers[i];
    if (!plainObject(buffer) || !Number.isSafeInteger(buffer.byteLength) || Number(buffer.byteLength) < 0) { issue(issues,"error","GLTF_BUFFER_INVALID",`/buffers/${i}`,"Buffer byteLength must be a non-negative safe integer."); bufferLengths.push(0); continue; }
    bufferLengths.push(Number(buffer.byteLength));
    if (typeof buffer.uri === "string") {
      if (/^(?:https?:|file:|javascript:|data:)/i.test(buffer.uri)) issue(issues,"warning","GLTF_EXTERNAL_OR_EMBEDDED_URI",`/buffers/${i}/uri`,"External or embedded buffer URI requires a separate controlled resource pipeline.");
      else if (container.format === "glb") issue(issues,"warning","GLB_BUFFER_URI_PRESENT",`/buffers/${i}/uri`,"GLB buffer URI is unusual; validate resource mapping with Khronos Validator.");
    } else if (container.format === "gltf-json") issue(issues,"warning","GLTF_BUFFER_RESOURCE_MISSING",`/buffers/${i}/uri`,"JSON glTF buffer has no URI; standalone binary data is not embedded.");
  }
  if (container.format === "glb" && buffers.length > 0) {
    const primary = buffers[0];
    if (plainObject(primary) && primary.uri === undefined) {
      const declared = Number(primary.byteLength);
      if (container.binBytes < declared || container.binBytes - declared > 3) issue(issues,"error","GLB_BINARY_CHUNK_LENGTH_MISMATCH","/buffers/0/byteLength","GLB BIN chunk length must cover the primary buffer with at most three padding bytes.");
    } else if (container.binBytes > 0) issue(issues,"warning","GLB_BINARY_CHUNK_UNREFERENCED","/buffers","A BIN chunk exists but the primary buffer does not declare the expected implicit resource.");
    if (buffers.length > 1) issue(issues,"warning","GLB_MULTIPLE_BUFFERS","/buffers","Additional buffers need explicit resource mapping outside the single GLB BIN chunk.");
  }
  for (let i=0;i<views.length;i++) {
    const view = views[i];
    if (!plainObject(view) || !Number.isInteger(view.buffer) || Number(view.buffer)<0 || Number(view.buffer)>=bufferLengths.length || !Number.isSafeInteger(view.byteLength) || Number(view.byteLength)<0 || !Number.isSafeInteger(view.byteOffset ?? 0) || Number(view.byteOffset ?? 0)<0) { issue(issues,"error","GLTF_BUFFER_VIEW_INVALID",`/bufferViews/${i}`,"Buffer view indices, offsets and lengths are invalid."); continue; }
    const end = Number(view.byteOffset ?? 0) + Number(view.byteLength);
    if (!Number.isSafeInteger(end) || end > bufferLengths[Number(view.buffer)]!) issue(issues,"error","GLTF_BUFFER_VIEW_OUT_OF_RANGE",`/bufferViews/${i}`,"Buffer view exceeds its referenced buffer length.");
  }
  for (let i=0;i<accessors.length;i++) {
    const accessor = accessors[i];
    if (!plainObject(accessor) || !Number.isSafeInteger(accessor.count) || Number(accessor.count)<1 || ![5120,5121,5122,5123,5125,5126].includes(Number(accessor.componentType)) || !["SCALAR","VEC2","VEC3","VEC4","MAT2","MAT3","MAT4"].includes(String(accessor.type))) issue(issues,"error","GLTF_ACCESSOR_INVALID",`/accessors/${i}`,"Accessor count, componentType or type is invalid.");
    if (plainObject(accessor) && accessor.bufferView !== undefined && (!Number.isInteger(accessor.bufferView) || Number(accessor.bufferView)<0 || Number(accessor.bufferView)>=views.length)) issue(issues,"error","GLTF_ACCESSOR_VIEW_MISSING",`/accessors/${i}/bufferView`,"Accessor references a missing buffer view.");
  }
  const childOwners = new Map<number,number>();
  const nodeEdges: number[][] = Array.from({length:nodes.length},()=>[]);
  for (let i=0;i<nodes.length;i++) {
    const node = nodes[i];
    if (!plainObject(node)) { issue(issues,"error","GLTF_NODE_INVALID",`/nodes/${i}`,"Node must be an object."); continue; }
    if (node.mesh !== undefined && (!Number.isInteger(node.mesh) || Number(node.mesh)<0 || Number(node.mesh)>=meshes.length)) issue(issues,"error","GLTF_NODE_MESH_MISSING",`/nodes/${i}/mesh`,"Node references a missing mesh.");
    if (node.children !== undefined) {
      if (!Array.isArray(node.children) || node.children.length > MAX_ELEMENTS) issue(issues,"error","GLTF_NODE_CHILDREN_INVALID",`/nodes/${i}/children`,"Children must be a bounded array.");
      else for (const child of node.children) {
        if (!Number.isInteger(child) || Number(child)<0 || Number(child)>=nodes.length) issue(issues,"error","GLTF_NODE_CHILD_MISSING",`/nodes/${i}/children`,"Node references a missing child.");
        else { const childIndex=Number(child); childOwners.set(childIndex,(childOwners.get(childIndex) ?? 0)+1); nodeEdges[i]!.push(childIndex); }
      }
    }
  }
  for (const [child, owners] of childOwners) if (owners > 1) issue(issues,"error","GLTF_NODE_MULTIPLE_PARENTS",`/nodes/${child}`,"A node cannot have more than one parent.");
  const nodeColor = new Uint8Array(nodes.length);
  for (let rootIndex=0;rootIndex<nodes.length;rootIndex++) {
    if (nodeColor[rootIndex] !== 0) continue;
    const stackNodes=[rootIndex], stackOffsets=[0]; nodeColor[rootIndex]=1;
    while (stackNodes.length) {
      const top=stackNodes.length-1, current=stackNodes[top]!, children=nodeEdges[current]!;
      if (stackOffsets[top]! >= children.length) { nodeColor[current]=2; stackNodes.pop(); stackOffsets.pop(); continue; }
      const child=children[stackOffsets[top]!]; stackOffsets[top]=stackOffsets[top]!+1;
      if (nodeColor[child] === 1) { issue(issues,"error","GLTF_NODE_CYCLE",`/nodes/${current}/children`,`Node hierarchy contains a cycle through node ${child}.`); }
      else if (nodeColor[child] === 0) { nodeColor[child]=1; stackNodes.push(child); stackOffsets.push(0); }
    }
  }
  for (let i=0;i<meshes.length;i++) if (!plainObject(meshes[i]) || !Array.isArray((meshes[i] as Record<string,unknown>).primitives)) issue(issues,"error","GLTF_MESH_INVALID",`/meshes/${i}`,"Mesh must contain a primitives array.");
  const errors = issues.some(item => item.severity === "error");
  return Object.freeze({ ok:!errors, format:container.format, bytes:bytes.byteLength, issues:Object.freeze(issues), stats:Object.freeze({ nodes:nodes.length, meshes:meshes.length, materials:materials.length, accessors:accessors.length, buffers:buffers.length }) });
}

/** Uses the official Khronos validator when injected by a build/host adapter, without bundling it into the mobile runtime. */
export async function validateGltfWithKhronos(bytes: Uint8Array, adapter: KhronosGltfValidatorAdapter): Promise<GltfPreflightReport> {
  const base = preflightGltf(bytes);
  if (!base.ok) return base;
  if (!adapter || typeof adapter.validateBytes !== "function") return Object.freeze({ ...base, issues:Object.freeze([...base.issues,Object.freeze({ severity:"warning" as const, code:"KHRONOS_VALIDATOR_NOT_CONFIGURED", path:"", message:"Structural preflight passed; full Khronos glTF Validator was not provided." })]) });
  try {
    const result = await adapter.validateBytes(bytes);
    const issues = [...base.issues];
    for (const item of result.issues ?? []) issues.push(Object.freeze({ severity:item.severity === 0 ? "error" : "warning", code:String(item.code ?? "KHRONOS_ISSUE").slice(0,80), path:String(item.pointer ?? "").slice(0,512), message:String(item.message ?? "Validation issue").slice(0,1000) }));
    const ok = !issues.some(item=>item.severity === "error");
    return Object.freeze({ ...base, ok, issues:Object.freeze(issues) });
  } catch {
    return Object.freeze({ ...base, issues:Object.freeze([...base.issues,Object.freeze({severity:"warning" as const,code:"KHRONOS_VALIDATOR_FAILED",path:"",message:"Khronos validator execution failed; structural preflight report retained."})]) });
  }
}
