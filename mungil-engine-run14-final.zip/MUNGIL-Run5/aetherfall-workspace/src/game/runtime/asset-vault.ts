import type { ImportedAsset } from "./asset-pipeline.ts";

export type AssetVaultTier = 0 | 1 | 2;
export type AssetVaultLimits = Readonly<{ maxBytes: number; maxSingleBytes: number; maxEntries: number }>;
export type AssetVaultEntry = Readonly<{
  id: string;
  path: string;
  kind: ImportedAsset["kind"];
  mime: string;
  bytes: number;
  sha256: string;
  width?: number;
  height?: number;
  createdAt: number;
  lastAccessedAt: number;
  pinned: boolean;
  blob: Blob;
}>;
export type AssetVaultSummary = Readonly<{ entries: number; bytes: number; maxBytes: number; maxEntries: number }>;
export type AssetVaultResult<T> = Readonly<{ ok: true; value: T }> | Readonly<{ ok: false; error: string }>;

const DEFAULT_LIMITS: Readonly<Record<AssetVaultTier, AssetVaultLimits>> = Object.freeze({
  0: Object.freeze({ maxBytes: 24 * 1024 * 1024, maxSingleBytes: 8 * 1024 * 1024, maxEntries: 128 }),
  1: Object.freeze({ maxBytes: 48 * 1024 * 1024, maxSingleBytes: 16 * 1024 * 1024, maxEntries: 256 }),
  2: Object.freeze({ maxBytes: 96 * 1024 * 1024, maxSingleBytes: 32 * 1024 * 1024, maxEntries: 512 }),
});
const DB_NAME = "mungil-asset-vault";
const DB_VERSION = 1;
const STORE = "assets";

export function assetVaultLimits(tier: AssetVaultTier): AssetVaultLimits { return DEFAULT_LIMITS[tier]; }

/** Pure bounded LRU planner. Pinned entries and the incoming asset are never evicted. */
export function planAssetVaultEviction(
  entries: readonly Pick<AssetVaultEntry, "id" | "bytes" | "lastAccessedAt" | "pinned">[],
  incoming: Readonly<{ id: string; bytes: number }>,
  limits: AssetVaultLimits,
): AssetVaultResult<readonly string[]> {
  if (!Number.isSafeInteger(limits.maxBytes) || limits.maxBytes < 1 || !Number.isSafeInteger(limits.maxSingleBytes) || limits.maxSingleBytes < 1 || !Number.isSafeInteger(limits.maxEntries) || limits.maxEntries < 1 || !Number.isSafeInteger(incoming.bytes) || incoming.bytes < 0) return { ok: false, error: "INVALID_VAULT_LIMITS" };
  if (incoming.bytes > limits.maxSingleBytes || incoming.bytes > limits.maxBytes) return { ok: false, error: "VAULT_SINGLE_ASSET_LIMIT" };
  const seen = new Set<string>(); let total = 0;
  for (const entry of entries) {
    if (!entry || typeof entry.id !== "string" || !entry.id || seen.has(entry.id) || !Number.isSafeInteger(entry.bytes) || entry.bytes < 0 || !Number.isFinite(entry.lastAccessedAt)) return { ok: false, error: "INVALID_VAULT_ENTRY" };
    seen.add(entry.id); total += entry.bytes;
    if (!Number.isSafeInteger(total)) return { ok: false, error: "VAULT_SIZE_OVERFLOW" };
  }
  const replacing = entries.find(entry => entry.id === incoming.id);
  let projectedBytes = total - (replacing?.bytes ?? 0) + incoming.bytes;
  let projectedEntries = entries.length + (replacing ? 0 : 1);
  const candidates = entries.filter(entry => entry.id !== incoming.id && !entry.pinned).slice().sort((a, b) => a.lastAccessedAt - b.lastAccessedAt || a.id.localeCompare(b.id));
  const evict: string[] = [];
  for (const candidate of candidates) {
    if (projectedBytes <= limits.maxBytes && projectedEntries <= limits.maxEntries) break;
    projectedBytes -= candidate.bytes; projectedEntries--; evict.push(candidate.id);
  }
  if (projectedBytes > limits.maxBytes || projectedEntries > limits.maxEntries) return { ok: false, error: "VAULT_CAPACITY_PINNED_OR_EXHAUSTED" };
  return { ok: true, value: Object.freeze(evict) };
}

function requestValue<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("INDEXEDDB_REQUEST_FAILED"));
  });
}
function transactionDone(transaction: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onabort = () => reject(transaction.error ?? new Error("INDEXEDDB_TRANSACTION_ABORTED"));
    transaction.onerror = () => reject(transaction.error ?? new Error("INDEXEDDB_TRANSACTION_FAILED"));
  });
}
function isValidImportedAsset(asset: ImportedAsset, blob: Blob, limits: AssetVaultLimits): boolean {
  return !!asset && typeof asset.id === "string" && /^[A-Za-z0-9_-]{1,80}$/.test(asset.id) && typeof asset.path === "string" && asset.path.length <= 240 && !asset.path.includes("..") && !asset.path.startsWith("/") && Number.isSafeInteger(asset.bytes) && asset.bytes > 0 && asset.bytes <= limits.maxSingleBytes && blob.size === asset.bytes && typeof asset.sha256 === "string" && /^[a-f0-9]{64}$/i.test(asset.sha256) && typeof asset.mime === "string";
}

/** Offline IndexedDB blob vault. No network, URL fetching, or implicit upload is performed. */
export class AssetVault {
  private database: IDBDatabase | null = null;
  private opening: Promise<IDBDatabase> | null = null;
  private readonly limits: AssetVaultLimits;
  private readonly indexedDBFactory: IDBFactory | undefined;
  private readonly estimateStorage: (() => Promise<StorageEstimate>) | undefined;
  private writeQueue: Promise<void> = Promise.resolve();

  private exclusive<T>(work: () => Promise<T>): Promise<T> {
    const result = this.writeQueue.then(work, work);
    this.writeQueue = result.then(() => undefined, () => undefined);
    return result;
  }

  constructor(options: Readonly<{ tier?: AssetVaultTier; limits?: AssetVaultLimits; indexedDB?: IDBFactory; estimateStorage?: () => Promise<StorageEstimate> }> = {}) {
    this.limits = options.limits ?? assetVaultLimits(options.tier ?? 0);
    this.indexedDBFactory = options.indexedDB ?? globalThis.indexedDB;
    this.estimateStorage = options.estimateStorage ?? (globalThis.navigator?.storage?.estimate ? () => globalThis.navigator.storage.estimate() : undefined);
  }

  private async db(): Promise<IDBDatabase> {
    if (this.database) return this.database;
    if (!this.indexedDBFactory) throw new Error("INDEXEDDB_UNAVAILABLE");
    if (!this.opening) this.opening = new Promise<IDBDatabase>((resolve, reject) => {
      const request = this.indexedDBFactory!.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE)) {
          const store = db.createObjectStore(STORE, { keyPath: "id" });
          store.createIndex("lastAccessedAt", "lastAccessedAt", { unique: false });
        }
      };
      request.onsuccess = () => { this.database = request.result; this.database.onversionchange = () => this.close(); resolve(request.result); };
      request.onerror = () => reject(request.error ?? new Error("INDEXEDDB_OPEN_FAILED"));
      request.onblocked = () => reject(new Error("INDEXEDDB_OPEN_BLOCKED"));
    }).finally(() => { this.opening = null; });
    const opening = this.opening;
    if (!opening) throw new Error("INDEXEDDB_OPEN_FAILED");
    return opening;
  }

  async put(asset: ImportedAsset, blob: Blob, options: Readonly<{ pinned?: boolean }> = {}): Promise<AssetVaultResult<AssetVaultEntry>> {
    if (!isValidImportedAsset(asset, blob, this.limits)) return { ok: false, error: "INVALID_ASSET_OR_BLOB" };
    return this.exclusive(async () => {
    try {
      if (this.estimateStorage) {
        const estimate = await this.estimateStorage();
        if (Number.isFinite(estimate.quota) && Number.isFinite(estimate.usage) && (estimate.quota! - estimate.usage! < asset.bytes)) return { ok: false, error: "BROWSER_STORAGE_QUOTA_LOW" };
      }
      const db = await this.db();
      const readTx = db.transaction(STORE, "readonly");
      const existing = await requestValue(readTx.objectStore(STORE).getAll()) as AssetVaultEntry[];
      await transactionDone(readTx);
      const plan = planAssetVaultEviction(existing, { id: asset.id, bytes: asset.bytes }, this.limits);
      if (!plan.ok) return plan;
      const now = Date.now();
      const entry: AssetVaultEntry = Object.freeze({ id: asset.id, path: asset.path, kind: asset.kind, mime: asset.mime, bytes: asset.bytes, sha256: asset.sha256, ...(asset.width ? { width: asset.width } : {}), ...(asset.height ? { height: asset.height } : {}), createdAt: existing.find(item => item.id === asset.id)?.createdAt ?? now, lastAccessedAt: now, pinned: options.pinned ?? existing.find(item => item.id === asset.id)?.pinned ?? false, blob });
      const tx = db.transaction(STORE, "readwrite");
      const store = tx.objectStore(STORE);
      for (const id of plan.value) store.delete(id);
      store.put(entry);
      await transactionDone(tx);
      return { ok: true, value: entry };
    } catch (error) { return { ok: false, error: error instanceof Error ? error.message : "VAULT_WRITE_FAILED" }; }
    });
  }

  async get(id: string): Promise<AssetVaultResult<AssetVaultEntry | null>> {
    if (typeof id !== "string" || !/^[A-Za-z0-9_-]{1,80}$/.test(id)) return { ok: false, error: "INVALID_ASSET_ID" };
    try {
      const db = await this.db(); const tx = db.transaction(STORE, "readwrite"); const store = tx.objectStore(STORE);
      const entry = await requestValue(store.get(id)) as AssetVaultEntry | undefined;
      if (entry) store.put({ ...entry, lastAccessedAt: Date.now() });
      await transactionDone(tx);
      return { ok: true, value: entry ?? null };
    } catch (error) { return { ok: false, error: error instanceof Error ? error.message : "VAULT_READ_FAILED" }; }
  }

  async list(): Promise<AssetVaultResult<readonly Omit<AssetVaultEntry, "blob">[]>> {
    try {
      const db = await this.db(); const tx = db.transaction(STORE, "readonly");
      const entries = await requestValue(tx.objectStore(STORE).getAll()) as AssetVaultEntry[]; await transactionDone(tx);
      return { ok: true, value: Object.freeze(entries.sort((a, b) => b.lastAccessedAt - a.lastAccessedAt).map(({ blob: _blob, ...metadata }) => Object.freeze(metadata))) };
    } catch (error) { return { ok: false, error: error instanceof Error ? error.message : "VAULT_LIST_FAILED" }; }
  }

  async remove(id: string): Promise<AssetVaultResult<boolean>> {
    if (typeof id !== "string" || !/^[A-Za-z0-9_-]{1,80}$/.test(id)) return { ok: false, error: "INVALID_ASSET_ID" };
    try { const db = await this.db(); const tx = db.transaction(STORE, "readwrite"); const store = tx.objectStore(STORE); const found = await requestValue(store.getKey(id)); store.delete(id); await transactionDone(tx); return { ok: true, value: found !== undefined }; }
    catch (error) { return { ok: false, error: error instanceof Error ? error.message : "VAULT_DELETE_FAILED" }; }
  }

  async setPinned(id: string, pinned: boolean): Promise<AssetVaultResult<boolean>> {
    if (typeof id !== "string" || !/^[A-Za-z0-9_-]{1,80}$/.test(id) || typeof pinned !== "boolean") return { ok: false, error: "INVALID_PIN_REQUEST" };
    try { const db = await this.db(); const tx = db.transaction(STORE, "readwrite"); const store = tx.objectStore(STORE); const entry = await requestValue(store.get(id)) as AssetVaultEntry | undefined; if (entry) store.put({ ...entry, pinned }); await transactionDone(tx); return { ok: true, value: !!entry }; }
    catch (error) { return { ok: false, error: error instanceof Error ? error.message : "VAULT_PIN_FAILED" }; }
  }

  /** Requests persistent origin storage only when the caller invokes it from an explicit user action. */
  async requestPersistentStorage(): Promise<AssetVaultResult<boolean>> {
    try {
      const storage = globalThis.navigator?.storage;
      if (!storage?.persist) return { ok: false, error: "PERSISTENT_STORAGE_UNAVAILABLE" };
      return { ok: true, value: await storage.persist() };
    } catch (error) { return { ok: false, error: error instanceof Error ? error.message : "PERSISTENT_STORAGE_REQUEST_FAILED" }; }
  }

  async summary(): Promise<AssetVaultResult<AssetVaultSummary>> {
    try { const db = await this.db(); const tx = db.transaction(STORE, "readonly"); const entries = await requestValue(tx.objectStore(STORE).getAll()) as AssetVaultEntry[]; await transactionDone(tx); return { ok: true, value: Object.freeze({ entries: entries.length, bytes: entries.reduce((sum, entry) => sum + entry.bytes, 0), maxBytes: this.limits.maxBytes, maxEntries: this.limits.maxEntries }) }; }
    catch (error) { return { ok: false, error: error instanceof Error ? error.message : "VAULT_SUMMARY_FAILED" }; }
  }

  async clearUnpinned(): Promise<AssetVaultResult<number>> {
    try { const db = await this.db(); const tx = db.transaction(STORE, "readwrite"); const store = tx.objectStore(STORE); const entries = await requestValue(store.getAll()) as AssetVaultEntry[]; const targets = entries.filter(entry => !entry.pinned); for (const entry of targets) store.delete(entry.id); await transactionDone(tx); return { ok: true, value: targets.length }; }
    catch (error) { return { ok: false, error: error instanceof Error ? error.message : "VAULT_CLEAR_FAILED" }; }
  }

  close(): void { this.database?.close(); this.database = null; }
}
