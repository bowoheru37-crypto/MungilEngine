/** Small, deterministic image-preview sizing for low-memory editor surfaces. */
export type ImagePreviewSize = Readonly<{ width: number; height: number; estimatedRgbaBytes: number }>;

export function fitImagePreview(
  width: number,
  height: number,
  options: Readonly<{ maxDimension?: number; maxPixels?: number }> = {},
): ImagePreviewSize | null {
  const maxDimension = options.maxDimension ?? 384;
  const maxPixels = options.maxPixels ?? 384 * 384;
  if (![width, height, maxDimension, maxPixels].every(Number.isSafeInteger) || width < 1 || height < 1 || maxDimension < 1 || maxPixels < 1) return null;
  const sourcePixels = width * height;
  if (!Number.isSafeInteger(sourcePixels)) return null;
  const scale = Math.min(1, maxDimension / Math.max(width, height), Math.sqrt(maxPixels / sourcePixels));
  const outWidth = Math.max(1, Math.floor(width * scale));
  const outHeight = Math.max(1, Math.floor(height * scale));
  const pixels = outWidth * outHeight;
  if (!Number.isSafeInteger(pixels) || pixels > maxPixels) return null;
  const estimatedRgbaBytes = pixels * 4;
  if (!Number.isSafeInteger(estimatedRgbaBytes)) return null;
  return Object.freeze({ width: outWidth, height: outHeight, estimatedRgbaBytes });
}
