/** Cell-based world coordinates keep GPU-facing values local while retaining JS Number precision. */
export const WORLD_CELL_METERS = 1_000;
export type WorldPoint = Readonly<{
  cellX: number; cellY: number; cellZ: number;
  offsetX: number; offsetY: number; offsetZ: number;
}>;
export type RelativeWorldPosition = Readonly<{ x: number; y: number; z: number }>;

function normalizeAxis(cell: number, offset: number): readonly [number, number] {
  if (!Number.isSafeInteger(cell) || !Number.isFinite(offset)) throw new RangeError("INVALID_WORLD_COORDINATE");
  const shift = Math.floor(offset / WORLD_CELL_METERS);
  const nextCell = cell + shift;
  if (!Number.isSafeInteger(nextCell)) throw new RangeError("WORLD_CELL_RANGE_EXCEEDED");
  let local = offset - shift * WORLD_CELL_METERS;
  let finalCell = nextCell;
  if (local >= WORLD_CELL_METERS) { local -= WORLD_CELL_METERS; finalCell += 1; }
  if (local < 0) { local += WORLD_CELL_METERS; finalCell -= 1; }
  if (!Number.isSafeInteger(finalCell) || !Number.isFinite(local) || local < 0 || local >= WORLD_CELL_METERS) throw new RangeError("WORLD_COORDINATE_NORMALIZATION_FAILED");
  return [finalCell, local];
}

export function worldPointFromMeters(x: number, y: number, z: number): WorldPoint {
  if (![x,y,z].every(Number.isFinite)) throw new TypeError("WORLD_POSITION_MUST_BE_FINITE");
  const [cellX,offsetX] = normalizeAxis(0,x);
  const [cellY,offsetY] = normalizeAxis(0,y);
  const [cellZ,offsetZ] = normalizeAxis(0,z);
  return Object.freeze({ cellX,cellY,cellZ,offsetX,offsetY,offsetZ });
}

export function translateWorldPoint(point: WorldPoint, dx: number, dy: number, dz: number): WorldPoint {
  if (!point || ![dx,dy,dz,point.offsetX,point.offsetY,point.offsetZ].every(Number.isFinite)) throw new TypeError("INVALID_WORLD_TRANSLATION");
  const [cellX,offsetX] = normalizeAxis(point.cellX,point.offsetX+dx);
  const [cellY,offsetY] = normalizeAxis(point.cellY,point.offsetY+dy);
  const [cellZ,offsetZ] = normalizeAxis(point.cellZ,point.offsetZ+dz);
  return Object.freeze({ cellX,cellY,cellZ,offsetX,offsetY,offsetZ });
}

/** Returns null rather than emitting imprecise or unbounded GPU-local coordinates. */
export function relativeWorldPosition(point: WorldPoint, origin: WorldPoint, maxDistance = 1_000_000): RelativeWorldPosition | null {
  if (!point || !origin || !Number.isFinite(maxDistance) || maxDistance <= 0) return null;
  const axis = (cellA:number, offsetA:number, cellB:number, offsetB:number):number|null => {
    const cellDelta = cellA-cellB;
    if (!Number.isSafeInteger(cellDelta) || Math.abs(cellDelta) > Math.ceil(maxDistance/WORLD_CELL_METERS)+1) return null;
    const value = cellDelta*WORLD_CELL_METERS + offsetA-offsetB;
    return Number.isFinite(value) && Math.abs(value)<=maxDistance ? value : null;
  };
  const x=axis(point.cellX,point.offsetX,origin.cellX,origin.offsetX);
  const y=axis(point.cellY,point.offsetY,origin.cellY,origin.offsetY);
  const z=axis(point.cellZ,point.offsetZ,origin.cellZ,origin.offsetZ);
  return x===null||y===null||z===null?null:Object.freeze({x,y,z});
}

/** Re-centers the render origin around the active focus; world-space identity never changes. */
export class WorldOriginRebaser {
  private current: WorldPoint;
  readonly thresholdMeters: number;
  constructor(initialOrigin: WorldPoint = worldPointFromMeters(0,0,0), thresholdMeters = 500) {
    if (!Number.isFinite(thresholdMeters) || thresholdMeters < 1 || thresholdMeters >= WORLD_CELL_METERS*100) throw new RangeError("INVALID_REBASE_THRESHOLD");
    this.current=initialOrigin; this.thresholdMeters=thresholdMeters;
  }
  get origin(): WorldPoint { return this.current; }
  update(focus: WorldPoint): boolean {
    const relative=relativeWorldPosition(focus,this.current,this.thresholdMeters*2);
    if (!relative) { this.current=focus; return true; }
    if (relative.x*relative.x+relative.y*relative.y+relative.z*relative.z > this.thresholdMeters*this.thresholdMeters) { this.current=focus; return true; }
    return false;
  }
  toLocal(point: WorldPoint, maxDistance = this.thresholdMeters*4): RelativeWorldPosition | null { return relativeWorldPosition(point,this.current,maxDistance); }
}
