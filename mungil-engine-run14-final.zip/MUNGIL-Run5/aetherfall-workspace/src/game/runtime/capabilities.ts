import type { RendererKind, ProjectionKind } from "./contracts.ts";

export type RendererCapabilities = Readonly<{
  webgpu: boolean;
  webgl2: boolean;
  webgl1: boolean;
  canvas2d: boolean;
}>;

export type RendererResolution = { ok: true; renderer: Exclude<RendererKind, "auto"> } | { ok: false; error: string };

/** Selects a backend without silently downgrading true 3D projects to a 2D canvas. */
export function resolveRenderer(
  requested: RendererKind,
  projection: ProjectionKind,
  capabilities: RendererCapabilities,
): RendererResolution {
  const available: Record<Exclude<RendererKind, "auto">, boolean> = {
    webgpu: capabilities.webgpu,
    webgl2: capabilities.webgl2,
    webgl1: capabilities.webgl1,
    canvas2d: capabilities.canvas2d,
  };
  const isPerspective3D = projection === "perspective-3d";
  if (requested !== "auto") {
    if (!available[requested]) return { ok: false, error: `REQUESTED_RENDERER_UNAVAILABLE:${requested}` };
    if (isPerspective3D && requested === "canvas2d") return { ok: false, error: "CANVAS2D_CANNOT_RENDER_PERSPECTIVE_3D" };
    return { ok: true, renderer: requested };
  }
  // Prefer stable, broadly deployed APIs. WebGPU is opt-in until the adapter is explicitly validated.
  if (capabilities.webgl2) return { ok: true, renderer: "webgl2" };
  if (capabilities.webgl1) return { ok: true, renderer: "webgl1" };
  if (!isPerspective3D && capabilities.canvas2d) return { ok: true, renderer: "canvas2d" };
  if (capabilities.webgpu) return { ok: true, renderer: "webgpu" };
  return { ok: false, error: isPerspective3D ? "NO_COMPATIBLE_3D_RENDERER" : "NO_COMPATIBLE_RENDERER" };
}
