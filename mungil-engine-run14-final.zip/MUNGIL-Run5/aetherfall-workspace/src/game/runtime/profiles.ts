import type { QualityTier } from "./core.ts";

export type ArtDirection = "pixel-art" | "hand-drawn" | "vector" | "isometric" | "retro-3d" | "voxel" | "toon" | "low-poly" | "pbr" | "photogrammetry" | "2d-skeletal" | "3d-skeletal";
export type Genre = "platformer" | "metroidvania" | "racing" | "fighting" | "shooter" | "rpg" | "jrpg" | "strategy" | "tower-defense" | "survival" | "sandbox" | "open-world" | "puzzle" | "rhythm" | "visual-novel" | "sports" | "horror" | "simulation" | "roguelike" | "card" | "educational" | "point-and-click";

export type ArtBudget = Readonly<{
  preferredRenderer: "canvas2d" | "webgl2";
  textureMaxDimension: 512 | 1024 | 2048 | 4096;
  nearestFiltering: boolean;
  antialias: boolean;
  realtimeShadows: boolean;
  dynamicLights: 0 | 1 | 2 | 4;
  maxBonesPerCharacter: 0 | 8 | 15 | 32;
  postProcessing: boolean;
  bakedLightingPreferred: boolean;
}>;

const ART_BASE: Record<ArtDirection, Omit<ArtBudget, "textureMaxDimension" | "antialias" | "realtimeShadows" | "dynamicLights" | "postProcessing">> = {
  "pixel-art": { preferredRenderer: "canvas2d", nearestFiltering: true, maxBonesPerCharacter: 0, bakedLightingPreferred: true },
  "hand-drawn": { preferredRenderer: "canvas2d", nearestFiltering: false, maxBonesPerCharacter: 8, bakedLightingPreferred: true },
  vector: { preferredRenderer: "canvas2d", nearestFiltering: false, maxBonesPerCharacter: 8, bakedLightingPreferred: true },
  isometric: { preferredRenderer: "canvas2d", nearestFiltering: false, maxBonesPerCharacter: 8, bakedLightingPreferred: true },
  "retro-3d": { preferredRenderer: "webgl2", nearestFiltering: true, maxBonesPerCharacter: 8, bakedLightingPreferred: true },
  voxel: { preferredRenderer: "webgl2", nearestFiltering: false, maxBonesPerCharacter: 8, bakedLightingPreferred: true },
  toon: { preferredRenderer: "webgl2", nearestFiltering: false, maxBonesPerCharacter: 15, bakedLightingPreferred: true },
  "low-poly": { preferredRenderer: "webgl2", nearestFiltering: false, maxBonesPerCharacter: 15, bakedLightingPreferred: true },
  pbr: { preferredRenderer: "webgl2", nearestFiltering: false, maxBonesPerCharacter: 32, bakedLightingPreferred: true },
  photogrammetry: { preferredRenderer: "webgl2", nearestFiltering: false, maxBonesPerCharacter: 32, bakedLightingPreferred: true },
  "2d-skeletal": { preferredRenderer: "canvas2d", nearestFiltering: false, maxBonesPerCharacter: 15, bakedLightingPreferred: true },
  "3d-skeletal": { preferredRenderer: "webgl2", nearestFiltering: false, maxBonesPerCharacter: 32, bakedLightingPreferred: true },
};

export function createArtBudget(style: ArtDirection, tier: QualityTier): ArtBudget {
  const base = ART_BASE[style];
  if (!base) throw new TypeError("UNSUPPORTED_ART_DIRECTION");
  const low = tier === 0;
  const mid = tier === 1;
  const textureMaxDimension = low ? 512 : mid ? 1024 : 2048;
  const is2d = base.preferredRenderer === "canvas2d";
  return Object.freeze({
    ...base,
    textureMaxDimension,
    antialias: !low && !base.nearestFiltering,
    realtimeShadows: !low && !is2d && (style === "toon" || style === "low-poly" || style === "pbr" || style === "3d-skeletal"),
    dynamicLights: low ? 0 : mid ? 1 : style === "pbr" || style === "photogrammetry" ? 4 : 2,
    postProcessing: !low && tier === 2 && (style === "pbr" || style === "photogrammetry" || style === "3d-skeletal"),
  });
}

export type GenreBudget = Readonly<{ simulationHz: 30 | 60; targetFps: 30 | 60; maxEntities: number; maxActiveAI: number; maxParticles: number; maxAudioVoices: number; maxDynamicLights: number }>;
const COMPLEX_GENRES = new Set<Genre>(["open-world", "sandbox", "simulation", "survival", "rpg", "jrpg"]);
const LOW_ENTITY_CAP: Record<Genre, number> = {
  platformer: 128, metroidvania: 160, racing: 64, fighting: 48, shooter: 96, rpg: 192, jrpg: 160, strategy: 256,
  "tower-defense": 192, survival: 192, sandbox: 256, "open-world": 256, puzzle: 64, rhythm: 48, "visual-novel": 32,
  sports: 96, horror: 96, simulation: 192, roguelike: 128, card: 32, educational: 64, "point-and-click": 48,
};

export function createGenreBudget(genre: Genre, tier: QualityTier): GenreBudget {
  if (!(genre in LOW_ENTITY_CAP)) throw new TypeError("UNSUPPORTED_GENRE");
  const base = LOW_ENTITY_CAP[genre];
  const scale = tier === 0 ? 1 : tier === 1 ? 2 : 4;
  return Object.freeze({
    simulationHz: tier === 0 ? 30 : 60,
    targetFps: tier === 0 ? 30 : 60,
    maxEntities: Math.min(4096, base * scale),
    maxActiveAI: Math.min(256, Math.max(4, Math.floor(base * scale * (COMPLEX_GENRES.has(genre) ? 0.18 : 0.12)))),
    maxParticles: tier === 0 ? 32 : tier === 1 ? 96 : 256,
    maxAudioVoices: tier === 0 ? 8 : tier === 1 ? 16 : 32,
    maxDynamicLights: tier === 0 ? 0 : tier === 1 ? 1 : 4,
  });
}
