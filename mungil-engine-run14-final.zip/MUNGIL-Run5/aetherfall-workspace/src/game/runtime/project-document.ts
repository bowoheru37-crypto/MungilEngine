/** Versioned, renderer-neutral project document and bounded undo/redo history. */
export const PROJECT_SCHEMA_VERSION = 1;
export type ProjectNode = Readonly<{ id: string; type: string; name: string; parentId: string | null; props: Readonly<Record<string, unknown>> }>;
export type ProjectDocument = Readonly<{ schemaVersion: 1; projectId: string; title: string; activeSceneId: string; nodes: readonly ProjectNode[]; updatedAt: number }>;
export type ProjectResult<T> = { ok: true; value: T } | { ok: false; error: string };

const ID = /^[A-Za-z0-9_-]{1,80}$/;
const TYPE = /^[A-Za-z][A-Za-z0-9_.-]{0,63}$/;
const MAX_NODES = 20_000;
const MAX_DOCUMENT_BYTES = 2 * 1024 * 1024;
const MAX_HISTORY = 32;
const MAX_HISTORY_BYTES = 4 * 1024 * 1024;

function isJsonValue(value: unknown, depth: number, seen: Set<object>): boolean {
  if (value === null || typeof value === "string" || typeof value === "boolean") return true;
  if (typeof value === "number") return Number.isFinite(value);
  if (typeof value !== "object" || depth > 32 || seen.has(value)) return false;
  seen.add(value);
  let valid = true;
  if (Array.isArray(value)) {
    if (value.length > 4096) valid = false;
    else for (const item of value) if (!isJsonValue(item, depth + 1, seen)) { valid = false; break; }
  } else {
    const proto = Object.getPrototypeOf(value);
    if (proto !== Object.prototype && proto !== null) valid = false;
    else {
      const entries = Object.entries(value as Record<string, unknown>);
      if (entries.length > 4096) valid = false;
      else for (const [key, item] of entries) if (key === "__proto__" || key === "constructor" || !isJsonValue(item, depth + 1, seen)) { valid = false; break; }
    }
  }
  seen.delete(value);
  return valid;
}
function validProps(value: unknown): value is Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value) || !isJsonValue(value, 0, new Set())) return false;
  try { return JSON.stringify(value).length <= 32_768; } catch { return false; }
}
function cloneJson<T>(value: T): T { return JSON.parse(JSON.stringify(value)) as T; }
export function validateProjectDocument(input: unknown): ProjectResult<ProjectDocument> {
  if (!input || typeof input !== "object") return { ok: false, error: "PROJECT_NOT_OBJECT" };
  const p = input as Partial<ProjectDocument>;
  if (p.schemaVersion !== PROJECT_SCHEMA_VERSION) return { ok: false, error: "UNSUPPORTED_PROJECT_SCHEMA" };
  if (typeof p.projectId !== "string" || !ID.test(p.projectId)) return { ok: false, error: "INVALID_PROJECT_ID" };
  if (typeof p.title !== "string" || !p.title.trim() || p.title.length > 120) return { ok: false, error: "INVALID_PROJECT_TITLE" };
  if (typeof p.activeSceneId !== "string" || !ID.test(p.activeSceneId)) return { ok: false, error: "INVALID_ACTIVE_SCENE" };
  if (!Array.isArray(p.nodes) || p.nodes.length > MAX_NODES) return { ok: false, error: "INVALID_NODE_LIST" };
  if (!Number.isFinite(p.updatedAt)) return { ok: false, error: "INVALID_UPDATED_AT" };
  const ids = new Set<string>();
  for (const node of p.nodes) {
    if (!node || typeof node !== "object" || !ID.test(node.id) || !TYPE.test(node.type) || typeof node.name !== "string" || node.name.length > 120 || !(node.parentId === null || (typeof node.parentId === "string" && ID.test(node.parentId))) || !validProps(node.props) || ids.has(node.id)) return { ok: false, error: "INVALID_PROJECT_NODE" };
    ids.add(node.id);
  }
  const parentById = new Map<string, string | null>();
  for (const node of p.nodes) {
    if (node.parentId !== null && !ids.has(node.parentId)) return { ok: false, error: "MISSING_PARENT_NODE" };
    parentById.set(node.id, node.parentId);
  }
  for (const node of p.nodes) {
    let cursor: string | null = node.id;
    let hops = 0;
    while (cursor !== null && hops++ <= p.nodes.length) cursor = parentById.get(cursor) ?? null;
    if (hops > p.nodes.length + 1) return { ok: false, error: "PROJECT_HIERARCHY_CYCLE" };
  }
  try { if (JSON.stringify(p).length > MAX_DOCUMENT_BYTES) return { ok: false, error: "PROJECT_TOO_LARGE" }; } catch { return { ok: false, error: "PROJECT_NOT_SERIALIZABLE" }; }
  return { ok: true, value: p as ProjectDocument };
}

export type ProjectOperation =
  | { kind: "add"; node: ProjectNode }
  | { kind: "remove"; id: string }
  | { kind: "rename"; id: string; name: string }
  | { kind: "set-props"; id: string; props: Readonly<Record<string, unknown>> }
  | { kind: "set-parent"; id: string; parentId: string | null };

export class ProjectHistory {
  private current: ProjectDocument;
  private readonly undoStack: ProjectDocument[] = [];
  private readonly redoStack: ProjectDocument[] = [];
  private undoBytes = 0;
  private redoBytes = 0;
  private pushBounded(stack: ProjectDocument[], value: ProjectDocument, kind: "undo" | "redo"): void {
    const bytes = JSON.stringify(value).length;
    stack.push(value);
    if (kind === "undo") this.undoBytes += bytes; else this.redoBytes += bytes;
    while (stack.length > MAX_HISTORY || (kind === "undo" ? this.undoBytes : this.redoBytes) > MAX_HISTORY_BYTES) {
      const removed = stack.shift();
      if (!removed) break;
      const removedBytes = JSON.stringify(removed).length;
      if (kind === "undo") this.undoBytes -= removedBytes; else this.redoBytes -= removedBytes;
    }
  }
  constructor(initial: ProjectDocument) {
    const checked = validateProjectDocument(initial);
    if (!checked.ok) throw new TypeError(checked.error);
    this.current = cloneJson(checked.value);
  }
  get document(): ProjectDocument { return this.current; }
  get canUndo(): boolean { return this.undoStack.length > 0; }
  get canRedo(): boolean { return this.redoStack.length > 0; }

  apply(operation: ProjectOperation, now = Date.now()): ProjectResult<ProjectDocument> {
    if (!operation || typeof operation !== "object" || !["add", "remove", "rename", "set-props", "set-parent"].includes(operation.kind)) return { ok: false, error: "INVALID_PROJECT_OPERATION" };
    const nodes = this.current.nodes.slice();
    const index = operation.kind === "add" ? -1 : nodes.findIndex(n => n.id === operation.id);
    if (operation.kind !== "add" && index < 0) return { ok: false, error: "NODE_NOT_FOUND" };
    switch (operation.kind) {
      case "add":
        if (!operation.node || typeof operation.node !== "object" || nodes.length >= MAX_NODES || nodes.some(n => n.id === operation.node.id)) return { ok: false, error: "NODE_LIMIT_OR_DUPLICATE" };
        try { nodes.push(cloneJson(operation.node)); } catch { return { ok: false, error: "INVALID_NODE_PAYLOAD" }; }
        break;
      case "remove": {
        const removeIds = new Set([operation.id]);
        let changed = true;
        while (changed) {
          changed = false;
          for (let i = 0; i < nodes.length; i++) {
            const node = nodes[i]!;
            if (node.parentId !== null && removeIds.has(node.parentId) && !removeIds.has(node.id)) {
              removeIds.add(node.id);
              changed = true;
            }
          }
        }
        for (let i = nodes.length - 1; i >= 0; i--) if (removeIds.has(nodes[i]!.id)) nodes.splice(i, 1);
        break;
      }
      case "rename":
        if (typeof operation.name !== "string" || !operation.name.trim() || operation.name.length > 120) return { ok: false, error: "INVALID_NODE_NAME" };
        nodes[index] = { ...nodes[index]!, name: operation.name }; break;
      case "set-props":
        if (!validProps(operation.props)) return { ok: false, error: "INVALID_NODE_PROPS" };
        nodes[index] = { ...nodes[index]!, props: cloneJson(operation.props) }; break;
      case "set-parent": {
        if (operation.parentId === operation.id || (operation.parentId !== null && !nodes.some(n => n.id === operation.parentId))) return { ok: false, error: "INVALID_PARENT" };
        let ancestor = operation.parentId;
        let hops = 0;
        while (ancestor !== null && hops++ <= nodes.length) {
          if (ancestor === operation.id) return { ok: false, error: "PARENT_CYCLE" };
          ancestor = nodes.find(n => n.id === ancestor)?.parentId ?? null;
        }
        if (hops > nodes.length + 1) return { ok: false, error: "PARENT_CYCLE" };
        nodes[index] = { ...nodes[index]!, parentId: operation.parentId }; break;
      }
    }
    const next = { ...this.current, nodes, updatedAt: now };
    const checked = validateProjectDocument(next);
    if (!checked.ok) return checked;
    // History is only mutated after the candidate document passes all validation.
    this.pushBounded(this.undoStack, this.current, "undo");
    this.redoStack.length = 0;
    this.redoBytes = 0;
    this.current = checked.value;
    return { ok: true, value: this.current };
  }
  /** Applies a bounded command group as one undo/redo transaction. */
  applyBatch(operations: readonly ProjectOperation[], now = Date.now()): ProjectResult<ProjectDocument> {
    if (!Array.isArray(operations) || operations.length < 1 || operations.length > 512) return { ok: false, error: "INVALID_OPERATION_BATCH" };
    const shadow = new ProjectHistory(this.current);
    for (const operation of operations) {
      if (!operation || typeof operation !== "object") return { ok: false, error: "INVALID_PROJECT_OPERATION" };
      const result = shadow.apply(operation, now);
      if (!result.ok) return result;
    }
    const checked = validateProjectDocument(shadow.document);
    if (!checked.ok) return checked;
    this.pushBounded(this.undoStack, this.current, "undo");
    this.redoStack.length = 0;
    this.redoBytes = 0;
    this.current = checked.value;
    return { ok: true, value: this.current };
  }
  undo(): ProjectResult<ProjectDocument> {
    const previous = this.undoStack.pop();
    if (!previous) return { ok: false, error: "NOTHING_TO_UNDO" };
    this.undoBytes -= JSON.stringify(previous).length;
    this.pushBounded(this.redoStack, this.current, "redo"); this.current = previous;
    return { ok: true, value: this.current };
  }
  redo(): ProjectResult<ProjectDocument> {
    const next = this.redoStack.pop();
    if (!next) return { ok: false, error: "NOTHING_TO_REDO" };
    this.redoBytes -= JSON.stringify(next).length;
    this.pushBounded(this.undoStack, this.current, "undo"); this.current = next;
    return { ok: true, value: this.current };
  }
}

export interface ProjectStorage { get(key: string): string | null; set(key: string, value: string): void; remove(key: string): void; }
export function saveProject(storage: ProjectStorage, key: string, document: ProjectDocument): ProjectResult<number> {
  if (!/^[A-Za-z0-9_-]{1,100}$/.test(key)) return { ok: false, error: "INVALID_STORAGE_KEY" };
  const checked = validateProjectDocument(document);
  if (!checked.ok) return checked;
  try {
    const serialized = JSON.stringify(checked.value);
    if (serialized.length > MAX_DOCUMENT_BYTES) return { ok: false, error: "PROJECT_TOO_LARGE" };
    storage.set(key, serialized);
    return { ok: true, value: serialized.length };
  } catch { return { ok: false, error: "PROJECT_STORAGE_FAILED" }; }
}
export function loadProject(storage: ProjectStorage, key: string): ProjectResult<ProjectDocument> {
  if (!/^[A-Za-z0-9_-]{1,100}$/.test(key)) return { ok: false, error: "INVALID_STORAGE_KEY" };
  try {
    const raw = storage.get(key);
    if (raw === null) return { ok: false, error: "PROJECT_NOT_FOUND" };
    if (raw.length > MAX_DOCUMENT_BYTES) return { ok: false, error: "PROJECT_TOO_LARGE" };
    return validateProjectDocument(JSON.parse(raw));
  } catch { return { ok: false, error: "PROJECT_STORAGE_FAILED_OR_INVALID_JSON" }; }
}
