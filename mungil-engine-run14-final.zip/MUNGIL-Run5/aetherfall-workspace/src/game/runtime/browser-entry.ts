/** Browser entry for the standalone MUNGIL Studio website and Android WebView shell. */
import * as runtime from "./index.ts";

Object.defineProperty(window, "MUNGIL_RUNTIME", {
  configurable: false,
  enumerable: false,
  writable: false,
  value: Object.freeze(runtime),
});
