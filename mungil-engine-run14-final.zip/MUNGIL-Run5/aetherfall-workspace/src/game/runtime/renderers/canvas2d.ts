import type { RendererAdapter, RuntimeProjectManifest } from "../contracts.ts";
import type { DeviceProfile, QualityTier } from "../core.ts";

export type Vec2 = Readonly<{ x: number; y: number }>;
export type CanvasDrawCommand =
  | { kind: "rect"; x: number; y: number; width: number; height: number; color: string; layer?: number; alpha?: number }
  | { kind: "circle"; x: number; y: number; radius: number; color: string; layer?: number; alpha?: number }
  | { kind: "line"; x1: number; y1: number; x2: number; y2: number; color: string; lineWidth?: number; layer?: number; alpha?: number }
  | { kind: "polygon"; points: readonly Vec2[]; color: string; layer?: number; alpha?: number }
  | { kind: "text"; text: string; x: number; y: number; color: string; font?: string; align?: CanvasTextAlign; layer?: number; alpha?: number }
  | { kind: "image"; image: CanvasImageSource; x: number; y: number; width: number; height: number; alpha?: number; layer?: number };

/** Stable ordered scene: insertion order is preserved for equal layers. */
const MAX_SCENE_COMMANDS = 32_768;

export class Canvas2DScene {
  private readonly drawCommands: CanvasDrawCommand[] = [];
  get commands(): readonly CanvasDrawCommand[] { return this.drawCommands; }
  clearColor: string = "#101018";
  cameraX = 0;
  cameraY = 0;
  zoom = 1;
  add(command: CanvasDrawCommand): void {
    if (!isValidCommand(command)) throw new TypeError("INVALID_CANVAS_COMMAND");
    if (this.drawCommands.length >= MAX_SCENE_COMMANDS) throw new RangeError("CANVAS_SCENE_COMMAND_LIMIT");
    this.drawCommands.push(command);
    // Stable insertion sort is cheap for editor/game scenes that append a few commands per update.
    let i = this.drawCommands.length - 1;
    const layer = command.layer ?? 0;
    while (i > 0 && (this.drawCommands[i - 1]!.layer ?? 0) > layer) {
      this.drawCommands[i] = this.drawCommands[i - 1]!;
      i--;
    }
    this.drawCommands[i] = command;
  }
  clear(): void { this.drawCommands.length = 0; }
}

function finite(v: number): boolean { return Number.isFinite(v); }
function validStyle(c: { color: string; alpha?: number }): boolean {
  return typeof c.color === "string" && c.color.length > 0 && c.color.length <= 128 &&
    (c.alpha === undefined || (finite(c.alpha) && c.alpha >= 0 && c.alpha <= 1));
}
function isValidCommand(c: CanvasDrawCommand): boolean {
  if (!c || typeof c !== "object") return false;
  if (c.layer !== undefined && (!finite(c.layer) || Math.abs(c.layer) > 1_000_000)) return false;
  switch (c.kind) {
    case "rect": return validStyle(c) && [c.x,c.y,c.width,c.height].every(finite) && c.width >= 0 && c.height >= 0;
    case "circle": return validStyle(c) && [c.x,c.y,c.radius].every(finite) && c.radius >= 0;
    case "line": return validStyle(c) && [c.x1,c.y1,c.x2,c.y2,c.lineWidth ?? 1].every(finite) && (c.lineWidth ?? 1) >= 0;
    case "polygon": return validStyle(c) && c.points.length >= 3 && c.points.length <= 4096 && c.points.every(p => finite(p.x) && finite(p.y));
    case "text": return validStyle(c) && typeof c.text === "string" && c.text.length <= 8192 && finite(c.x) && finite(c.y) && (c.font === undefined || (typeof c.font === "string" && c.font.length <= 128));
    case "image": return finite(c.x) && finite(c.y) && finite(c.width) && finite(c.height) && c.width >= 0 && c.height >= 0 && (c.alpha === undefined || (finite(c.alpha) && c.alpha >= 0 && c.alpha <= 1));
  }
}

/** Canvas2D backend for 2D, isometric and pseudo-3D scenes; it is not a perspective 3D renderer. */
export class Canvas2DRenderer implements RendererAdapter<Canvas2DScene> {
  readonly kind = "canvas2d" as const;
  private canvas: HTMLCanvasElement | null = null;
  private context: CanvasRenderingContext2D | null = null;
  private lost = false;
  private width = 1;
  private height = 1;
  private pixelRatio = 1;
  private quality: QualityTier = 0;
  private readonly imageCache = new Map<string, CanvasImageSource>();
  private readonly onLost = (event: Event) => { event.preventDefault(); this.lost = true; };
  private readonly onRestored = () => { this.lost = false; this.context = this.canvas?.getContext("2d", { alpha: false }) ?? null; };

  initialize(host: HTMLCanvasElement, profile: DeviceProfile): void {
    if (this.canvas) throw new Error("CANVAS_RENDERER_ALREADY_INITIALIZED");
    const context = host.getContext("2d", { alpha: false, desynchronized: true });
    if (!context) throw new Error("CANVAS2D_CONTEXT_UNAVAILABLE");
    this.canvas = host;
    this.context = context;
    this.quality = profile.tier;
    host.addEventListener("contextlost", this.onLost);
    host.addEventListener("contextrestored", this.onRestored);
    this.resize(host.clientWidth || host.width || 1, host.clientHeight || host.height || 1, Math.min(profile.maxPixelRatio, 1));
  }

  createScene(_manifest: RuntimeProjectManifest): Canvas2DScene { return new Canvas2DScene(); }
  setImage(key: string, image: CanvasImageSource): void {
    if (!key || key.length > 160) throw new TypeError("INVALID_IMAGE_KEY");
    this.imageCache.set(key, image);
  }
  getImage(key: string): CanvasImageSource | undefined { return this.imageCache.get(key); }
  releaseImage(key: string): void { this.imageCache.delete(key); }

  resize(width: number, height: number, pixelRatio: number): void {
    if (!this.canvas) return;
    this.width = Math.max(1, Math.floor(finite(width) ? width : 1));
    this.height = Math.max(1, Math.floor(finite(height) ? height : 1));
    const tierCap = this.quality === 0 ? 1 : this.quality === 1 ? 1.25 : 1.5;
    this.pixelRatio = Math.max(0.5, Math.min(finite(pixelRatio) ? pixelRatio : 1, tierCap));
    const w = Math.max(1, Math.floor(this.width * this.pixelRatio));
    const h = Math.max(1, Math.floor(this.height * this.pixelRatio));
    if (this.canvas.width !== w) this.canvas.width = w;
    if (this.canvas.height !== h) this.canvas.height = h;
    this.context = this.canvas.getContext("2d", { alpha: false, desynchronized: true });
  }

  render(scene: Canvas2DScene, _interpolationAlpha: number): void {
    const ctx = this.context;
    if (!ctx || this.lost || !scene || !finite(scene.zoom) || scene.zoom <= 0) return;
    const dpr = this.pixelRatio;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.globalAlpha = 1;
    ctx.fillStyle = typeof scene.clearColor === "string" && scene.clearColor.length <= 128 ? scene.clearColor : "#101018";
    ctx.fillRect(0, 0, this.width, this.height);
    ctx.save();
    ctx.translate(this.width * 0.5, this.height * 0.5);
    ctx.scale(scene.zoom, scene.zoom);
    ctx.translate(-scene.cameraX, -scene.cameraY);
    for (let i = 0; i < scene.commands.length; i++) {
      const c = scene.commands[i]!;
      ctx.globalAlpha = c.alpha === undefined ? 1 : Math.max(0, Math.min(1, c.alpha));
      switch (c.kind) {
        case "rect": ctx.fillStyle = c.color; ctx.fillRect(c.x, c.y, c.width, c.height); break;
        case "circle": ctx.beginPath(); ctx.arc(c.x, c.y, c.radius, 0, Math.PI * 2); ctx.fillStyle = c.color; ctx.fill(); break;
        case "line": ctx.beginPath(); ctx.moveTo(c.x1, c.y1); ctx.lineTo(c.x2, c.y2); ctx.strokeStyle = c.color; ctx.lineWidth = c.lineWidth ?? 1; ctx.stroke(); break;
        case "polygon":
          ctx.beginPath(); ctx.moveTo(c.points[0]!.x, c.points[0]!.y);
          for (let p = 1; p < c.points.length; p++) ctx.lineTo(c.points[p]!.x, c.points[p]!.y);
          ctx.closePath(); ctx.fillStyle = c.color; ctx.fill(); break;
        case "text": ctx.fillStyle = c.color; ctx.font = c.font ?? "14px sans-serif"; ctx.textAlign = c.align ?? "left"; ctx.fillText(c.text, c.x, c.y); break;
        case "image": ctx.drawImage(c.image, c.x, c.y, c.width, c.height); break;
      }
    }
    ctx.restore();
    ctx.globalAlpha = 1;
  }

  setQuality(tier: QualityTier): void {
    this.quality = tier;
    this.resize(this.width, this.height, this.pixelRatio);
  }
  disposeScene(scene: Canvas2DScene): void { scene.clear(); }
  dispose(): void {
    this.canvas?.removeEventListener("contextlost", this.onLost);
    this.canvas?.removeEventListener("contextrestored", this.onRestored);
    this.imageCache.clear();
    this.context = null;
    this.canvas = null;
    this.lost = false;
  }
}
