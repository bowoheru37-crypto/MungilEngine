import type { RendererAdapter, RuntimeProjectManifest } from "../contracts.ts";
import type { DeviceProfile, QualityTier } from "../core.ts";
import type { SpriteAtlas } from "../sprite-atlas.ts";

export type GL2Command =
  | { kind: "rect"; x: number; y: number; width: number; height: number; color: string; alpha?: number; layer?: number }
  | { kind: "circle"; x: number; y: number; radius: number; color: string; segments?: number; alpha?: number; layer?: number }
  | { kind: "line"; x1: number; y1: number; x2: number; y2: number; width?: number; color: string; alpha?: number; layer?: number }
  | { kind: "polygon"; points: readonly Readonly<{ x: number; y: number }>[]; color: string; alpha?: number; layer?: number }
  | { kind: "sprite"; textureId: string; x: number; y: number; width: number; height: number; u0?: number; v0?: number; u1?: number; v1?: number; rotation?: number; pivotX?: number; pivotY?: number; color?: string; alpha?: number; layer?: number };

const MAX_COMMANDS = 32_768;
const MAX_VERTICES = 196_608;
const FLOATS_PER_VERTEX = 8; // x, y, r, g, b, a, u, v
const VERTEX_SHADER = `#version 300 es
in vec2 a_position; in vec4 a_color; in vec2 a_uv; uniform vec2 u_resolution; uniform vec2 u_camera; uniform float u_zoom; out vec4 v_color; out vec2 v_uv;
void main(){ vec2 p=(a_position-u_camera)*u_zoom+u_resolution*0.5; vec2 clip=(p/u_resolution)*2.0-1.0; gl_Position=vec4(clip.x,-clip.y,0.0,1.0); v_color=a_color; v_uv=a_uv; }`;
const FRAGMENT_SHADER = `#version 300 es
precision mediump float; in vec4 v_color; in vec2 v_uv; uniform sampler2D u_texture; uniform float u_textured; out vec4 outColor;
void main(){ vec4 texel=mix(vec4(1.0),texture(u_texture,v_uv),u_textured); outColor=v_color*texel; }`;

export class WebGL2Scene {
  readonly commands: GL2Command[] = [];
  clearColor = "#101018";
  cameraX = 0;
  cameraY = 0;
  zoom = 1;
  add(command: GL2Command): void {
    if (!validCommand(command)) throw new TypeError("INVALID_WEBGL2_COMMAND");
    if (this.commands.length >= MAX_COMMANDS) throw new RangeError("WEBGL2_SCENE_COMMAND_LIMIT");
    let i = this.commands.length;
    this.commands.push(command);
    const layer = command.layer ?? 0;
    while (i > 0 && (this.commands[i - 1]!.layer ?? 0) > layer) {
      this.commands[i] = this.commands[i - 1]!;
      i--;
    }
    this.commands[i] = command;
  }
  addSprite(command: Omit<Extract<GL2Command, { kind: "sprite" }>, "kind">): void { this.add({ kind: "sprite", ...command }); }
  addAtlasSprite(atlasId: string, atlas: SpriteAtlas, frameId: string, sprite: { x: number; y: number; width?: number; height?: number; rotation?: number; pivotX?: number; pivotY?: number; tint?: string; alpha?: number; layer?: number }): boolean {
    if (!/^[a-zA-Z0-9_-]{1,64}$/.test(atlasId) || !atlas || atlas.schemaVersion !== 1 || !Array.isArray(atlas.frames) || !Array.isArray(atlas.pages)) return false;
    const frame = atlas.frames.find(item => item.id === frameId); if (!frame) return false;
    const page = atlas.pages[frame.page]; if (!page) return false;
    try { this.add({ kind: "sprite", textureId: `${atlasId}-${frame.page}`, x: sprite.x, y: sprite.y, width: sprite.width ?? frame.width, height: sprite.height ?? frame.height, u0: frame.x / page.width, v0: frame.y / page.height, u1: (frame.x + frame.width) / page.width, v1: (frame.y + frame.height) / page.height, rotation: sprite.rotation, pivotX: sprite.pivotX, pivotY: sprite.pivotY, color: sprite.tint ?? "#ffffff", alpha: sprite.alpha, layer: sprite.layer }); return true; }
    catch { return false; }
  }
  clear(): void { this.commands.length = 0; }
}

function isConvexPolygon(points: readonly Readonly<{x:number;y:number}>[]): boolean {
  if (!Array.isArray(points) || points.length < 3 || points.length > 4096 || !points.every(p => p && Number.isFinite(p.x) && Number.isFinite(p.y))) return false;
  let sign = 0;
  for (let i=0;i<points.length;i++) {
    const a=points[i]!, b=points[(i+1)%points.length]!, c=points[(i+2)%points.length]!;
    const cross=(b.x-a.x)*(c.y-b.y)-(b.y-a.y)*(c.x-b.x);
    if (Math.abs(cross) < 1e-9) continue;
    const next=cross>0?1:-1;
    if (sign!==0 && sign!==next) return false;
    sign=next;
  }
  return sign!==0;
}
function validCommand(c: GL2Command): boolean {
  if (!c || typeof c !== "object") return false;
  if (c.layer !== undefined && (!Number.isFinite(c.layer) || Math.abs(c.layer) > 1_000_000)) return false;
  if (c.alpha !== undefined && (!Number.isFinite(c.alpha) || c.alpha < 0 || c.alpha > 1)) return false;
  if (c.kind === "sprite") {
    const color = c.color ?? "#ffffff";
    return /^[a-zA-Z0-9_-]{1,80}$/.test(c.textureId) && [c.x,c.y,c.width,c.height,c.u0 ?? 0,c.v0 ?? 0,c.u1 ?? 1,c.v1 ?? 1,c.rotation ?? 0,c.pivotX ?? 0.5,c.pivotY ?? 0.5].every(Number.isFinite) && c.width >= 0 && c.height >= 0 && (c.u0 ?? 0) >= 0 && (c.v0 ?? 0) >= 0 && (c.u1 ?? 1) <= 1 && (c.v1 ?? 1) <= 1 && (c.u1 ?? 1) >= (c.u0 ?? 0) && (c.v1 ?? 1) >= (c.v0 ?? 0) && Math.abs(c.rotation ?? 0) <= Math.PI * 1000 && (c.pivotX ?? 0.5) >= 0 && (c.pivotX ?? 0.5) <= 1 && (c.pivotY ?? 0.5) >= 0 && (c.pivotY ?? 0.5) <= 1 && typeof color === "string" && color.length <= 32 && !!parseHexColor(color);
  }
  if (typeof c.color !== "string" || c.color.length > 32 || !parseHexColor(c.color)) return false;
  switch (c.kind) {
    case "rect": return [c.x,c.y,c.width,c.height].every(Number.isFinite) && c.width >= 0 && c.height >= 0;
    case "circle": return [c.x,c.y,c.radius].every(Number.isFinite) && c.radius >= 0 && (c.segments === undefined || (Number.isInteger(c.segments) && c.segments >= 8 && c.segments <= 64));
    case "line": return [c.x1,c.y1,c.x2,c.y2,c.width ?? 1].every(Number.isFinite) && (c.width ?? 1) >= 0;
    case "polygon": return isConvexPolygon(c.points);
  }
}

/** Deliberately accepts only hex colors so parsing is deterministic and allocation-light. */
export function parseHexColor(value: string): readonly [number, number, number, number] | null {
  if (typeof value !== "string") return null;
  const raw = value.startsWith("#") ? value.slice(1) : "";
  if (!/^(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(raw)) return null;
  const expanded = raw.length === 3 ? raw.split("").map(c => c + c).join("") : raw;
  const r = Number.parseInt(expanded.slice(0,2),16) / 255;
  const g = Number.parseInt(expanded.slice(2,4),16) / 255;
  const b = Number.parseInt(expanded.slice(4,6),16) / 255;
  const a = expanded.length === 8 ? Number.parseInt(expanded.slice(6,8),16) / 255 : 1;
  return [r,g,b,a];
}

export type WebGL2BatchOutput = {
  data: Float32Array;
  count: number;
  runCount: number;
  runTextureIds: (string | null)[];
  runFirst: number[];
  runCounts: number[];
};
function createBatchOutput(data = new Float32Array(MAX_VERTICES * FLOATS_PER_VERTEX)): WebGL2BatchOutput {
  return { data, count: 0, runCount: 0, runTextureIds: new Array(MAX_COMMANDS), runFirst: new Array(MAX_COMMANDS), runCounts: new Array(MAX_COMMANDS) };
}

/** CPU tessellation writes one reusable interleaved buffer and contiguous texture runs. */
export function buildWebGL2Batches(scene: WebGL2Scene, output: WebGL2BatchOutput = createBatchOutput()): WebGL2BatchOutput {
  let cursor = 0; output.count = 0; output.runCount = 0;
  const push = (x: number, y: number, color: readonly number[], alpha: number, u = 0, v = 0) => {
    if (cursor + FLOATS_PER_VERTEX > output.data.length) throw new RangeError("WEBGL2_VERTEX_BUDGET_EXCEEDED");
    output.data[cursor++] = x; output.data[cursor++] = y;
    output.data[cursor++] = color[0]!; output.data[cursor++] = color[1]!; output.data[cursor++] = color[2]!; output.data[cursor++] = color[3]! * alpha;
    output.data[cursor++] = u; output.data[cursor++] = v;
  };
  const tri = (a: readonly [number,number], b: readonly [number,number], c: readonly [number,number], color: readonly number[], alpha: number) => { push(a[0],a[1],color,alpha); push(b[0],b[1],color,alpha); push(c[0],c[1],color,alpha); };
  const quad = (x1:number,y1:number,x2:number,y2:number,x3:number,y3:number,x4:number,y4:number,color:readonly number[],alpha:number,uv?:readonly [number,number,number,number]) => {
    const [u0,v0,u1,v1] = uv ?? [0,0,0,0];
    push(x1,y1,color,alpha,u0,v0); push(x2,y2,color,alpha,u1,v0); push(x3,y3,color,alpha,u1,v1);
    push(x1,y1,color,alpha,u0,v0); push(x3,y3,color,alpha,u1,v1); push(x4,y4,color,alpha,u0,v1);
  };
  let activeTexture: string | null | undefined;
  for (const c of scene.commands) {
    const textureId = c.kind === "sprite" ? c.textureId : null;
    if (textureId !== activeTexture) {
      if (output.runCount >= MAX_COMMANDS) throw new RangeError("WEBGL2_DRAW_RUN_LIMIT");
      const run = output.runCount++;
      output.runTextureIds[run] = textureId; output.runFirst[run] = cursor / FLOATS_PER_VERTEX; output.runCounts[run] = 0;
      activeTexture = textureId;
    }
    const run = output.runCount - 1;
    const color = parseHexColor(c.kind === "sprite" ? c.color ?? "#ffffff" : c.color)!; const alpha = c.alpha ?? 1;
    switch (c.kind) {
      case "rect": quad(c.x,c.y,c.x+c.width,c.y,c.x+c.width,c.y+c.height,c.x,c.y+c.height,color,alpha); break;
      case "sprite": {
        const px=c.x+c.width*(c.pivotX??0.5), py=c.y+c.height*(c.pivotY??0.5), angle=c.rotation??0, cs=Math.cos(angle), sn=Math.sin(angle);
        const left=-c.width*(c.pivotX??0.5), right=c.width*(1-(c.pivotX??0.5)), top=-c.height*(c.pivotY??0.5), bottom=c.height*(1-(c.pivotY??0.5));
        const u0=c.u0??0,v0=c.v0??0,u1=c.u1??1,v1=c.v1??1;
        const points=[[left,top,u0,v0],[right,top,u1,v0],[right,bottom,u1,v1],[left,bottom,u0,v1]] as const;
        for(const index of [0,1,2,0,2,3]){const point=points[index]!;push(px+point[0]*cs-point[1]*sn,py+point[0]*sn+point[1]*cs,color,alpha,point[2],point[3]);}
        break;
      }
      case "circle": {
        const segments = c.segments ?? 16;
        for (let i=0;i<segments;i++) { const a=i*Math.PI*2/segments, b=(i+1)*Math.PI*2/segments; tri([c.x,c.y],[c.x+Math.cos(a)*c.radius,c.y+Math.sin(a)*c.radius],[c.x+Math.cos(b)*c.radius,c.y+Math.sin(b)*c.radius],color,alpha); }
        break;
      }
      case "line": {
        const dx=c.x2-c.x1, dy=c.y2-c.y1, len=Math.hypot(dx,dy); if (len===0 || (c.width ?? 1)===0) break;
        const half=(c.width ?? 1)*0.5, nx=-dy/len*half, ny=dx/len*half;
        quad(c.x1+nx,c.y1+ny,c.x2+nx,c.y2+ny,c.x2-nx,c.y2-ny,c.x1-nx,c.y1-ny,color,alpha); break;
      }
      case "polygon": {
        const p=c.points[0]!; for(let i=1;i<c.points.length-1;i++){const b=c.points[i]!, d=c.points[i+1]!;tri([p.x,p.y],[b.x,b.y],[d.x,d.y],color,alpha);} break;
      }
    }
    output.runCounts[run] = cursor / FLOATS_PER_VERTEX - output.runFirst[run]!;
  }
  output.count = cursor / FLOATS_PER_VERTEX;
  return output;
}

/** Compatibility helper for primitive-only callers and existing tests. */
export function buildWebGL2Vertices(scene: WebGL2Scene, target = new Float32Array(MAX_VERTICES * FLOATS_PER_VERTEX)): { data: Float32Array; count: number } {
  const output = buildWebGL2Batches(scene, createBatchOutput(target));
  return { data: output.data.subarray(0, output.count * FLOATS_PER_VERTEX), count: output.count };
}

type TextureRecord = { source: TexImageSource; texture: WebGLTexture | null; width: number; height: number; bytes: number };
function sourceSize(source: TexImageSource): { width: number; height: number } {
  const value = source as unknown as { width?: number; height?: number; videoWidth?: number; videoHeight?: number; naturalWidth?: number; naturalHeight?: number };
  return { width: value.naturalWidth || value.videoWidth || value.width || 0, height: value.naturalHeight || value.videoHeight || value.height || 0 };
}

/** WebGL2 batch renderer for solid 2D/2.5D primitives and bounded atlas-backed sprites; not perspective 3D. */
export class WebGL2BatchRenderer implements RendererAdapter<WebGL2Scene> {
  readonly kind = "webgl2" as const;
  private canvas: HTMLCanvasElement | null = null;
  private gl: WebGL2RenderingContext | null = null;
  private program: WebGLProgram | null = null;
  private buffer: WebGLBuffer | null = null;
  private positionLocation = -1; private colorLocation = -1; private uvLocation = -1;
  private resolutionLocation: WebGLUniformLocation | null = null; private cameraLocation: WebGLUniformLocation | null = null; private zoomLocation: WebGLUniformLocation | null = null;
  private textureLocation: WebGLUniformLocation | null = null; private texturedLocation: WebGLUniformLocation | null = null;
  private width = 1; private height = 1; private pixelRatio = 1; private quality: QualityTier = 0; private lost = false;
  private readonly vertices = new Float32Array(MAX_VERTICES * FLOATS_PER_VERTEX);
  private readonly batches = createBatchOutput(this.vertices);
  private readonly textures = new Map<string, TextureRecord>();
  private textureBytes = 0;
  private readonly onLost = (event: Event) => { event.preventDefault(); this.lost = true; this.releaseGpuObjects(); };
  private readonly onRestored = () => { try { if (this.canvas) { this.createGpuObjects(); for (const record of this.textures.values()) this.uploadTexture(record); } this.lost = false; } catch { this.lost = true; this.releaseGpuObjects(); } };

  initialize(host: HTMLCanvasElement, profile: DeviceProfile): void {
    if (this.canvas) throw new Error("WEBGL2_RENDERER_ALREADY_INITIALIZED");
    const gl = host.getContext("webgl2", { alpha: false, antialias: profile.antialias, depth: false, stencil: false, powerPreference: "low-power", preserveDrawingBuffer: false });
    if (!gl) throw new Error("WEBGL2_CONTEXT_UNAVAILABLE");
    this.canvas = host; this.gl = gl; this.quality = profile.tier;
    host.addEventListener("webglcontextlost", this.onLost, false); host.addEventListener("webglcontextrestored", this.onRestored, false);
    try { this.createGpuObjects(); this.resize(host.clientWidth || host.width || 1, host.clientHeight || host.height || 1, Math.min(profile.maxPixelRatio, 1)); }
    catch (error) { host.removeEventListener("webglcontextlost", this.onLost); host.removeEventListener("webglcontextrestored", this.onRestored); this.releaseGpuObjects(); this.gl = null; this.canvas = null; throw error; }
  }
  createScene(_manifest: RuntimeProjectManifest): WebGL2Scene { return new WebGL2Scene(); }
  resize(width:number,height:number,pixelRatio:number):void {
    if (!this.canvas || !this.gl) return;
    this.width=Math.max(1,Math.floor(Number.isFinite(width)?width:1)); this.height=Math.max(1,Math.floor(Number.isFinite(height)?height:1));
    const cap=this.quality===0?1:this.quality===1?1.25:1.5;
    this.pixelRatio=Math.max(0.5,Math.min(Number.isFinite(pixelRatio)?pixelRatio:1,cap));
    const w=Math.max(1,Math.floor(this.width*this.pixelRatio)), h=Math.max(1,Math.floor(this.height*this.pixelRatio));
    if(this.canvas.width!==w)this.canvas.width=w; if(this.canvas.height!==h)this.canvas.height=h;
    this.gl.viewport(0,0,w,h);
  }
  registerTexture(id: string, source: TexImageSource): boolean {
    if (this.lost || !this.gl || !/^[a-zA-Z0-9_-]{1,80}$/.test(id) || !source) return false;
    const size = sourceSize(source); const maxDimension = this.quality === 0 ? 1024 : this.quality === 1 ? 2048 : 4096;
    if (!Number.isSafeInteger(size.width) || !Number.isSafeInteger(size.height) || size.width < 1 || size.height < 1 || size.width > maxDimension || size.height > maxDimension) return false;
    const bytes = size.width * size.height * 4; const budget = this.quality === 0 ? 8 : this.quality === 1 ? 16 : 32;
    const previous = this.textures.get(id);
    if (previous) return previous.source === source;
    const maxTextures = this.quality === 0 ? 32 : this.quality === 1 ? 64 : 128;
    const total = this.textureBytes + bytes;
    if (!Number.isSafeInteger(bytes) || total > budget * 1024 * 1024 || this.textures.size >= maxTextures) return false;
    const record: TextureRecord = { source, texture: null, width: size.width, height: size.height, bytes };
    try { this.uploadTexture(record); } catch { if (record.texture) this.gl.deleteTexture(record.texture); return false; }
    this.textureBytes = total; this.textures.set(id, record); return true;
  }
  removeTexture(id: string): void {
    const record = this.textures.get(id); if (!record) return;
    if (record.texture && this.gl && !this.lost) this.gl.deleteTexture(record.texture);
    this.textureBytes -= record.bytes; this.textures.delete(id);
  }
  registerAtlasPage(atlasId: string, atlas: SpriteAtlas, pageIndex: number, source: TexImageSource): boolean {
    if (!/^[a-zA-Z0-9_-]{1,64}$/.test(atlasId) || !atlas || atlas.schemaVersion !== 1 || !Number.isInteger(pageIndex) || !Array.isArray(atlas.pages) || !Array.isArray(atlas.frames)) return false;
    const page = atlas.pages[pageIndex]; if (!page || !Number.isSafeInteger(page.width) || !Number.isSafeInteger(page.height)) return false;
    const size = sourceSize(source); if (size.width !== page.width || size.height !== page.height) return false;
    let frameCount = 0;
    for (const frame of atlas.frames) if (frame.page === pageIndex) {
      frameCount++;
      if (!/^[A-Za-z0-9_-]{1,80}$/.test(frame.id) || !Number.isSafeInteger(frame.x) || !Number.isSafeInteger(frame.y) || !Number.isSafeInteger(frame.width) || !Number.isSafeInteger(frame.height) || frame.x < 0 || frame.y < 0 || frame.width < 1 || frame.height < 1 || frame.x + frame.width > page.width || frame.y + frame.height > page.height) return false;
    }
    return frameCount > 0 && this.registerTexture(`${atlasId}-${pageIndex}`, source);
  }
  render(scene:WebGL2Scene,_interpolationAlpha:number):void {
    const gl=this.gl; const program=this.program; const buffer=this.buffer;
    if(!gl||!program||!buffer||this.lost||!scene||!Number.isFinite(scene.zoom)||scene.zoom<=0)return;
    const clear=parseHexColor(scene.clearColor)??[0.063,0.063,0.094,1];
    gl.viewport(0,0,this.canvas?.width??1,this.canvas?.height??1); gl.clearColor(clear[0],clear[1],clear[2],1); gl.clear(gl.COLOR_BUFFER_BIT);
    const batch=buildWebGL2Batches(scene,this.batches); if(batch.count===0)return;
    gl.useProgram(program); gl.bindBuffer(gl.ARRAY_BUFFER,buffer); gl.bufferData(gl.ARRAY_BUFFER,batch.data.subarray(0,batch.count*FLOATS_PER_VERTEX),gl.DYNAMIC_DRAW);
    const stride=FLOATS_PER_VERTEX*4;
    gl.enableVertexAttribArray(this.positionLocation); gl.vertexAttribPointer(this.positionLocation,2,gl.FLOAT,false,stride,0);
    gl.enableVertexAttribArray(this.colorLocation); gl.vertexAttribPointer(this.colorLocation,4,gl.FLOAT,false,stride,2*4);
    gl.enableVertexAttribArray(this.uvLocation); gl.vertexAttribPointer(this.uvLocation,2,gl.FLOAT,false,stride,6*4);
    gl.uniform2f(this.resolutionLocation,this.width,this.height); gl.uniform2f(this.cameraLocation,scene.cameraX,scene.cameraY); gl.uniform1f(this.zoomLocation,scene.zoom);
    gl.activeTexture(gl.TEXTURE0); gl.uniform1i(this.textureLocation,0); gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);
    for (let i=0;i<batch.runCount;i++) {
      const textureId=batch.runTextureIds[i]; const first=batch.runFirst[i]!; const count=batch.runCounts[i]!; if(count<=0)continue;
      if(textureId!==null){const texture=this.textures.get(textureId)?.texture;if(!texture)continue;gl.bindTexture(gl.TEXTURE_2D,texture);gl.uniform1f(this.texturedLocation,1);}
      else {gl.bindTexture(gl.TEXTURE_2D,null);gl.uniform1f(this.texturedLocation,0);}
      gl.drawArrays(gl.TRIANGLES,first,count);
    }
  }
  setQuality(tier:QualityTier):void { this.quality=tier; this.resize(this.width,this.height,this.pixelRatio); }
  disposeScene(scene:WebGL2Scene):void { scene.clear(); }
  private compile(type:number,source:string):WebGLShader {
    const gl=this.gl!; const shader=gl.createShader(type); if(!shader)throw new Error("WEBGL2_SHADER_ALLOCATION_FAILED");
    gl.shaderSource(shader,source); gl.compileShader(shader);
    if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS)){const log=gl.getShaderInfoLog(shader)??"unknown";gl.deleteShader(shader);throw new Error(`WEBGL2_SHADER_COMPILE_FAILED:${log.slice(0,240)}`);}
    return shader;
  }
  private createGpuObjects():void {
    const gl=this.gl!; const vs=this.compile(gl.VERTEX_SHADER,VERTEX_SHADER); let fs:WebGLShader;
    try{fs=this.compile(gl.FRAGMENT_SHADER,FRAGMENT_SHADER);}catch(error){gl.deleteShader(vs);throw error;}
    const program=gl.createProgram(); if(!program){gl.deleteShader(vs);gl.deleteShader(fs);throw new Error("WEBGL2_PROGRAM_ALLOCATION_FAILED");}
    gl.attachShader(program,vs);gl.attachShader(program,fs);gl.linkProgram(program);gl.deleteShader(vs);gl.deleteShader(fs);
    if(!gl.getProgramParameter(program,gl.LINK_STATUS)){const log=gl.getProgramInfoLog(program)??"unknown";gl.deleteProgram(program);throw new Error(`WEBGL2_PROGRAM_LINK_FAILED:${log.slice(0,240)}`);}
    const buffer=gl.createBuffer();if(!buffer){gl.deleteProgram(program);throw new Error("WEBGL2_BUFFER_ALLOCATION_FAILED");}
    this.program=program;this.buffer=buffer;
    this.positionLocation=gl.getAttribLocation(program,"a_position");this.colorLocation=gl.getAttribLocation(program,"a_color");this.uvLocation=gl.getAttribLocation(program,"a_uv");
    this.resolutionLocation=gl.getUniformLocation(program,"u_resolution");this.cameraLocation=gl.getUniformLocation(program,"u_camera");this.zoomLocation=gl.getUniformLocation(program,"u_zoom");this.textureLocation=gl.getUniformLocation(program,"u_texture");this.texturedLocation=gl.getUniformLocation(program,"u_textured");
    if(this.positionLocation<0||this.colorLocation<0||this.uvLocation<0||!this.resolutionLocation||!this.cameraLocation||!this.zoomLocation||!this.textureLocation||!this.texturedLocation){this.releaseGpuObjects();throw new Error("WEBGL2_SHADER_INTERFACE_INVALID");}
  }
  private uploadTexture(record: TextureRecord): void {
    const gl=this.gl!;
    // Do not misattribute an earlier unrelated WebGL error to this upload.
    for (let i=0;i<8 && gl.getError()!==gl.NO_ERROR;i++) { /* drain bounded stale errors */ }
    const texture=gl.createTexture(); if(!texture)throw new Error("WEBGL2_TEXTURE_ALLOCATION_FAILED");
    gl.bindTexture(gl.TEXTURE_2D,texture);
    try {
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,1); gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,1);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
      gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,record.source);
      const error=gl.getError(); if(error!==gl.NO_ERROR)throw new Error(`WEBGL2_TEXTURE_UPLOAD_FAILED:${error}`);
      record.texture=texture;
    } catch(error) { gl.deleteTexture(texture); throw error; }
    finally { gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,0); gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,0); gl.bindTexture(gl.TEXTURE_2D,null); }
  }
  private releaseGpuObjects():void {
    const gl=this.gl;if(!gl)return;
    if(this.buffer)gl.deleteBuffer(this.buffer);if(this.program)gl.deleteProgram(this.program);
    for(const record of this.textures.values()){if(record.texture)gl.deleteTexture(record.texture);record.texture=null;}
    this.buffer=null;this.program=null;this.positionLocation=-1;this.colorLocation=-1;this.uvLocation=-1;this.resolutionLocation=null;this.cameraLocation=null;this.zoomLocation=null;this.textureLocation=null;this.texturedLocation=null;
  }
  dispose():void {
    this.canvas?.removeEventListener("webglcontextlost",this.onLost);this.canvas?.removeEventListener("webglcontextrestored",this.onRestored);
    if(!this.lost)this.releaseGpuObjects();this.textures.clear();this.textureBytes=0;this.gl=null;this.canvas=null;this.lost=false;
  }
  get residentTextureBytes(): number { return this.textureBytes; }
  get residentTextureCount(): number { return this.textures.size; }
}
