import assert from "node:assert/strict";
import test from "node:test";
import { WebGL2Scene, buildWebGL2Batches } from "./renderers/webgl2-2d.ts";
import { buildSpriteAtlas } from "./sprite-atlas.ts";

// This suite targets the renderer that is actually exported by the runtime.
test("WebGL2 sprite batches follow primitive geometry with correct alpha and texture runs", () => {
  const atlas = buildSpriteAtlas([{ id: "hero", width: 16, height: 16 }], { maxSize: 64, padding: 1 });
  assert.equal(atlas.ok, true);
  if (!atlas.ok) return;
  const scene = new WebGL2Scene();
  scene.add({ kind: "rect", x: 0, y: 0, width: 10, height: 10, color: "#ffffff", layer: 0 });
  assert.equal(scene.addAtlasSprite("atlas", atlas.atlas, "hero", { x: 12, y: 4, alpha: 0.5, layer: 1 }), true);
  const result = buildWebGL2Batches(scene, { data: new Float32Array(128), count: 0, runCount: 0, runTextureIds: [], runFirst: [], runCounts: [] });
  assert.equal(result.count, 12);
  assert.equal(result.runCount, 2);
  assert.deepEqual(result.runTextureIds.slice(0, 2), [null, "atlas-0"]);
  assert.equal(result.data[53], 0.5);
});
