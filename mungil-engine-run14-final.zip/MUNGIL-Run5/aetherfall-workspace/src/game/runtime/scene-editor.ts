import { ProjectHistory, type ProjectDocument, type ProjectNode, type ProjectResult } from "./project-document.ts";

export type SceneTreeItem = Readonly<{ id: string; name: string; type: string; depth: number; childCount: number; selected: boolean }>;
export type SceneEditorLimits = Readonly<{ maxSelection: number; maxDuplicateNodes: number }>;
const DEFAULT_LIMITS: SceneEditorLimits = Object.freeze({ maxSelection: 256, maxDuplicateNodes: 512 });
const SAFE_ID = /^[A-Za-z0-9_-]{1,80}$/;

/** Renderer-neutral editor commands; persistence and undo remain owned by ProjectHistory. */
export class SceneEditorSession {
  readonly history: ProjectHistory;
  private readonly selected = new Set<string>();
  private readonly limits: SceneEditorLimits;
  private disposed = false;
  constructor(document: ProjectDocument, limits: Partial<SceneEditorLimits> = {}) {
    this.history = new ProjectHistory(document);
    this.limits = { ...DEFAULT_LIMITS, ...limits };
    if (!Number.isInteger(this.limits.maxSelection) || this.limits.maxSelection < 1 || this.limits.maxSelection > 2048 || !Number.isInteger(this.limits.maxDuplicateNodes) || this.limits.maxDuplicateNodes < 1 || this.limits.maxDuplicateNodes > 4096) throw new TypeError("INVALID_SCENE_EDITOR_LIMITS");
  }
  get document(): ProjectDocument { return this.history.document; }
  get selection(): readonly string[] { return [...this.selected]; }
  private assertActive(): void { if (this.disposed) throw new Error("SCENE_EDITOR_DISPOSED"); }
  select(ids: readonly string[], additive = false): ProjectResult<readonly string[]> {
    this.assertActive();
    if (!Array.isArray(ids) || ids.length > this.limits.maxSelection || ids.some(id => typeof id !== "string" || !SAFE_ID.test(id))) return { ok: false, error: "INVALID_SELECTION" };
    const known = new Set(this.document.nodes.map(node => node.id));
    if (ids.some(id => !known.has(id))) return { ok: false, error: "SELECTION_NODE_NOT_FOUND" };
    if (!additive) this.selected.clear();
    for (const id of ids) this.selected.add(id);
    return { ok: true, value: this.selection };
  }
  tree(): readonly SceneTreeItem[] {
    this.assertActive();
    const nodes = this.document.nodes;
    const children = new Map<string | null, ProjectNode[]>();
    for (const node of nodes) { const list = children.get(node.parentId) ?? []; list.push(node); children.set(node.parentId, list); }
    const output: SceneTreeItem[] = []; const visited = new Set<string>();
    const walk = (parent: string | null, depth: number) => {
      for (const node of children.get(parent) ?? []) {
        if (visited.has(node.id)) continue;
        visited.add(node.id);
        output.push({ id: node.id, name: node.name, type: node.type, depth, childCount: (children.get(node.id) ?? []).length, selected: this.selected.has(node.id) });
        walk(node.id, depth + 1);
      }
    };
    walk(null, 0);
    // Invalid/disconnected nodes are not hidden; validation should prevent them, but fail visibly.
    for (const node of nodes) if (!visited.has(node.id)) output.push({ id: node.id, name: node.name, type: node.type, depth: 0, childCount: 0, selected: this.selected.has(node.id) });
    return output;
  }
  add(node: ProjectNode, now?: number): ProjectResult<ProjectDocument> { this.assertActive(); return this.history.apply({ kind: "add", node }, now); }
  rename(id: string, name: string, now?: number): ProjectResult<ProjectDocument> { this.assertActive(); return this.history.apply({ kind: "rename", id, name }, now); }
  setProperties(id: string, props: Readonly<Record<string, unknown>>, now?: number): ProjectResult<ProjectDocument> { this.assertActive(); return this.history.apply({ kind: "set-props", id, props }, now); }
  reparent(id: string, parentId: string | null, now?: number): ProjectResult<ProjectDocument> { this.assertActive(); return this.history.apply({ kind: "set-parent", id, parentId }, now); }
  remove(id: string, now?: number): ProjectResult<ProjectDocument> {
    this.assertActive(); const descendants = new Set([id]); let changed = true;
    while (changed) { changed = false; for (const node of this.document.nodes) if (node.parentId !== null && descendants.has(node.parentId) && !descendants.has(node.id)) { descendants.add(node.id); changed = true; } }
    const result = this.history.apply({ kind: "remove", id }, now);
    if (result.ok) for (const selected of descendants) this.selected.delete(selected);
    return result;
  }
  duplicateSubtree(rootId: string, createId: (sourceId: string, index: number) => string, now?: number): ProjectResult<readonly string[]> {
    this.assertActive();
    const nodes = this.document.nodes; const root = nodes.find(node => node.id === rootId);
    if (!root) return { ok: false, error: "NODE_NOT_FOUND" };
    const subtree: ProjectNode[] = []; const included = new Set([rootId]); let changed = true;
    while (changed) { changed = false; for (const node of nodes) if (node.parentId !== null && included.has(node.parentId) && !included.has(node.id)) { included.add(node.id); changed = true; } }
    for (const node of nodes) if (included.has(node.id)) subtree.push(node);
    if (subtree.length > this.limits.maxDuplicateNodes) return { ok: false, error: "DUPLICATE_SUBTREE_LIMIT" };
    const remap = new Map<string, string>();
    for (let i = 0; i < subtree.length; i++) { const id = createId(subtree[i]!.id, i); if (typeof id !== "string" || !SAFE_ID.test(id) || nodes.some(node => node.id === id) || [...remap.values()].includes(id)) return { ok: false, error: "INVALID_DUPLICATE_ID" }; remap.set(subtree[i]!.id, id); }
    const created = subtree.map(node => remap.get(node.id)!);
    const operations = subtree.map(node => ({ kind: "add" as const, node: { ...node, id: remap.get(node.id)!, name: `${node.name} Copy`, parentId: node.id === rootId ? root.parentId : remap.get(node.parentId ?? "") ?? null } }));
    const result = this.history.applyBatch(operations, now);
    if (!result.ok) return { ok: false, error: `DUPLICATE_FAILED:${result.error}` };
    this.selected.clear(); for (const id of created) this.selected.add(id);
    return { ok: true, value: created };
  }
  undo(): ProjectResult<ProjectDocument> { this.assertActive(); const result = this.history.undo(); if (result.ok) this.pruneSelection(); return result; }
  redo(): ProjectResult<ProjectDocument> { this.assertActive(); const result = this.history.redo(); if (result.ok) this.pruneSelection(); return result; }
  private pruneSelection(): void { const known = new Set(this.document.nodes.map(node => node.id)); for (const id of this.selected) if (!known.has(id)) this.selected.delete(id); }
  dispose(): void { this.selected.clear(); this.disposed = true; }
}
