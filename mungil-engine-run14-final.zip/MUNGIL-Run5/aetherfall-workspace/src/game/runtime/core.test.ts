import assert from "node:assert/strict";
import test from "node:test";
import { RuntimeKernel } from "./kernel.ts";
import { validateRuntimeManifest } from "./contracts.ts";
import {
  FixedStepClock,
  QualityGovernor,
  ResourceScope,
  SeededRandom,
  StateMachine,
  createDeviceProfile,
  validateAssetManifest,
  writeJsonStorage,
  readJsonStorage,
} from "./core.ts";

test("fixed-step clock clamps long frames and bounds catch-up", () => {
  const clock = new FixedStepClock({ stepSeconds: 1 / 60, maxFrameSeconds: 0.1, maxSubSteps: 3 });
  assert.equal(clock.beginFrame(1000), 0);
  assert.equal(clock.beginFrame(2000), 0.1);
  let calls = 0;
  assert.equal(clock.runFixed(() => { calls += 1; }), 3);
  assert.equal(calls, 3);
  assert.ok(clock.droppedSeconds >= 0.04);
  assert.ok(clock.alpha >= 0 && clock.alpha < 1);
});

test("fixed-step clock resets cleanly across pause and resume", () => {
  const clock = new FixedStepClock();
  clock.beginFrame(10);
  clock.beginFrame(27);
  clock.pause();
  assert.equal(clock.beginFrame(10000), 0);
  clock.resume(20000);
  assert.equal(clock.beginFrame(20016), 0.016);
  assert.equal(clock.runFixed(() => undefined), 0);
});

test("fixed-step clock rejects unstable configuration", () => {
  assert.throws(() => new FixedStepClock({ stepSeconds: 0, maxFrameSeconds: 0.1 }), /INVALID_FIXED_STEP_CONFIGURATION/);
  assert.throws(() => new FixedStepClock({ stepSeconds: 1 / 60, maxFrameSeconds: 0.1, maxSubSteps: 99 }), /INVALID_FIXED_STEP_CONFIGURATION/);
});

test("resource scope disposes in reverse order exactly once", () => {
  const scope = new ResourceScope();
  const order: number[] = [];
  scope.defer(() => order.push(1));
  const remove = scope.defer(() => order.push(2));
  remove();
  scope.defer(() => order.push(3));
  scope.dispose();
  scope.dispose();
  assert.deepEqual(order, [2, 3, 1]);
  assert.equal(scope.isDisposed, true);
  assert.equal(scope.size, 0);
});

test("resource scope runs late cleanup immediately", () => {
  const scope = new ResourceScope();
  scope.dispose();
  let count = 0;
  scope.defer(() => { count += 1; });
  assert.equal(count, 1);
});

test("device profiles are bounded and conservative on low-end hints", () => {
  const low = createDeviceProfile({ deviceMemory: 4, hardwareConcurrency: 4, coarsePointer: true });
  const high = createDeviceProfile({ deviceMemory: 12, hardwareConcurrency: 12, coarsePointer: false });
  assert.equal(low.tier, 0);
  assert.equal(low.targetFps, 30);
  assert.equal(low.maxPixelRatio, 1);
  assert.equal(low.shadows, false);
  assert.equal(high.tier, 2);
  assert.equal(high.shadows, true);
  assert.ok(high.maxPixelRatio <= 1.6);
  const unknownTouch = createDeviceProfile({ coarsePointer: true, hardwareConcurrency: 8 });
  assert.equal(unknownTouch.tier, 0);
});

test("quality governor steps down quickly but steps up slowly", () => {
  const governor = new QualityGovernor(2, { sampleCount: 12, downMs: 20, upMs: 12, allowUpgrade: true });
  for (let i = 0; i < 36; i++) governor.sample(28);
  assert.equal(governor.currentTier, 1);
  for (let i = 0; i < 24; i++) governor.sample(28);
  assert.equal(governor.currentTier, 0);
  for (let i = 0; i < 60; i++) governor.sample(8);
  assert.equal(governor.currentTier, 1);
  for (let i = 0; i < 60; i++) governor.sample(8);
  assert.equal(governor.currentTier, 2);
});

test("seeded random reproduces and restores its sequence", () => {
  const a = new SeededRandom(12345);
  const b = new SeededRandom(12345);
  assert.deepEqual([a.nextUint(), a.nextUint(), a.nextUint()], [b.nextUint(), b.nextUint(), b.nextUint()]);
  const snapshot = a.snapshot();
  const expected = a.nextUint();
  assert.equal(a.restore(snapshot), true);
  assert.equal(a.nextUint(), expected);
  assert.equal(a.restore(-1), false);
});

test("FSM applies the first matching table transition deterministically", () => {
  const entered: string[] = [];
  const fsm = new StateMachine<{ speed: number }>("idle", ["idle", "walk", "run"], [
    { from: "idle", to: "walk", when: (c) => c.speed > 0.1, onEnter: () => entered.push("walk") },
    { from: "walk", to: "run", when: (c) => c.speed > 5, onEnter: () => entered.push("run") },
  ]);
  assert.equal(fsm.update({ speed: 0 }, 1 / 60), false);
  assert.equal(fsm.update({ speed: 1 }, 1 / 60), true);
  assert.equal(fsm.state, "walk");
  assert.equal(fsm.update({ speed: 6 }, 1 / 60), true);
  assert.equal(fsm.state, "run");
  assert.deepEqual(entered, ["walk", "run"]);
  assert.equal(fsm.force("unknown"), false);
});

test("asset manifest validates ids, paths, types and total bytes", () => {
  assert.deepEqual(validateAssetManifest([
    { id: "hero", path: "characters/hero.glb", type: "model", bytes: 1024 },
    { id: "theme", path: "audio/theme.ogg", type: "audio", bytes: 2048 },
  ]), { ok: true, totalBytes: 3072 });
  assert.equal(validateAssetManifest([{ id: "a", path: "../secret", type: "image", bytes: 10 }]).ok, false);
  assert.equal(validateAssetManifest([
    { id: "a", path: "a.png", type: "image", bytes: 1 },
    { id: "a", path: "b.png", type: "image", bytes: 1 },
  ]).ok, false);
  assert.equal(validateAssetManifest([{ id: "huge", path: "huge.bin", type: "binary", bytes: 100 }], { maxBytes: 10 }).ok, false);
  assert.equal(validateAssetManifest([], { maxAssets: -1 }).ok, false);
  assert.equal(validateAssetManifest([{ id: "drive", path: "C:/secret", type: "image", bytes: 1 }]).ok, false);
});

test("storage helpers fail closed for malformed, denied and quota-full storage", () => {
  const values = new Map<string, string>();
  const storage = {
    getItem: (key: string) => values.get(key) ?? null,
    setItem: (key: string, value: string) => { values.set(key, value); },
    removeItem: (key: string) => { values.delete(key); },
    clear: () => values.clear(),
    key: (index: number) => [...values.keys()][index] ?? null,
    get length() { return values.size; },
  } as Storage;
  const valid = (v: unknown): v is { score: number } => !!v && typeof v === "object" && typeof (v as { score?: unknown }).score === "number";
  assert.equal(writeJsonStorage(storage, "save", { score: 42 }), true);
  assert.deepEqual(readJsonStorage(storage, "save", { score: 0 }, valid), { score: 42 });
  values.set("save", "{broken");
  assert.deepEqual(readJsonStorage(storage, "save", { score: 0 }, valid), { score: 0 });
  const denied = { getItem() { throw new Error("denied"); }, setItem() { throw new Error("quota"); } } as unknown as Storage;
  assert.deepEqual(readJsonStorage(denied, "save", { score: 0 }, valid), { score: 0 });
  assert.equal(writeJsonStorage(denied, "save", { score: 1 }), false);
});


test("runtime kernel orders systems and disposes them in reverse", () => {
  const device = createDeviceProfile({ deviceMemory: 8, hardwareConcurrency: 8 });
  const context = { qualityTier: device.tier, tick: 0, deltaSeconds: 0, interpolationAlpha: 0 };
  const kernel = new RuntimeKernel({ context, device, stepSeconds: 1 / 60, maxSubSteps: 3 });
  const calls: string[] = [];
  assert.equal(kernel.register({ id: "render", order: 20, init: () => calls.push("init-render"), fixedUpdate: () => calls.push("fixed-render"), dispose: () => calls.push("dispose-render") }), true);
  assert.equal(kernel.register({ id: "physics", order: 10, init: () => calls.push("init-physics"), fixedUpdate: () => calls.push("fixed-physics"), dispose: () => calls.push("dispose-physics") }), true);
  assert.equal(kernel.register({ id: "physics", order: 0 }), false);
  assert.equal(kernel.start(0), true);
  assert.deepEqual(calls, ["init-physics", "init-render"]);
  assert.equal(kernel.frame(0), true);
  assert.equal(kernel.frame(17), true);
  assert.deepEqual(calls.slice(2), ["fixed-physics", "fixed-render"]);
  assert.equal(kernel.fixedTicks, 1);
  assert.equal(kernel.status, "running");
  kernel.dispose();
  kernel.dispose();
  assert.deepEqual(calls.slice(-2), ["dispose-render", "dispose-physics"]);
  assert.equal(kernel.status, "disposed");
});

test("runtime kernel faults safely and releases the system that failed initialization", () => {
  const device = createDeviceProfile({ deviceMemory: 4, hardwareConcurrency: 4 });
  const context = { qualityTier: device.tier, tick: 0, deltaSeconds: 0, interpolationAlpha: 0 };
  const faults: string[] = [];
  const disposed: string[] = [];
  const kernel = new RuntimeKernel({ context, device, onError: (id) => faults.push(id) });
  kernel.register({ id: "first", init: () => undefined, dispose: () => disposed.push("first") });
  kernel.register({ id: "second", init: () => { throw new Error("init failure"); }, dispose: () => disposed.push("second") });
  assert.equal(kernel.start(0), false);
  assert.equal(kernel.status, "faulted");
  assert.deepEqual(faults, ["second"]);
  assert.deepEqual(disposed, ["second", "first"]);
  assert.equal(kernel.frame(16), false);
});

test("runtime manifest validates schema, projection, feature flags and safe scene ids", () => {
  const manifest = {
    schemaVersion: 1, projectId: "demo_project", title: "Demo", renderer: "auto", projection: "isometric-2.5d",
    simulationHz: 60, targetFps: 30, qualityTier: "auto", seed: 123,
    features: { physics2d: true, physics3d: false, skeletal2d: true, skeletal3d: false, particles: true, navigation: false, multiplayer: false, postProcessing: false, editorTools: false },
    scenes: ["scenes/menu", "scenes/level-01"],
  };
  assert.deepEqual(validateRuntimeManifest(manifest), { ok: true });
  assert.equal(validateRuntimeManifest({ ...manifest, scenes: ["../secret"] }).ok, false);
  assert.equal(validateRuntimeManifest({ ...manifest, simulationHz: 240 }).ok, false);
});

import { ObjectPool } from "./pool.ts";
import { UniformGrid2D } from "./spatial.ts";
import { isometricToWorld, projectPseudo3D, raycastGrid, worldToIsometric } from "./projection.ts";

test("fixed object pool is bounded and rejects duplicate release", () => {
  let constructed = 0;
  const pool = new ObjectPool(2, () => ({ value: ++constructed }), (item) => { item.value = 0; });
  const a = pool.acquire();
  const b = pool.acquire();
  assert.notEqual(a, b);
  assert.equal(pool.acquire(), -1);
  assert.equal(pool.get(a)?.value, 1);
  assert.equal(pool.release(a), true);
  assert.equal(pool.release(a), false);
  const again = pool.acquire();
  assert.equal(again, a);
  assert.equal(pool.get(again)?.value, 0);
  assert.equal(constructed, 2);
  pool.dispose();
  assert.equal(pool.acquire(), -1);
});

test("uniform grid broadphase deduplicates multi-cell entities and bounds capacity", () => {
  const grid = new UniformGrid2D(0, 0, 10, 8, 8, 32, 128, 16);
  assert.equal(grid.insert(3, { minX: 2, minY: 2, maxX: 22, maxY: 22 }), true);
  assert.equal(grid.insert(4, { minX: 20, minY: 20, maxX: 29, maxY: 29 }), true);
  const out = new Uint32Array(8);
  const count = grid.query({ minX: 10, minY: 10, maxX: 25, maxY: 25 }, out);
  assert.equal(count, 2);
  assert.deepEqual([...out.slice(0, count)].sort(), [3, 4]);
  assert.equal(grid.insert(5, { minX: 0, minY: 0, maxX: 1000, maxY: 1000 }), false);
  assert.equal(grid.insert(33, { minX: 0, minY: 0, maxX: 1, maxY: 1 }), false);
  // A single entity may only be inserted once per build; otherwise stale
  // memberships survive when a caller forgets to clear before rebuilding.
  assert.equal(grid.insert(3, { minX: 40, minY: 40, maxX: 45, maxY: 45 }), false);
  // A box starting at the far boundary is outside, not in the last cell.
  assert.equal(grid.insert(6, { minX: 80, minY: 10, maxX: 85, maxY: 15 }), true);
  assert.equal(grid.entriesUsed, 10);
  grid.clear();
  assert.equal(grid.entriesUsed, 0);
  assert.equal(grid.query({ minX: 0, minY: 0, maxX: 10, maxY: 10 }, out), 0);
  assert.equal(grid.insert(3, { minX: 2, minY: 2, maxX: 5, maxY: 5 }), true);
  assert.equal(grid.entriesUsed, 1);
});

test("isometric projection round-trips and rejects invalid dimensions", () => {
  const screen = { x: 0, y: 0 };
  const world = { x: 0, y: 0 };
  assert.equal(worldToIsometric(12.5, -8, 64, 32, screen), true);
  assert.equal(isometricToWorld(screen.x, screen.y, 64, 32, world), true);
  assert.ok(Math.abs(world.x - 12.5) < 1e-9);
  assert.ok(Math.abs(world.y + 8) < 1e-9);
  assert.equal(worldToIsometric(1, 2, 0, 32, screen), false);
});

test("pseudo-3D projection rejects points behind camera", () => {
  const out = { x: 0, y: 0 };
  assert.equal(projectPseudo3D(2, 1, 10, 0, 0, 0, 1, 100, out), true);
  assert.equal(out.x, 20);
  assert.equal(projectPseudo3D(2, 1, -1, 0, 0, 0, 1, 100, out), false);
});

test("grid raycaster finds wall and safely exits map bounds", () => {
  const map = new Uint8Array(25);
  map[2 * 5 + 3] = 1;
  const hit = { hit: false, distance: 0, cellX: 0, cellY: 0, side: 0 as 0 | 1 };
  assert.equal(raycastGrid(map, 5, 5, 1.5, 2.5, 1, 0, 10, hit), true);
  assert.equal(hit.hit, true);
  assert.equal(hit.cellX, 3);
  assert.equal(hit.cellY, 2);
  assert.equal(raycastGrid(map, 5, 5, 1.5, 2.5, 0, 0, 10, hit), false);
  assert.equal(raycastGrid(map, 5, 5, 1.5, 2.5, 1, 0, 10, hit), true);
});

test("asset manifest rejects encoded traversal, URI schemes and control characters", () => {
  assert.equal(validateAssetManifest([{ id: "x", path: "%2e%2e/private.bin", type: "binary", bytes: 1 }]).ok, false);
  assert.equal(validateAssetManifest([{ id: "x", path: "https://example.test/a", type: "binary", bytes: 1 }]).ok, false);
  assert.equal(validateAssetManifest([{ id: "x", path: "assets/%00evil.png", type: "image", bytes: 1 }]).ok, false);
});

test("storage helpers enforce bounded payload and reject non-serializable undefined", () => {
  const values = new Map<string, string>();
  const storage = {
    getItem: (key: string) => values.get(key) ?? null,
    setItem: (key: string, value: string) => { values.set(key, value); },
    removeItem: (key: string) => { values.delete(key); },
    clear: () => values.clear(),
    key: (index: number) => [...values.keys()][index] ?? null,
    get length() { return values.size; },
  } as Storage;
  assert.equal(writeJsonStorage(storage, "large", "x".repeat(1_048_577)), false);
  assert.equal(writeJsonStorage(storage, "undefined", undefined), false);
  values.set("large", `"${"x".repeat(1_048_577)}"`);
  assert.deepEqual(readJsonStorage(storage, "large", { ok: false }, (v): v is { ok: boolean } => !!v && typeof v === "object"), { ok: false });
});

test("grid raycaster reports immediate hit when ray begins inside solid cell", () => {
  const map = new Uint8Array([1, 0, 0, 0]);
  const hit = { hit: false, distance: 10, cellX: -1, cellY: -1, side: 1 as 0 | 1 };
  assert.equal(raycastGrid(map, 2, 2, 0.5, 0.5, 1, 0, 5, hit), true);
  assert.equal(hit.hit, true);
  assert.equal(hit.distance, 0);
});

import { resolveRenderer } from "./capabilities.ts";

test("renderer resolver keeps 3D projects off Canvas2D and prefers stable backends", () => {
  const legacy = { webgpu: false, webgl2: false, webgl1: false, canvas2d: true } as const;
  assert.deepEqual(resolveRenderer("auto", "orthographic-2d", legacy), { ok: true, renderer: "canvas2d" });
  assert.deepEqual(resolveRenderer("auto", "perspective-3d", legacy), { ok: false, error: "NO_COMPATIBLE_3D_RENDERER" });
  assert.deepEqual(resolveRenderer("auto", "perspective-3d", { ...legacy, webgl2: true }), { ok: true, renderer: "webgl2" });
  assert.deepEqual(resolveRenderer("canvas2d", "perspective-3d", legacy), { ok: false, error: "CANVAS2D_CANNOT_RENDER_PERSPECTIVE_3D" });
  assert.deepEqual(resolveRenderer("webgpu", "perspective-3d", legacy), { ok: false, error: "REQUESTED_RENDERER_UNAVAILABLE:webgpu" });
});

import { MemoryBudget } from "./memory.ts";
import { createArtBudget, createGenreBudget } from "./profiles.ts";

test("memory budget evicts least-recently-used unpinned resources within hard cap", () => {
  const freed: string[] = [];
  const budget = new MemoryBudget(100);
  assert.equal(budget.register("texture-a", "texture", 40, () => freed.push("a")), true);
  assert.equal(budget.register("mesh-b", "mesh", 30, () => freed.push("b")), true);
  assert.equal(budget.touch("texture-a"), true);
  assert.equal(budget.register("audio-c", "audio", 50, () => freed.push("c")), true);
  assert.deepEqual(freed, ["b"]);
  assert.equal(budget.usedBytes, 90);
  assert.equal(budget.pin("texture-a"), true);
  assert.equal(budget.register("other-d", "other", 80), false);
  assert.equal(budget.release("texture-a"), true);
  assert.equal(budget.usedBytes, 50);
  budget.dispose();
  assert.equal(budget.usedBytes, 0);
  assert.equal(budget.register("after", "other", 1), false);
});

test("genre and art-direction budgets preserve styles while scaling low-tier cost", () => {
  const pixel = createArtBudget("pixel-art", 0);
  const pbr = createArtBudget("pbr", 0);
  const pbrHigh = createArtBudget("pbr", 2);
  assert.equal(pixel.preferredRenderer, "canvas2d");
  assert.equal(pixel.nearestFiltering, true);
  assert.equal(pixel.antialias, false);
  assert.equal(pbr.textureMaxDimension, 512);
  assert.equal(pbr.realtimeShadows, false);
  assert.equal(pbrHigh.textureMaxDimension, 2048);
  assert.equal(pbrHigh.postProcessing, true);
  const fighting = createGenreBudget("fighting", 0);
  const sandbox = createGenreBudget("sandbox", 0);
  assert.equal(fighting.simulationHz, 30);
  assert.ok(fighting.maxEntities <= 128);
  assert.ok(sandbox.maxEntities >= fighting.maxEntities);
  assert.equal(sandbox.maxAudioVoices, 8);
});

test("uniform grid randomized queries never miss overlapping indexed AABBs", () => {
  const grid = new UniformGrid2D(-100, -100, 10, 20, 20, 256, 4096, 64);
  const boxes: Array<{ minX: number; minY: number; maxX: number; maxY: number }> = [];
  let seed = 0x51f15e;
  const random = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 0x1_0000_0000; };
  for (let id = 0; id < 180; id++) {
    const x = -95 + random() * 180;
    const y = -95 + random() * 180;
    const w = 0.1 + random() * 18;
    const h = 0.1 + random() * 18;
    const box = { minX: x, minY: y, maxX: x + w, maxY: y + h };
    boxes.push(box);
    assert.equal(grid.insert(id, box), true);
  }
  const output = new Uint32Array(256);
  for (let sample = 0; sample < 100; sample++) {
    const x = -100 + random() * 190;
    const y = -100 + random() * 190;
    const query = { minX: x, minY: y, maxX: x + random() * 35, maxY: y + random() * 35 };
    const count = grid.query(query, output);
    const actual = new Set(output.slice(0, count));
    for (let id = 0; id < boxes.length; id++) {
      const b = boxes[id]!;
      const overlaps = b.minX <= query.maxX && b.maxX >= query.minX && b.minY <= query.maxY && b.maxY >= query.minY;
      if (overlaps) assert.equal(actual.has(id), true, `missed entity ${id} at sample ${sample}`);
    }
  }
});

import { Canvas2DRenderer, Canvas2DScene } from "./renderers/canvas2d.ts";
import { ProjectHistory, loadProject, saveProject, validateProjectDocument } from "./project-document.ts";

test("Canvas2D scene keeps stable layer order and rejects invalid geometry", () => {
  const scene = new Canvas2DScene();
  scene.add({ kind: "rect", x: 0, y: 0, width: 10, height: 10, color: "red", layer: 4 });
  scene.add({ kind: "circle", x: 5, y: 5, radius: 2, color: "blue", layer: 1 });
  scene.add({ kind: "text", text: "top", x: 1, y: 2, color: "white", layer: 4 });
  assert.deepEqual(scene.commands.map(c => c.kind), ["circle", "rect", "text"]);
  assert.throws(() => scene.add({ kind: "rect", x: 0, y: 0, width: -1, height: 2, color: "red" }), /INVALID_CANVAS_COMMAND/);
  assert.throws(() => scene.add({ kind: "circle", x: 0, y: 0, radius: 1, color: "blue", alpha: Number.NaN }), /INVALID_CANVAS_COMMAND/);
  scene.clear();
  assert.equal(scene.commands.length, 0);
});

const testProject = () => ({
  schemaVersion: 1 as const, projectId: "demo", title: "Demo", activeSceneId: "main", updatedAt: 1,
  nodes: [
    { id: "root", type: "Scene", name: "Root", parentId: null, props: {} },
    { id: "child", type: "Sprite", name: "Player", parentId: "root", props: { x: 10, y: 20 } },
    { id: "grandchild", type: "Collider", name: "Hitbox", parentId: "child", props: {} },
  ],
});

test("project document validation rejects missing parents and duplicate IDs", () => {
  const project = testProject();
  assert.equal(validateProjectDocument(project).ok, true);
  assert.deepEqual(validateProjectDocument({ ...project, nodes: [...project.nodes, project.nodes[0]] }), { ok: false, error: "INVALID_PROJECT_NODE" });
  assert.deepEqual(validateProjectDocument({ ...project, nodes: [{ ...project.nodes[1], parentId: "missing" }] }), { ok: false, error: "MISSING_PARENT_NODE" });
});

test("project history applies atomic edits and supports undo redo", () => {
  const history = new ProjectHistory(testProject());
  assert.equal(history.apply({ kind: "rename", id: "child", name: "Hero" }, 2).ok, true);
  assert.equal(history.document.nodes[1]?.name, "Hero");
  assert.equal(history.undo().ok, true);
  assert.equal(history.document.nodes[1]?.name, "Player");
  assert.equal(history.redo().ok, true);
  assert.equal(history.document.nodes[1]?.name, "Hero");
  assert.equal(history.apply({ kind: "set-parent", id: "root", parentId: "grandchild" }).ok, false);
});

test("project removal deletes descendants regardless of node order", () => {
  const p = testProject();
  const history = new ProjectHistory({ ...p, nodes: [p.nodes[2], p.nodes[1], p.nodes[0]] });
  assert.equal(history.apply({ kind: "remove", id: "root" }).ok, true);
  assert.equal(history.document.nodes.length, 0);
});

test("project save/load is bounded and fails closed", () => {
  const map = new Map<string, string>();
  const storage = { get: (k: string) => map.get(k) ?? null, set: (k: string, v: string) => { map.set(k, v); }, remove: (k: string) => { map.delete(k); } };
  assert.equal(saveProject(storage, "project_demo", testProject()).ok, true);
  assert.equal(loadProject(storage, "project_demo").ok, true);
  assert.equal(loadProject(storage, "bad key").ok, false);
  map.set("project_demo", "{");
  assert.equal(loadProject(storage, "project_demo").ok, false);
});

test("project validation rejects cyclic imported hierarchies", () => {
  const p = testProject();
  const nodes = [
    { ...p.nodes[0], parentId: "grandchild" },
    p.nodes[1],
    p.nodes[2],
  ];
  assert.deepEqual(validateProjectDocument({ ...p, nodes }), { ok: false, error: "PROJECT_HIERARCHY_CYCLE" });
});

test("Canvas2D renderer initializes, draws a scene and disposes listeners", () => {
  const calls: string[] = [];
  const ctx = {
    setTransform: () => calls.push("transform"), fillRect: () => calls.push("fillRect"), save: () => calls.push("save"),
    translate: () => undefined, scale: () => undefined, restore: () => calls.push("restore"), beginPath: () => undefined,
    arc: () => undefined, fill: () => undefined, moveTo: () => undefined, lineTo: () => undefined, stroke: () => undefined,
    closePath: () => undefined, fillText: () => undefined, drawImage: () => undefined,
    globalAlpha: 1, fillStyle: "", strokeStyle: "", lineWidth: 1, font: "", textAlign: "left",
  } as unknown as CanvasRenderingContext2D;
  const listeners = new Map<string, EventListener>();
  const canvas = {
    width: 0, height: 0, clientWidth: 320, clientHeight: 200,
    getContext: () => ctx,
    addEventListener: (name: string, fn: EventListener) => listeners.set(name, fn),
    removeEventListener: (name: string) => listeners.delete(name),
  } as unknown as HTMLCanvasElement;
  const renderer = new Canvas2DRenderer();
  renderer.initialize(canvas, createDeviceProfile({ deviceMemory: 3, hardwareConcurrency: 4, coarsePointer: true }));
  const scene = renderer.createScene({} as never);
  scene.add({ kind: "rect", x: 1, y: 2, width: 3, height: 4, color: "white" });
  renderer.render(scene, 0);
  assert.ok(calls.includes("fillRect"));
  assert.ok(calls.includes("restore"));
  renderer.dispose();
  assert.equal(listeners.size, 0);
});

test("project history bounds undo depth to avoid unbounded mobile memory growth", () => {
  const history = new ProjectHistory(testProject());
  for (let i = 0; i < 40; i++) assert.equal(history.apply({ kind: "rename", id: "child", name: `Player-${i}` }, i + 2).ok, true);
  let undos = 0;
  while (history.undo().ok) undos++;
  assert.equal(undos, 32);
});

test("project props reject non-JSON values and prototype-sensitive keys", () => {
  const p = testProject();
  assert.equal(validateProjectDocument({ ...p, nodes: [{ ...p.nodes[0], props: { value: undefined } }] }).ok, false);
  assert.equal(validateProjectDocument({ ...p, nodes: [{ ...p.nodes[0], props: JSON.parse('{"constructor":{"x":1}}') }] }).ok, false);
});

import { createGenerationPlan, executeGenerationPlan } from "./generator/agent-pipeline.ts";
import { DEFAULT_CONTROLLER_MAP, normalizeAxis, readGamepadActions, remapAction, validateControllerMap } from "./generator/controller-map.ts";

test("generator planner creates a bounded dependency-ordered plan", () => {
  const result = createGenerationPlan("Create a pixel-art isometric RPG with crafting and quests", "mobile-low");
  assert.equal(result.ok, true);
  if (!result.ok) return;
  assert.equal(result.plan.genre, "rpg");
  assert.equal(result.plan.dimension, "2.5d");
  assert.equal(result.plan.style, "pixel-retro");
  assert.ok(result.plan.tasks.length <= 24);
  const done = new Set<string>();
  for (const task of result.plan.tasks) { assert.ok(task.dependsOn.every(id => done.has(id))); done.add(task.id); }
  assert.equal(createGenerationPlan(" ").ok, false);
  assert.equal(createGenerationPlan("x".repeat(4001)).ok, false);
  assert.deepEqual(createGenerationPlan("valid prompt", "bad-target" as "mobile-low"), { ok: false, error: "INVALID_TARGET" });
});

test("agent pipeline is sequential, reports progress and stops on failure", async () => {
  const planned = createGenerationPlan("Make a mobile platformer");
  assert.equal(planned.ok, true);
  if (!planned.ok) return;
  const events: string[] = [];
  const success = await executeGenerationPlan(planned.plan, { run: async task => { events.push(task.id); return {}; } }, new AbortController().signal, event => events.push(`${event.taskId}:${event.state}`));
  assert.equal(success.ok, true);
  assert.equal(events.filter(value => value.endsWith(":done")).length, planned.plan.tasks.length);
  const failed = await executeGenerationPlan(planned.plan, { run: async task => { if (task.id === "art") throw new Error("asset provider unavailable"); return {}; } }, new AbortController().signal);
  assert.deepEqual(failed, { ok: false, error: "TASK_FAILED:art" });
  const abort = new AbortController(); abort.abort();
  assert.deepEqual(await executeGenerationPlan(planned.plan, { run: async () => ({}) }, abort.signal), { ok: false, error: "ABORTED" });
});

test("controller map supports validated remapping and axis deadzone", () => {
  assert.equal(validateControllerMap(DEFAULT_CONTROLLER_MAP), true);
  const remapped = remapAction(DEFAULT_CONTROLLER_MAP, "jump", [{ device: "touch", code: "jump-button" }]);
  assert.ok(remapped);
  assert.equal(remapped?.actions.find(action => action.action === "jump")?.bindings[0]?.code, "jump-button");
  assert.equal(remapAction(DEFAULT_CONTROLLER_MAP, "bad action", []), null);
  assert.equal(normalizeAxis(0.1, 0.18), 0);
  assert.ok(Math.abs(normalizeAxis(1, 0.2) - 1) < 1e-9);
  assert.equal(normalizeAxis(Number.NaN, 0.2), 0);
});


test("gamepad adapter maps standard buttons and deadzoned axes", () => {
  const buttons = Array.from({ length: 4 }, () => ({ pressed: false, value: 0 }));
  buttons[0] = { pressed: true, value: 1 };
  const active = readGamepadActions(DEFAULT_CONTROLLER_MAP, { mapping: "standard", buttons, axes: [-0.9, 0] });
  assert.equal(active.has("jump"), true);
  assert.equal(active.has("move.left"), true);
  assert.equal(readGamepadActions(DEFAULT_CONTROLLER_MAP, { mapping: "", buttons, axes: [-1] }).size, 0);
});

import { WebGL2Scene, buildWebGL2Vertices, parseHexColor } from "./renderers/webgl2-2d.ts";

test("WebGL2 renderer parses only deterministic hex colors", () => {
  assert.deepEqual(parseHexColor("#f08"), [1, 0, 136 / 255, 1]);
  assert.deepEqual(parseHexColor("#33669980"), [51 / 255, 102 / 255, 153 / 255, 128 / 255]);
  assert.equal(parseHexColor("red"), null);
  assert.equal(parseHexColor("#12345"), null);
});

test("WebGL2 scene validates and stable-sorts bounded primitive commands", () => {
  const scene = new WebGL2Scene();
  scene.add({ kind: "rect", x: 0, y: 0, width: 10, height: 10, color: "#fff", layer: 2 });
  scene.add({ kind: "circle", x: 2, y: 2, radius: 1, color: "#000", layer: 1 });
  scene.add({ kind: "line", x1: 0, y1: 0, x2: 1, y2: 1, color: "#f00", layer: 2 });
  assert.deepEqual(scene.commands.map(c => c.kind), ["circle", "rect", "line"]);
  assert.throws(() => scene.add({ kind: "rect", x: 0, y: 0, width: -1, height: 1, color: "#fff" }), /INVALID_WEBGL2_COMMAND/);
  assert.throws(() => scene.add({ kind: "rect", x: 0, y: 0, width: 1, height: 1, color: "rgba(0,0,0,1)" }), /INVALID_WEBGL2_COMMAND/);
  assert.throws(() => scene.add({ kind: "polygon", points: [{x:0,y:0},{x:4,y:0},{x:2,y:1},{x:4,y:4},{x:0,y:4}], color: "#fff" }), /INVALID_WEBGL2_COMMAND/);
});

test("WebGL2 tessellator batches rect, circle, line and polygon into bounded triangles", () => {
  const scene = new WebGL2Scene();
  scene.add({ kind: "rect", x: 0, y: 0, width: 10, height: 5, color: "#ff0000" });
  scene.add({ kind: "circle", x: 5, y: 5, radius: 2, segments: 8, color: "#00ff00" });
  scene.add({ kind: "line", x1: 0, y1: 0, x2: 10, y2: 0, width: 2, color: "#0000ff" });
  scene.add({ kind: "polygon", points: [{x:0,y:0},{x:4,y:0},{x:2,y:3}], color: "#ffffff" });
  const output = buildWebGL2Vertices(scene, new Float32Array(2048));
  assert.equal(output.count, 6 + 24 + 6 + 3);
  assert.equal(output.data.length, output.count * 8);
  assert.equal(output.data[2], 1);
  assert.equal(output.data[3], 0);
  assert.equal(output.data[4], 0);
  assert.throws(() => buildWebGL2Vertices(scene, new Float32Array(12)), /WEBGL2_VERTEX_BUDGET_EXCEEDED/);
});


test("agent pipeline passes bounded prior outputs to downstream tasks", async () => {
  const planned = createGenerationPlan("Create a pixel-art platformer");
  assert.equal(planned.ok, true);
  if (!planned.ok) return;
  let sawBrief = false;
  const result = await executeGenerationPlan(planned.plan, {
    run: async (task, plan) => {
      if (task.id === "design") sawBrief = typeof plan.outputs?.brief?.coreLoop === "string";
      return task.id === "brief" ? { coreLoop: "run-jump-collect" } : { accepted: true };
    },
  }, new AbortController().signal);
  assert.equal(result.ok, true);
  if (result.ok) assert.equal(result.plan.outputs?.brief?.coreLoop, "run-jump-collect");
  assert.equal(sawBrief, true);
});

test("agent pipeline rejects prototype-sensitive and oversized provider output", async () => {
  const planned = createGenerationPlan("Create a mobile puzzle game");
  assert.equal(planned.ok, true);
  if (!planned.ok) return;
  const unsafe = await executeGenerationPlan(planned.plan, {
    run: async () => JSON.parse('{"__proto__":{"polluted":true}}'),
  }, new AbortController().signal);
  assert.deepEqual(unsafe, { ok: false, error: "INVALID_AGENT_OUTPUT:brief" });
  const huge = await executeGenerationPlan(planned.plan, {
    run: async () => ({ content: "x".repeat(40_000) }),
  }, new AbortController().signal);
  assert.deepEqual(huge, { ok: false, error: "INVALID_AGENT_OUTPUT:brief" });
});

test("agent pipeline event callback errors do not interrupt provider work", async () => {
  const planned = createGenerationPlan("Create a casual arcade game");
  assert.equal(planned.ok, true);
  if (!planned.ok) return;
  let runs = 0;
  const result = await executeGenerationPlan(planned.plan, { run: async () => { runs++; return { ok: true }; } }, new AbortController().signal, () => { throw new Error("view disposed"); });
  assert.equal(result.ok, true);
  assert.equal(runs, planned.plan.tasks.length);
});


import { recommendAssetBuild, validateAssetBundle } from "./asset-pipeline.ts";

test("asset pipeline validates MIME, paths, dimensions, hashes and bounded totals", () => {
  const budget = { maxAssets: 8, maxTotalBytes: 1_000_000, maxSingleBytes: 500_000, maxTextureDimension: 512 };
  const assets = [
    { id: "hero", path: "sprites/hero.png", kind: "texture", mime: "image/png", bytes: 2048, width: 256, height: 256, sha256: "a".repeat(64) },
    { id: "theme", path: "audio/theme.ogg", kind: "audio", mime: "audio/ogg", bytes: 4096 },
  ] as const;
  assert.deepEqual(validateAssetBundle(assets, budget), { ok: true, totalBytes: 6144, assets: 2 });
  assert.equal(validateAssetBundle([{ ...assets[0], path: "../../private.png" }], budget).ok, false);
  assert.equal(validateAssetBundle([{ ...assets[0], mime: "audio/ogg" }], budget).ok, false);
  assert.equal(validateAssetBundle([{ ...assets[0], width: 8192 }], budget).ok, false);
  assert.equal(validateAssetBundle([{ ...assets[0], sha256: "bad" }], budget).ok, false);
  assert.equal(validateAssetBundle([{ ...assets[0], kind: "toString" as "texture" }], budget).ok, false);
  assert.equal(validateAssetBundle([{ ...assets[0], path: "sprites/%252e%252e/secret.png" }], budget).ok, false);
  assert.equal(validateAssetBundle([{ ...assets[0] }, { ...assets[0], id: "other" }], budget).ok, false);
});

test("asset build recommendations are deterministic and tier-aware", () => {
  const assets = [
    { id: "atlas", path: "atlas.png", kind: "texture", mime: "image/png", bytes: 10, width: 32, height: 32 },
    { id: "music", path: "music.wav", kind: "audio", mime: "audio/wav", bytes: 10 },
    { id: "level", path: "level.json", kind: "data", mime: "application/json", bytes: 10 },
  ] as const;
  const result = recommendAssetBuild(assets, 0);
  assert.deepEqual(result.map(item => item.recommendedCompression), ["basis", "opus", "gzip"]);
  assert.ok(result[0]?.reason.includes("mobile"));
});


import { WorldOriginRebaser, relativeWorldPosition, translateWorldPoint, worldPointFromMeters } from "./world-scale.ts";

test("world scale splits large coordinates into stable 1km cells", () => {
  const point = worldPointFromMeters(1_000_250, -1_250, 42);
  assert.deepEqual([point.cellX, point.offsetX], [1000, 250]);
  assert.deepEqual([point.cellY, point.offsetY], [-2, 750]);
  assert.deepEqual([point.cellZ, point.offsetZ], [0, 42]);
  const shifted = translateWorldPoint(point, -500, 500, 2000);
  assert.deepEqual([shifted.cellX, shifted.offsetX], [999, 750]);
  assert.deepEqual([shifted.cellY, shifted.offsetY], [-1, 250]);
  assert.deepEqual([shifted.cellZ, shifted.offsetZ], [2, 42]);
  assert.throws(() => worldPointFromMeters(Number.NaN, 0, 0), /WORLD_POSITION_MUST_BE_FINITE/);
});

test("world origin rebasing keeps nearby GPU coordinates bounded", () => {
  const origin = worldPointFromMeters(0,0,0);
  const player = worldPointFromMeters(750,0,0);
  assert.deepEqual(relativeWorldPosition(player,origin,1000), {x:750,y:0,z:0});
  const rebaser = new WorldOriginRebaser(origin,500);
  assert.equal(rebaser.update(player),true);
  assert.deepEqual(rebaser.toLocal(player),{x:0,y:0,z:0});
  const distant = worldPointFromMeters(1_000_000,0,0);
  assert.equal(relativeWorldPosition(distant,origin,1000),null);
  assert.equal(rebaser.update(distant),true);
  assert.deepEqual(rebaser.toLocal(distant),{x:0,y:0,z:0});
});


import { SceneEditorSession } from "./scene-editor.ts";
import { ProjectHistory as ProjectHistoryForTests } from "./project-document.ts";
import { AgentKnowledgeBase } from "./knowledge-base.ts";

const editorDocument = { schemaVersion: 1 as const, projectId: "demo", title: "Demo", activeSceneId: "scene", updatedAt: 1, nodes: [
  { id: "scene", type: "Scene", name: "Main Scene", parentId: null, props: {} },
  { id: "player", type: "Sprite", name: "Player", parentId: "scene", props: { x: 1, y: 2 } },
  { id: "weapon", type: "Sprite", name: "Weapon", parentId: "player", props: {} },
] };

test("scene editor builds stable hierarchy and bounded selection", () => {
  const editor = new SceneEditorSession(editorDocument);
  assert.deepEqual(editor.tree().map(item => [item.id, item.depth]), [["scene", 0], ["player", 1], ["weapon", 2]]);
  assert.equal(editor.select(["player"]).ok, true);
  assert.equal(editor.tree()[1]?.selected, true);
  assert.equal(editor.select(["missing"]).ok, false);
  editor.dispose();
  assert.throws(() => editor.tree(), /SCENE_EDITOR_DISPOSED/);
});

test("scene editor duplicates a subtree with remapped parent links and undo", () => {
  const editor = new SceneEditorSession(editorDocument);
  const result = editor.duplicateSubtree("player", (source, index) => `copy_${source}_${index}`, 10);
  assert.equal(result.ok, true);
  if (!result.ok) return;
  assert.deepEqual(result.value, ["copy_player_0", "copy_weapon_1"]);
  assert.equal(editor.document.nodes.find(node => node.id === "copy_weapon_1")?.parentId, "copy_player_0");
  assert.equal(editor.undo().ok, true);
  assert.equal(editor.document.nodes.some(node => node.id === "copy_player_0"), false);
});

test("scene editor rejects cycles and clears removed selections", () => {
  const editor = new SceneEditorSession(editorDocument);
  editor.select(["player", "weapon"]);
  assert.equal(editor.reparent("player", "weapon").ok, false);
  assert.equal(editor.remove("player").ok, true);
  assert.deepEqual(editor.selection, []);
});

test("agent knowledge base ranks by provenance tags and query within budget", () => {
  const memory = new AgentKnowledgeBase({ maxEntries: 3, maxBytes: 8192, maxEntryBytes: 2048 });
  assert.equal(memory.add({ id: "webgl-mobile", kind: "pattern", title: "Mobile WebGL memory", content: "Delete GPU resources eagerly and handle context loss.", tags: ["webgl", "mobile"], sourceUrl: "https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API/WebGL_best_practices", confidence: 0.95, createdAt: 1, updatedAt: 1 }).ok, true);
  assert.equal(memory.add({ id: "audio-worklet", kind: "reference", title: "AudioWorklet", content: "Use a separate audio rendering thread for custom low latency processing.", tags: ["audio", "web"], sourceUrl: "https://developer.mozilla.org/en-US/docs/Web/API/AudioWorklet", confidence: 0.9, createdAt: 2, updatedAt: 2 }).ok, true);
  assert.equal(memory.search("webgl context", ["mobile"])[0]?.id, "webgl-mobile");
  assert.equal(memory.add({ id: "bad-url", kind: "reference", title: "Bad", content: "No provenance", tags: [], sourceUrl: "javascript:alert(1)", confidence: 1, createdAt: 1, updatedAt: 1 }).ok, false);
  assert.ok(memory.bytes <= 8192);
});

test("agent knowledge snapshot imports atomically and rejects malformed entries", () => {
  const source = new AgentKnowledgeBase();
  source.add({ id: "decision", kind: "decision", title: "Use bounded queues", content: "Single worker on tier zero.", tags: ["scheduler"], confidence: 1, createdAt: 1, updatedAt: 2 });
  const target = new AgentKnowledgeBase();
  assert.equal(target.importSnapshot(source.exportSnapshot()).value, 1);
  const before = target.exportSnapshot();
  assert.equal(target.importSnapshot(JSON.stringify({ schemaVersion: 1, entries: [{ id: "x", kind: "reference", title: "x", content: "x", tags: [], confidence: 1, createdAt: 0, updatedAt: 1, sourceUrl: "file:///etc/passwd" }] })).ok, false);
  assert.equal(target.exportSnapshot(), before);
});

test("agent skill outcomes use a bounded moving score", () => {
  const memory = new AgentKnowledgeBase();
  assert.equal(memory.recordSkillOutcome("asset-audit", true, 1).ok, true);
  assert.equal(memory.recordSkillOutcome("asset-audit", false, 2).ok, true);
  const skill = memory.search("asset audit", ["skill"])[0];
  assert.ok(skill?.content.includes("score=0.4800"));
});

test("project batch is atomic when a later operation fails", () => {
  const { ProjectHistory } = requireProjectHistoryForTest();
  const history = new ProjectHistory(editorDocument);
  const result = history.applyBatch([
    { kind: "rename", id: "player", name: "Hero" },
    { kind: "rename", id: "missing", name: "Missing" },
  ]);
  assert.equal(result.ok, false);
  assert.equal(history.document.nodes.find(node => node.id === "player")?.name, "Player");
  assert.equal(history.canUndo, false);
});

test("knowledge base rejects accessors and duplicate IDs in snapshots", () => {
  const memory = new AgentKnowledgeBase();
  const unsafe = Object.defineProperty({ kind: "fact", title: "Unsafe", content: "No getters", tags: [], confidence: 1, createdAt: 1, updatedAt: 1 }, "id", { enumerable: true, get() { throw new Error("getter executed"); } });
  assert.equal(memory.add(unsafe as never).ok, false);
  const duplicate = JSON.stringify({ schemaVersion: 1, entries: [
    { id: "same", kind: "fact", title: "A", content: "A", tags: [], confidence: 1, createdAt: 1, updatedAt: 1 },
    { id: "same", kind: "fact", title: "B", content: "B", tags: [], confidence: 1, createdAt: 1, updatedAt: 1 },
  ] });
  assert.equal(memory.importSnapshot(duplicate).ok, false);
});

function requireProjectHistoryForTest(): { ProjectHistory: typeof import("./project-document.ts").ProjectHistory } {
  // A static import is used by the test module; this indirection keeps the helper type explicit.
  return { ProjectHistory: ProjectHistoryForTests };
}

import { fitImagePreview } from "./asset-preview.ts";

test("image preview sizing preserves aspect ratio and stays inside pixel budget", () => {
  const size = fitImagePreview(2048, 1024, { maxDimension: 384, maxPixels: 384 * 384 });
  assert.deepEqual(size, { width: 384, height: 192, estimatedRgbaBytes: 384 * 192 * 4 });
  assert.ok(size!.width * size!.height <= 384 * 384);
});

test("image preview sizing rejects invalid and unsafe dimensions", () => {
  assert.equal(fitImagePreview(0, 20), null);
  assert.equal(fitImagePreview(-1, 20), null);
  assert.equal(fitImagePreview(Number.MAX_SAFE_INTEGER + 1, 20), null);
  assert.equal(fitImagePreview(1_000_000_000, 1_000_000_000), null);
  assert.equal(fitImagePreview(100, 100, { maxPixels: 0 }), null);
});
