import { SeededRandom, clamp } from "./core.ts";

export type ParticleBurst = Readonly<{
  x: number; y: number; count: number;
  speedMin?: number; speedMax?: number;
  angle?: number; spread?: number;
  lifeMin?: number; lifeMax?: number;
  sizeMin?: number; sizeMax?: number;
  gravityX?: number; gravityY?: number;
  drag?: number;
}>;
export type ParticleStats = Readonly<{ active: number; capacity: number; droppedEmissions: number }>;
const MAX_CAPACITY = 4096;
const FLOATS_PER_PARTICLE = 6;

/** Data-oriented bounded particles; call update at a fixed simulation timestep. */
export class ParticleSystem {
  readonly capacity: number;
  readonly x: Float32Array;
  readonly y: Float32Array;
  readonly vx: Float32Array;
  readonly vy: Float32Array;
  readonly age: Float32Array;
  readonly life: Float32Array;
  readonly size: Float32Array;
  readonly rotation: Float32Array;
  readonly spin: Float32Array;
  readonly gravityX: Float32Array;
  readonly gravityY: Float32Array;
  readonly drag: Float32Array;
  private readonly random: SeededRandom;
  private activeCount = 0;
  private droppedCount = 0;
  constructor(capacity = 32, seed = 1) {
    if (!Number.isInteger(capacity) || capacity < 1 || capacity > MAX_CAPACITY) throw new RangeError("INVALID_PARTICLE_CAPACITY");
    this.capacity = capacity;
    this.x = new Float32Array(capacity); this.y = new Float32Array(capacity);
    this.vx = new Float32Array(capacity); this.vy = new Float32Array(capacity);
    this.age = new Float32Array(capacity); this.life = new Float32Array(capacity);
    this.size = new Float32Array(capacity); this.rotation = new Float32Array(capacity); this.spin = new Float32Array(capacity);
    this.gravityX = new Float32Array(capacity); this.gravityY = new Float32Array(capacity); this.drag = new Float32Array(capacity);
    this.random = new SeededRandom(seed);
  }

  emit(burst: ParticleBurst): number {
    if (!burst || ![burst.x,burst.y].every(Number.isFinite) || !Number.isInteger(burst.count) || burst.count < 0 || burst.count > 65_536) return 0;
    const speedMin = burst.speedMin ?? 20, speedMax = burst.speedMax ?? 80;
    const lifeMin = burst.lifeMin ?? 0.25, lifeMax = burst.lifeMax ?? 0.7;
    const sizeMin = burst.sizeMin ?? 2, sizeMax = burst.sizeMax ?? 5;
    const angle = burst.angle ?? -Math.PI / 2, spread = burst.spread ?? Math.PI * 2;
    const gravityX = burst.gravityX ?? 0, gravityY = burst.gravityY ?? 0, drag = burst.drag ?? 0;
    if (![speedMin,speedMax,lifeMin,lifeMax,sizeMin,sizeMax,angle,spread,gravityX,gravityY,drag].every(Number.isFinite) || speedMin < 0 || speedMax < speedMin || speedMax > 100_000 || lifeMin <= 0 || lifeMax < lifeMin || lifeMax > 120 || sizeMin < 0 || sizeMax < sizeMin || sizeMax > 4096 || spread < 0 || spread > Math.PI * 2 || drag < 0 || drag > 100) return 0;
    const available = this.capacity - this.activeCount;
    const count = Math.min(available, burst.count);
    this.droppedCount += burst.count - count;
    for (let i = 0; i < count; i++) {
      const index = this.activeCount++;
      const theta = angle + (this.random.next() - 0.5) * spread;
      const speed = speedMin + this.random.next() * (speedMax - speedMin);
      this.x[index] = burst.x; this.y[index] = burst.y;
      this.vx[index] = Math.cos(theta) * speed; this.vy[index] = Math.sin(theta) * speed;
      this.age[index] = 0; this.life[index] = lifeMin + this.random.next() * (lifeMax - lifeMin);
      this.size[index] = sizeMin + this.random.next() * (sizeMax - sizeMin);
      this.rotation[index] = this.random.next() * Math.PI * 2;
      this.spin[index] = (this.random.next() - 0.5) * 8;
      this.gravityX[index] = gravityX; this.gravityY[index] = gravityY; this.drag[index] = drag;
    }
    return count;
  }

  update(deltaSeconds: number): void {
    if (!Number.isFinite(deltaSeconds) || deltaSeconds <= 0 || this.activeCount === 0) return;
    const dt = Math.min(deltaSeconds, 0.1);
    let index = 0;
    while (index < this.activeCount) {
      const age = this.age[index]! + dt;
      if (age >= this.life[index]!) {
        const last = --this.activeCount;
        if (index !== last) this.copyParticle(last, index);
        continue;
      }
      this.age[index] = age;
      const damping = Math.exp(-this.drag[index]! * dt);
      this.vx[index] = (this.vx[index]! + this.gravityX[index]! * dt) * damping;
      this.vy[index] = (this.vy[index]! + this.gravityY[index]! * dt) * damping;
      this.x[index] = this.x[index]! + this.vx[index]! * dt;
      this.y[index] = this.y[index]! + this.vy[index]! * dt;
      this.rotation[index] = this.rotation[index]! + this.spin[index]! * dt;
      index++;
    }
  }

  /** Writes x, y, size, rotation, normalized age and alpha. Returns particles written. */
  writeSnapshot(target: Float32Array): number {
    const count = this.activeCount;
    if (!(target instanceof Float32Array) || target.length < count * FLOATS_PER_PARTICLE) throw new RangeError("PARTICLE_SNAPSHOT_BUFFER_TOO_SMALL");
    for (let i = 0; i < count; i++) {
      const offset = i * FLOATS_PER_PARTICLE;
      const normalizedAge = clamp(this.age[i]! / this.life[i]!, 0, 1);
      target[offset] = this.x[i]!; target[offset + 1] = this.y[i]!; target[offset + 2] = this.size[i]!;
      target[offset + 3] = this.rotation[i]!; target[offset + 4] = normalizedAge; target[offset + 5] = 1 - normalizedAge;
    }
    return count;
  }

  clear(): void { this.activeCount = 0; }
  get stats(): ParticleStats { return Object.freeze({ active: this.activeCount, capacity: this.capacity, droppedEmissions: this.droppedCount }); }

  private copyParticle(from: number, to: number): void {
    this.x[to] = this.x[from]!; this.y[to] = this.y[from]!; this.vx[to] = this.vx[from]!; this.vy[to] = this.vy[from]!;
    this.age[to] = this.age[from]!; this.life[to] = this.life[from]!; this.size[to] = this.size[from]!;
    this.rotation[to] = this.rotation[from]!; this.spin[to] = this.spin[from]!;
    this.gravityX[to] = this.gravityX[from]!; this.gravityY[to] = this.gravityY[from]!; this.drag[to] = this.drag[from]!;
  }
}
