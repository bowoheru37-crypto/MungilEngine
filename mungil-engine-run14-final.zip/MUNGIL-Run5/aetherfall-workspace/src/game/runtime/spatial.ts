/** Bounded uniform-grid broadphase for 2D AABBs. Output buffers are caller-owned. */
export type Aabb2 = Readonly<{ minX: number; minY: number; maxX: number; maxY: number }>;

export class UniformGrid2D {
  private readonly heads: Int32Array;
  private readonly next: Int32Array;
  private readonly ids: Uint32Array;
  private readonly stamps: Uint32Array;
  private readonly inserted: Uint8Array;
  private entryCount = 0;
  private queryStamp = 0;
  private readonly columns: number;
  private readonly rows: number;
  readonly originX: number;
  readonly originY: number;
  readonly cellSize: number;
  readonly maxEntities: number;
  readonly maxEntries: number;
  readonly maxCellsPerEntity: number;

  constructor(
    originX: number, originY: number, cellSize: number,
    columns: number, rows: number, maxEntities: number,
    maxEntries: number, maxCellsPerEntity = 64,
  ) {
    if (![originX, originY, cellSize].every(Number.isFinite) || cellSize <= 0 || !Number.isSafeInteger(columns) || columns < 1 || columns > 1024 ||
      !Number.isSafeInteger(rows) || rows < 1 || rows > 1024 || columns * rows > 262_144 ||
      !Number.isSafeInteger(maxEntities) || maxEntities < 1 || maxEntities > 262_144 ||
      !Number.isSafeInteger(maxEntries) || maxEntries < maxEntities || maxEntries > 2_000_000 ||
      !Number.isSafeInteger(maxCellsPerEntity) || maxCellsPerEntity < 1 || maxCellsPerEntity > 1024) {
      throw new RangeError("INVALID_SPATIAL_GRID_CONFIGURATION");
    }
    this.originX = originX; this.originY = originY; this.cellSize = cellSize;
    this.columns = columns; this.rows = rows; this.maxEntities = maxEntities;
    this.maxEntries = maxEntries; this.maxCellsPerEntity = maxCellsPerEntity;
    this.heads = new Int32Array(columns * rows);
    this.next = new Int32Array(maxEntries);
    this.ids = new Uint32Array(maxEntries);
    this.stamps = new Uint32Array(maxEntities);
    this.inserted = new Uint8Array(maxEntities);
    this.clear();
  }

  clear(): void { this.heads.fill(-1); this.entryCount = 0; this.inserted.fill(0); }

  insert(id: number, bounds: Aabb2): boolean {
    if (!Number.isInteger(id) || id < 0 || id >= this.maxEntities || !this.validBounds(bounds) || this.inserted[id] === 1) return false;
    const worldMaxX = this.originX + this.columns * this.cellSize;
    const worldMaxY = this.originY + this.rows * this.cellSize;
    // Reject boxes wholly outside the grid before clamping. Without this check,
    // an AABB beginning exactly at the far edge is incorrectly placed in the last cell.
    if (bounds.maxX < this.originX || bounds.maxY < this.originY || bounds.minX >= worldMaxX || bounds.minY >= worldMaxY) {
      this.inserted[id] = 1;
      return true;
    }
    const minX = Math.max(0, Math.floor((bounds.minX - this.originX) / this.cellSize));
    const minY = Math.max(0, Math.floor((bounds.minY - this.originY) / this.cellSize));
    const maxX = Math.min(this.columns - 1, Math.floor((bounds.maxX - this.originX) / this.cellSize));
    const maxY = Math.min(this.rows - 1, Math.floor((bounds.maxY - this.originY) / this.cellSize));
    if (minX > maxX || minY > maxY) return true;
    const cellCount = (maxX - minX + 1) * (maxY - minY + 1);
    if (cellCount > this.maxCellsPerEntity || this.entryCount + cellCount > this.maxEntries) return false;
    this.inserted[id] = 1;
    for (let y = minY; y <= maxY; y++) for (let x = minX; x <= maxX; x++) {
      const cell = y * this.columns + x;
      const entry = this.entryCount++;
      this.ids[entry] = id;
      this.next[entry] = this.heads[cell]!;
      this.heads[cell] = entry;
    }
    return true;
  }

  query(bounds: Aabb2, output: Uint32Array): number {
    if (!this.validBounds(bounds) || !(output instanceof Uint32Array)) return 0;
    const minX = Math.max(0, Math.floor((bounds.minX - this.originX) / this.cellSize));
    const minY = Math.max(0, Math.floor((bounds.minY - this.originY) / this.cellSize));
    const maxX = Math.min(this.columns - 1, Math.floor((bounds.maxX - this.originX) / this.cellSize));
    const maxY = Math.min(this.rows - 1, Math.floor((bounds.maxY - this.originY) / this.cellSize));
    if (minX > maxX || minY > maxY) return 0;
    this.queryStamp = (this.queryStamp + 1) >>> 0;
    if (this.queryStamp === 0) { this.stamps.fill(0); this.queryStamp = 1; }
    let count = 0;
    for (let y = minY; y <= maxY; y++) for (let x = minX; x <= maxX; x++) {
      let entry = this.heads[y * this.columns + x]!;
      while (entry !== -1) {
        const id = this.ids[entry]!;
        if (this.stamps[id] !== this.queryStamp) {
          this.stamps[id] = this.queryStamp;
          if (count < output.length) output[count++] = id;
        }
        entry = this.next[entry]!;
      }
    }
    return count;
  }

  private validBounds(b: Aabb2): boolean {
    return !!b && Number.isFinite(b.minX) && Number.isFinite(b.minY) && Number.isFinite(b.maxX) && Number.isFinite(b.maxY) && b.minX <= b.maxX && b.minY <= b.maxY;
  }
  get entriesUsed(): number { return this.entryCount; }
}
