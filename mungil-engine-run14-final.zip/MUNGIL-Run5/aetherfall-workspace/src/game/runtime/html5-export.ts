import { validateProjectDocument, type ProjectDocument } from "./project-document.ts";

export type Html5ExportOptions = Readonly<{ width?: number; height?: number; genre?: string; includeTouchControls?: boolean }>;
export type Html5ExportResult = Readonly<{ ok: true; html: string; bytes: number; exportedNodes: number; excludedAssetCount: number }> | Readonly<{ ok: false; error: string }>;
type ExportEntity = Readonly<{ id:string; kind:"platform"|"coin"|"hazard"|"enemy"|"goal"|"decor"; x:number; y:number; w:number; h:number; color:string; solid:boolean; vx:number; vy:number }>;
const MAX_EXPORTED_NODES = 512;
const MAX_EXPORT_BYTES = 1_500_000;

function readNumber(props: Readonly<Record<string, unknown>>, key: string, fallback: number, min: number, max: number): number {
  const value = props[key]; return typeof value === "number" && Number.isFinite(value) ? Math.max(min,Math.min(max,value)) : fallback;
}
function safeColor(value: unknown, fallback: string): string { return typeof value === "string" && /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i.test(value) ? value : fallback; }
function jsonForScript(value: unknown): string { return JSON.stringify(value).replace(/</g,"\\u003c").replace(/\u2028/g,"\\u2028").replace(/\u2029/g,"\\u2029"); }

/** Produces an offline, keyboard/touch playable 2D prototype. Imported binary assets are not embedded yet. */
export function buildPlayableHtml5Export(input: ProjectDocument, options: Html5ExportOptions = {}): Html5ExportResult {
  const checked = validateProjectDocument(input);
  if (!checked.ok) return { ok:false, error:checked.error };
  const project = checked.value;
  if (project.nodes.length > MAX_EXPORTED_NODES) return { ok:false, error:"HTML5_EXPORT_NODE_LIMIT" };
  const width = options.width ?? 720, height = options.height ?? 1280;
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 320 || height < 320 || width > 2048 || height > 2048) return { ok:false, error:"INVALID_EXPORT_VIEWPORT" };
  const exported: ExportEntity[] = [];
  let player: {x:number;y:number;w:number;h:number;color:string}|null = null;
  let excludedAssetCount = 0;
  for (const node of project.nodes) {
    const props = node.props;
    if (typeof props.assetId === "string") excludedAssetCount++;
    const rawType = (node.type+" "+node.name).toLowerCase();
    const x = readNumber(props,"x",80, -100_000,100_000);
    const y = readNumber(props,"y",height-180,-100_000,100_000);
    const w = readNumber(props,"width",rawType.includes("player")?34:48,1,4096);
    const h = readNumber(props,"height",rawType.includes("player")?48:48,1,4096);
    const color = safeColor(props.color, rawType.includes("enemy")?"#e85d75":rawType.includes("coin")?"#ffd166":"#4e9ee8");
    if (rawType.includes("player")) { if (!player) player={x,y,w,h,color}; continue; }
    let kind: ExportEntity["kind"] = "decor";
    if (/platform|ground|floor|wall|block/.test(rawType) || props.solid === true) kind="platform";
    else if (/coin|pickup|collectible|gem/.test(rawType) || props.collectible === true) kind="coin";
    else if (/hazard|spike|trap/.test(rawType) || props.hazard === true) kind="hazard";
    else if (/enemy|mob|monster/.test(rawType)) kind="enemy";
    else if (/goal|exit|finish|portal/.test(rawType)) kind="goal";
    exported.push(Object.freeze({ id:node.id,kind,x,y,w,h,color,solid:kind==="platform",vx:readNumber(props,"vx",kind==="enemy"?40:0,-500,500),vy:readNumber(props,"vy",0,-500,500) }));
  }
  const defaultPlayer = player ?? {x:Math.min(96,width*0.2),y:height-190,w:34,h:48,color:"#6fe3c1"};
  const hasFloor = exported.some(entity=>entity.kind==="platform" && entity.y >= height*0.65);
  if (!hasFloor) exported.push(Object.freeze({id:"__floor",kind:"platform",x:0,y:height-56,w:width,h:56,color:"#29364b",solid:true,vx:0,vy:0}));
  if (!exported.some(entity=>entity.kind==="platform")) {
    exported.push(Object.freeze({id:"__platform_a",kind:"platform",x:width*0.18,y:height*0.7,w:width*0.34,h:18,color:"#3b5975",solid:true,vx:0,vy:0}));
    exported.push(Object.freeze({id:"__platform_b",kind:"platform",x:width*0.58,y:height*0.54,w:width*0.26,h:18,color:"#3b5975",solid:true,vx:0,vy:0}));
  }
  if (!exported.some(entity=>entity.kind==="coin")) exported.push(Object.freeze({id:"__coin",kind:"coin",x:width*0.7,y:height*0.45,w:24,h:24,color:"#ffd166",solid:false,vx:0,vy:0}));
  const payload = { title:project.title, width,height,genre:String(options.genre??"arcade").slice(0,40),player:defaultPlayer,entities:exported };
  const data = jsonForScript(payload);
  const touch = options.includeTouchControls !== false;
  const html = `<!doctype html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"><meta name="theme-color" content="#101827"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data: blob:; media-src data: blob:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'"><title>${project.title.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]!))}</title>
<style>*{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;overflow:hidden;background:#0b1220;color:#eef4ff;font:14px system-ui,sans-serif;touch-action:none}main{height:100vh;height:100dvh;display:grid;grid-template-rows:auto 1fr auto;gap:8px;padding:max(8px,env(safe-area-inset-top)) max(8px,env(safe-area-inset-right)) max(8px,env(safe-area-inset-bottom)) max(8px,env(safe-area-inset-left))}.top,.bottom{display:flex;align-items:center;justify-content:space-between;gap:8px}.top strong{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.top span,.bottom{color:#aab8ce;font-size:12px}#stage{min-height:0;display:flex;align-items:center;justify-content:center;position:relative}canvas{display:block;max-width:100%;max-height:100%;width:auto;height:auto;aspect-ratio:${width}/${height};background:#121d30;border:1px solid #33435a;border-radius:12px;touch-action:none}.controls{display:flex;justify-content:center;gap:12px}.controls button,.top button{border:1px solid #405574;border-radius:14px;background:#1a2a43;color:white;min-width:64px;min-height:48px;font-weight:700;font-size:16px;touch-action:none}.top button{min-width:auto;min-height:34px;padding:5px 12px;font-size:12px}.controls button:active{background:#31527a}.muted{opacity:.65}.overlay{position:absolute;inset:0;display:grid;place-items:center;pointer-events:none}.overlay b{background:#0c1524e8;padding:12px 18px;border:1px solid #50627d;border-radius:12px;text-align:center;max-width:80%}@media(orientation:landscape){main{grid-template-rows:auto 1fr auto}.controls button{min-width:58px}}</style></head>
<body><main><header class="top"><strong id="title"></strong><span id="score">Score 0</span><button id="restart" type="button">Restart</button></header><section id="stage"><canvas id="game" width="${width}" height="${height}" aria-label="Playable game"></canvas><div class="overlay" id="overlay"></div></section>${touch?'<nav class="controls" aria-label="Touch controls"><button data-key="left" aria-label="Move left">◀</button><button data-key="right" aria-label="Move right">▶</button><button data-key="jump" aria-label="Jump">JUMP</button></nav>':'<footer class="bottom">Arrow keys / A-D to move · Space to jump · R to restart</footer>'}<footer class="bottom"><span>Offline HTML5 prototype</span><span>Move · Jump · Collect · Reach the exit</span></footer></main>
<script>'use strict';(()=>{const DATA=${data};const canvas=document.getElementById('game'),ctx=canvas.getContext('2d',{alpha:false});if(!ctx)return;const W=DATA.width,H=DATA.height;document.getElementById('title').textContent=DATA.title;let entities=[],player,score=0,won=false,paused=false,last=0,acc=0,keys=new Set();const spawn=()=>{entities=DATA.entities.map(e=>({...e,visible:true,originX:e.x,dir:1}));player={...DATA.player,vx:0,vy:0,onGround:false};score=0;won=false;document.getElementById('overlay').replaceChildren();updateScore()};function updateScore(){document.getElementById('score').textContent='Score '+score}function overlap(a,b){return a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y}function step(dt){if(won)return;const speed=260;player.vx=(keys.has('left')?-1:0)+(keys.has('right')?1:0);player.vx*=speed;if(keys.has('jump')&&player.onGround){player.vy=-560;player.onGround=false}player.vy=Math.min(1100,player.vy+1400*dt);player.x=Math.max(0,Math.min(W-player.w,player.x+player.vx*dt));const oldY=player.y;player.y+=player.vy*dt;player.onGround=false;if(player.vy>=0){for(const e of entities){if(e.visible&&e.kind==='platform'&&oldY+player.h<=e.y+8&&player.y+player.h>=e.y&&player.x<e.x+e.w&&player.x+player.w>e.x){player.y=e.y-player.h;player.vy=0;player.onGround=true}}}if(player.y>H+80){spawn();return}for(const e of entities){if(!e.visible)continue;if(e.kind==='enemy'){e.x+=e.vx*e.dir*dt;if(e.x<e.originX-55||e.x>e.originX+55)e.dir*=-1}if(!overlap(player,e))continue;if(e.kind==='coin'){e.visible=false;score+=10;updateScore()}else if(e.kind==='hazard'||e.kind==='enemy'){spawn();return}else if(e.kind==='goal'){won=true;const label=document.createElement('b');label.textContent='LEVEL COMPLETE · Score '+score;document.getElementById('overlay').append(label)}}}
function draw(){ctx.fillStyle='#111d31';ctx.fillRect(0,0,W,H);const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,'#172944');g.addColorStop(1,'#0b1424');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);ctx.strokeStyle='rgba(150,190,230,.07)';ctx.lineWidth=1;for(let y=0;y<H;y+=64){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}for(const e of entities){if(!e.visible)continue;ctx.fillStyle=e.color;if(e.kind==='coin'){ctx.beginPath();ctx.arc(e.x+e.w/2,e.y+e.h/2,Math.min(e.w,e.h)/2,0,Math.PI*2);ctx.fill()}else{ctx.fillRect(e.x,e.y,e.w,e.h);if(e.kind==='goal'){ctx.strokeStyle='#f7f4aa';ctx.strokeRect(e.x-3,e.y-3,e.w+6,e.h+6)}}}ctx.fillStyle=player.color;ctx.fillRect(player.x,player.y,player.w,player.h);ctx.fillStyle='#eaf5ff';ctx.fillRect(player.x+player.w*.62,player.y+10,4,4)}function frame(now){if(paused){last=now;requestAnimationFrame(frame);return}if(!last)last=now;const dt=Math.min(.1,(now-last)/1000);last=now;acc+=dt;let n=0;while(acc>=1/60&&n<4){step(1/60);acc-=1/60;n++}if(n===4&&acc>1/60)acc=0;draw();requestAnimationFrame(frame)}function key(e,down){const map={ArrowLeft:'left',KeyA:'left',ArrowRight:'right',KeyD:'right',Space:'jump',ArrowUp:'jump',KeyW:'jump'};const action=map[e.code];if(action){if(down)keys.add(action);else keys.delete(action);e.preventDefault()}if(down&&e.code==='KeyR')spawn()}window.addEventListener('keydown',e=>key(e,true));window.addEventListener('keyup',e=>key(e,false));document.querySelectorAll('[data-key]').forEach(button=>{const action=button.dataset.key;const down=e=>{e.preventDefault();keys.add(action)};const up=e=>{e.preventDefault();keys.delete(action)};button.addEventListener('pointerdown',down);button.addEventListener('pointerup',up);button.addEventListener('pointercancel',up);button.addEventListener('lostpointercapture',up)});document.getElementById('restart').addEventListener('click',spawn);document.addEventListener('visibilitychange',()=>{paused=document.hidden;last=0;acc=0;keys.clear()});spawn();requestAnimationFrame(frame)})();<\/script></body></html>`;
  const bytes = new TextEncoder().encode(html).byteLength;
  if (bytes > MAX_EXPORT_BYTES) return { ok:false, error:"HTML5_EXPORT_SIZE_LIMIT" };
  return Object.freeze({ ok:true,html,bytes,exportedNodes:exported.length,excludedAssetCount });
}
