import assert from "node:assert/strict";
import test from "node:test";
import { buildSpriteAtlas } from "./sprite-atlas.ts";
import { createSpriteAnimationClip, SpriteAnimator } from "./sprite-animation.ts";
import { ParticleSystem } from "./particles.ts";
import { buildWebGL2Batches, WebGL2Scene } from "./renderers/webgl2-2d.ts";
import { preflightGltf, validateGltfWithKhronos } from "./gltf-preflight.ts";
import { buildPlayableHtml5Export } from "./html5-export.ts";
import type { ProjectDocument } from "./project-document.ts";
import { executeGenerationPlan, type GenerationPlan } from "./generator/agent-pipeline.ts";
import { WebAudioMixer } from "./generator/audio-manager.ts";

const project: ProjectDocument = Object.freeze({ schemaVersion:1, projectId:"test-project", title:"Test World", activeSceneId:"main", updatedAt:1, nodes:Object.freeze([
  Object.freeze({id:"player",type:"Player",name:"Player",parentId:null,props:Object.freeze({x:32,y:120,width:30,height:44,color:"#66ddaa"})}),
  Object.freeze({id:"platform",type:"Platform",name:"Ground",parentId:null,props:Object.freeze({x:0,y:220,width:360,height:24,color:"#334455",solid:true})}),
  Object.freeze({id:"coin",type:"Coin",name:"Coin",parentId:null,props:Object.freeze({x:180,y:160,width:20,height:20})}),
]) });

test("sprite atlas packs repeatably and keeps every frame within its page", () => {
  const sources = [{id:"hero",width:32,height:32},{id:"coin",width:16,height:16},{id:"tile",width:64,height:32}];
  const first = buildSpriteAtlas(sources,{maxSize:128,padding:2});
  const second = buildSpriteAtlas(sources,{maxSize:128,padding:2});
  assert.equal(first.ok,true); assert.equal(second.ok,true);
  if (!first.ok || !second.ok) return;
  assert.deepEqual(first.atlas,second.atlas);
  for (const frame of first.atlas.frames) {
    const page = first.atlas.pages[frame.page]!;
    assert.ok(frame.x >= 2 && frame.y >= 2);
    assert.ok(frame.x + frame.width + 2 <= page.width);
    assert.ok(frame.y + frame.height + 2 <= page.height);
  }
});

test("sprite atlas rejects duplicate, oversized and unbounded inputs", () => {
  assert.equal(buildSpriteAtlas([{id:"same",width:4,height:4},{id:"same",width:2,height:2}]).ok,false);
  assert.equal(buildSpriteAtlas([{id:"huge",width:4096,height:4096}],{maxSize:1024}).ok,false);
  assert.equal(buildSpriteAtlas([], {maxPages:0}).ok,false);
  assert.deepEqual(buildSpriteAtlas([{id:"large",width:64,height:64}],{maxSize:128,maxTextureBytes:64}),{ok:false,error:"ATLAS_MEMORY_BUDGET_EXCEEDED"});
});

test("sprite animator advances loop, ping-pong and non-loop clips predictably", () => {
  const clip = createSpriteAnimationClip("walk",[{frameId:"a",durationMs:100},{frameId:"b",durationMs:100},{frameId:"c",durationMs:100}],{loop:true});
  assert.equal(clip.ok,true); if(!clip.ok)return;
  const animator = new SpriteAnimator(); animator.play(clip.clip);
  assert.equal(animator.currentFrameId,"a"); animator.update(.11); assert.equal(animator.currentFrameId,"b");
  animator.update(.11); assert.equal(animator.currentFrameId,"c"); animator.update(.11); assert.equal(animator.currentFrameId,"a");
  assert.equal(animator.play({...clip.clip,frames:[{frameId:"unsafe",durationMs:0}]} as typeof clip.clip),false);
  const ping = createSpriteAnimationClip("ping",[{frameId:"a",durationMs:100},{frameId:"b",durationMs:100},{frameId:"c",durationMs:100}],{pingPong:true});
  assert.equal(ping.ok,true); if(!ping.ok)return;
  animator.play(ping.clip); animator.update(.21); assert.equal(animator.currentFrameId,"c"); animator.update(.11); assert.equal(animator.currentFrameId,"b");
  const once = createSpriteAnimationClip("once",[{frameId:"a",durationMs:100},{frameId:"b",durationMs:100}],{loop:false});
  assert.equal(once.ok,true); if(!once.ok)return;
  animator.play(once.clip); animator.update(.25); assert.equal(animator.currentFrameId,"b"); assert.equal(animator.isComplete,true);
});

test("main WebGL2 renderer batches atlas sprites with rotation, tint and stable layers", () => {
  const atlas = buildSpriteAtlas([{id:"hero",width:20,height:10},{id:"coin",width:8,height:8}],{maxSize:64,padding:1});
  assert.equal(atlas.ok,true); if(!atlas.ok)return;
  const scene = new WebGL2Scene();
  assert.equal(scene.addAtlasSprite("game",atlas.atlas,"hero",{x:10,y:20,width:40,height:20,rotation:Math.PI/2,alpha:.5,layer:2}),true);
  scene.add({kind:"rect",x:0,y:0,width:4,height:4,color:"#fff",layer:1});
  const output = buildWebGL2Batches(scene,{data:new Float32Array(256),count:0,runCount:0,runTextureIds:[],runFirst:[],runCounts:[]});
  assert.equal(output.count,12); assert.deepEqual(output.runTextureIds.slice(0,2),[null,"game-0"]);
  assert.deepEqual(output.runCounts.slice(0,2),[6,6]);
  assert.equal(output.data[5],1); // primitive alpha
  assert.equal(output.data[53],.5); // first sprite vertex alpha after the 48-float primitive batch
  assert.equal(scene.addAtlasSprite("bad id",atlas.atlas,"hero",{x:0,y:0}),false);
  assert.throws(()=>scene.add({kind:"sprite",textureId:"bad",x:0,y:0,width:-1,height:2}),/INVALID_WEBGL2_COMMAND/);
});

test("particle system stays within capacity, advances deterministically and compacts expired particles", () => {
  const a = new ParticleSystem(8,123), b = new ParticleSystem(8,123);
  const burst = {x:10,y:20,count:12,speedMin:10,speedMax:30,lifeMin:.1,lifeMax:.3,gravityY:20,drag:.1};
  assert.equal(a.emit(burst),8); assert.equal(b.emit(burst),8); assert.equal(a.stats.droppedEmissions,4);
  a.update(.05); b.update(.05);
  const snapA=new Float32Array(8*6),snapB=new Float32Array(8*6);
  assert.equal(a.writeSnapshot(snapA),8); assert.equal(b.writeSnapshot(snapB),8); assert.deepEqual(snapA,snapB);
  assert.throws(()=>a.writeSnapshot(new Float32Array(1)),/PARTICLE_SNAPSHOT_BUFFER_TOO_SMALL/);
  a.update(.1); assert.ok(a.stats.active < 8);
  a.clear(); assert.equal(a.stats.active,0);
  assert.equal(a.emit({...burst,count:-1}),0);
});

function makeGlb(json: object, bin = new Uint8Array(0)): Uint8Array {
  const encoder = new TextEncoder(); let jsonBytes=encoder.encode(JSON.stringify(json));
  const jsonLength=(jsonBytes.length+3)&~3; const binLength=bin.length?((bin.length+3)&~3):0;
  const total=12+8+jsonLength+(binLength?8+binLength:0); const bytes=new Uint8Array(total); const view=new DataView(bytes.buffer);
  view.setUint32(0,0x46546c67,true); view.setUint32(4,2,true); view.setUint32(8,total,true);
  view.setUint32(12,jsonLength,true); view.setUint32(16,0x4e4f534a,true); bytes.fill(0x20,20,20+jsonLength); bytes.set(jsonBytes,20);
  if(binLength){const offset=20+jsonLength;view.setUint32(offset,binLength,true);view.setUint32(offset+4,0x004e4942,true);bytes.set(bin,offset+8)}
  return bytes;
}

test("glTF preflight accepts a minimal glTF 2.0 JSON envelope and reports URI review", () => {
  const json={asset:{version:"2.0",generator:"test"},buffers:[{uri:"https://example.invalid/buffer.bin",byteLength:16}],nodes:[],meshes:[],materials:[],accessors:[],bufferViews:[]};
  const report=preflightGltf(new TextEncoder().encode(JSON.stringify(json)));
  assert.equal(report.ok,true); assert.equal(report.format,"gltf-json"); assert.ok(report.issues.some(i=>i.code==="GLTF_EXTERNAL_OR_EMBEDDED_URI"));
});

test("glTF preflight rejects malformed GLB, invalid references and non-2.0 assets", () => {
  assert.equal(preflightGltf(new Uint8Array([1,2,3])).ok,false);
  const invalid={asset:{version:"1.0"},buffers:[{byteLength:4}],bufferViews:[{buffer:2,byteLength:8}],accessors:[{count:0,componentType:1,type:"NOPE",bufferView:9}],nodes:[{mesh:5,children:[4]}],meshes:[],materials:[]};
  const report=preflightGltf(makeGlb(invalid)); assert.equal(report.ok,false);
  assert.ok(report.issues.some(i=>i.code==="GLTF_VERSION_UNSUPPORTED"));
  assert.ok(report.issues.some(i=>i.code==="GLTF_BUFFER_VIEW_INVALID"));
});

test("official glTF validator adapter adds severity mapped findings without hiding base issues", async () => {
  const data=new TextEncoder().encode(JSON.stringify({asset:{version:"2.0"}}));
  const report=await validateGltfWithKhronos(data,{validateBytes:async()=>({issues:[{code:"ACCESSOR_INVALID",message:"bad accessor",severity:0,pointer:"/accessors/0"}]})});
  assert.equal(report.ok,false); assert.ok(report.issues.some(i=>i.code==="ACCESSOR_INVALID"&&i.severity==="error"));
});

test("playable HTML5 export validates project, embeds no remote scripts and stays bounded", () => {
  const result=buildPlayableHtml5Export(project,{width:720,height:1280,genre:"platformer"});
  assert.equal(result.ok,true); if(!result.ok)return;
  assert.ok(result.bytes > 1000); assert.equal(result.exportedNodes,3);
  assert.ok(result.html.includes("Content-Security-Policy"));
  assert.ok(result.html.includes("requestAnimationFrame"));
  assert.ok(!result.html.includes("<script src="));
  const script=result.html.match(/<script>([\s\S]*?)<\/script>/)?.[1];
  assert.ok(script); assert.doesNotThrow(()=>new Function(script!));
  const tooLarge={...project,nodes:Array.from({length:513},(_,i)=>({id:`node-${i}`,type:"Sprite",name:"N",parentId:null,props:{}}))} as ProjectDocument;
  assert.equal(buildPlayableHtml5Export(tooLarge).ok,false);
});


test("multi-agent scheduler topologically orders tasks while preserving stable ready order", async () => {
  const plan: GenerationPlan = { schemaVersion:1, prompt:"test", genre:"arcade", style:"pixel-retro", dimension:"2d", target:"mobile-low", tasks:[
    {id:"assemble",role:"engineer",title:"Assemble",description:"",dependsOn:["design"],state:"queued"},
    {id:"design",role:"designer",title:"Design",description:"",dependsOn:["brief"],state:"queued"},
    {id:"brief",role:"producer",title:"Brief",description:"",dependsOn:[],state:"queued"},
    {id:"audio",role:"audio",title:"Audio",description:"",dependsOn:["design"],state:"queued"}
  ]};
  const order: string[]=[];
  const result=await executeGenerationPlan(plan,{run:async task=>{order.push(task.id);return {done:true}}},new AbortController().signal);
  assert.equal(result.ok,true);
  assert.deepEqual(order,["brief","design","assemble","audio"]);
});

test("multi-agent scheduler rejects cycles and marks unrun tasks skipped", async () => {
  const plan: GenerationPlan = { schemaVersion:1, prompt:"test", genre:"arcade", style:"stylized", dimension:"2d", target:"mobile-low", tasks:[
    {id:"a",role:"designer",title:"A",description:"",dependsOn:["b"],state:"queued"},
    {id:"b",role:"engineer",title:"B",description:"",dependsOn:["a"],state:"queued"}
  ]};
  const events: string[]=[];
  const result=await executeGenerationPlan(plan,{run:async()=>({})},new AbortController().signal,event=>events.push(event.taskId+":"+event.state));
  assert.deepEqual(result,{ok:false,error:"TASK_GRAPH_CYCLE"});
  assert.deepEqual(events,["a:skipped","b:skipped"]);
});


test("audio mixer rejects unsafe clip metadata and caps the voice pool", () => {
  const mixer=new WebAudioMixer(2);
  const fakeBuffer={duration:1,numberOfChannels:2,sampleRate:48000,length:48000} as AudioBuffer;
  assert.equal(mixer.register({id:"bad id",buffer:fakeBuffer}),false);
  assert.equal(mixer.register({id:"bad-bus",buffer:fakeBuffer,bus:"master" as never}),false);
  assert.equal(mixer.register({id:"valid-sfx",buffer:fakeBuffer,bus:"sfx",maxVoices:1}),true);
  assert.equal(mixer.registeredClips,1);
  mixer.dispose();
});
