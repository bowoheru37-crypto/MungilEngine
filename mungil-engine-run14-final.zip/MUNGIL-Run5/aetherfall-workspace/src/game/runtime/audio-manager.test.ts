import assert from "node:assert/strict";
import test from "node:test";
import { WebAudioMixer } from "./generator/audio-manager.ts";

class FakeAudioParam {
  value = 1;
  setTargetAtTime(value: number): void { this.value = value; }
  cancelScheduledValues(): void {}
  setValueAtTime(value: number): void { this.value = value; }
  linearRampToValueAtTime(value: number): void { this.value = value; }
}
class FakeNode {
  readonly gain = new FakeAudioParam();
  connect(): void {}
  disconnect(): void {}
}
class FakeBufferSource extends FakeNode {
  buffer: unknown = null;
  loop = false;
  onended: (() => void) | null = null;
  start(): void {}
  stop(): void {}
  finish(): void { this.onended?.(); }
}
class FakeAudioContext {
  state: "suspended" | "running" | "closed" = "suspended";
  currentTime = 0;
  readonly destination = new FakeNode();
  readonly sources: FakeBufferSource[] = [];
  createGain(): FakeNode { return new FakeNode(); }
  createBufferSource(): FakeBufferSource { const source = new FakeBufferSource(); this.sources.push(source); return source; }
  decodeAudioData(_data: ArrayBuffer): Promise<AudioBuffer> {
    return Promise.resolve({ duration: 1, numberOfChannels: 2, sampleRate: 44100, length: 44100 } as AudioBuffer);
  }
  async resume(): Promise<void> { this.state = "running"; }
  async suspend(): Promise<void> { this.state = "suspended"; }
  async close(): Promise<void> { this.state = "closed"; }
}

test("WebAudioMixer decodes bounded local audio, applies voice caps and releases ended voices", async () => {
  const originalWindow = Object.getOwnPropertyDescriptor(globalThis, "window");
  Object.defineProperty(globalThis, "window", { configurable: true, value: { AudioContext: FakeAudioContext } });
  try {
    const mixer = new WebAudioMixer(2);
    const blob = new Blob([new Uint8Array([1, 2, 3, 4])], { type: "audio/wav" });
    assert.equal(await mixer.decodeAndRegister("effect", blob, { bus: "sfx", maxVoices: 1, maxBytes: 16 }), true);
    assert.equal(mixer.registeredClips, 1);
    const first = mixer.play("effect");
    assert.notEqual(first, null);
    assert.equal(mixer.activeVoices, 1);
    assert.equal(mixer.play("effect"), null);
    const context = (mixer as unknown as { context: FakeAudioContext }).context;
    context.sources[0]!.finish();
    assert.equal(mixer.activeVoices, 0);
    assert.notEqual(mixer.play("effect"), null);
    mixer.setBusVolume("sfx", 0.4);
    mixer.dispose();
    assert.equal(mixer.activeVoices, 0);
    assert.equal(await mixer.decodeAndRegister("after-dispose", blob), false);
  } finally {
    if (originalWindow) Object.defineProperty(globalThis, "window", originalWindow);
    else delete (globalThis as typeof globalThis & { window?: unknown }).window;
  }
});

test("WebAudioMixer rejects oversized, invalid and aborted decodes before audio allocation", async () => {
  const originalWindow = Object.getOwnPropertyDescriptor(globalThis, "window");
  Object.defineProperty(globalThis, "window", { configurable: true, value: { AudioContext: FakeAudioContext } });
  try {
    const mixer = new WebAudioMixer(1);
    const blob = new Blob([new Uint8Array(8)]);
    assert.equal(await mixer.decodeAndRegister("large", blob, { maxBytes: 4 }), false);
    const controller = new AbortController();
    controller.abort();
    assert.equal(await mixer.decodeAndRegister("aborted", blob, {}, controller.signal), false);
    assert.equal(await mixer.decodeAndRegister("invalid id", blob), false);
    assert.equal(mixer.registeredClips, 0);
    mixer.dispose();
  } finally {
    if (originalWindow) Object.defineProperty(globalThis, "window", originalWindow);
    else delete (globalThis as typeof globalThis & { window?: unknown }).window;
  }
});
