import assert from "node:assert/strict";
import test from "node:test";
import { inspectAssetFiles, validateAssetBundle } from "./asset-pipeline.ts";

function file(name: string, bytes: number[], type = "application/octet-stream") {
  const data = new Uint8Array(bytes);
  return { name, size: data.byteLength, type, arrayBuffer: async () => data.buffer.slice(0) };
}
const png = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 13, 0x49, 0x48, 0x44, 0x52, 0, 0, 0, 2, 0, 0, 0, 3];

test("asset inspection trusts signatures rather than a spoofed MIME type", async () => {
  const result = await inspectAssetFiles([file("hero.png", png, "text/html")]);
  assert.equal(result.ok, true);
  if (!result.ok) return;
  assert.equal(result.assets[0]?.mime, "image/png");
  assert.equal(result.assets[0]?.width, 2);
  assert.equal(result.assets[0]?.height, 3);
  assert.match(result.assets[0]?.sha256 ?? "", /^[a-f0-9]{64}$/);
});

test("asset inspection recognizes KTX2 texture headers", async () => {
  const bytes = [0xab, 0x4b, 0x54, 0x58, 0x20, 0x32, 0x30, 0xbb, 0x0d, 0x0a, 0x1a, 0x0a, ...new Array(8).fill(0), 0x00, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00];
  const result = await inspectAssetFiles([file("terrain.ktx2", bytes)]);
  assert.equal(result.ok, true);
  if (result.ok) { assert.equal(result.assets[0]?.kind, "texture"); assert.equal(result.assets[0]?.width, 1024); assert.equal(result.assets[0]?.height, 512); }
});

test("asset inspection rejects mislabeled or malformed files", async () => {
  const result = await inspectAssetFiles([file("payload.png", [0x3c, 0x68, 0x74, 0x6d, 0x6c])]);
  assert.deepEqual(result, { ok: false, error: "UNSUPPORTED_OR_INVALID_FILE_SIGNATURE", file: "payload.png" });
});

test("asset inspection rejects excessive dimensions and total bytes", async () => {
  const tooLarge = await inspectAssetFiles([file("huge.png", [...png.slice(0, 16), 0, 0x20, 0, 0, ...png.slice(20)])], { maxImageDimension: 4096 });
  assert.equal(tooLarge.ok, false);
  if (!tooLarge.ok) assert.equal(tooLarge.error, "IMAGE_DIMENSION_INVALID_OR_LIMIT");
  const overBudget = await inspectAssetFiles([file("a.png", png), file("b.png", png)], { maxTotalBytes: 30 });
  assert.equal(overBudget.ok, false);
  if (!overBudget.ok) assert.equal(overBudget.error, "IMPORT_TOTAL_SIZE_LIMIT");
});

test("asset inspection rejects path-like filenames and aborts between files", async () => {
  const unsafe = await inspectAssetFiles([file("../escape.png", png)]);
  assert.equal(unsafe.ok, false);
  const controller = new AbortController(); controller.abort();
  const aborted = await inspectAssetFiles([file("safe.png", png)], {}, controller.signal);
  assert.equal(aborted.ok, false);
  if (!aborted.ok) assert.equal(aborted.error, "IMPORT_ABORTED");
});

test("asset manifest rejects unsafe paths and duplicate ids", () => {
  const valid = { id: "hero", path: "assets/hero.png", kind: "image", mime: "image/png", bytes: png.length, width: 2, height: 3 } as const;
  assert.equal(validateAssetBundle([valid], { maxAssets: 4, maxTotalBytes: 1024, maxSingleBytes: 512, maxTextureDimension: 64 }).ok, true);
  assert.equal(validateAssetBundle([{ ...valid, path: "../hero.png" }], { maxAssets: 4, maxTotalBytes: 1024, maxSingleBytes: 512, maxTextureDimension: 64 }).ok, false);
  assert.equal(validateAssetBundle([valid, valid], { maxAssets: 4, maxTotalBytes: 1024, maxSingleBytes: 512, maxTextureDimension: 64 }).ok, false);
});

import { assetVaultLimits, planAssetVaultEviction } from "./asset-vault.ts";

test("asset vault applies the conservative Tier 0 memory/storage ceiling", () => {
  assert.deepEqual(assetVaultLimits(0), { maxBytes: 24 * 1024 * 1024, maxSingleBytes: 8 * 1024 * 1024, maxEntries: 128 });
});

test("asset vault evicts least-recently-used unpinned entries without evicting pinned assets", () => {
  const plan = planAssetVaultEviction([
    { id: "old", bytes: 8, lastAccessedAt: 1, pinned: false },
    { id: "pinned", bytes: 8, lastAccessedAt: 2, pinned: true },
    { id: "newer", bytes: 8, lastAccessedAt: 3, pinned: false },
  ], { id: "incoming", bytes: 8 }, { maxBytes: 24, maxSingleBytes: 16, maxEntries: 3 });
  assert.deepEqual(plan, { ok: true, value: ["old"] });
});

test("asset vault rejects capacity pressure when pinned entries cannot be evicted", () => {
  const plan = planAssetVaultEviction([
    { id: "pinned-a", bytes: 8, lastAccessedAt: 1, pinned: true },
    { id: "pinned-b", bytes: 8, lastAccessedAt: 2, pinned: true },
  ], { id: "incoming", bytes: 8 }, { maxBytes: 16, maxSingleBytes: 8, maxEntries: 2 });
  assert.deepEqual(plan, { ok: false, error: "VAULT_CAPACITY_PINNED_OR_EXHAUSTED" });
});

test("asset vault replaces an existing id without consuming an extra entry", () => {
  const plan = planAssetVaultEviction([{ id: "same", bytes: 10, lastAccessedAt: 1, pinned: false }], { id: "same", bytes: 12 }, { maxBytes: 12, maxSingleBytes: 12, maxEntries: 1 });
  assert.deepEqual(plan, { ok: true, value: [] });
});
