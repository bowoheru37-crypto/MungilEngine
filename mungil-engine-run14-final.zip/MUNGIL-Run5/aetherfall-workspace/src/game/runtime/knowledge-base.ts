/** Bounded, provenance-aware agent memory. Stored text is data, never executable instructions. */
export type KnowledgeKind = "fact" | "decision" | "pattern" | "pitfall" | "reference" | "skill-note";
export type KnowledgeEntry = Readonly<{ id: string; kind: KnowledgeKind; title: string; content: string; tags: readonly string[]; sourceUrl?: string; confidence: number; createdAt: number; updatedAt: number; hits: number }>;
export type KnowledgeLimits = Readonly<{ maxEntries: number; maxBytes: number; maxEntryBytes: number; maxTags: number }>;
export type KnowledgeResult<T> = { ok: true; value: T } | { ok: false; error: string };
const ID = /^[A-Za-z0-9_-]{1,80}$/;
const KINDS = new Set<KnowledgeKind>(["fact", "decision", "pattern", "pitfall", "reference", "skill-note"]);
const DEFAULTS: KnowledgeLimits = Object.freeze({ maxEntries: 256, maxBytes: 256 * 1024, maxEntryBytes: 8192, maxTags: 16 });
function safeUrl(value: string): boolean { try { const url = new URL(value); return (url.protocol === "https:" || url.protocol === "http:") && !url.username && !url.password; } catch { return false; } }
function normalizedText(value: string, max: number): boolean { return typeof value === "string" && value.trim().length > 0 && value.length <= max && !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(value); }
export class AgentKnowledgeBase {
  private readonly entries = new Map<string, KnowledgeEntry>();
  private readonly limits: KnowledgeLimits;
  constructor(limits: Partial<KnowledgeLimits> = {}) {
    this.limits = { ...DEFAULTS, ...limits };
    if (!Number.isInteger(this.limits.maxEntries) || this.limits.maxEntries < 1 || this.limits.maxEntries > 4096 || !Number.isInteger(this.limits.maxBytes) || this.limits.maxBytes < 1024 || !Number.isInteger(this.limits.maxEntryBytes) || this.limits.maxEntryBytes < 128 || this.limits.maxEntryBytes > this.limits.maxBytes || !Number.isInteger(this.limits.maxTags) || this.limits.maxTags < 1 || this.limits.maxTags > 64) throw new TypeError("INVALID_KNOWLEDGE_LIMITS");
  }
  get size(): number { return this.entries.size; }
  get bytes(): number { let total = 0; for (const entry of this.entries.values()) total += this.entryBytes(entry); return total; }
  private entryBytes(entry: KnowledgeEntry): number { return JSON.stringify(entry).length * 2; }
  add(input: Omit<KnowledgeEntry, "hits"> & { hits?: number }): KnowledgeResult<KnowledgeEntry> {
    if (!input || typeof input !== "object" || (Object.getPrototypeOf(input) !== Object.prototype && Object.getPrototypeOf(input) !== null)) return { ok: false, error: "INVALID_KNOWLEDGE_ENTRY" };
    const descriptors = Object.getOwnPropertyDescriptors(input);
    const allowed = new Set(["id", "kind", "title", "content", "tags", "sourceUrl", "confidence", "createdAt", "updatedAt", "hits"]);
    if (Object.keys(descriptors).some(key => !allowed.has(key) || !("value" in descriptors[key]!) || descriptors[key]!.get || descriptors[key]!.set)) return { ok: false, error: "INVALID_KNOWLEDGE_ENTRY" };
    if (!ID.test(input.id) || !KINDS.has(input.kind) || !normalizedText(input.title, 160) || !normalizedText(input.content, 6000) || !Array.isArray(input.tags) || input.tags.length > this.limits.maxTags || input.tags.some(tag => !normalizedText(tag, 32)) || new Set(input.tags).size !== input.tags.length || !Number.isFinite(input.confidence) || input.confidence < 0 || input.confidence > 1 || !Number.isFinite(input.createdAt) || !Number.isFinite(input.updatedAt) || input.updatedAt < input.createdAt || (input.sourceUrl !== undefined && (typeof input.sourceUrl !== "string" || !safeUrl(input.sourceUrl)))) return { ok: false, error: "INVALID_KNOWLEDGE_ENTRY" };
    const entry: KnowledgeEntry = Object.freeze({ ...input, tags: Object.freeze([...input.tags]), hits: Number.isSafeInteger(input.hits ?? 0) && (input.hits ?? 0) >= 0 ? input.hits ?? 0 : 0 });
    if (this.entryBytes(entry) > this.limits.maxEntryBytes) return { ok: false, error: "KNOWLEDGE_ENTRY_TOO_LARGE" };
    const previous = this.entries.get(entry.id); this.entries.delete(entry.id); this.entries.set(entry.id, entry);
    while (this.entries.size > this.limits.maxEntries || this.bytes > this.limits.maxBytes) {
      const oldest = this.entries.keys().next().value as string | undefined;
      if (!oldest || oldest === entry.id) { if (previous) this.entries.set(previous.id, previous); else this.entries.delete(entry.id); return { ok: false, error: "KNOWLEDGE_BUDGET_EXCEEDED" }; }
      this.entries.delete(oldest);
    }
    return { ok: true, value: entry };
  }
  search(query: string, tags: readonly string[] = [], limit = 8): readonly KnowledgeEntry[] {
    if (!normalizedText(query, 256) || !Array.isArray(tags) || tags.length > this.limits.maxTags || !Number.isInteger(limit) || limit < 1 || limit > 32) return [];
    const terms = query.toLowerCase().split(/[^a-z0-9_+-]+/).filter(Boolean);
    const ranked = [...this.entries.values()].map(entry => {
      const haystack = `${entry.title} ${entry.content} ${entry.tags.join(" ")}`.toLowerCase();
      const tagHits = tags.filter(tag => entry.tags.includes(tag)).length;
      const termHits = terms.reduce((score, term) => score + (haystack.includes(term) ? 1 : 0), 0);
      return { entry, score: termHits * 3 + tagHits * 5 + entry.confidence };
    }).filter(item => item.score > 0).sort((a, b) => b.score - a.score || b.entry.updatedAt - a.entry.updatedAt).slice(0, limit);
    for (const item of ranked) { this.entries.delete(item.entry.id); this.entries.set(item.entry.id, Object.freeze({ ...item.entry, hits: item.entry.hits + 1 })); }
    return ranked.map(item => this.entries.get(item.entry.id)!);
  }
  recordSkillOutcome(skillId: string, success: boolean, now = Date.now()): KnowledgeResult<KnowledgeEntry> {
    if (!/^[A-Za-z0-9_-]{1,32}$/.test(skillId) || typeof success !== "boolean" || !Number.isFinite(now)) return { ok: false, error: "INVALID_SKILL_OUTCOME" };
    const id = `skill-${skillId}`; const prior = this.entries.get(id);
    const priorScore = prior ? Number(prior.content.match(/score=([0-9.]+)/)?.[1] ?? 0.5) : 0.5;
    const score = Math.max(0, Math.min(1, priorScore * 0.8 + (success ? 1 : 0) * 0.2));
    const content = `score=${score.toFixed(4)}; observations=${(prior?.hits ?? 0) + 1}; last=${success ? "success" : "failure"}`;
    return this.add({ id, kind: "skill-note", title: `Skill outcome: ${skillId}`, content, tags: ["skill", skillId], confidence: 0.8, createdAt: prior?.createdAt ?? now, updatedAt: now, hits: (prior?.hits ?? 0) + 1 });
  }
  exportSnapshot(): string { return JSON.stringify({ schemaVersion: 1, entries: [...this.entries.values()] }); }
  importSnapshot(raw: string): KnowledgeResult<number> {
    if (typeof raw !== "string" || raw.length > this.limits.maxBytes * 2) return { ok: false, error: "KNOWLEDGE_SNAPSHOT_LIMIT" };
    let parsed: unknown; try { parsed = JSON.parse(raw); } catch { return { ok: false, error: "KNOWLEDGE_SNAPSHOT_INVALID_JSON" }; }
    if (!parsed || typeof parsed !== "object" || (parsed as { schemaVersion?: unknown }).schemaVersion !== 1 || !Array.isArray((parsed as { entries?: unknown }).entries) || (parsed as { entries: unknown[] }).entries.length > this.limits.maxEntries) return { ok: false, error: "KNOWLEDGE_SNAPSHOT_SCHEMA" };
    const candidate = new AgentKnowledgeBase(this.limits);
    const seen = new Set<string>();
    for (const entry of (parsed as { entries: KnowledgeEntry[] }).entries) {
      if (!entry || typeof entry.id !== "string" || seen.has(entry.id)) return { ok: false, error: "KNOWLEDGE_SNAPSHOT_DUPLICATE_ID" };
      seen.add(entry.id);
      const result = candidate.add(entry); if (!result.ok) return { ok: false, error: `KNOWLEDGE_SNAPSHOT_ENTRY:${result.error}` };
    }
    this.entries.clear(); for (const entry of candidate.entries.values()) this.entries.set(entry.id, entry);
    return { ok: true, value: this.entries.size };
  }
  clear(): void { this.entries.clear(); }
}
