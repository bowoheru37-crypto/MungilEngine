import type { DeviceProfile, QualityTier } from "./core.ts";

export type RendererKind = "auto" | "canvas2d" | "webgl1" | "webgl2" | "webgpu";
export type ProjectionKind = "orthographic-2d" | "isometric-2.5d" | "perspective-3d" | "pseudo-3d-road" | "grid-raycaster";

export type RuntimeFeatureFlags = Readonly<{
  physics2d: boolean;
  physics3d: boolean;
  skeletal2d: boolean;
  skeletal3d: boolean;
  particles: boolean;
  navigation: boolean;
  multiplayer: boolean;
  postProcessing: boolean;
  editorTools: boolean;
}>;

export type RuntimeProjectManifest = Readonly<{
  schemaVersion: number;
  projectId: string;
  title: string;
  renderer: RendererKind;
  projection: ProjectionKind;
  simulationHz: number;
  targetFps: 30 | 60;
  qualityTier: QualityTier | "auto";
  seed: number;
  features: RuntimeFeatureFlags;
  scenes: readonly string[];
}>;

export type RuntimeContext = {
  device: DeviceProfile;
  qualityTier: QualityTier;
  tick: number;
  deltaSeconds: number;
  interpolationAlpha: number;
};

export interface RuntimeSystem<C = RuntimeContext> {
  readonly id: string;
  readonly order?: number;
  init?(context: C): void;
  fixedUpdate?(context: C, stepSeconds: number, tick: number): void;
  update?(context: C, deltaSeconds: number): void;
  render?(context: C, interpolationAlpha: number): void;
  onSuspend?(context: C): void;
  onResume?(context: C): void;
  dispose?(): void;
}

export interface RendererAdapter<Scene = unknown> {
  readonly kind: Exclude<RendererKind, "auto">;
  initialize(host: HTMLCanvasElement, profile: DeviceProfile): void | Promise<void>;
  createScene?(manifest: RuntimeProjectManifest): Scene;
  resize(width: number, height: number, pixelRatio: number): void;
  render(scene: Scene, interpolationAlpha: number): void;
  setQuality(tier: QualityTier): void;
  disposeScene?(scene: Scene): void;
  dispose(): void;
}

export interface PhysicsAdapter<World = unknown, Body = unknown> {
  readonly dimension: 2 | 3;
  createWorld(options?: Readonly<Record<string, number | boolean>>): World;
  createBody(world: World, definition: Readonly<Record<string, unknown>>): Body;
  step(world: World, fixedDeltaSeconds: number): void;
  removeBody(world: World, body: Body): void;
  disposeWorld(world: World): void;
}

export interface AssetProvider<Asset = unknown> {
  load(id: string, signal?: AbortSignal): Promise<Asset>;
  release(id: string): void;
  has(id: string): boolean;
  dispose(): void;
}

export interface AudioAdapter {
  unlock(): void;
  play(id: string, options?: Readonly<{ volume?: number; loop?: boolean; bus?: string }>): number | null;
  stop(handle: number): void;
  setBusVolume(bus: string, volume: number): void;
  suspend(): void;
  resume(): void;
  dispose(): void;
}

export type RuntimeManifestValidation = { ok: true } | { ok: false; error: string };

export function validateRuntimeManifest(value: unknown): RuntimeManifestValidation {
  if (!value || typeof value !== "object") return { ok: false, error: "MANIFEST_NOT_OBJECT" };
  const m = value as Partial<RuntimeProjectManifest>;
  if (!Number.isSafeInteger(m.schemaVersion) || (m.schemaVersion ?? 0) < 1) return { ok: false, error: "INVALID_SCHEMA_VERSION" };
  if (typeof m.projectId !== "string" || !/^[a-zA-Z0-9_-]{1,80}$/.test(m.projectId)) return { ok: false, error: "INVALID_PROJECT_ID" };
  if (typeof m.title !== "string" || !m.title.trim() || m.title.length > 120) return { ok: false, error: "INVALID_PROJECT_TITLE" };
  if (!["auto", "canvas2d", "webgl1", "webgl2", "webgpu"].includes(m.renderer ?? "")) return { ok: false, error: "INVALID_RENDERER" };
  if (!["orthographic-2d", "isometric-2.5d", "perspective-3d", "pseudo-3d-road", "grid-raycaster"].includes(m.projection ?? "")) return { ok: false, error: "INVALID_PROJECTION" };
  if (!Number.isInteger(m.simulationHz) || (m.simulationHz ?? 0) < 10 || (m.simulationHz ?? 0) > 120) return { ok: false, error: "INVALID_SIMULATION_RATE" };
  if (m.targetFps !== 30 && m.targetFps !== 60) return { ok: false, error: "INVALID_TARGET_FPS" };
  if (m.qualityTier !== "auto" && m.qualityTier !== 0 && m.qualityTier !== 1 && m.qualityTier !== 2) return { ok: false, error: "INVALID_QUALITY_TIER" };
  if (!Number.isSafeInteger(m.seed) || (m.seed ?? -1) < 0 || (m.seed ?? 0) > 0xffffffff) return { ok: false, error: "INVALID_PROJECT_SEED" };
  if (!Array.isArray(m.scenes) || m.scenes.length < 1 || m.scenes.length > 256) return { ok: false, error: "INVALID_SCENE_LIST" };
  const seen = new Set<string>();
  for (const scene of m.scenes) {
    if (typeof scene !== "string" || !/^[a-zA-Z0-9_./-]{1,160}$/.test(scene) || scene.includes("..") || seen.has(scene)) return { ok: false, error: "INVALID_SCENE_ID" };
    seen.add(scene);
  }
  if (!m.features || typeof m.features !== "object") return { ok: false, error: "INVALID_FEATURE_FLAGS" };
  const flags = ["physics2d", "physics3d", "skeletal2d", "skeletal3d", "particles", "navigation", "multiplayer", "postProcessing", "editorTools"] as const;
  for (const key of flags) if (typeof m.features[key] !== "boolean") return { ok: false, error: `INVALID_FEATURE_${key}` };
  return { ok: true };
}
