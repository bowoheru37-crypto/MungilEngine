export type AssetKind = "image" | "texture" | "audio" | "model" | "font" | "data" | "video";
export type AssetCompression = "none" | "webp" | "basis" | "ktx2" | "opus" | "gzip";
export type AssetDescriptor = Readonly<{
  id: string; path: string; kind: AssetKind; mime: string; bytes: number;
  width?: number; height?: number; sha256?: string; compression?: AssetCompression;
}>;
export type AssetBudget = Readonly<{ maxAssets: number; maxTotalBytes: number; maxSingleBytes: number; maxTextureDimension: number }>;
export type AssetValidation = { ok: true; totalBytes: number; assets: number } | { ok: false; error: string };

const MIME_BY_KIND: Readonly<Record<AssetKind, readonly string[]>> = {
  image: ["image/png", "image/jpeg", "image/webp", "image/avif", "image/gif"],
  texture: ["image/png", "image/jpeg", "image/webp", "image/ktx2", "image/basis"],
  audio: ["audio/ogg", "audio/opus", "audio/mpeg", "audio/wav", "audio/mp4"],
  model: ["model/gltf+json", "model/gltf-binary", "application/octet-stream"],
  font: ["font/woff2", "font/woff", "font/ttf", "application/font-sfnt"],
  data: ["application/json", "application/octet-stream", "text/plain"],
  video: ["video/mp4", "video/webm"],
};
const ID = /^[a-zA-Z0-9_-]{1,80}$/;
const SHA256 = /^[a-f0-9]{64}$/i;

function safeAssetPath(path: string): boolean {
  if (!path || path.length > 240 || path.startsWith("/") || path.includes("\\") || path.includes("%") || /[\u0000-\u001f\u007f]/.test(path)) return false;
  let decoded = path;
  for (let i = 0; i < 3; i++) {
    try { const next = decodeURIComponent(decoded); if (next === decoded) break; decoded = next; }
    catch { return false; }
  }
  if (decoded.includes("\\") || decoded.startsWith("/") || /[\u0000-\u001f\u007f]/.test(decoded)) return false;
  const parts = decoded.split("/");
  return parts.every(part => part.length > 0 && part !== "." && part !== "..") && !/^[a-z][a-z0-9+.-]*:/i.test(decoded);
}

/** Validates untrusted imported metadata before any asset bytes are decoded or uploaded. */
export function validateAssetBundle(value: unknown, budget: AssetBudget): AssetValidation {
  if (!Array.isArray(value) || !Number.isSafeInteger(budget.maxAssets) || budget.maxAssets < 1 || !Number.isSafeInteger(budget.maxTotalBytes) || budget.maxTotalBytes < 1 || !Number.isSafeInteger(budget.maxSingleBytes) || budget.maxSingleBytes < 1 || !Number.isSafeInteger(budget.maxTextureDimension) || budget.maxTextureDimension < 1) return { ok: false, error: "INVALID_ASSET_BUDGET_OR_LIST" };
  if (value.length > budget.maxAssets) return { ok: false, error: "ASSET_COUNT_LIMIT" };
  const ids = new Set<string>(); const paths = new Set<string>(); let totalBytes = 0;
  for (const raw of value) {
    if (!raw || typeof raw !== "object") return { ok: false, error: "INVALID_ASSET_DESCRIPTOR" };
    const asset = raw as Partial<AssetDescriptor>;
    if (typeof asset.id !== "string" || !ID.test(asset.id) || ids.has(asset.id)) return { ok: false, error: "INVALID_OR_DUPLICATE_ASSET_ID" };
    if (typeof asset.path !== "string" || !safeAssetPath(asset.path) || paths.has(asset.path)) return { ok: false, error: "INVALID_OR_DUPLICATE_ASSET_PATH" };
    if (typeof asset.kind !== "string" || !Object.prototype.hasOwnProperty.call(MIME_BY_KIND, asset.kind) || typeof asset.mime !== "string" || !MIME_BY_KIND[asset.kind as AssetKind].includes(asset.mime)) return { ok: false, error: "ASSET_MIME_KIND_MISMATCH" };
    if (!Number.isSafeInteger(asset.bytes) || (asset.bytes ?? 0) < 0 || (asset.bytes ?? 0) > budget.maxSingleBytes) return { ok: false, error: "ASSET_SIZE_LIMIT" };
    if (asset.sha256 !== undefined && (typeof asset.sha256 !== "string" || !SHA256.test(asset.sha256))) return { ok: false, error: "INVALID_ASSET_HASH" };
    if (asset.compression !== undefined && !["none", "webp", "basis", "ktx2", "opus", "gzip"].includes(asset.compression)) return { ok: false, error: "INVALID_ASSET_COMPRESSION" };
    if (asset.kind === "image" || asset.kind === "texture") {
      if (!Number.isSafeInteger(asset.width) || !Number.isSafeInteger(asset.height) || (asset.width ?? 0) < 1 || (asset.height ?? 0) < 1 || (asset.width ?? 0) > budget.maxTextureDimension || (asset.height ?? 0) > budget.maxTextureDimension) return { ok: false, error: "TEXTURE_DIMENSION_LIMIT" };
    }
    totalBytes += asset.bytes!;
    if (!Number.isSafeInteger(totalBytes) || totalBytes > budget.maxTotalBytes) return { ok: false, error: "ASSET_BUNDLE_BYTE_LIMIT" };
    ids.add(asset.id); paths.add(asset.path);
  }
  return { ok: true, totalBytes, assets: value.length };
}

export type AssetBuildRecommendation = Readonly<{ id: string; source: string; recommendedCompression: AssetCompression; reason: string }>;
/** Emits a deterministic conversion manifest; actual transcoding is delegated to build-time tools. */
export function recommendAssetBuild(assets: readonly AssetDescriptor[], tier: 0 | 1 | 2): readonly AssetBuildRecommendation[] {
  const output: AssetBuildRecommendation[] = [];
  for (const asset of assets) {
    if (asset.kind === "texture" || asset.kind === "image") output.push({ id: asset.id, source: asset.path, recommendedCompression: asset.kind === "texture" ? "basis" : "webp", reason: tier === 0 ? "Reduce mobile transfer and GPU memory; cap dimensions before transcoding." : "Use a modern compact image representation and preserve source for fallback." });
    else if (asset.kind === "audio") output.push({ id: asset.id, source: asset.path, recommendedCompression: "opus", reason: "Use streaming for long music and short decoded buffers for frequently triggered effects." });
    else if (asset.kind === "data") output.push({ id: asset.id, source: asset.path, recommendedCompression: "gzip", reason: "Compress text-like payloads at build time; keep runtime parsing bounded." });
  }
  return output;
}

export type AssetImportLimits = Readonly<{
  maxFiles: number;
  maxSingleBytes: number;
  maxTotalBytes: number;
  maxImageDimension: number;
  maxJsonBytes: number;
}>;
export type AssetFileLike = Readonly<{ name: string; size: number; type?: string; arrayBuffer(): Promise<ArrayBuffer> }>;
export type ImportedAsset = Readonly<{
  id: string;
  path: string;
  kind: AssetKind;
  mime: string;
  bytes: number;
  sha256: string;
  width?: number;
  height?: number;
}>;
export type AssetImportResult =
  | Readonly<{ ok: true; assets: readonly ImportedAsset[]; totalBytes: number }>
  | Readonly<{ ok: false; error: string; file?: string }>;

const DEFAULT_IMPORT_LIMITS: AssetImportLimits = Object.freeze({
  maxFiles: 64,
  maxSingleBytes: 32 * 1024 * 1024,
  maxTotalBytes: 96 * 1024 * 1024,
  maxImageDimension: 4096,
  maxJsonBytes: 2 * 1024 * 1024,
});

function ascii(bytes: Uint8Array, offset: number, length: number): string {
  return String.fromCharCode(...bytes.subarray(offset, offset + length));
}
function u32be(bytes: Uint8Array, offset: number): number {
  return (((bytes[offset] ?? 0) * 0x1000000) + ((bytes[offset + 1] ?? 0) << 16) + ((bytes[offset + 2] ?? 0) << 8) + (bytes[offset + 3] ?? 0)) >>> 0;
}
function imageDimensions(bytes: Uint8Array, mime: string): { width: number; height: number } | null {
  if (mime === "image/png" && bytes.length >= 24 && ascii(bytes, 0, 8) === "\x89PNG\r\n\x1a\n" && ascii(bytes, 12, 4) === "IHDR") return { width: u32be(bytes, 16), height: u32be(bytes, 20) };
  if (mime === "image/gif" && bytes.length >= 10 && (ascii(bytes, 0, 6) === "GIF87a" || ascii(bytes, 0, 6) === "GIF89a")) return { width: (bytes[6] ?? 0) | ((bytes[7] ?? 0) << 8), height: (bytes[8] ?? 0) | ((bytes[9] ?? 0) << 8) };
  if (mime === "image/webp" && bytes.length >= 30 && ascii(bytes, 0, 4) === "RIFF" && ascii(bytes, 8, 4) === "WEBP") {
    const chunk = ascii(bytes, 12, 4);
    if (chunk === "VP8X") return { width: 1 + (bytes[24] ?? 0) + ((bytes[25] ?? 0) << 8) + ((bytes[26] ?? 0) << 16), height: 1 + (bytes[27] ?? 0) + ((bytes[28] ?? 0) << 8) + ((bytes[29] ?? 0) << 16) };
    if (chunk === "VP8L" && bytes.length >= 25 && bytes[20] === 0x2f) { const b1 = bytes[21] ?? 0, b2 = bytes[22] ?? 0, b3 = bytes[23] ?? 0, b4 = bytes[24] ?? 0; return { width: 1 + (((b2 & 0x3f) << 8) | b1), height: 1 + (((b4 & 0x0f) << 10) | (b3 << 2) | ((b2 & 0xc0) >> 6)) }; }
    if (chunk === "VP8 " && bytes.length >= 30 && bytes[23] === 0x9d && bytes[24] === 0x01 && bytes[25] === 0x2a) return { width: (((bytes[27] ?? 0) & 0x3f) << 8) | (bytes[26] ?? 0), height: (((bytes[29] ?? 0) & 0x3f) << 8) | (bytes[28] ?? 0) };
  }
  if (mime === "image/jpeg" && bytes.length >= 4 && bytes[0] === 0xff && bytes[1] === 0xd8) {
    let offset = 2;
    while (offset + 4 < bytes.length) {
      if (bytes[offset] !== 0xff) { offset++; continue; }
      const marker = bytes[offset + 1] ?? 0; offset += 2;
      if (marker === 0xd8 || marker === 0xd9 || (marker >= 0xd0 && marker <= 0xd7)) continue;
      const length = ((bytes[offset] ?? 0) << 8) | (bytes[offset + 1] ?? 0);
      if (length < 2 || offset + length > bytes.length) return null;
      if ([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf].includes(marker) && length >= 7) return { height: ((bytes[offset + 3] ?? 0) << 8) | (bytes[offset + 4] ?? 0), width: ((bytes[offset + 5] ?? 0) << 8) | (bytes[offset + 6] ?? 0) };
      offset += length;
    }
  }
  return null;
}
function detectAsset(bytes: Uint8Array, name: string): { kind: AssetKind; mime: string; width?: number; height?: number } | null {
  if (bytes.length >= 12 && bytes[0] === 0xab && ascii(bytes, 1, 11) === "KTX 20\xbb\r\n\x1a\n") {
    const width = (bytes[20] ?? 0) | ((bytes[21] ?? 0) << 8) | ((bytes[22] ?? 0) << 16) | ((bytes[23] ?? 0) << 24);
    const height = (bytes[24] ?? 0) | ((bytes[25] ?? 0) << 8) | ((bytes[26] ?? 0) << 16) | ((bytes[27] ?? 0) << 24);
    if (bytes.length < 28 || width < 1 || height < 1) return null;
    return { kind: "texture", mime: "image/ktx2", width: width >>> 0, height: height >>> 0 };
  }
  if (bytes.length >= 8 && ascii(bytes, 0, 8) === "\x89PNG\r\n\x1a\n") return { kind: "image", mime: "image/png", ...imageDimensions(bytes, "image/png") };
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return { kind: "image", mime: "image/jpeg", ...imageDimensions(bytes, "image/jpeg") };
  if (bytes.length >= 12 && ascii(bytes, 0, 4) === "RIFF" && ascii(bytes, 8, 4) === "WEBP") return { kind: "image", mime: "image/webp", ...imageDimensions(bytes, "image/webp") };
  if (bytes.length >= 10 && (ascii(bytes, 0, 6) === "GIF87a" || ascii(bytes, 0, 6) === "GIF89a")) return { kind: "image", mime: "image/gif", ...imageDimensions(bytes, "image/gif") };
  if (bytes.length >= 12 && ascii(bytes, 0, 4) === "RIFF" && ascii(bytes, 8, 4) === "WAVE") return { kind: "audio", mime: "audio/wav" };
  if (bytes.length >= 4 && ascii(bytes, 0, 4) === "OggS") return { kind: "audio", mime: "audio/ogg" };
  if (bytes.length >= 3 && (ascii(bytes, 0, 3) === "ID3" || (bytes[0] === 0xff && ((bytes[1] ?? 0) & 0xe0) === 0xe0))) return { kind: "audio", mime: "audio/mpeg" };
  if (bytes.length >= 20 && ascii(bytes, 0, 4) === "glTF" && bytes[4] === 2 && (bytes[8]! | (bytes[9]! << 8) | (bytes[10]! << 16) | (bytes[11]! << 24)) >>> 0 === bytes.length) return { kind: "model", mime: "model/gltf-binary" };
  if (bytes.length >= 4 && ascii(bytes, 0, 4) === "wOF2") return { kind: "font", mime: "font/woff2" };
  if (bytes.length >= 4 && ascii(bytes, 0, 4) === "wOFF") return { kind: "font", mime: "font/woff" };
  if (bytes.length >= 4 && (ascii(bytes, 0, 4) === "OTTO" || ascii(bytes, 0, 4) === "true" || (bytes[0] === 0 && bytes[1] === 1 && bytes[2] === 0 && bytes[3] === 0))) return { kind: "font", mime: "font/ttf" };
  const ext = name.toLowerCase().split(".").pop();
  if (ext === "gltf" || ext === "json") {
    try {
      const parsed: unknown = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
      if (parsed && typeof parsed === "object" && "asset" in parsed && (parsed as { asset?: { version?: unknown } }).asset?.version === "2.0") return { kind: "model", mime: "model/gltf+json" };
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) return { kind: "data", mime: "application/json" };
    } catch { return null; }
  }
  if (bytes.length >= 4 && ascii(bytes, 0, 4) === "\u001aE\u00df\u00a3") return { kind: "video", mime: "video/webm" };
  if (bytes.length >= 12 && ascii(bytes, 4, 4) === "ftyp") return { kind: "video", mime: "video/mp4" };
  return null;
}

/** Inspect untrusted files sequentially; metadata comes from file signatures, never the supplied MIME label. */
export async function inspectAssetFiles(
  files: readonly AssetFileLike[],
  limits: Partial<AssetImportLimits> = {},
  signal?: AbortSignal,
): Promise<AssetImportResult> {
  const budget = { ...DEFAULT_IMPORT_LIMITS, ...limits };
  if (!Number.isSafeInteger(budget.maxFiles) || budget.maxFiles < 1 || !Number.isSafeInteger(budget.maxSingleBytes) || budget.maxSingleBytes < 1 || !Number.isSafeInteger(budget.maxTotalBytes) || budget.maxTotalBytes < 1 || !Number.isSafeInteger(budget.maxImageDimension) || budget.maxImageDimension < 1 || !Number.isSafeInteger(budget.maxJsonBytes) || budget.maxJsonBytes < 1) return { ok: false, error: "INVALID_IMPORT_LIMITS" };
  if (!Array.isArray(files) || files.length > budget.maxFiles) return { ok: false, error: "IMPORT_FILE_COUNT_LIMIT" };
  if (!globalThis.crypto?.subtle) return { ok: false, error: "CRYPTO_SUBTLE_UNAVAILABLE" };
  const output: ImportedAsset[] = []; const used = new Set<string>(); let total = 0;
  for (const file of files) {
    if (signal?.aborted) return { ok: false, error: "IMPORT_ABORTED", file: file?.name };
    if (!file || typeof file.name !== "string" || !file.name || file.name.length > 180 || /[\\/\u0000-\u001f]/.test(file.name) || !Number.isSafeInteger(file.size) || file.size < 1 || file.size > budget.maxSingleBytes) return { ok: false, error: "INVALID_FILE_OR_SIZE_LIMIT", file: file?.name };
    total += file.size;
    if (!Number.isSafeInteger(total) || total > budget.maxTotalBytes) return { ok: false, error: "IMPORT_TOTAL_SIZE_LIMIT", file: file.name };
    let buffer: ArrayBuffer;
    try { buffer = await file.arrayBuffer(); } catch { return { ok: false, error: "FILE_READ_FAILED", file: file.name }; }
    if (signal?.aborted) return { ok: false, error: "IMPORT_ABORTED", file: file.name };
    if (buffer.byteLength !== file.size) return { ok: false, error: "FILE_SIZE_CHANGED_DURING_READ", file: file.name };
    const bytes = new Uint8Array(buffer);
    const detected = detectAsset(bytes, file.name);
    if (!detected) return { ok: false, error: "UNSUPPORTED_OR_INVALID_FILE_SIGNATURE", file: file.name };
    if (detected.kind === "image" && (!detected.width || !detected.height || detected.width > budget.maxImageDimension || detected.height > budget.maxImageDimension)) return { ok: false, error: "IMAGE_DIMENSION_INVALID_OR_LIMIT", file: file.name };
    if ((detected.kind === "model" || detected.kind === "data") && file.size > budget.maxJsonBytes && detected.mime !== "model/gltf-binary") return { ok: false, error: "JSON_ASSET_SIZE_LIMIT", file: file.name };
    const hash = await globalThis.crypto.subtle.digest("SHA-256", buffer);
    const sha256 = Array.from(new Uint8Array(hash), value => value.toString(16).padStart(2, "0")).join("");
    const base = file.name.replace(/\.[^.]+$/, "").normalize("NFKD").replace(/[^A-Za-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 64) || "asset";
    let id = base; let suffix = 2; while (used.has(id)) id = `${base}-${suffix++}`; used.add(id);
    output.push(Object.freeze({ id, path: `assets/${id}${file.name.match(/\.[^.]+$/)?.[0].toLowerCase() ?? ""}`, kind: detected.kind, mime: detected.mime, bytes: file.size, sha256, ...(detected.width ? { width: detected.width } : {}), ...(detected.height ? { height: detected.height } : {}) }));
  }
  return { ok: true, assets: output, totalBytes: total };
}
