/**
 * MUNGIL Runtime Primitives
 * Dependency-free runtime building blocks for 2D, 2.5D and 3D projects.
 * Keep engine-specific renderers, physics solvers and editors behind adapters.
 */

export type QualityTier = 0 | 1 | 2;
export type DeviceProfile = Readonly<{
  tier: QualityTier;
  targetFps: 30 | 60;
  maxPixelRatio: number;
  antialias: boolean;
  shadows: boolean;
  shadowMapSize: 256 | 512 | 1024;
  maxSubSteps: number;
}>;

export type DeviceHints = {
  deviceMemory?: number;
  hardwareConcurrency?: number;
  coarsePointer?: boolean;
  viewportPixels?: number;
  webgl2?: boolean;
};

export function clamp(value: number, min: number, max: number): number {
  if (!Number.isFinite(value)) return min;
  return value < min ? min : value > max ? max : value;
}

export function createDeviceProfile(hints: DeviceHints = {}): DeviceProfile {
  const memory = Number.isFinite(hints.deviceMemory) ? hints.deviceMemory! : 6;
  const cores = Number.isFinite(hints.hardwareConcurrency) ? hints.hardwareConcurrency! : 6;
  const coarse = hints.coarsePointer === true;
  const pixels = Number.isFinite(hints.viewportPixels) ? hints.viewportPixels! : 0;
  const unknownMemoryOnTouch = hints.deviceMemory === undefined && coarse;
  const weak = memory <= 4 || cores <= 4 || unknownMemoryOnTouch || (coarse && pixels > 2_500_000) || hints.webgl2 === false;
  const strong = memory >= 8 && cores >= 8 && !coarse;
  const tier: QualityTier = weak ? 0 : strong ? 2 : 1;
  return Object.freeze({
    tier,
    targetFps: tier === 0 ? 30 : 60,
    maxPixelRatio: tier === 0 ? 1 : tier === 1 ? 1.25 : 1.6,
    antialias: tier === 2,
    shadows: tier > 0,
    shadowMapSize: tier === 0 ? 256 : tier === 1 ? 512 : 1024,
    maxSubSteps: tier === 0 ? 3 : 4,
  });
}

/** Fixed-step clock with bounded catch-up and explicit backlog dropping. */
export class FixedStepClock {
  readonly stepSeconds: number;
  readonly maxFrameSeconds: number;
  readonly maxSubSteps: number;
  private lastMs: number | null = null;
  private accumulator = 0;
  private delta = 0;
  private paused = false;
  private totalSteps = 0;
  private dropped = 0;

  constructor(options: { stepSeconds?: number; maxFrameSeconds?: number; maxSubSteps?: number } = {}) {
    this.stepSeconds = options.stepSeconds ?? 1 / 60;
    this.maxFrameSeconds = options.maxFrameSeconds ?? 0.05;
    this.maxSubSteps = options.maxSubSteps ?? 4;
    if (!Number.isFinite(this.stepSeconds) || this.stepSeconds <= 0 ||
        !Number.isFinite(this.maxFrameSeconds) || this.maxFrameSeconds < this.stepSeconds ||
        !Number.isInteger(this.maxSubSteps) || this.maxSubSteps < 1 || this.maxSubSteps > 8) {
      throw new RangeError("INVALID_FIXED_STEP_CONFIGURATION");
    }
  }

  beginFrame(nowMs: number): number {
    if (!Number.isFinite(nowMs)) return 0;
    if (this.lastMs === null) {
      this.lastMs = nowMs;
      this.delta = 0;
      return 0;
    }
    const raw = Math.max(0, (nowMs - this.lastMs) / 1000);
    this.lastMs = nowMs;
    if (this.paused) {
      this.delta = 0;
      this.accumulator = 0;
      return 0;
    }
    this.delta = Math.min(raw, this.maxFrameSeconds);
    this.dropped += Math.max(0, raw - this.delta);
    this.accumulator += this.delta;
    return this.delta;
  }

  runFixed(update: (stepSeconds: number, tick: number) => void): number {
    if (this.paused) return 0;
    let steps = 0;
    while (this.accumulator + 1e-9 >= this.stepSeconds && steps < this.maxSubSteps) {
      update(this.stepSeconds, this.totalSteps);
      this.accumulator -= this.stepSeconds;
      if (this.accumulator < 0) this.accumulator = 0;
      this.totalSteps += 1;
      steps += 1;
    }
    if (this.accumulator >= this.stepSeconds) {
      const remainder = this.accumulator % this.stepSeconds;
      this.dropped += this.accumulator - remainder;
      this.accumulator = remainder;
    }
    return steps;
  }

  clearAccumulator(): void { this.accumulator = 0; }
  reset(nowMs?: number): void {
    this.lastMs = Number.isFinite(nowMs) ? nowMs! : null;
    this.accumulator = 0;
    this.delta = 0;
  }
  pause(): void { this.paused = true; this.accumulator = 0; }
  resume(nowMs?: number): void { this.paused = false; this.reset(nowMs); }
  get deltaSeconds(): number { return this.delta; }
  get alpha(): number { return this.accumulator / this.stepSeconds; }
  get tick(): number { return this.totalSteps; }
  get droppedSeconds(): number { return this.dropped; }
  get isPaused(): boolean { return this.paused; }
}

/** Idempotent owner for listeners, timers and GPU/resource cleanup callbacks. */
export class ResourceScope {
  private cleanups: Array<() => void> = [];
  private disposed = false;

  defer(cleanup: () => void): () => void {
    if (typeof cleanup !== "function") return () => undefined;
    if (this.disposed) {
      try { cleanup(); } catch { /* cleanup is best effort */ }
      return () => undefined;
    }
    let active = true;
    const once = () => {
      if (!active) return;
      active = false;
      try { cleanup(); } catch { /* cleanup is best effort */ }
    };
    this.cleanups.push(once);
    return once;
  }

  listen(target: EventTarget, type: string, listener: EventListener, options?: AddEventListenerOptions | boolean): () => void {
    target.addEventListener(type, listener, options);
    return this.defer(() => target.removeEventListener(type, listener, options));
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    for (let i = this.cleanups.length - 1; i >= 0; i--) this.cleanups[i]?.();
    this.cleanups.length = 0;
  }
  get isDisposed(): boolean { return this.disposed; }
  get size(): number { return this.cleanups.length; }
}

/** Hysteretic quality controller; it changes tiers only after sustained evidence. */
export class QualityGovernor {
  private readonly samples: Float32Array;
  private cursor = 0;
  private count = 0;
  private sum = 0;
  private slowWindows = 0;
  private fastWindows = 0;
  private sinceEvaluation = 0;
  private tier: QualityTier;
  private readonly downMs: number;
  private readonly upMs: number;
  private readonly allowUpgrade: boolean;

  constructor(initialTier: QualityTier, options: { sampleCount?: number; downMs?: number; upMs?: number; allowUpgrade?: boolean } = {}) {
    const requestedSamples = Number.isFinite(options.sampleCount) ? Math.floor(options.sampleCount!) : 45;
    const n = Math.max(12, Math.min(240, requestedSamples));
    this.samples = new Float32Array(n);
    this.tier = initialTier === 0 ? 0 : initialTier === 2 ? 2 : 1;
    this.downMs = Number.isFinite(options.downMs) && options.downMs! > 0 ? options.downMs! : 25;
    this.upMs = Number.isFinite(options.upMs) && options.upMs! > 0 ? Math.min(options.upMs!, this.downMs) : 17;
    this.allowUpgrade = options.allowUpgrade === true;
  }

  sample(frameWorkMs: number): QualityTier {
    if (!Number.isFinite(frameWorkMs) || frameWorkMs < 0 || frameWorkMs > 1000) return this.tier;
    if (this.count === this.samples.length) this.sum -= this.samples[this.cursor]!;
    else this.count += 1;
    this.samples[this.cursor] = frameWorkMs;
    this.sum += frameWorkMs;
    this.cursor = (this.cursor + 1) % this.samples.length;
    if (this.count < this.samples.length) return this.tier;
    this.sinceEvaluation += 1;
    if (this.sinceEvaluation < this.samples.length) return this.tier;
    this.sinceEvaluation = 0;
    const avg = this.sum / this.count;
    if (avg > this.downMs) { this.slowWindows += 1; this.fastWindows = 0; }
    else if (avg < this.upMs) { this.fastWindows += 1; this.slowWindows = 0; }
    else { this.slowWindows = 0; this.fastWindows = 0; }
    if (this.slowWindows >= 2 && this.tier > 0) { this.tier = (this.tier - 1) as QualityTier; this.slowWindows = 0; }
    if (this.allowUpgrade && this.fastWindows >= 5 && this.tier < 2) { this.tier = (this.tier + 1) as QualityTier; this.fastWindows = 0; }
    return this.tier;
  }

  get currentTier(): QualityTier { return this.tier; }
  get averageMs(): number { return this.count ? this.sum / this.count : 0; }
}

/** Small deterministic RNG for procedural content and reproducible test cases. */
export class SeededRandom {
  private state: number;
  constructor(seed: number) {
    if (!Number.isSafeInteger(seed)) throw new RangeError("INVALID_RANDOM_SEED");
    this.state = seed >>> 0 || 0x6d2b79f5;
  }
  nextUint(): number {
    let x = this.state;
    x ^= x << 13; x ^= x >>> 17; x ^= x << 5;
    this.state = x >>> 0;
    return this.state;
  }
  next(): number { return this.nextUint() / 0x100000000; }
  snapshot(): number { return this.state >>> 0; }
  restore(state: number): boolean {
    if (!Number.isSafeInteger(state) || state < 0 || state > 0xffffffff) return false;
    this.state = state >>> 0 || 0x6d2b79f5;
    return true;
  }
}

export type Transition<C> = {
  from: string;
  to: string;
  when: (context: C) => boolean;
  onEnter?: (context: C) => void;
};

/** Table-driven FSM; transition order is stable and explicit. */
export class StateMachine<C> {
  private readonly valid: Set<string>;
  private readonly transitions: readonly Transition<C>[];
  state: string;
  previous: string;
  elapsed = 0;
  transitionCount = 0;

  constructor(initial: string, states: readonly string[], transitions: readonly Transition<C>[]) {
    this.valid = new Set(states);
    if (!this.valid.has(initial)) throw new TypeError("FSM_INITIAL_STATE_MISSING");
    for (const t of transitions) {
      if (!this.valid.has(t.from) || !this.valid.has(t.to) || typeof t.when !== "function") throw new TypeError("FSM_INVALID_TRANSITION");
    }
    this.state = initial;
    this.previous = initial;
    this.transitions = transitions.slice();
  }

  update(context: C, dt: number): boolean {
    if (!Number.isFinite(dt) || dt < 0) return false;
    for (const t of this.transitions) {
      if (t.from !== this.state) continue;
      let match = false;
      try { match = t.when(context) === true; } catch { match = false; }
      if (!match) continue;
      this.previous = this.state;
      this.state = t.to;
      this.elapsed = 0;
      this.transitionCount += 1;
      try { t.onEnter?.(context); } catch { /* state transition remains committed */ }
      return true;
    }
    this.elapsed += dt;
    return false;
  }

  force(next: string): boolean {
    if (!this.valid.has(next)) return false;
    if (next !== this.state) {
      this.previous = this.state;
      this.state = next;
      this.elapsed = 0;
      this.transitionCount += 1;
    }
    return true;
  }
}

export type AssetManifestEntry = { id: string; path: string; type: string; bytes: number };
export function validateAssetManifest(
  assets: readonly AssetManifestEntry[],
  options: { maxAssets?: number; maxBytes?: number; maxPathLength?: number; allowedTypes?: readonly string[] } = {},
): { ok: true; totalBytes: number } | { ok: false; error: string } {
  const maxAssets = options.maxAssets ?? 4096;
  const maxBytes = options.maxBytes ?? 128 * 1024 * 1024;
  const maxPathLength = options.maxPathLength ?? 240;
  const allowed = new Set(options.allowedTypes ?? ["image", "audio", "json", "binary", "model", "font", "video"]);
  if (!Number.isSafeInteger(maxAssets) || maxAssets < 0 || !Number.isSafeInteger(maxBytes) || maxBytes < 0 ||
      !Number.isSafeInteger(maxPathLength) || maxPathLength < 1) return { ok: false, error: "INVALID_ASSET_LIMITS" };
  if (!Array.isArray(assets) || assets.length > maxAssets) return { ok: false, error: "INVALID_ASSET_LIST" };
  const ids = new Set<string>();
  let total = 0;
  for (let i = 0; i < assets.length; i++) {
    const a = assets[i];
    let decodedPath = "";
    try { decodedPath = typeof a?.path === "string" ? decodeURIComponent(a.path) : ""; } catch { return { ok: false, error: `INVALID_ASSET_${i}` }; }
    if (!a || typeof a.id !== "string" || !/^[a-zA-Z0-9_-]{1,96}$/.test(a.id) || ids.has(a.id) || typeof a.path !== "string" ||
        !a.path || a.path.length > maxPathLength || decodedPath.length > maxPathLength || a.path.startsWith("/") || /^[a-zA-Z]:/.test(a.path) ||
        a.path.includes("\\") || decodedPath.includes("\\") || /[\0-\x1f\x7f]/.test(decodedPath) ||
        /^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(decodedPath) || decodedPath.split("/").some((part: string) => part === ".." || part === ".") ||
        !allowed.has(a.type) || !Number.isSafeInteger(a.bytes) || a.bytes < 0) return { ok: false, error: `INVALID_ASSET_${i}` };
    ids.add(a.id);
    total += a.bytes;
    if (!Number.isSafeInteger(total) || total > maxBytes) return { ok: false, error: "ASSET_BUDGET_EXCEEDED" };
  }
  return { ok: true, totalBytes: total };
}

const MAX_STORAGE_KEY_LENGTH = 128;
const MAX_STORAGE_PAYLOAD_LENGTH = 1_048_576;

export function readJsonStorage<T>(storage: Storage | null, key: string, fallback: T, validate: (value: unknown) => value is T): T {
  if (!storage || typeof key !== "string" || !key || key.length > MAX_STORAGE_KEY_LENGTH || typeof validate !== "function") return fallback;
  try {
    const raw = storage.getItem(key);
    if (!raw || raw.length > MAX_STORAGE_PAYLOAD_LENGTH) return fallback;
    const value: unknown = JSON.parse(raw);
    return validate(value) ? value : fallback;
  } catch { return fallback; }
}

export function writeJsonStorage(storage: Storage | null, key: string, value: unknown): boolean {
  if (!storage || typeof key !== "string" || !key || key.length > MAX_STORAGE_KEY_LENGTH) return false;
  try {
    const serialized = JSON.stringify(value);
    if (typeof serialized !== "string" || serialized.length > MAX_STORAGE_PAYLOAD_LENGTH) return false;
    storage.setItem(key, serialized);
    return true;
  } catch { return false; }
}
