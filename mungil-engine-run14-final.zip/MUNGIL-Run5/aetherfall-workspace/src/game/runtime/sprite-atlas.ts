/** Deterministic, bounded shelf atlas packer. Pixel composition is a separate caller-owned step. */
export type SpriteSource = Readonly<{ id: string; width: number; height: number }>;
export type SpriteAtlasFrame = Readonly<{ id: string; page: number; x: number; y: number; width: number; height: number }>;
export type SpriteAtlasPage = Readonly<{ index: number; width: number; height: number; frameIds: readonly string[] }>;
export type SpriteAtlas = Readonly<{ schemaVersion: 1; padding: number; pages: readonly SpriteAtlasPage[]; frames: readonly SpriteAtlasFrame[] }>;
export type SpriteAtlasOptions = Readonly<{ maxSize?: number; maxPages?: number; padding?: number; maxTextureBytes?: number }>;
export type SpriteAtlasResult = Readonly<{ ok: true; atlas: SpriteAtlas }> | Readonly<{ ok: false; error: string }>;

const ID = /^[A-Za-z0-9_-]{1,80}$/;
const MAX_SOURCES = 8192;
const MAX_ATLAS_SIZE = 4096;

/** Uses stable sort and first-fit shelves; no rotation, no hidden allocations per pixel. */
export function buildSpriteAtlas(sources: readonly SpriteSource[], options: SpriteAtlasOptions = {}): SpriteAtlasResult {
  const maxSize = options.maxSize ?? 1024;
  const maxPages = options.maxPages ?? 16;
  const padding = options.padding ?? 2;
  const maxTextureBytes = options.maxTextureBytes ?? 8 * 1024 * 1024;
  if (!Array.isArray(sources) || sources.length > MAX_SOURCES) return { ok: false, error: "ATLAS_SOURCE_LIMIT" };
  if (!Number.isInteger(maxSize) || maxSize < 32 || maxSize > MAX_ATLAS_SIZE || !Number.isInteger(maxPages) || maxPages < 1 || maxPages > 64 || !Number.isInteger(padding) || padding < 0 || padding > 16 || !Number.isSafeInteger(maxTextureBytes) || maxTextureBytes < 4 || maxTextureBytes > 64 * 1024 * 1024) return { ok: false, error: "INVALID_ATLAS_OPTIONS" };
  const seen = new Set<string>();
  const items: Array<SpriteSource & { paddedWidth: number; paddedHeight: number }> = [];
  for (const source of sources) {
    if (!source || typeof source.id !== "string" || !ID.test(source.id) || seen.has(source.id) || !Number.isSafeInteger(source.width) || !Number.isSafeInteger(source.height) || source.width < 1 || source.height < 1) return { ok: false, error: "INVALID_ATLAS_SOURCE" };
    seen.add(source.id);
    const paddedWidth = source.width + padding * 2;
    const paddedHeight = source.height + padding * 2;
    if (!Number.isSafeInteger(paddedWidth) || !Number.isSafeInteger(paddedHeight) || paddedWidth > maxSize || paddedHeight > maxSize) return { ok: false, error: "ATLAS_FRAME_TOO_LARGE" };
    items.push({ ...source, paddedWidth, paddedHeight });
  }
  items.sort((a, b) => Math.max(b.paddedWidth, b.paddedHeight) - Math.max(a.paddedWidth, a.paddedHeight) || b.paddedWidth * b.paddedHeight - a.paddedWidth * a.paddedHeight || a.id.localeCompare(b.id));
  type Shelf = { y: number; height: number; x: number };
  type PageState = { shelves: Shelf[]; usedWidth: number; usedHeight: number; ids: string[] };
  const pages: PageState[] = [];
  const frames: SpriteAtlasFrame[] = [];
  for (const item of items) {
    let placed = false;
    for (let pageIndex = 0; pageIndex < pages.length && !placed; pageIndex++) {
      const page = pages[pageIndex]!;
      for (const shelf of page.shelves) {
        if (item.paddedHeight <= shelf.height && shelf.x + item.paddedWidth <= maxSize) {
          frames.push({ id: item.id, page: pageIndex, x: shelf.x + padding, y: shelf.y + padding, width: item.width, height: item.height });
          shelf.x += item.paddedWidth;
          page.usedWidth = Math.max(page.usedWidth, shelf.x);
          page.usedHeight = Math.max(page.usedHeight, shelf.y + shelf.height);
          page.ids.push(item.id); placed = true; break;
        }
      }
      if (placed) break;
      const y = page.usedHeight;
      if (y + item.paddedHeight <= maxSize) {
        const shelf: Shelf = { y, height: item.paddedHeight, x: item.paddedWidth };
        page.shelves.push(shelf);
        frames.push({ id: item.id, page: pageIndex, x: padding, y: y + padding, width: item.width, height: item.height });
        page.usedWidth = Math.max(page.usedWidth, item.paddedWidth);
        page.usedHeight = y + item.paddedHeight;
        page.ids.push(item.id); placed = true;
      }
    }
    if (!placed) {
      if (pages.length >= maxPages) return { ok: false, error: "ATLAS_PAGE_LIMIT" };
      const page: PageState = { shelves: [{ y: 0, height: item.paddedHeight, x: item.paddedWidth }], usedWidth: item.paddedWidth, usedHeight: item.paddedHeight, ids: [item.id] };
      const pageIndex = pages.push(page) - 1;
      frames.push({ id: item.id, page: pageIndex, x: padding, y: padding, width: item.width, height: item.height });
    }
  }
  const estimatedBytes = pages.reduce((sum, page) => sum + page.usedWidth * page.usedHeight * 4, 0);
  if (!Number.isSafeInteger(estimatedBytes) || estimatedBytes > maxTextureBytes) return { ok: false, error: "ATLAS_MEMORY_BUDGET_EXCEEDED" };
  frames.sort((a, b) => a.id.localeCompare(b.id));
  const frozenPages = pages.map((page, index) => Object.freeze({ index, width: Math.max(1, page.usedWidth), height: Math.max(1, page.usedHeight), frameIds: Object.freeze(page.ids.slice().sort()) }));
  return { ok: true, atlas: Object.freeze({ schemaVersion: 1, padding, pages: Object.freeze(frozenPages), frames: Object.freeze(frames) }) };
}

/** Draws a packed page into a caller-provided canvas; source ownership remains with the caller. */
export function composeSpriteAtlasPage(atlas: SpriteAtlas, pageIndex: number, sources: ReadonlyMap<string, CanvasImageSource>, createCanvas: (width: number, height: number) => HTMLCanvasElement = (width, height) => {
  if (typeof document === "undefined") throw new Error("CANVAS_FACTORY_REQUIRED");
  const canvas = document.createElement("canvas"); canvas.width = width; canvas.height = height; return canvas;
}): HTMLCanvasElement | null {
  const page = atlas.pages[pageIndex];
  if (!page || !sources || typeof sources.get !== "function") return null;
  const canvas = createCanvas(page.width, page.height);
  if (canvas.width !== page.width || canvas.height !== page.height) throw new RangeError("ATLAS_CANVAS_DIMENSION_MISMATCH");
  const context = canvas.getContext("2d", { alpha: true });
  if (!context) throw new Error("ATLAS_CANVAS_CONTEXT_UNAVAILABLE");
  context.clearRect(0, 0, page.width, page.height);
  for (const frame of atlas.frames) {
    if (frame.page !== pageIndex) continue;
    const source = sources.get(frame.id);
    if (!source) throw new Error("ATLAS_SOURCE_MISSING:" + frame.id);
    context.drawImage(source, frame.x, frame.y, frame.width, frame.height);
    const pad = atlas.padding;
    if (pad > 0) {
      // Edge extrusion protects adjacent atlas frames from linear-filter bleeding.
      context.drawImage(source, 0, 0, 1, frame.height, frame.x-pad, frame.y, pad, frame.height);
      context.drawImage(source, frame.width-1, 0, 1, frame.height, frame.x+frame.width, frame.y, pad, frame.height);
      context.drawImage(source, 0, 0, frame.width, 1, frame.x, frame.y-pad, frame.width, pad);
      context.drawImage(source, 0, frame.height-1, frame.width, 1, frame.x, frame.y+frame.height, frame.width, pad);
      context.drawImage(source, 0, 0, 1, 1, frame.x-pad, frame.y-pad, pad, pad);
      context.drawImage(source, frame.width-1, 0, 1, 1, frame.x+frame.width, frame.y-pad, pad, pad);
      context.drawImage(source, 0, frame.height-1, 1, 1, frame.x-pad, frame.y+frame.height, pad, pad);
      context.drawImage(source, frame.width-1, frame.height-1, 1, 1, frame.x+frame.width, frame.y+frame.height, pad, pad);
    }
  }
  return canvas;
}
