import { FixedStepClock, ResourceScope, type DeviceProfile, type QualityTier } from "./core.ts";
import type { RuntimeSystem } from "./contracts.ts";

export type KernelState = "created" | "running" | "paused" | "faulted" | "disposed";
export type KernelOptions<C> = {
  context: C;
  device: DeviceProfile;
  stepSeconds?: number;
  maxFrameSeconds?: number;
  maxSubSteps?: number;
  onError?: (systemId: string, error: unknown) => void;
};

/** Deterministic, bounded system orchestrator. Registration is setup-time only. */
export class RuntimeKernel<C extends { qualityTier: QualityTier; tick: number; deltaSeconds: number; interpolationAlpha: number }> {
  private readonly context: C;
  private readonly clock: FixedStepClock;
  private readonly systems: RuntimeSystem<C>[] = [];
  private readonly resources = new ResourceScope();
  private readonly onError?: (systemId: string, error: unknown) => void;
  private state: KernelState = "created";
  private stepping = false;
  private initializedCount = 0;
  private frameCount = 0;
  private fixedCount = 0;
  private lastFault = "";

  constructor(options: KernelOptions<C>) {
    this.context = options.context;
    this.context.qualityTier = options.device.tier;
    this.clock = new FixedStepClock({
      stepSeconds: options.stepSeconds ?? 1 / 60,
      maxFrameSeconds: options.maxFrameSeconds ?? 0.05,
      maxSubSteps: options.maxSubSteps ?? options.device.maxSubSteps,
    });
    this.onError = options.onError;
  }

  register(system: RuntimeSystem<C>): boolean {
    if (this.state !== "created" || this.stepping || this.systems.length >= 64 || !system ||
        typeof system.id !== "string" || !system.id || this.systems.some((item) => item.id === system.id)) return false;
    this.systems.push(system);
    return true;
  }

  start(nowMs = 0): boolean {
    if (this.state !== "created") return false;
    this.systems.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
    this.clock.reset(nowMs);
    this.state = "running";
    for (const system of this.systems) {
      this.initializedCount += 1;
      try { system.init?.(this.context); }
      catch (error) { this.fail(system.id, error); return false; }
    }
    return true;
  }

  frame(nowMs: number): boolean {
    if (this.state !== "running" || this.stepping) return false;
    this.stepping = true;
    try {
      const dt = this.clock.beginFrame(nowMs);
      this.context.deltaSeconds = dt;
      this.clock.runFixed((stepSeconds, tick) => {
        this.context.tick = tick;
        for (const system of this.systems) {
          try { system.fixedUpdate?.(this.context, stepSeconds, tick); }
          catch (error) { this.fail(system.id, error); throw error; }
        }
        this.fixedCount += 1;
      });
      this.context.interpolationAlpha = this.clock.alpha;
      for (const system of this.systems) {
        try { system.update?.(this.context, dt); }
        catch (error) { this.fail(system.id, error); return false; }
      }
      for (const system of this.systems) {
        try { system.render?.(this.context, this.context.interpolationAlpha); }
        catch (error) { this.fail(system.id, error); return false; }
      }
      this.frameCount += 1;
      return true;
    } catch (error) {
      if ((this.state as KernelState) !== "faulted") this.fail("frame", error);
      return false;
    } finally {
      this.stepping = false;
    }
  }

  pause(): boolean {
    if (this.state !== "running") return false;
    this.clock.pause();
    this.state = "paused";
    for (const system of this.systems) {
      try { system.onSuspend?.(this.context); } catch (error) { this.notifyError(system.id, error); }
    }
    return true;
  }

  resume(nowMs = 0): boolean {
    if (this.state !== "paused") return false;
    this.clock.resume(nowMs);
    this.state = "running";
    for (const system of this.systems) {
      try { system.onResume?.(this.context); } catch (error) { this.notifyError(system.id, error); }
    }
    return true;
  }

  own(cleanup: () => void): () => void { return this.resources.defer(cleanup); }

  dispose(): void {
    if (this.state === "disposed") return;
    this.clock.pause();
    this.resources.dispose();
    for (let i = this.initializedCount - 1; i >= 0; i--) {
      const system = this.systems[i];
      try { system?.dispose?.(); } catch (error) { if (system) this.notifyError(system.id, error); }
    }
    this.systems.length = 0;
    this.initializedCount = 0;
    this.state = "disposed";
  }

  private notifyError(systemId: string, error: unknown): void {
    try { this.onError?.(systemId, error); } catch { /* error reporting must not recurse */ }
  }

  private fail(systemId: string, error: unknown): void {
    this.state = "faulted";
    this.lastFault = systemId;
    this.notifyError(systemId, error);
    this.disposeFaulted();
  }

  private disposeFaulted(): void {
    this.clock.pause();
    this.resources.dispose();
    for (let i = this.initializedCount - 1; i >= 0; i--) {
      const system = this.systems[i];
      try { system?.dispose?.(); } catch (error) { if (system) this.notifyError(system.id, error); }
    }
    this.systems.length = 0;
    this.initializedCount = 0;
    this.state = "faulted";
  }

  get status(): KernelState { return this.state; }
  get frames(): number { return this.frameCount; }
  get fixedTicks(): number { return this.fixedCount; }
  get droppedSeconds(): number { return this.clock.droppedSeconds; }
  get lastFaultSystem(): string { return this.lastFault; }
  get systemCount(): number { return this.systems.length; }
}
