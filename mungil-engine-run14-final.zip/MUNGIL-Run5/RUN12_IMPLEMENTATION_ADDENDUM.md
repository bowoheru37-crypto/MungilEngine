# MUNGIL Run 12 — Asset Vault & Offline Project Intake

## Scope
Run 12 continues Run 11. It adds bounded offline blob persistence to the existing asset-intake path without replacing the runtime kernel, project document, scene editor, renderer adapters, generator planner, or Android WebView wrapper.

## Implemented
- New `asset-vault.ts` module backed by IndexedDB, with no network requests or implicit uploads.
- Tiered local limits: Tier 0 = 24 MiB / 8 MiB per asset / 128 entries; Tier 1 = 48 MiB / 16 MiB / 256; Tier 2 = 96 MiB / 32 MiB / 512.
- Validates asset identifiers, safe project paths, SHA-256 metadata, blob length, and single-asset limit before persistence.
- LRU eviction is deterministic and never evicts pinned entries or the asset being replaced.
- Refuses a write when the browser's estimated remaining origin quota is below the incoming blob size; IndexedDB quota errors are caught and surfaced.
- Serializes writes through a promise queue to prevent concurrent put operations from racing the local capacity planner.
- Supports get, list metadata, remove, pin/unpin, summary, clear-unpinned, and explicit persistent-storage request.
- Studio's asset intake action now performs signature preflight and stores each accepted original file in the Tier 0 Vault. The UI reports saved/not-saved per asset and current vault usage.
- Added Vault refresh, per-asset pin/unpin, per-asset delete, clear-unpinned with confirmation, and a user-initiated persistent-storage request button.
- Android WebView Studio asset is updated from the same standalone Studio source.

## Validation
- Runtime tests: 67/67 passed (63 prior + 4 vault budget/eviction tests).
- TypeScript strict runtime index check: passed.
- Browser runtime bundle: 22 modules, 153,797 bytes.
- Browser runtime smoke: passed.
- Studio inline JavaScript syntax: passed.
- ZIP integrity: passed for all four Run 12 archives.
- Research notes added for IndexedDB/storage quotas, Khronos glTF Validator, Android Go and WebView memory.
- Full browser IndexedDB persistence test and physical Android test are not yet claimed in this increment.

## Boundaries and residual risks
- IndexedDB is browser-managed best-effort storage by default. The browser may evict origin data under storage pressure or the user may clear site data. The app exposes a persistent-storage request but does not call it automatically; it must be invoked from an explicit user action.
- The current Tier 0 preflight is intentionally smaller than Run 11's generic ceiling: 8 MiB/file, 24 MiB/import batch, 2048 px image dimensions.
- The Vault stores original blobs and metadata only. It does not decode media, transcode textures/audio, run full glTF validation, load assets into the renderer, or package a playable game.
- The browser `storage.estimate()` API is an estimate, not a reservation. A later IndexedDB write can still fail with quota exceeded; that failure is surfaced.
- No malware scanner, archive extractor, remote upload, CDN, LLM provider, social publishing, or cloud sync is included.
- No APK/AAB release build or itel A70 benchmark was performed.

## Next
1. Add full glTF validation in CI using a pinned Khronos validator package/release.
2. Add bounded image/audio decode adapters and deterministic disposal.
3. Bind Vault image assets to Canvas2D preview first; then sprite animation timeline and WebGL2 texture adapter.
4. Export a playable 2D/2.5D HTML5 project bundle with asset manifest and integrity hashes.
