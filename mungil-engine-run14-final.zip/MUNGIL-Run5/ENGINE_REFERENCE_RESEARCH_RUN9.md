# MUNGIL Run 9 — Reference Research

## Device baseline
- [itel A70 official Indonesia specifications](https://www.itel-life.com/id/products/phone/a-series/a70/spec): T603 octa-core, Android 13 Go, 720×1612, 5000mAh, extended RAM options. Use official physical/extended RAM distinction when setting budgets.
- [itel A70 device profile (secondary)](https://www.deviceinfo.app/devices/itel/a70/): reports Unisoc T603, PowerVR GE8322 and 3GB/4GB RAM variants. Treat GPU identification as secondary evidence; verify with the device itself.

## Android performance and build
- [Android game optimization](https://developer.android.com/games/optimize): lazy loading, thread separation, frame pacing, thermal stress response, memory state and touch-to-display latency.
- [Android CPU/GPU optimization tips](https://developer.android.com/games/optimize/optimization-tips): texture formats, ASTC, geometry complexity, LOD, culling and profiling.
- [Android slow sessions / frame pacing](https://developer.android.com/games/optimize/vitals/slow-session): Swappy/frame pacing and diagnosing slow frames.
- [Android technical quality](https://developer.android.com/quality/technical): 30 FPS as a reasonable baseline for most games; higher rates trade battery, temperature and fidelity.
- [Android Gradle Plugin compatibility table](https://developer.android.com/build/releases/about-agp): API 36 support minimums; Run 9 uses AGP 8.13.0 / Gradle 8.13 / JDK 17 as a conservative API 36 build configuration.

## Rendering and WebView
- [MDN WebGL best practices](https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API/WebGL_best_practices): conservative VRAM budgets, explicit resource deletion, context-loss handling, compressed texture formats and mipmap tradeoffs.
- [MDN WebGL context lost detection](https://developer.mozilla.org/en-US/docs/Web/API/WebGLRenderingContext/isContextLost): renderer lifecycle must tolerate context loss and restoration.
- [Chromium Android WebView compatibility](https://chromium.googlesource.com/chromium/src/+/HEAD/android_webview/docs/web-platform-compatibility.md): WebView updates independently over time; minSdk does not guarantee a modern web API surface on every installed WebView.
- [Chrome for Developers — WebView overview](https://developer.chrome.com/docs/webview): WebView/Chrome relationship and API differences.

## Lightweight engine references
- [Litecanvas](https://github.com/litecanvas/game-engine): compact dependency-free Canvas2D game engine; repository labels itself alpha, so it is a pattern reference, not a production dependency.
- [LittleJS](https://github.com/KilledByAPixel/LittleJS): small engine architecture and hybrid renderer ideas; inspect license and current commit before any adoption.
- [Phaser](https://github.com/phaserjs/phaser): mature 2D browser engine patterns for input, scenes, assets and WebGL/Canvas rendering.

## Adopted engineering principles
1. Start at 30 FPS for low-end Android; do not force 60 FPS when thermal and GPU budgets cannot sustain it.
2. Use lazy loading and bounded caches; release GPU handles explicitly.
3. Keep text/UI at readable device resolution while lowering game-world render cost.
4. Use atlas/compressed textures and choose formats based on supported GPU extensions.
5. Treat WebView version as a runtime capability, not an Android API-level guarantee.
6. Prefer a small number of workers only after measuring; a 128-thread target is not a fit for an 8-core low-end handset.
7. Keep the Canvas2D fallback explicit: it is for 2D/2.5D, not perspective 3D.

No GitHub repositories were cloned or merged in Run 9. These references inform design choices only; licenses and exact upstream revisions must be checked before code adoption.
