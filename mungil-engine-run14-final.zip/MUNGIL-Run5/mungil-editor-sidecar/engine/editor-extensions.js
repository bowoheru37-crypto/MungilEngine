/* MUNGIL editor extension primitives. Additive adapters for existing flat entity records. */
'use strict';

const PHYSICS_PRESETS = Object.freeze({
  BOUNCY: Object.freeze({ mass: 1, gravityScale: 1, restitution: 0.92, friction: 0.18, linearDamping: 0.02, angularDamping: 0.04, isSensor: false }),
  HEAVY: Object.freeze({ mass: 8, gravityScale: 1.25, restitution: 0.04, friction: 0.86, linearDamping: 0.12, angularDamping: 0.2, isSensor: false }),
  GHOST: Object.freeze({ mass: 1, gravityScale: 0, restitution: 0, friction: 0, linearDamping: 0, angularDamping: 0, isSensor: true }),
  SLIPPERY: Object.freeze({ mass: 1, gravityScale: 1, restitution: 0.05, friction: 0.015, linearDamping: 0.005, angularDamping: 0.02, isSensor: false })
});
const MAX_ENTITIES = 128;
const MAX_HIERARCHY_DEPTH = 32;
const MAX_OFFSET = 10000;
const finite = (v, fallback = 0) => Number.isFinite(v) ? v : fallback;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

function readTransform(entity) {
  if (!entity || typeof entity !== 'object') return null;
  if (entity.transform && typeof entity.transform === 'object') {
    const t = entity.transform;
    return {
      x: finite(t.x), y: finite(t.y), rotation: finite(t.rotation),
      scaleX: clamp(finite(t.scaleX, 1), 0.01, 100),
      scaleY: clamp(finite(t.scaleY, 1), 0.01, 100)
    };
  }
  return {
    x: finite(entity.x), y: finite(entity.y), rotation: finite(entity.rot),
    scaleX: clamp(finite(entity.scale, 100) / 100, 0.01, 100),
    scaleY: clamp(finite(entity.scale, 100) / 100, 0.01, 100)
  };
}

function writeTransform(entity, transform) {
  if (!entity || !transform) return false;
  if (entity.transform && typeof entity.transform === 'object') Object.assign(entity.transform, transform);
  else {
    entity.x = transform.x; entity.y = transform.y; entity.rot = transform.rotation;
    entity.scale = clamp((transform.scaleX + transform.scaleY) * 50, 1, 10000);
  }
  return true;
}

function applyPhysicsPreset(entity, presetName) {
  if (!entity || typeof entity !== 'object') return { ok: false, error: 'ENTITY_MISSING' };
  const name = String(presetName || '').toUpperCase();
  const preset = PHYSICS_PRESETS[name];
  if (!preset) return { ok: false, error: 'UNKNOWN_PRESET' };
  if (!entity.physics || typeof entity.physics !== 'object' || Array.isArray(entity.physics)) {
    entity.mass = preset.mass;
    entity.gravityScale = preset.gravityScale;
    entity.restitution = preset.restitution * 100;
    entity.friction = preset.friction * 100;
    entity.linearDamping = preset.linearDamping;
    entity.angularDamping = preset.angularDamping;
    entity.isSensor = preset.isSensor;
    entity.physicsPreset = name;
  } else {
    Object.assign(entity.physics, preset);
    entity.physics.preset = name;
  }
  return { ok: true, preset: name };
}

function normalizeEntity(entity) {
  if (!entity || typeof entity.id !== 'string' || !entity.id.trim()) throw new TypeError('ENTITY_REQUIRES_STABLE_ID');
  if (entity.parentId === undefined) entity.parentId = null;
  if (!Array.isArray(entity.children)) entity.children = [];
  if (!entity.transform && !Number.isFinite(entity.x)) {
    entity.x = 0; entity.y = 0; entity.rot = 0; entity.scale = 100;
  }
  if (entity.transform) writeTransform(entity, readTransform(entity));
  return entity;
}

function groupEntities(entities, selectedIds, containerId, name = 'Container') {
  if (!Array.isArray(entities) || !Array.isArray(selectedIds) || selectedIds.length < 2) return { ok: false, error: 'SELECT_AT_LEAST_TWO' };
  if (entities.length >= MAX_ENTITIES) return { ok: false, error: 'ENTITY_CAP_REACHED' };
  if (typeof containerId !== 'string' || !/^[a-zA-Z0-9_-]{1,96}$/.test(containerId)) return { ok: false, error: 'INVALID_CONTAINER_ID' };
  if (entities.some((e) => e && e.id === containerId)) return { ok: false, error: 'DUPLICATE_CONTAINER_ID' };
  const ids = new Set(selectedIds);
  if (ids.size !== selectedIds.length || selectedIds.some((id) => typeof id !== 'string' || !id)) return { ok: false, error: 'INVALID_SELECTION' };
  const entityIds = new Set();
  for (const entity of entities) {
    if (!entity || typeof entity.id !== 'string' || entityIds.has(entity.id)) return { ok: false, error: 'INVALID_ENTITY_REGISTRY' };
    entityIds.add(entity.id);
  }
  const selected = entities.filter((entity) => ids.has(entity.id));
  if (selected.length !== selectedIds.length) return { ok: false, error: 'INVALID_SELECTION' };
  if (selected.some((entity) => entity.parentId)) return { ok: false, error: 'NESTED_GROUPING_NOT_SUPPORTED_IN_V1' };
  const transforms = selected.map(readTransform);
  if (transforms.some((t) => !t || ![t.x, t.y, t.rotation, t.scaleX, t.scaleY].every(Number.isFinite))) return { ok: false, error: 'INVALID_TRANSFORM' };
  const centerX = transforms.reduce((sum, t) => sum + t.x, 0) / transforms.length;
  const centerY = transforms.reduce((sum, t) => sum + t.y, 0) / transforms.length;
  const container = normalizeEntity({
    id: containerId, name: String(name || 'Container').slice(0, 80), type: 'Container', emoji: '📦',
    parentId: null, visible: true, locked: false, x: centerX, y: centerY, rot: 0, scale: 100,
    depth: 0, opacity: 100, comps: ['Transform'], children: selected.map((entity) => entity.id)
  });
  for (let i = 0; i < selected.length; i++) {
    const entity = normalizeEntity(selected[i]);
    const transform = transforms[i];
    entity.parentId = containerId;
    writeTransform(entity, { ...transform, x: transform.x - centerX, y: transform.y - centerY });
  }
  entities.push(container);
  return { ok: true, container, grouped: selected.length };
}

function worldTransform(entity, byId, depth = 0, visited = new Set()) {
  if (!entity || depth > MAX_HIERARCHY_DEPTH || visited.has(entity.id)) return null;
  const local = readTransform(entity);
  if (!local) return null;
  if (!entity.parentId) return local;
  if (!byId || typeof byId.get !== 'function') return null;
  visited.add(entity.id);
  const parent = byId.get(entity.parentId);
  const parentWorld = worldTransform(parent, byId, depth + 1, visited);
  visited.delete(entity.id);
  if (!parentWorld) return null;
  const cos = Math.cos(parentWorld.rotation);
  const sin = Math.sin(parentWorld.rotation);
  const localX = local.x * parentWorld.scaleX;
  const localY = local.y * parentWorld.scaleY;
  const result = {
    x: parentWorld.x + localX * cos - localY * sin,
    y: parentWorld.y + localX * sin + localY * cos,
    rotation: parentWorld.rotation + local.rotation,
    scaleX: parentWorld.scaleX * local.scaleX,
    scaleY: parentWorld.scaleY * local.scaleY
  };
  return [result.x, result.y, result.rotation, result.scaleX, result.scaleY].every(Number.isFinite) ? result : null;
}

function setContainerTransform(entities, containerId, patch) {
  if (!Array.isArray(entities) || !patch || typeof patch !== 'object' || Array.isArray(patch)) return { ok: false, error: 'INVALID_PATCH' };
  const container = entities.find((entity) => entity && entity.id === containerId && entity.type === 'Container');
  if (!container) return { ok: false, error: 'CONTAINER_NOT_FOUND' };
  const transform = readTransform(container);
  for (const key of ['x', 'y', 'rotation', 'scaleX', 'scaleY']) {
    if (patch[key] !== undefined && !Number.isFinite(patch[key])) return { ok: false, error: 'NON_FINITE_TRANSFORM' };
  }
  if (patch.x !== undefined) transform.x = clamp(patch.x, -1e7, 1e7);
  if (patch.y !== undefined) transform.y = clamp(patch.y, -1e7, 1e7);
  if (patch.rotation !== undefined) transform.rotation = clamp(patch.rotation, -1e6, 1e6);
  if (container.transform && typeof container.transform === 'object') {
    if (patch.scaleX !== undefined) transform.scaleX = clamp(patch.scaleX, 0.01, 100);
    if (patch.scaleY !== undefined) transform.scaleY = clamp(patch.scaleY, 0.01, 100);
  } else if (patch.scaleX !== undefined || patch.scaleY !== undefined) {
    const sx = patch.scaleX === undefined ? patch.scaleY : patch.scaleX;
    const sy = patch.scaleY === undefined ? patch.scaleX : patch.scaleY;
    if (Math.abs(sx - sy) > 1e-8) return { ok: false, error: 'NON_UNIFORM_SCALE_UNSUPPORTED_BY_MUNGIL_ENTITY_SCHEMA' };
    transform.scaleX = transform.scaleY = clamp(sx, 0.01, 100);
  }
  writeTransform(container, transform);
  return { ok: true, container };
}

function setCollisionShape(entity, shape) {
  if (!entity || typeof entity !== 'object') return { ok: false, error: 'ENTITY_MISSING' };
  if (!shape || typeof shape !== 'object' || !['AABB', 'CIRCLE'].includes(shape.type)) return { ok: false, error: 'INVALID_SHAPE_TYPE' };
  const offsetX = shape.offsetX === undefined ? 0 : shape.offsetX;
  const offsetY = shape.offsetY === undefined ? 0 : shape.offsetY;
  if (!Number.isFinite(offsetX) || !Number.isFinite(offsetY) || Math.abs(offsetX) > MAX_OFFSET || Math.abs(offsetY) > MAX_OFFSET) return { ok: false, error: 'INVALID_SHAPE_OFFSET' };
  if (shape.type === 'AABB') {
    const width = shape.width; const height = shape.height;
    if (!Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0 || width > 10000 || height > 10000) return { ok: false, error: 'INVALID_AABB_SIZE' };
    entity.collision = { type: 'AABB', offsetX, offsetY, width, height };
  } else {
    const radius = shape.radius;
    if (!Number.isFinite(radius) || radius <= 0 || radius > 5000) return { ok: false, error: 'INVALID_CIRCLE_RADIUS' };
    entity.collision = { type: 'CIRCLE', offsetX, offsetY, radius };
  }
  return { ok: true, collision: entity.collision };
}

function collisionGeometry(entity, byId) {
  if (!entity || !entity.collision) return null;
  const world = worldTransform(entity, byId);
  if (!world) return null;
  const shape = entity.collision;
  if (shape.type !== 'AABB' && shape.type !== 'CIRCLE') return null;
  const ox = finite(shape.offsetX); const oy = finite(shape.offsetY);
  const localX = ox * world.scaleX; const localY = oy * world.scaleY;
  const cos = Math.cos(world.rotation); const sin = Math.sin(world.rotation);
  const x = world.x + localX * cos - localY * sin;
  const y = world.y + localX * sin + localY * cos;
  if (shape.type === 'CIRCLE') {
    if (!Number.isFinite(shape.radius) || shape.radius <= 0 || shape.radius > 5000) return null;
    return { type: 'CIRCLE', x, y, radius: shape.radius * Math.max(world.scaleX, world.scaleY), rotation: world.rotation };
  }
  if (!Number.isFinite(shape.width) || !Number.isFinite(shape.height) || shape.width <= 0 || shape.height <= 0 || shape.width > 10000 || shape.height > 10000) return null;
  return {
    type: 'OBB', x, y, halfWidth: shape.width * world.scaleX / 2,
    halfHeight: shape.height * world.scaleY / 2, rotation: world.rotation
  };
}

function circleCircle(a, b) {
  const dx = a.x - b.x; const dy = a.y - b.y; const radius = a.radius + b.radius;
  return dx * dx + dy * dy <= radius * radius;
}
function circleObb(circle, box) {
  const cos = Math.cos(box.rotation); const sin = Math.sin(box.rotation);
  const dx = circle.x - box.x; const dy = circle.y - box.y;
  const localX = dx * cos + dy * sin;
  const localY = -dx * sin + dy * cos;
  const nearestX = clamp(localX, -box.halfWidth, box.halfWidth);
  const nearestY = clamp(localY, -box.halfHeight, box.halfHeight);
  const ox = localX - nearestX; const oy = localY - nearestY;
  return ox * ox + oy * oy <= circle.radius * circle.radius;
}
function obbObb(a, b) {
  const ac = Math.cos(a.rotation); const as = Math.sin(a.rotation);
  const bc = Math.cos(b.rotation); const bs = Math.sin(b.rotation);
  const axes = [[ac, as], [-as, ac], [bc, bs], [-bs, bc]];
  const dx = b.x - a.x; const dy = b.y - a.y;
  for (const axis of axes) {
    const distance = Math.abs(dx * axis[0] + dy * axis[1]);
    const ra = a.halfWidth * Math.abs(ac * axis[0] + as * axis[1]) + a.halfHeight * Math.abs(-as * axis[0] + ac * axis[1]);
    const rb = b.halfWidth * Math.abs(bc * axis[0] + bs * axis[1]) + b.halfHeight * Math.abs(-bs * axis[0] + bc * axis[1]);
    if (distance > ra + rb) return false;
  }
  return true;
}
function collisionOverlap(a, b, byId) {
  if (!a || !b || !a.collision || !b.collision) return false;
  const map = byId && typeof byId.get === 'function' ? byId : new Map([[a.id, a], [b.id, b]]);
  const ga = collisionGeometry(a, map); const gb = collisionGeometry(b, map);
  if (!ga || !gb) return false;
  if (ga.type === 'CIRCLE' && gb.type === 'CIRCLE') return circleCircle(ga, gb);
  if (ga.type === 'CIRCLE') return circleObb(ga, gb);
  if (gb.type === 'CIRCLE') return circleObb(gb, ga);
  return obbObb(ga, gb);
}

module.exports = {
  PHYSICS_PRESETS, MAX_ENTITIES, MAX_HIERARCHY_DEPTH, readTransform, writeTransform,
  applyPhysicsPreset, groupEntities, worldTransform, setContainerTransform,
  setCollisionShape, collisionGeometry, collisionOverlap
};
