'use strict';
/* Event-driven collision overlay. Host owns the canvas, entity store and commit/undo transaction. */
const { setCollisionShape, collisionOverlap, collisionGeometry, worldTransform } = require('./editor-extensions');

function attachCollisionEditor(canvas, getSelection, getEntities, commit, options = {}) {
  if (!canvas || typeof canvas.addEventListener !== 'function' || typeof getSelection !== 'function' || typeof getEntities !== 'function' || typeof commit !== 'function') {
    return { ok: false, error: 'INVALID_HOST_ADAPTER' };
  }
  const ctx = canvas.getContext && canvas.getContext('2d');
  if (!ctx) return { ok: false, error: 'CANVAS_CONTEXT_UNAVAILABLE' };
  const state = { enabled: false, drag: null, destroyed: false };
  const handleSize = Math.max(6, Math.min(14, Number(options.handleSize) || 10));
  const screenToWorld = typeof options.screenToWorld === 'function' ? options.screenToWorld : (x, y) => ({ x, y });
  const worldToScreen = typeof options.worldToScreen === 'function' ? options.worldToScreen : (x, y) => ({ x, y });

  function registry() {
    const entities = getEntities();
    return Array.isArray(entities) ? entities : [];
  }
  function indexEntities(entities) {
    const map = new Map();
    for (const entity of entities) if (entity && typeof entity.id === 'string') map.set(entity.id, entity);
    return map;
  }
  function selected(entities) {
    const id = getSelection();
    return entities.find((entity) => entity && entity.id === id) || null;
  }
  function point(event) {
    const rect = canvas.getBoundingClientRect();
    const width = rect.width || canvas.width || 1;
    const height = rect.height || canvas.height || 1;
    const x = (event.clientX - rect.left) * (canvas.width / width);
    const y = (event.clientY - rect.top) * (canvas.height / height);
    const world = screenToWorld(x, y);
    return world && Number.isFinite(world.x) && Number.isFinite(world.y) ? world : null;
  }
  function toScreen(x, y) {
    const p = worldToScreen(x, y);
    return p && Number.isFinite(p.x) && Number.isFinite(p.y) ? p : { x, y };
  }
  function geometry(entity, byId) { return collisionGeometry(entity, byId); }
  function corner(g) {
    const c = Math.cos(g.rotation); const s = Math.sin(g.rotation);
    return { x: g.x + g.halfWidth * c - g.halfHeight * s, y: g.y + g.halfWidth * s + g.halfHeight * c };
  }
  function draw() {
    if (state.destroyed) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (!state.enabled) return;
    const entities = registry(); const byId = indexEntities(entities);
    const entity = selected(entities); const g = geometry(entity, byId);
    if (!entity || !g) return;
    ctx.save();
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#55d6a5';
    ctx.fillStyle = 'rgba(85,214,165,.12)';
    if (g.type === 'CIRCLE') {
      const p = toScreen(g.x, g.y);
      const edge = toScreen(g.x + g.radius, g.y);
      const radius = Math.hypot(edge.x - p.x, edge.y - p.y);
      ctx.beginPath(); ctx.arc(p.x, p.y, radius, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      ctx.fillRect(p.x + radius - handleSize / 2, p.y - handleSize / 2, handleSize, handleSize);
    } else {
      const points = [
        [-g.halfWidth, -g.halfHeight], [g.halfWidth, -g.halfHeight],
        [g.halfWidth, g.halfHeight], [-g.halfWidth, g.halfHeight]
      ];
      const c = Math.cos(g.rotation); const s = Math.sin(g.rotation);
      ctx.beginPath();
      for (let i = 0; i < points.length; i++) {
        const local = points[i];
        const p = toScreen(g.x + local[0] * c - local[1] * s, g.y + local[0] * s + local[1] * c);
        if (i === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y);
      }
      ctx.closePath(); ctx.fill(); ctx.stroke();
      const handle = corner(g); const p = toScreen(handle.x, handle.y);
      ctx.fillStyle = '#55d6a5'; ctx.fillRect(p.x - handleSize / 2, p.y - handleSize / 2, handleSize, handleSize);
    }
    let overlaps = false;
    for (const other of entities) {
      if (other && other.id !== entity.id && collisionOverlap(entity, other, byId)) { overlaps = true; break; }
    }
    const label = toScreen(g.x, g.y);
    ctx.fillStyle = overlaps ? '#ff6b78' : '#55d6a5';
    ctx.font = '12px system-ui';
    ctx.fillText(overlaps ? 'OVERLAP' : 'CLEAR', label.x + 8, label.y - 8);
    ctx.restore();
  }

  function down(event) {
    if (!state.enabled || state.destroyed) return;
    const entities = registry(); const byId = indexEntities(entities);
    const entity = selected(entities); const g = geometry(entity, byId); const p = point(event);
    if (!entity || !g || !p) return;
    const handle = g.type === 'CIRCLE' ? { x: g.x + g.radius, y: g.y } : corner(g);
    const screenHandle = toScreen(handle.x, handle.y);
    const screenPoint = toScreen(p.x, p.y);
    if (Math.hypot(screenPoint.x - screenHandle.x, screenPoint.y - screenHandle.y) <= handleSize * 2.5) {
      state.drag = { id: entity.id, type: g.type };
      try { canvas.setPointerCapture(event.pointerId); } catch { /* pointer capture is best effort */ }
    }
  }

  function move(event) {
    if (!state.enabled || state.destroyed || !state.drag) return;
    const entities = registry(); const byId = indexEntities(entities);
    const entity = byId.get(state.drag.id); const p = point(event);
    if (!entity || !p) { state.drag = null; return; }
    const world = worldTransform(entity, byId);
    if (!world) { state.drag = null; return; }
    const cos = Math.cos(world.rotation); const sin = Math.sin(world.rotation);
    const dx = p.x - world.x; const dy = p.y - world.y;
    const localX = dx * cos + dy * sin;
    const localY = -dx * sin + dy * cos;
    const old = entity.collision || {};
    let shape;
    if (state.drag.type === 'CIRCLE') {
      const ox = Number.isFinite(old.offsetX) ? old.offsetX : 0;
      const oy = Number.isFinite(old.offsetY) ? old.offsetY : 0;
      const radius = Math.hypot(localX - ox, localY - oy) / Math.max(world.scaleX, world.scaleY);
      shape = { type: 'CIRCLE', radius, offsetX: ox, offsetY: oy };
    } else {
      const ox = Number.isFinite(old.offsetX) ? old.offsetX : 0;
      const oy = Number.isFinite(old.offsetY) ? old.offsetY : 0;
      shape = {
        type: 'AABB',
        width: Math.abs(localX - ox) * 2 / world.scaleX,
        height: Math.abs(localY - oy) * 2 / world.scaleY,
        offsetX: ox, offsetY: oy
      };
    }
    const result = setCollisionShape(entity, shape);
    if (result.ok) {
      try { commit(entity); } catch { /* host transaction errors do not break pointer handling */ }
      draw();
    }
  }

  function up() { state.drag = null; }
  function enabled(value) { state.enabled = value === true; state.drag = null; draw(); }
  function destroy() {
    if (state.destroyed) return;
    state.destroyed = true;
    state.drag = null;
    canvas.removeEventListener('pointerdown', down);
    canvas.removeEventListener('pointermove', move);
    canvas.removeEventListener('pointerup', up);
    canvas.removeEventListener('pointercancel', up);
    canvas.removeEventListener('lostpointercapture', up);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  }

  canvas.addEventListener('pointerdown', down);
  canvas.addEventListener('pointermove', move);
  canvas.addEventListener('pointerup', up);
  canvas.addEventListener('pointercancel', up);
  canvas.addEventListener('lostpointercapture', up);
  return { ok: true, enabled, destroy, draw, get destroyed() { return state.destroyed; } };
}

module.exports = { attachCollisionEditor };
