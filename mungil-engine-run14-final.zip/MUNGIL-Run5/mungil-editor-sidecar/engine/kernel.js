'use strict';

/* One command facade for MUNGIL sidecar editor, game tools and MCP adapters. */
const E = require('./editor-extensions');
const CollisionEditor = require('./collision-editor');

const COMMANDS = Object.freeze([
  'physicsPreset', 'groupEntities', 'setContainerTransform', 'setCollisionShape',
  'checkCollisionOverlap', 'worldTransform', 'collisionGeometry'
]);

function createKernel(options = {}) {
  let disposed = false;
  let collisionOverlay = null;
  const getEntities = typeof options.getEntities === 'function' ? options.getEntities : () => [];
  const commit = typeof options.commit === 'function' ? options.commit : () => undefined;

  function execute(command, args = {}) {
    if (disposed) return { ok: false, error: 'KERNEL_DISPOSED' };
    if (!COMMANDS.includes(command)) return { ok: false, error: 'UNKNOWN_COMMAND' };
    if (!args || typeof args !== 'object' || Array.isArray(args)) return { ok: false, error: 'INVALID_ARGUMENTS' };
    try {
      let result;
      let changed = [];
      switch (command) {
        case 'physicsPreset':
          result = E.applyPhysicsPreset(args.entity, args.preset);
          if (result.ok) changed = [args.entity];
          break;
        case 'groupEntities':
          result = E.groupEntities(args.entities, args.selectedIds, args.containerId, args.name);
          if (result.ok) changed = args.entities;
          break;
        case 'setContainerTransform':
          result = E.setContainerTransform(args.entities, args.containerId, args.transform);
          if (result.ok) changed = [result.container];
          break;
        case 'setCollisionShape':
          result = E.setCollisionShape(args.entity, args.shape);
          if (result.ok) changed = [args.entity];
          break;
        case 'checkCollisionOverlap': {
          const entities = Array.isArray(args.entities) ? args.entities : getEntities();
          const byId = new Map(entities.filter((entity) => entity && typeof entity.id === 'string').map((entity) => [entity.id, entity]));
          if (args.a && !byId.has(args.a.id)) byId.set(args.a.id, args.a);
          if (args.b && !byId.has(args.b.id)) byId.set(args.b.id, args.b);
          result = { ok: true, overlap: E.collisionOverlap(args.a, args.b, byId) };
          break;
        }
        case 'worldTransform': {
          const entities = Array.isArray(args.entities) ? args.entities : getEntities();
          const byId = new Map(entities.filter((entity) => entity && typeof entity.id === 'string').map((entity) => [entity.id, entity]));
          if (args.entity && !byId.has(args.entity.id)) byId.set(args.entity.id, args.entity);
          result = { ok: true, transform: E.worldTransform(args.entity || byId.get(args.entityId), byId) };
          break;
        }
        case 'collisionGeometry': {
          const entities = Array.isArray(args.entities) ? args.entities : getEntities();
          const byId = new Map(entities.filter((entity) => entity && typeof entity.id === 'string').map((entity) => [entity.id, entity]));
          if (args.entity && !byId.has(args.entity.id)) byId.set(args.entity.id, args.entity);
          result = { ok: true, geometry: E.collisionGeometry(args.entity || byId.get(args.entityId), byId) };
          break;
        }
        default:
          result = { ok: false, error: 'UNKNOWN_COMMAND' };
      }
      if (result && result.ok && changed.length) {
        for (const entity of changed) commit(entity, command);
      }
      return result;
    } catch (error) {
      if (typeof options.onError === 'function') {
        try { options.onError(command, error); } catch { /* error reporting cannot break the kernel */ }
      }
      return { ok: false, error: 'COMMAND_FAILED', detail: String(error && error.message || error).slice(0, 160) };
    }
  }

  function attachCollisionEditor(canvas, getSelection, getEntityList, onCommit, editorOptions) {
    if (disposed) return { ok: false, error: 'KERNEL_DISPOSED' };
    if (collisionOverlay) collisionOverlay.destroy();
    collisionOverlay = CollisionEditor.attachCollisionEditor(
      canvas,
      getSelection,
      getEntityList || getEntities,
      onCommit || ((entity) => commit(entity, 'setCollisionShape')),
      editorOptions
    );
    return collisionOverlay;
  }

  function dispose() {
    if (disposed) return;
    disposed = true;
    if (collisionOverlay) collisionOverlay.destroy();
    collisionOverlay = null;
  }

  return Object.freeze({ execute, attachCollisionEditor, dispose, get disposed() { return disposed; }, commands: COMMANDS });
}

module.exports = { createKernel, COMMANDS };
