# MUNGIL AI + Editor Extension Workspace (Prototype 0.1)

This workspace is a **reversible sidecar**, not a replacement for the bundled MUNGIL application. The recovered original source is kept untouched at `baseline/source.original.html`.

## Contents
- `engine/editor-extensions.js`: physics presets, Container grouping, cycle-safe hierarchy transforms, collision shape editing, world-space OBB/circle geometry and overlap tests.
- `engine/kernel.js`: one command facade for editor, collision overlay and MCP adapters; bounded command surface and idempotent disposal.
- `agent/agent-core.js`: concise engine knowledge base and action validation.
- `agent/assistant-panel.js`: optional browser custom element. The app host must bridge its `mungil:agent-request` event to the MCP process and return `mungil:agent-result`.
- `mcp/server.js`: dependency-free MCP stdio server exposing engine explanation, physics preset, grouping, collision editing, world-transform/collision-geometry queries, game manifest and sample AI action tools.
- `game/index.html`: offline playable Relic Tactics prototype with Player-vs-AI and AI-vs-AI modes.

## Run
- Tests: `node tests/run.js && node tests/mcp-smoke.js`
- Syntax checks: `node --check engine/editor-extensions.js && node --check agent/agent-core.js && node --check agent/assistant-panel.js && node --check mcp/server.js`
- Game: open `game/index.html` in a modern browser.
- MCP: run `node mcp/server.js` as an MCP stdio server from an MCP-capable host.

## Important integration boundary
The current MUNGIL HTML is a large compiled React bundle. Its hierarchy/inspector/game systems are present, but there is no verified source-level component boundary or build pipeline in this workspace. Therefore these primitives are not injected into the production UI. Integrate only after mapping the exact existing entity schema, selection state, transform store, persistence action and inspector render function. Avoid string-replacing the minified bundle.

## Performance and compatibility
- Sidecar functions are event-driven, not called per-frame.
- Grouping v1 rejects nested grouping rather than silently corrupting transforms.
- Physics and collision values are bounded and finite-checked; hierarchy cycles are rejected and collision checks support rotated OBBs and circle-vs-OBB.
- Collision editor pointer capture is best-effort and all listeners are removed on idempotent disposal.
- AI demo uses a small 7x7 turn-based board, no network or external assets.
- Android 5+ browser compatibility must be validated on actual devices; this prototype does not claim Android 5+ support certification.
- No APK/AAB is produced. A browser HTML game cannot be truthfully described as a signed Android release binary.
- `engine/collision-editor.js`: event-driven canvas overlay adapter for editing AABB/circle handles and showing overlap state; requires the host canvas and entity-store callbacks.

See `docs/ENGINE_CONSTRAINT_REVIEW.md` for corrections to the proposed 9 rules, `docs/SOURCE_MAP.md` for inspected current entity/physics structures, and `docs/INTEGRATION_PLAN.md` for production integration sequencing. Configure the MCP host using `mcp/mcp-config.example.json` after replacing its path with the actual absolute path.
