'use strict';
const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const input = [
  { jsonrpc: '2.0', id: 1, method: 'initialize', params: { protocolVersion: '2024-11-05' } },
  { jsonrpc: '2.0', id: 2, method: 'tools/list' },
  { jsonrpc: '2.0', id: 3, method: 'tools/call', params: { name: 'mungil.explain_engine', arguments: { topic: 'loop' } } },
  { jsonrpc: '2.0', id: 4, method: 'tools/call', params: { name: 'mungil.physics_preset', arguments: { entity: { id: 'e', physics: 'Arcade', mass: 10, friction: 50, restitution: 10 }, preset: 'BOUNCY' } } },
  { jsonrpc: '2.0', id: 5, method: 'tools/call', params: { name: 'mungil.world_transform', arguments: { entity: { id: 'e', x: 4, y: 8, rot: 0, scale: 100 }, entities: [{ id: 'e', x: 4, y: 8, rot: 0, scale: 100 }] } } },
].map((message) => JSON.stringify(message)).join('\n') + '\n';
const processResult = spawnSync(process.execPath, ['mcp/server.js'], { input, encoding: 'utf8' });
assert.equal(processResult.status, 0, processResult.stderr);
const lines = processResult.stdout.trim().split('\n').map(JSON.parse);
assert.equal(lines.length, 5);
assert.equal(lines[0].result.serverInfo.name, 'mungil-game-agent');
assert.equal(lines[0].result.serverInfo.version, '0.2.0');
assert.ok(lines[1].result.tools.length >= 10);
assert.ok(lines[2].result.content[0].text.includes('30 Hz'));
const physics = JSON.parse(lines[3].result.content[0].text);
assert.equal(physics.entity.friction, 18);
const transform = JSON.parse(lines[4].result.content[0].text);
assert.equal(transform.transform.x, 4);
console.log('PASS MCP initialize, tool discovery, explanation, physics mutation and world-transform query');
const malformed = spawnSync(process.execPath, ['mcp/server.js'], { input: '{not-json\n', encoding: 'utf8' });
assert.equal(malformed.status, 0, malformed.stderr);
assert.equal(JSON.parse(malformed.stdout.trim()).error.code, -32700);
const oversized = spawnSync(process.execPath, ['mcp/server.js'], { input: ' '.repeat(1024 * 1024 + 16) + '\n', encoding: 'utf8', maxBuffer: 1024 * 1024 });
assert.equal(oversized.status, 0, oversized.stderr);
assert.match(JSON.parse(oversized.stdout.trim()).error.message, /1 MiB/);
console.log('PASS MCP malformed JSON and 1 MiB message-size guards');
