'use strict';
const assert = require('node:assert/strict');
const E = require('../engine/editor-extensions');
const K = require('../engine/kernel');
const A = require('../agent/agent-core');
const CE = require('../engine/collision-editor');

// Physics presets preserve the two existing MUNGIL entity schema variants.
const ent = { id: 'ball', physics: {} };
assert.equal(E.applyPhysicsPreset(ent, 'BOUNCY').ok, true);
assert.equal(ent.physics.restitution, 0.92);
assert.equal(E.applyPhysicsPreset(ent, 'bad').ok, false);
const flatBody = { id: 'flat', physics: 'Arcade', mass: 10, friction: 50, restitution: 10 };
assert.equal(E.applyPhysicsPreset(flatBody, 'SLIPPERY').ok, true);
assert.equal(flatBody.friction, 1.5);
assert.equal(flatBody.restitution, 5);

// Grouping and hierarchical transforms preserve original world positions.
const entities = [
  { id: 'a', transform: { x: 10, y: 10, rotation: 0, scaleX: 1, scaleY: 1 } },
  { id: 'b', transform: { x: 20, y: 10, rotation: 0, scaleX: 1, scaleY: 1 } },
];
const grouped = E.groupEntities(entities, ['a', 'b'], 'grp');
assert.equal(grouped.ok, true);
assert.equal(grouped.container.x, 15);
const map = new Map(entities.map((entity) => [entity.id, entity]));
assert.equal(E.worldTransform(entities[0], map).x, 10);
assert.equal(E.setContainerTransform(entities, 'grp', { x: 30, scaleX: 2 }).ok, true);
assert.equal(E.worldTransform(entities[0], map).x, 20);
assert.equal(E.groupEntities(entities, ['a', 'a'], 'dup').ok, false);
assert.equal(E.setContainerTransform(entities, 'grp', { x: NaN }).ok, false);

const flat = [
  { id: 'n1', name: 'A', type: 'Entity', parentId: null, x: 40, y: 100, rot: 0, scale: 100, comps: ['Transform'] },
  { id: 'n2', name: 'B', type: 'Entity', parentId: null, x: 80, y: 100, rot: 0, scale: 100, comps: ['Transform'] },
];
assert.equal(E.groupEntities(flat, ['n1', 'n2'], 'container').ok, true);
const flatMap = new Map(flat.map((entity) => [entity.id, entity]));
assert.equal(E.worldTransform(flat[0], flatMap).x, 40);
E.setContainerTransform(flat, 'container', { x: 100, rotation: Math.PI / 2, scaleX: 2, scaleY: 2 });
assert.ok(Math.abs(E.worldTransform(flat[0], flatMap).x - 100) < 1e-8);
assert.ok(Math.abs(E.worldTransform(flat[0], flatMap).y - 60) < 1e-8);

// Parent cycles are rejected instead of recursing until a stack overflow.
const cycleA = { id: 'cycleA', parentId: 'cycleB', transform: { x: 0, y: 0, rotation: 0, scaleX: 1, scaleY: 1 } };
const cycleB = { id: 'cycleB', parentId: 'cycleA', transform: { x: 0, y: 0, rotation: 0, scaleX: 1, scaleY: 1 } };
assert.equal(E.worldTransform(cycleA, new Map([[cycleA.id, cycleA], [cycleB.id, cycleB]])), null);

// AABB/circle editor validation, parent-aware world geometry and collision tests.
const a = { id: 'aabb', transform: { x: 0, y: 0, rotation: 0, scaleX: 1, scaleY: 1 } };
const b = { id: 'circle', transform: { x: 5, y: 0, rotation: 0, scaleX: 1, scaleY: 1 } };
assert.equal(E.setCollisionShape(a, { type: 'AABB', width: 10, height: 10 }).ok, true);
assert.equal(E.setCollisionShape(b, { type: 'CIRCLE', radius: 2 }).ok, true);
assert.equal(E.collisionOverlap(a, b), true);
const c = { id: 'far', transform: { x: 6, y: 6, rotation: 0, scaleX: 1, scaleY: 1 } };
E.setCollisionShape(c, { type: 'CIRCLE', radius: 1 });
assert.equal(E.collisionOverlap(a, c), false);
assert.equal(E.setCollisionShape(a, { type: 'AABB', width: -1, height: 10 }).ok, false);
assert.equal(E.setCollisionShape(a, { type: 'AABB', width: 2, height: 2, offsetX: 10001 }).ok, false);

const rotatedA = { id: 'ra', transform: { x: 0, y: 0, rotation: Math.PI / 4, scaleX: 1, scaleY: 1 } };
const rotatedB = { id: 'rb', transform: { x: 0, y: 0, rotation: Math.PI / 4, scaleX: 1, scaleY: 1 } };
E.setCollisionShape(rotatedA, { type: 'AABB', width: 10, height: 2 });
E.setCollisionShape(rotatedB, { type: 'AABB', width: 10, height: 2 });
assert.equal(E.collisionOverlap(rotatedA, rotatedB), true);
rotatedB.transform.x = 0; rotatedB.transform.y = 8;
assert.equal(E.collisionOverlap(rotatedA, rotatedB), false);

const parent = { id: 'parent', parentId: null, transform: { x: 10, y: 10, rotation: Math.PI / 2, scaleX: 2, scaleY: 2 } };
const child = { id: 'child', parentId: 'parent', transform: { x: 1, y: 0, rotation: 0, scaleX: 1, scaleY: 1 } };
E.setCollisionShape(child, { type: 'CIRCLE', radius: 1 });
const hierarchy = new Map([[parent.id, parent], [child.id, child]]);
const childWorld = E.worldTransform(child, hierarchy);
assert.ok(Math.abs(childWorld.x - 10) < 1e-8);
assert.ok(Math.abs(childWorld.y - 12) < 1e-8);
assert.equal(E.collisionGeometry(child, hierarchy).radius, 2);

// One kernel facade owns command routing and safely disposes its overlay.
let commits = 0;
const kernel = K.createKernel({ commit: () => { commits += 1; } });
const target = { id: 'target', transform: { x: 0, y: 0, rotation: 0, scaleX: 1, scaleY: 1 } };
assert.equal(kernel.execute('physicsPreset', { entity: target, preset: 'HEAVY' }).ok, true);
assert.equal(commits, 1);
assert.equal(kernel.execute('not-a-command', {}).ok, false);
assert.equal(kernel.execute('setCollisionShape', { entity: target, shape: { type: 'CIRCLE', radius: 5 } }).ok, true);
assert.equal(kernel.execute('collisionGeometry', { entity: target, entities: [target] }).geometry.type, 'CIRCLE');
kernel.dispose();
kernel.dispose();
assert.equal(kernel.execute('physicsPreset', { entity: target, preset: 'BOUNCY' }).error, 'KERNEL_DISPOSED');

// Collision overlay has idempotent teardown, including pointer-capture failure.
const listeners = new Map();
const fakeContext = { clearRect() {}, save() {}, restore() {}, beginPath() {}, arc() {}, fill() {}, stroke() {}, fillRect() {}, strokeRect() {}, moveTo() {}, lineTo() {}, closePath() {}, fillText() {} };
const fakeCanvas = {
  width: 100, height: 100,
  getContext: () => fakeContext,
  getBoundingClientRect: () => ({ left: 0, top: 0, width: 100, height: 100 }),
  addEventListener: (name, fn) => listeners.set(name, fn),
  removeEventListener: (name) => listeners.delete(name),
  setPointerCapture: () => { throw new Error('capture denied'); },
};
const overlayEntity = { id: 'overlay', transform: { x: 50, y: 50, rotation: 0, scaleX: 1, scaleY: 1 } };
E.setCollisionShape(overlayEntity, { type: 'AABB', width: 20, height: 20 });
const overlay = CE.attachCollisionEditor(fakeCanvas, () => 'overlay', () => [overlayEntity], () => undefined);
assert.equal(overlay.ok, true);
overlay.enabled(true);
overlay.draw();
overlay.destroy();
overlay.destroy();
assert.equal(overlay.destroyed, true);
assert.equal(listeners.size, 0);

assert.equal(A.validateAction({ type: 'MOVE', x: 3, y: 4 }), true);
assert.equal(A.validateAction({ type: 'MOVE', x: 99, y: 4 }), false);
assert.ok(A.explain('loop').explanation.includes('30 Hz'));
assert.equal(CE.attachCollisionEditor(null, () => null, () => [], () => {}).ok, false);

console.log('PASS: presets, grouping, parent transforms/cycle guard, AABB/OBB/circle collisions, shape bounds, kernel routing/disposal, collision overlay teardown and AI validation');
