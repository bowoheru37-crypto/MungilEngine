# MUNGIL editor sidecar — Run 5 audit

## Source review

The uploaded `mungil-ai-game-platform-prototype.zip` did not contain `engine/kernel.js`, despite earlier notes describing a unified command facade. Run 5 restores this missing file and routes MCP editor operations through it. The original `baseline/source.original.html` remains untouched.

## Changes

- `engine/kernel.js`: bounded command list, safe argument checks, exception boundary, optional host commit callback, collision-overlay ownership and idempotent dispose.
- `engine/editor-extensions.js`: stable entity ID checks, parent transform cycle guard and depth limit, finite transform validation, collision offset bounds, world-space collision geometry, rotated OBB SAT, circle-circle and circle-OBB tests.
- `engine/collision-editor.js`: parent-aware geometry, optional world/screen coordinate adapters, rotated OBB drawing, pointer-capture best effort, pointercancel/lostpointercapture cleanup, idempotent destroy and canvas clear.
- `mcp/server.js`: routes mutations/queries through kernel, adds world-transform and collision-geometry tools, validates project registry capacity/title, rejects malformed JSON and messages larger than 1 MiB.
- `tests/run.js` and `tests/mcp-smoke.js`: expanded regression coverage for transform cycles, OBB/circle collisions, command routing, overlay teardown, MCP tools and malformed/oversized requests.

## Verification

- `node tests/run.js`: PASS.
- `node tests/mcp-smoke.js`: PASS.
- Node syntax checks for editor extensions, collision editor, kernel, MCP server and tests: PASS.

## Remaining integration boundaries

- No production React bundle patch was made. The original MUNGIL application is a compiled bundle and the exact state/undo/persistence seam remains unverified.
- Container grouping v1 still rejects nested grouping. This is deliberate to avoid silently changing world transforms.
- Circle collision under non-uniform scale uses the maximum world scale as a conservative circle approximation; exact ellipse collision is not implemented.
- MCP runs as a local stdio process and still requires a trusted host bridge. Browser JavaScript must not connect directly to stdio or bypass host authorization.
- This is a reversible extension layer, not a complete multi-genre game editor/runtime.
