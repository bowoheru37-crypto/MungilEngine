# MUNGIL Engine — genre and art-direction support matrix

This matrix defines supported composition profiles, not a claim that every genre is already implemented. A project selects one primary simulation profile and one or more presentation profiles. Optional systems are loaded only when referenced by the project manifest.

## Core contract shared by every project

- Project manifest: schema version, runtime target, scene list, asset IDs, input map, renderer profile, feature flags and build settings.
- Scene lifecycle: create → preload → enter → update fixed-step → render → suspend/resume → exit → dispose.
- Input actions: device-independent actions (`move`, `aim`, `jump`, `confirm`, `cancel`, `primary`, `secondary`) mapped to keyboard, pointer, touch, gamepad or virtual controls.
- State: explicit game state and transition table; simulation state is separate from presentation state.
- Time: fixed-step simulation with bounded catch-up; render interpolation is optional and never mutates authoritative simulation state.
- Resource ownership: each loaded resource has one owner, a stable asset ID, a byte estimate, a release path and optional pin state.
- Renderer: adapter contract for resize, begin frame, draw scene, context loss, quality change and dispose.
- Serialization: stable entity/component IDs, schema versioning, validation and deterministic migration.
- Accessibility: remappable input, text scale, subtitles, color-safe indicators and reduced-motion mode.

## Genre composition profiles

| Genre | Required baseline | Optional systems | Low-end adaptation |
|---|---|---|---|
| Platformer / metroidvania | 2D camera, tilemap, AABB/capsule collision, animation FSM | slopes, one-way platforms, ledge grab, particles, dialogue | tile chunks, fixed collision grid, sprite atlases |
| Top-down action / adventure | orthographic camera, input actions, hitboxes, FSM | inventory, quest, dialogue, stealth, light cones | grid/sector culling, simple shadow blobs |
| JRPG / turn-based RPG | scene state, turn scheduler, data-driven abilities, UI | status effects, party, crafting, dialogue graphs | no continuous physics; turn-based AI budgets |
| ARPG / roguelite | fixed-step combat, object pools, hitbox/hurtbox, drops | procedural rooms, build synergies, nav grid | bounded active enemies/projectiles, reuse particles |
| Fighting / beat-em-up | deterministic input buffer, frame windows, hitbox sets, FSM | rollback netcode, cancels, juggle, training recorder | fixed animation sampling, no per-frame mesh deform |
| Racing / kart / pseudo-3D | road/track representation, projection, vehicle state | tire/suspension, drift, ghost replay, traffic | segment culling, low-poly vehicles, baked road textures |
| FPS / TPS / shooter | camera, ray/shape casts, projectile pool, aim input | recoil, ballistic penetration, squad AI, multiplayer | limit active agents, simple materials, baked lighting |
| RTS / tactics / tower defense | grid/nav graph, selection, command queue, deterministic ticks | fog of war, economy, formation, replay | hierarchical pathfinding, staggered AI ticks |
| Sports | input sampling, deterministic match state, animation FSM | ball/vehicle physics, team AI, replay | simplified collision and animation LOD |
| Puzzle / logic / board | turn/state machine, grid, undo/redo, serialization | procedural puzzle generator, hints, editor | Canvas2D default, zero continuous simulation when idle |
| Rhythm / music | audio clock, event timeline, latency calibration | MIDI import, beat maps, scoring replay | precompute chart; avoid syncing gameplay to RAF clock |
| Visual novel / narrative | dialogue graph, text renderer, save slots | branching variables, voice, portrait animation | static art, compressed audio streaming |
| Simulation / tycoon | entity components, schedules, economy, persistence | behavior trees, transport networks, weather | aggregate distant agents; simulate only active region |
| Survival / crafting | inventory, interaction, needs, world state | weather, temperature, farming, building | coarse world ticks; chunked persistence |
| Sandbox / builder | transform gizmos, grid snapping, undo/redo, save | physics joints, blueprints, procedural generation | editor tools excluded from player export |
| Open world | chunk streaming, origin rebasing, LOD, navigation | crowds, climate, vehicles, multiplayer | small active cell radius, impostors, baked assets |
| Rhythm-action / hybrid | input buffer, fixed-step state, audio clock | beat-synced VFX, score replay | event-driven effects and capped particles |
| Educational / serious game | scene state, UI, accessibility, progress save | assessment, analytics, offline content | Canvas2D and low-motion default |

## Art-direction profiles

| Art direction | Rendering path | Asset rules | Low-end policy |
|---|---|---|---|
| Pixel art / 8-bit / 16-bit | Canvas2D or batched WebGL2 | integer scale, nearest filtering, sprite sheets, palette constraints | native low resolution, no MSAA, no mipmaps unless scaled down |
| Hand-drawn / 2D illustration | Canvas2D/WebGL2 sprites | trim transparent bounds, atlas, premultiplied-alpha consistency | limit oversized translucent layers |
| Vector / flat / UI-heavy | Canvas2D or vector-to-atlas build | convert static vectors to raster atlases at target scales | avoid per-frame complex path tessellation |
| Isometric / 2.5D | orthographic camera, depth sorting, tilemap | explicit sort origin, tile dimensions, occlusion layers | chunk sorting, static layer caching |
| Retro 3D / PS1 / low-poly | WebGL2 or pseudo-3D adapter | low vertex count, affine/vertex-color options, texture limits | vertex colors, baked lighting, no real-time shadows |
| Voxel | instanced cubes or greedy meshed chunks | chunk mesh rebuilds off main thread where possible | greedy meshing and distance-based chunk LOD |
| Toon / anime / cel-shaded | WebGL2 shader/material profile | palette ramps, outlines, limited lights | one/two lights, SDF/geometry outline only where needed |
| Low-poly stylized | WebGL2, instancing and baked maps | shared materials, meshopt, atlas | no post-processing by default |
| PBR realistic | WebGL2 high tier / optional WebGPU | glTF PBR, KTX2/Basis, LOD, normal/roughness maps | baked GI, capped texture sizes, limited dynamic lights |
| Photogrammetry / scanned | glTF pipeline, meshopt, texture streaming | offline decimation, UV validation, KTX2, LOD chain | reject unoptimized source scans from runtime build |
| 2D skeletal / cutout | skeletal adapter | bounded bone count, atlas, attachment swaps | skeletal for foreground; sprite bake for distant actors |
| 3D skeletal | glTF animation adapter | prune tracks, quantize, clip compression | animation LOD and reduced skeleton for NPCs |

## Render backend policy

- **Canvas2D:** required compatibility path for 2D, pixel art, UI, simple pseudo-3D and old browser/WebView targets.
- **WebGL2:** main cross-platform accelerated path for batched 2D, 2.5D and mobile 3D where supported.
- **WebGL1:** separate legacy adapter only; do not assume current Three.js supports it.
- **WebGPU:** optional capability-gated backend. It must never be a hard requirement for Android 5+.

Backend choice must not change gameplay APIs, scene serialization or project assets. If a feature is not available, a project-defined fallback is selected (for example baked shadows instead of real-time shadow maps, sprite animation instead of skeletal mesh deformation, or pseudo-3D instead of full perspective 3D).

## Asset build pipeline

1. Import original source file and retain immutable source ID.
2. Inspect dimensions, duration, sample rate, polygon count, UVs, skeleton and metadata.
3. Validate type, path, size, license, checksum and referenced dependencies.
4. Generate target variants: atlas pages, compressed audio, optimized glTF, texture formats and LOD.
5. Generate compatibility fallbacks (PNG/JPEG/OGG/JSON/Canvas) where required.
6. Build dependency graph and detect missing, duplicate, circular and orphan references.
7. Emit manifest with source/output hash, sizes, target profile, compression and tool versions.
8. Export only assets reachable from the selected scene graph and enabled feature set.
9. Verify package integrity and run an offline smoke load.

## Runtime budgets are profiles, not universal constants

Do not enforce a universal 128-thread job system, 16 GB memory target, 10,000 active NPCs or a single 30 FPS lock. Each project declares target FPS, simulation rate, maximum active entities, worker budget, texture budget, audio voice budget, draw/instance budget and fallback policy. Runtime clamps these values to detected device capabilities. On low-end phones, use a small bounded worker pool (or no workers), a bounded simulation catch-up, low render scale, no expensive post-processing, and distance/importance-based simulation.
