#!/usr/bin/env node
'use strict';
// Minimal MCP stdio server (JSON-RPC 2.0), no third-party dependencies.
const readline = require('node:readline');
const { createKernel } = require('../engine/kernel');
const kernel = createKernel();
const A = require('../agent/agent-core');
const rl = readline.createInterface({ input:process.stdin, crlfDelay:Infinity, terminal:false });
const projects = new Map();
function send(message) { process.stdout.write(JSON.stringify(message)+'\n'); }
function tool(name, description, inputSchema) { return { name, description, inputSchema }; }
const TOOLS = [
  tool('mungil.explain_engine','Explain an existing MUNGIL subsystem and safe integration guidance.',{type:'object',properties:{topic:{type:'string'}},required:['topic']}),
  tool('mungil.physics_preset','Apply a validated physics preset to an entity object supplied by the caller.',{type:'object',properties:{entity:{type:'object'},preset:{type:'string',enum:['BOUNCY','HEAVY','GHOST','SLIPPERY']}},required:['entity','preset']}),
  tool('mungil.group_entities','Group selected entity records into a transformable Container.',{type:'object',properties:{entities:{type:'array'},selectedIds:{type:'array',items:{type:'string'}},containerId:{type:'string'},name:{type:'string'}},required:['entities','selectedIds','containerId']}),
  tool('mungil.set_collision_shape','Set a bounded AABB or circle collision shape.',{type:'object',properties:{entity:{type:'object'},shape:{type:'object'}},required:['entity','shape']}),
  tool('mungil.set_container_transform','Move, rotate or scale an existing Container.',{type:'object',properties:{entities:{type:'array'},containerId:{type:'string'},transform:{type:'object'}},required:['entities','containerId','transform']}),
  tool('mungil.check_collision_overlap','Check parent-aware overlap between two collision-enabled entities.',{type:'object',properties:{a:{type:'object'},b:{type:'object'},entities:{type:'array'}},required:['a','b']}),
  tool('mungil.world_transform','Resolve a selected entity transform through its parent hierarchy.',{type:'object',properties:{entity:{type:'object'},entityId:{type:'string'},entities:{type:'array'}},required:['entities']}),
  tool('mungil.collision_geometry','Resolve world-space collision geometry for an entity.',{type:'object',properties:{entity:{type:'object'},entityId:{type:'string'},entities:{type:'array'}},required:['entities']}),
  tool('mungil.create_game_project','Create a lightweight local game project manifest with player-vs-AI and AI-demo modes.',{type:'object',properties:{projectId:{type:'string'},title:{type:'string'},genre:{type:'string'}},required:['projectId','title']}),
  tool('mungil.gameplay_ai_action','Return a safe deterministic sample action for the supplied board state.',{type:'object',properties:{board:{type:'array'},player:{type:'string'}},required:['board','player']})
];
function result(id, content, isError=false) { send({jsonrpc:'2.0',id,result:{content:[{type:'text',text:typeof content==='string'?content:JSON.stringify(content)}],isError}}); }
function chooseAI(board, player) {
  if (!Array.isArray(board) || board.length!==7 || board.some(r=>!Array.isArray(r)||r.length!==7)) throw Error('Board must be 7x7');
  const moves=[]; for(let y=0;y<7;y++) for(let x=0;x<7;x++) if(board[y][x]===null || board[y][x]===0 || board[y][x]==='') moves.push({type:'MOVE',x,y});
  if(!moves.length) return {type:'WAIT',x:0,y:0};
  // deterministic center preference; caller's game rules remain authoritative
  moves.sort((a,b)=>((Math.abs(a.x-3)+Math.abs(a.y-3))-(Math.abs(b.x-3)+Math.abs(b.y-3))) || a.y-b.y || a.x-b.x);
  return moves[0];
}
async function callTool(name,args) {
  switch(name) {
    case 'mungil.explain_engine': return A.explain(args.topic);
    case 'mungil.physics_preset': { const r=kernel.execute('physicsPreset', {entity:args.entity,preset:args.preset}); return {...r,entity:args.entity}; }
    case 'mungil.group_entities': { const r=kernel.execute('groupEntities', args); return {...r,entities:args.entities}; }
    case 'mungil.set_collision_shape': { const r=kernel.execute('setCollisionShape', args); return {...r,entity:args.entity}; }
    case 'mungil.set_container_transform': { const r=kernel.execute('setContainerTransform', args); return {...r,entities:args.entities}; }
    case 'mungil.check_collision_overlap': return kernel.execute('checkCollisionOverlap', args);
    case 'mungil.world_transform': return kernel.execute('worldTransform', args);
    case 'mungil.collision_geometry': return kernel.execute('collisionGeometry', args);
    case 'mungil.create_game_project': {
      if(!/^[a-z0-9][a-z0-9_-]{1,40}$/i.test(args.projectId)) throw Error('Invalid projectId');
      if(typeof args.title!=='string'||!args.title.trim()) throw Error('Invalid project title');
      if(!projects.has(args.projectId)&&projects.size>=128) throw Error('Project registry capacity reached');
      const p={id:args.projectId,title:args.title.trim().slice(0,80),genre:String(args.genre||'tactics').slice(0,40),modes:['PLAYER_VS_AI','AI_VS_AI'],createdAt:new Date().toISOString(),engine:'MUNGIL adapter'};
      projects.set(p.id,p); return p;
    }
    case 'mungil.gameplay_ai_action': return chooseAI(args.board,args.player);
    default: throw Error('Unknown tool');
  }
}
rl.on('line', async line => {
  if(Buffer.byteLength(line,'utf8')>1024*1024) { send({jsonrpc:'2.0',id:null,error:{code:-32700,message:'Message exceeds 1 MiB limit'}}); return; }
  let msg; try { msg=JSON.parse(line); } catch { send({jsonrpc:'2.0',id:null,error:{code:-32700,message:'Invalid JSON'}}); return; }
  try {
    if(msg.method==='initialize') return send({jsonrpc:'2.0',id:msg.id,result:{protocolVersion:msg.params?.protocolVersion||'2024-11-05',capabilities:{tools:{}},serverInfo:{name:'mungil-game-agent',version:'0.2.0'}}});
    if(msg.method==='notifications/initialized') return;
    if(msg.method==='ping') return send({jsonrpc:'2.0',id:msg.id,result:{}});
    if(msg.method==='tools/list') return send({jsonrpc:'2.0',id:msg.id,result:{tools:TOOLS}});
    if(msg.method==='tools/call') { const out=await callTool(msg.params?.name,msg.params?.arguments||{}); return result(msg.id,out,!!(out&&out.ok===false)); }
    if(msg.id!==undefined) send({jsonrpc:'2.0',id:msg.id,error:{code:-32601,message:'Method not found'}});
  } catch(e) { if(msg.id!==undefined) result(msg.id,{error:e&&e.message?e.message:'Tool failure'},true); }
});
