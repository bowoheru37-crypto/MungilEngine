# Changelog — MUNGIL AI + Game Platform Prototype 0.1

## Added
- Physics presets: Bouncy, Heavy, Ghost, Slippery.
- Flat MUNGIL physics body mapping (friction/restitution 0–100) and nested physics adapter support.
- Entity grouping into Container using existing flat entity schema (`parentId`, `x`, `y`, `rot`, `scale`, `comps`).
- Parent world-transform calculation and Container move/rotate/uniform-scale support.
- Explicit rejection of non-uniform scale for the current flat MUNGIL entity schema.
- AABB and circle collision shape data editor primitives, overlap detection and event-driven canvas overlay adapter.
- Dependency-free MCP stdio server with engine explanation, physics, grouping, collision, project manifest and AI action tools.
- Browser assistant custom element with a host-to-MCP event bridge contract.
- Offline Relic Tactics game with Player-vs-AI and AI-vs-AI modes.
- Source map, integration plan, constraint review, MCP host config example and tests.

## Validation
- Unit tests: pass.
- MCP initialize/tool discovery/tool call smoke test: pass.
- JavaScript syntax checks: pass.
- Original HTML SHA-256 unchanged.

## Not completed
- Production UI integration into the compiled React bundle.
- Browser runtime / touch gameplay test.
- Android 5+ and itel A70 device tests.
- Android APK/AAB build or signing.
- Clone and source/license/commit audit of 100 GitHub repositories.

## Run 5 — hardening and command-kernel restoration

- Restored the missing `engine/kernel.js` facade and routed MCP editor operations through it.
- Added cycle-safe parent transforms and world-space collision geometry.
- Added rotated OBB SAT and circle-vs-OBB collision checks; collision offsets and transform patches are bounded.
- Reworked collision overlay lifecycle, parent-aware drawing and pointer-capture handling.
- Expanded regression and MCP smoke coverage.
