# MUNGIL Run 8 — Technical Reference Notes

These sources inform architecture choices; they do not imply source code was copied or dependencies adopted.

## Platform export and runtime compatibility
- Godot stable FAQ: editor platforms and export targets (Windows, macOS, Linux/*BSD, Android, iOS, Web): https://docs.godotengine.org/en/stable/about/faq.html
- Godot system requirements: minimum/recommended mobile CPU, GPU, RAM and OS differences: https://docs.godotengine.org/en/latest/about/system_requirements.html
- Godot web export: WebAssembly + WebGL 2.0 requirements and mobile caveats: https://docs.godotengine.org/en/latest/tutorials/export/exporting_for_web.html
- Godot export workflow: export presets require SDKs/templates and platform-specific setup: https://docs.godotengine.org/en/latest/tutorials/export/exporting_projects.html

## Graphics and asset delivery
- MDN WebGL best practices: compressed GPU texture formats and resource lifecycle: https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API/WebGL_best_practices
- MDN WebGL best practices: reduced back buffer, batching and texture atlases: https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API/WebGL_best_practices
- Khronos KHR_texture_basisu: KTX2/Basis Universal transcoding and fallback behavior: https://github.com/KhronosGroup/glTF/blob/main/extensions/2.0/Khronos/KHR_texture_basisu/README.md
- Khronos KTX 2.0 specification: streaming and universal texture container: https://registry.khronos.org/KTX/specs/2.0/ktxspec.v2.html

## Audio and input
- MDN AudioWorklet: low-latency custom audio processing on a separate audio thread: https://developer.mozilla.org/en-US/docs/Web/API/AudioWorklet
- MDN Web Audio API: AudioWorklet and deprecated main-thread ScriptProcessorNode: https://developer.mozilla.org/en-US/docs/Web/API/Web_Audio_API
- MDN Gamepad API: gamepad connection events and state access: https://developer.mozilla.org/en-US/docs/Web/API/Gamepad_API
- MDN getGamepads: polling the currently visible gamepad list: https://developer.mozilla.org/en-US/docs/Web/API/Navigator/getGamepads

## Installability and offline delivery
- MDN PWA installability: web manifest, icons, HTTPS/localhost constraints: https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Guides/Making_PWAs_installable
- MDN PWA offline operation: service worker cache strategy: https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Guides/Offline_and_background_operation

## Implications for MUNGIL
1. Export support is a set of concrete platform adapters, SDKs and signing flows, not a single universal checkbox.
2. For low-end mobile, render resolution, batching, texture residency and voice counts should be explicit budgets.
3. Gamepad polling belongs in the host input loop; touch and keyboard remain first-class alternatives.
4. PWA installability and offline caching require manifest, icon assets, HTTPS/localhost and service worker lifecycle management.
5. AI generation should remain outside the frame loop and execute as cancellable, bounded background jobs with validated outputs.
