# Run 14 Android Release Build Status

Build script syntax check passed (`bash -n`). Release build was invoked and stopped at its prerequisite gate. The environment does not have Android SDK Platform 36 configured at `ANDROID_HOME` / `ANDROID_SDK_ROOT`, or the matching Build Tools 36.0.0. Gradle 8.13/wrapper and local release keystore credentials must also be provided before a signed APK/AAB can be produced.

No APK or AAB was generated in Run 14. The app Gradle metadata remains API 21 minimum, compile/target 36, versionCode 14, versionName `1.4.0-dev.14`. Physical install tests on Android 5, Android 13 Go and itel A70 are still outstanding.
