# MUNGIL — 12-Layer / 54-Slot Capability Matrix (Run 12)

Legend: **Implemented** = code exists and has targeted tests; **Partial** = limited foundation only; **Planned** = no production implementation; **Not suitable as Tier 0 default** = optional high-end/server workload.

The supplied original table enumerates layers 0–10 and 51 systems. The proposed Layer 11 from Run 9 adds three distribution slots, producing 12 layers / 54 roadmap slots. This is a roadmap count, not a claim that all systems are complete.

| Layer | System slots | Run 12 status |
|---|---:|---|
| 0 Foundation | 5 | Partial: fixed-step clock, seeded RNG, 1 km cell coordinates, origin rebasing, bounded pools, LRU memory, resource lifecycle. No 128-thread fibers, 16 GB budget, cross-platform fixed-point deterministic physics, or production crash telemetry. |
| 1 Asset pipeline | 5 | Partial: bounded manifest and signature-based intake; Tier 0 IndexedDB Asset Vault with SHA-256 metadata, LRU eviction, pin protection, per-file/batch quotas, and user-controlled deletion. Still no photogrammetry, full PBR+, virtual texturing, Nanite/Lumen, real transcoding, or full glTF validation. |
| 2 World simulation | 6 | Planned/partial: spatial broadphase helper only. Streaming, climate, ecosystem, rigid-body solver, crowds, erosion and procedural world simulation are not production systems. |
| 3 Rendering | 8 | Partial: Canvas2D and WebGL2 primitive batch renderers. Perspective 3D remains separate/unimplemented in MUNGIL Studio. GI, RT, water, hair, skin shaders and advanced post effects are not implemented. |
| 4 Character & animation | 5 | Planned: no production FACS, motion matching, full-body IK, muscle or damage system. |
| 5 AI & gameplay | 5 | Partial: prompt planner, sequential bounded agent scheduler, provider contract, output sanitizer and local knowledge memory. NPC perception, tactics, schedule, dialogue and physics combat are not implemented. |
| 6 Audio | 4 | Partial: WebAudio bus mixer and voice caps from prior runs. No HRTF, material reverb, dynamic stems or production foley library. |
| 7 Interaction & gameplay deep | 4 | Planned: no production survival, vehicle, crime/law or granular interaction system. |
| 8 Network & persistence | 3 | Partial: local project persistence and validation. No authoritative multiplayer, rollback server, persistent world service or anti-cheat kernel. |
| 9 Editor & dev tools | 3 | Partial: project document, bounded history, hierarchy projection, selection, inspector data editing, batch duplicate, undo/redo, and asset intake/Vault management UI. No full world painter, sequencer or GPU profiler. |
| 10 Accessibility & polish | 3 | Partial: controller remapping and quality profiles. No full accessibility audit, photo mode, color-blind presets or 4K/RT Ultra path. |
| 11 Distribution & live operations | 3 | Partial: PWA shell, Android WebView source scaffold, export manifest. No verified native build matrix, release supply chain or production telemetry/update service. |

## Tiering
- **Tier 0 (entry-level Android / itel A70):** 30 FPS target, 2D/2.5D first, small textures/atlases, baked/static lighting, sequential agent tasks, bounded asset decode/cache, small particle and audio budgets.
- **Tier 1 (mid-range mobile):** larger atlases, limited skeletal animation, more particles, optional WebGL2 sprite batches.
- **Tier 2 (desktop/high-end):** perspective 3D, higher material and shadow budgets, larger simulation and optional compute workloads where supported.
- **Server/build farm:** AI generation, asset transcoding, large-world baking, multiplayer authority and heavy offline optimization.

No tier is a promise that every genre's mechanics have already been implemented. Genre support is an extensible kit/adapter architecture.

## Run 11–12 deltas
- Layer 1 Asset Pipeline: **Partial** — Run 11 added signature-based preflight, dimension checks, cancellation, and SHA-256 metadata. Run 12 adds IndexedDB blob persistence, bounded tier budgets, LRU eviction, pin protection, quota checks, and storage-management APIs. Still no media decode/transcode, full glTF validator, renderer binding, or CDN upload.
- Layer 9 Editor & Dev Tools: **Partial** — Studio now supports validate-and-save, list/refresh, pin/unpin, delete, clear-unpinned with confirmation, and explicit persistent-storage request.
- Layer 10 Accessibility & Polish: no new implementation in Runs 11–12.
- Layer 11 Distribution & Operations: no new implementation in Runs 11–12.

Runs 11–12 do not change the 12-layer / 54-roadmap-slot accounting. They implement incremental slices within existing Layer 1 and Layer 9 slots; neither layer is complete.

## Run 13 delta

| Capability | Status | Evidence / boundary |
|---|---|---|
| Bounded image preview sizing | Implemented | `asset-preview.ts`; max 384px and 384×384 decoded pixels by default |
| Sprite-to-Vault image assignment | Partial | `assetId` property saved in scene document; one selected Sprite preview |
| Canvas2D image preview | Partial | Canvas2D fallback activated only when image assigned; no WebGL2 textured batching |
| Multi-sprite texture binding / atlas | Planned | Not implemented |
| Audio/video/model decoding | Planned | Vault storage only |
