# Run 8 Technical Audit

## Architecture decision
The product is split into three explicit layers:
- **Studio UI** (`platform/`): mobile-first browser prototype and local project workflow.
- **Generator orchestration** (`runtime/generator/agent-pipeline.ts`): provider-neutral plan and task scheduler.
- **Runtime services** (`controller-map.ts`, `audio-manager.ts`, existing kernel/renderers): reusable runtime adapters.

This avoids coupling prompt interpretation, cloud inference and the game loop. A real AI provider must be added behind `AgentProvider`; generated outputs must be schema-validated and sandboxed before import.

## Resource and safety boundaries
- Prompt max 4,000 characters; plan max 24 tasks; current plan has 10 tasks.
- Scheduler concurrency is one by design to limit CPU/memory spikes on low-end devices.
- Controller map max 128 actions and 12 bindings per action; axis values are clamped and deadzone is constrained to 0–0.5.
- Audio registry max 512 clips; global voices default to 24 (constructor allows 1–128); per-clip voices default to 8 and clamp to 1–32.
- Project data is stored locally by the browser prototype. This is not a cloud backup or secure multi-user persistence layer.

## Known gaps / risks
- `executeGenerationPlan` currently emits task completion events but does not persist task outputs into a project document. The next provider integration must define typed output schemas and transactional application to project history.
- The browser prototype has a separate lightweight planner implementation for offline UI demonstration; production should call the shared TypeScript planner through the app bundle rather than maintaining duplicated classification logic.
- AudioContext behavior, autoplay restrictions, device output routing and suspend/resume require testing on Android browsers/WebView.
- The PWA shell is only installable when served from HTTPS/localhost and served from the configured `/platform/` scope.
- Offline cache is a shell cache only; user-generated assets and projects are currently stored separately in localStorage, not synced or backed up.
- Native and console exports require platform SDKs, signing and compliance; no generic universal export target exists.

## Verification summary
- Runtime Node tests: 39 pass, 0 fail.
- Sidecar tests and MCP smoke tests: pass.
- HTML parser and embedded JavaScript syntax: pass.
- TypeScript project-wide check: blocked by absent installed type dependencies.
- Chromium headless: timed out in this environment; no screenshot or browser interaction test claimed.
- Physical Android tests: not run.
