# MUNGIL Runtime — Run 5 implementation addendum

## Scope

This addendum extends the existing dependency-free runtime primitives without replacing the original editor or game constructors. New modules are opt-in and exported from `src/game/runtime/index.ts`.

## Added modules

| Module | Purpose | Hot-path / allocation policy |
|---|---|---|
| `pool.ts` | Fixed-capacity object pool with integer handles | All objects are created at construction; acquire/release do not create objects |
| `spatial.ts` | Bounded uniform-grid broadphase for 2D AABBs | Typed-array heads/links/IDs/stamps; caller supplies query output buffer; call `clear()` before each rebuild |
| `projection.ts` | Isometric forward/inverse transforms, pseudo-3D road projection, bounded grid DDA raycast | Caller-owned output objects; DDA step count bounded |
| `capabilities.ts` | Renderer choice by capability and projection | Never silently selects Canvas2D for perspective 3D; WebGPU is opt-in in auto mode |
| `profiles.ts` | Art-direction and genre starter budgets | Presets are tunable starting limits, not guaranteed device capacity |
| `memory.ts` | Byte-accounted resource budget with LRU eviction and pinning | Registration/eviction are lifecycle operations; callbacks are isolated |

## Security and correctness hardening

- Asset paths reject absolute paths, drive prefixes, backslashes, dot segments, encoded traversal, URI schemes and control characters.
- Local JSON storage has a 128-character key cap and a 1 MiB serialized payload cap; malformed, oversized or denied storage fails closed.
- Memory budget refuses an allocation request if pinned resources alone would exceed the budget, before evicting unrelated unpinned resources.
- Spatial grid validates dimensions, capacities, AABB ordering, entity IDs and per-entity cell coverage.
- Raycaster validates dimensions and direction, detects a ray beginning inside a solid tile, exits map bounds and caps traversal steps.
- Object pool has a hard capacity ceiling and rejects duplicate release and post-disposal acquisition.

## Starter budgets

For tier 0 / low-end mobile, genre presets start at 30 Hz simulation, 30 FPS target, 8 audio voices, 32 particles and 0 dynamic lights. Entity caps are genre-specific rather than a universal 128: e.g. 48 for fighting/card-like workloads, 64 for racing/puzzle, 128 for platformer/roguelike and 256 for strategy/sandbox/open-world. These are configuration starting points; actual project complexity must be profiled.

Art-direction presets preserve the visual style while reducing implementation cost. Pixel art keeps nearest filtering and disables antialiasing; isometric and hand-drawn styles prefer a 2D path; retro-3D, voxel, toon, low-poly, PBR and skeletal 3D use WebGL-class backends. Tier 0 caps texture variants at 512 px, disables real-time shadows and post-processing, and prefers baked lighting. These are export-time recommendations, not automatic asset conversion.

## What is not implemented by these primitives

The new helpers do not constitute a complete rigid-body solver, skeletal animation runtime, navmesh, procedural terrain, PBR renderer, global illumination, video generator, multiplayer backend, editor scene graph or APK packaging pipeline. They are reusable foundations and adapters; feature implementations must be added as independent modules with tests and measured costs.

## Verification

- Runtime unit suite: 25/25 pass (`node --experimental-strip-types --test src/game/runtime/core.test.ts`).
- Strict type check of runtime modules: pass (`tsc --noEmit --strict ...`).
- MUNGIL editor sidecar tests: pass (`node tests/run.js`, `node tests/mcp-smoke.js`).
- Full workspace script tests: existing 8 brand/share-card fixture failures remain; 2 TypeScript test files cannot load because `@tanstack/react-start` and `jose` are not installed in the unpacked workspace. These are environment/fixture failures, not claimed as passing.
- No browser/device/Android APK benchmark in this run.
