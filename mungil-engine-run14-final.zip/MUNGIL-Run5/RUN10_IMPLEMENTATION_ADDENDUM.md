# MUNGIL Run 10 — Implementation Addendum

## Scope
Run 10 continues the Run 9 workspace. It adds an editor command layer and bounded, provenance-aware agent memory; improves transaction atomicity and import validation; updates the standalone Studio and Android wrapper; and hardens Android local-content loading.

## New runtime modules

### `src/game/runtime/scene-editor.ts`
- Renderer-neutral `SceneEditorSession` over the existing `ProjectHistory`.
- Stable hierarchy projection with depth and child counts.
- Bounded selection, add, rename, property update, reparent, subtree removal, subtree duplication, undo/redo, disposal.
- Duplicate IDs are checked before mutation; duplicated parent links are remapped.
- Subtree duplication uses a single bounded history transaction.

### `src/game/runtime/knowledge-base.ts`
- `AgentKnowledgeBase` with entry count, total-byte, per-entry, tag-count, text-length and URL bounds.
- Entry types: fact, decision, pattern, pitfall, reference, skill-note.
- Provenance URL restricted to HTTP(S); no credentials in URLs.
- Query and tag ranking; hit counts; bounded eviction; snapshot import/export.
- Snapshot import is atomic and rejects invalid/duplicate IDs.
- Accessor properties, non-plain objects and unexpected fields are rejected.
- Skill outcomes update a bounded exponentially weighted score. This is local evaluation memory, not model training.

## Project history hardening
- Added `ProjectHistory.applyBatch` with shadow validation and one undo/redo checkpoint.
- Batch count is bounded to 512 operations.
- Invalid operation objects and malformed node payloads fail closed.
- Failed batches do not mutate the current document or history.

## Studio Run 10
- Added a scene hierarchy panel, object selection, name/property inspector, add/duplicate/delete, undo/redo.
- Added a local knowledge browser with source links, search, and snapshot export.
- Scene document and knowledge snapshot are included in local project save/export.
- Scene edits currently update the renderer-neutral document; transform gizmos, full renderer binding, and asset-backed sprite rendering are not implemented.
- Planner remains local and deterministic; no remote model provider is configured.

## Android wrapper
- App version bumped to 1.0.0 / versionCode 10.
- Uses AndroidX WebKit `WebViewAssetLoader` and `WebViewClientCompat` to load packaged assets under the reserved appassets origin.
- Adds `androidx.webkit:webkit:1.14.0`; this is selected because 1.15 raises the library minimum to API 23 and 1.16 raises it to API 24, while the project retains minSdk 21.
- Disables file access and content access; no JavaScript bridge is exposed; external HTTP(S) links are handed to external browser apps.
- Avoids API 29/30-only `Insets` types in the Activity.
- Release build script remains fail-closed and requires SDK Platform 36, Build Tools 36.0.0, JDK 17, Gradle 8.13, and a locally configured signing key.

## Validation
- Runtime test suite: 57/57 passed.
- Strict TypeScript check for runtime entry/index: passed.
- Browser runtime bundle: built; VM smoke test passed.
- Studio embedded JavaScript syntax: passed.
- MUNGIL sidecar test suite: passed.
- MCP smoke: passed when run from the sidecar directory (test expects that working directory).
- Android manifest XML: parse check passed.
- Android release build: blocked before Gradle because SDK Platform 36 is not installed in the execution environment. No APK/AAB was produced.

## Not delivered in Run 10
- No live LLM / remote multi-agent provider, external model training, or automatic knowledge crawling.
- No real image/audio/model decoding, transcoding, malware scanning, or glTF runtime loader.
- No full 3D renderer, physics solver, GI/ray tracing, virtual texturing, cloth/fluid, or high-count NPC simulation.
- No real native exporter matrix or social publishing integration.
- No physical itel A70 benchmark, Android 5 device test, or signed release binary.
