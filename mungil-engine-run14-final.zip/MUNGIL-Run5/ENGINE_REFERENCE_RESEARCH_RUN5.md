# MUNGIL Engine — Open-source reference research (Run 5)

Snapshot: 2026-11-25. This is a curated engineering shortlist, not a claim that every repository was cloned, fully audited, or approved for code reuse. Repository metadata and README content were directly retrieved for a representative subset through GitHub; other entries are research candidates requiring commit pinning, source inspection, license review and device benchmarking before adoption.

## Selection rules

1. Prefer a narrow, proven subsystem over importing a full engine.
2. Preserve MUNGIL's existing project, scene, editor, renderer and asset constructors. Integrate behind adapters.
3. Separate browser editor dependencies from exported game runtime dependencies.
4. Keep optional systems lazy-loaded and remove them from export bundles when a project does not use them.
5. Verify the repository license and every bundled asset separately. A repository's MIT license does not automatically cover sample art, music, fonts or third-party packages.
6. Pin exact commit SHAs before adapting source. Re-check the license at that revision and retain all required notices.
7. Benchmark the resulting build on the lowest supported device, not only desktop.

## High-value repositories and transferable patterns

### Runtime / 2D / 3D / web rendering

| Repository | Primary value to study | MUNGIL adoption boundary |
|---|---|---|
| [KilledByAPixel/LittleJS](https://github.com/KilledByAPixel/LittleJS) | Small dependency-free runtime, hybrid WebGL2/Canvas2D, physics, particles, audio and input | Study compact lifecycle and renderer fallback; do not import its whole engine |
| [phaserjs/phaser](https://github.com/phaserjs/phaser) | Scene lifecycle, loader, camera, scale manager, input, 2D physics and mobile browser support | Use as a 2D scene/workflow reference; keep optional physics adapters |
| [pixijs/pixijs](https://github.com/pixijs/pixijs) | Sprite batching, texture resources, filters, masks, WebGL/WebGPU renderer separation | Study batch boundaries, resource ownership and texture GC |
| [melonjs/melonJS](https://github.com/melonjs/melonJS) | Orthogonal/isometric cameras, tilemaps, 2.5D, polygon collision and renderer fallback | Strong fit for tilemap and camera adapter patterns |
| [playcanvas/engine](https://github.com/playcanvas/engine) | Component/entity model, editor/runtime separation, WebGL2/WebGPU backends, asset registry | Study editor-to-runtime contract, component lifecycle and batching |
| [Babylon.js](https://github.com/BabylonJS/Babylon.js) | Scene optimizer, hardware scaling, materials, inspectors and WebGPU/WebGL | Study feature detection and quality scaling; avoid pulling all tooling into player |
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | General 3D scene graph, glTF, instancing, animation and renderer APIs | Existing Aetherfall project uses Three.js; use its official lifecycle/disposal rules |
| [regl-project/regl](https://github.com/regl-project/regl) | Functional WebGL command model and explicit resource lifetimes | Potential low-level renderer experiments only |
| [greggman/twgl.js](https://github.com/greggman/twgl.js) | Thin WebGL helpers, buffers, uniforms and textures | Reference for minimal WebGL backend, not a second renderer in the same project |
| [oframe/ogl](https://github.com/oframe/ogl) | Small WebGL scene/render abstractions | Candidate for a separate ultra-light 3D runtime profile |

### Fake 3D / pseudo-3D / raycasting / isometric / 2.5D

| Repository | Primary value to study | Risk / boundary |
|---|---|---|
| [jakesgordon/javascript-racer](https://github.com/jakesgordon/javascript-racer) | Classic road-segment projection, curves, hills, camera-relative coordinates | README warns of poor mobile performance; demo/tutorial only, do not copy assets |
| [ssusnic/Pseudo-3d-Racer](https://github.com/ssusnic/Pseudo-3d-Racer) | Step-by-step road projection and clipping | Phaser 2-era sample; math reference only |
| [xImDoctor/AndEngine](https://github.com/xImDoctor/AndEngine) | DDA raycasting for Doom-style pseudo-3D | Early project; review renderer correctness and license before any code use |
| [krotik/gladiator_3d](https://github.com/krotik/gladiator_3d) | Sector-based pseudo-3D ideas | Candidate only; source audit required |
| [justMoritz/3d-game-engine](https://github.com/justMoritz/3d-game-engine) | Minimal software/sector engine concepts | Educational reference, not a production dependency |
| [justMoritz/sector-based-3d-engine](https://github.com/justMoritz/sector-based-3d-engine) | Sector visibility and 2.5D world representation | Prototype-scale reference |
| [rohit-s-init/3d-raycaster-wolfstein](https://github.com/rohit-s-init/3d-raycaster-wolfstein) | Raycaster grid and wall projection | Study DDA bounds and texture mapping |
| [shiro1307/raycast_wolfenstein_renderer](https://github.com/shiro1307/raycast_wolfenstein_renderer) | Raycasting and sprite depth ordering | Study only after checking license and edge cases |
| [jwwicks/phaser3-plugin-isometric](https://github.com/jwwicks/phaser3-plugin-isometric) | Isometric projection and depth sorting | Adapter/reference; plugin compatibility must be pinned |
| [7hebel/IsoEngine](https://github.com/7hebel/IsoEngine) | Isometric scene primitives | Candidate for map editor math |
| [pixscapegames/pixscape-studio-free](https://github.com/pixscapegames/pixscape-studio-free) | LibGDX 2D/2.5D, orthographic/isometric maps, scene entities and deterministic spatial ordering | Apache-2.0 runtime; study schema and editor/runtime boundary |
| [mapeditor/tiled](https://github.com/mapeditor/tiled) | Mature map authoring and TMX/JSON data interchange | Import/export reference; do not recreate Tiled's editor |

### Mobile and cross-platform engine architecture

| Repository | Primary value to study | Adoption boundary |
|---|---|---|
| [godotengine/godot](https://github.com/godotengine/godot) | Scene tree, resource lifecycle, 2D/3D renderer profiles, mobile export | Architectural reference; full engine is too large to embed |
| [defold/defold](https://github.com/defold/defold) | Small runtime philosophy, Lua scripting, collections, atlas and mobile packaging | Defold license is not a simple MIT/Apache grant; review its exact license and notices |
| [4ian/GDevelop](https://github.com/4ian/GDevelop) | Event-based visual logic, behaviors, extension contracts | Strong editor UX reference; do not transplant its large stack |
| [libgdx/libgdx](https://github.com/libgdx/libgdx) | SpriteBatch, asset manager, lifecycle, Android/desktop/HTML5 backends | Apache-2.0; useful for batching and content pipeline concepts |
| [coronalabs/corona](https://github.com/coronalabs/corona) / Solar2D | Mobile-first Lua workflow, display objects, audio and native plugins | MIT repo metadata; inspect bundled native components and notices |
| [cocos2d/cocos2d-x](https://github.com/cocos2d/cocos2d-x) | Sprite batching, texture atlases, action system and mobile lifecycle | Older C++ engine branch; license and maintenance state need separate review |
| [raysan5/raylib](https://github.com/raysan5/raylib) | Small C API, explicit resource ownership, portable rendering | Zlib; useful native/NDK reference, not a web runtime dependency |
| [love2d/love](https://github.com/love2d/love) | Small 2D framework API and clear update/draw split | zlib license family; inspect bundled dependencies |
| [orx/orx](https://github.com/orx/orx) | Data-driven config and object lifecycle | Zlib; reference for compact data-driven projects |
| [HaxeFlixel](https://github.com/HaxeFlixel/flixel) | Retro 2D workflows, cameras, tilemaps and animation | Study genre workflows and retro tooling |
| [ct.js](https://github.com/ct-js/ct-js) | Beginner-friendly visual editor plus scripting | Editor UX and event/behavior ideas |

### Physics / collision / ECS / gameplay AI

| Repository | Primary value to study | MUNGIL policy |
|---|---|---|
| [erincatto/box2d](https://github.com/erincatto/box2d) | CCD, contact events, geometric mover, sleep, replay and data-oriented design | C17 source is a native-port candidate; do not compile it into web by default |
| [piqnt/planck.js](https://github.com/piqnt/planck.js) | Box2D-style 2D physics in JS/TS | Optional 2D rigid-body adapter |
| [dimforge/rapier](https://github.com/dimforge/rapier) | 2D/3D rigid bodies, character controllers, CCD and Rust/WASM | Optional advanced physics package; WASM load cost and Android WebView compatibility must be measured |
| [liabru/matter-js](https://github.com/liabru/matter-js) | Simple 2D rigid-body API and constraints | Optional for games needing flexible 2D physics, not default for platformer AABB |
| [jrouwe/JoltPhysics](https://github.com/jrouwe/JoltPhysics) | Native multithread-friendly 3D physics | Native/high-end profile only; too costly for base web bundle |
| [pmndrs/cannon-es](https://github.com/pmndrs/cannon-es) | Small JS 3D rigid-body concepts | Check fork/upstream maintenance; no dependency chosen in this run |
| [hmans/miniplex](https://github.com/hmans/miniplex) | Developer-friendly ECS query model | ECS-lite reference; avoid adopting a full archetype ECS unless profiling justifies it |
| [bitECS](https://github.com/NateTheGreatt/bitECS) | Typed-array/data-oriented ECS | MPL-2.0; candidate for large entity-count tier, retain file-level notices and check distribution obligations |
| [Mugen87/yuka](https://github.com/Mugen87/yuka) | Game AI, steering, decision and navigation utilities | Optional AI package; prefer budgeted local behaviors for mobile |
| [recastnavigation/recastnavigation](https://github.com/recastnavigation/recastnavigation) | Navmesh build, Detour queries, tiled streaming and crowd | Bake navmesh offline; runtime query only where genre requires it |
| [qiao/PathFinding.js](https://github.com/qiao/PathFinding.js) | Grid A*, Dijkstra and pathfinding algorithms | Use as algorithm reference; add node/iteration caps |

### Animation / audio / content pipeline / networking

| Repository | Primary value to study | MUNGIL policy |
|---|---|---|
| [UXCentury/open-bone](https://github.com/UXCentury/open-bone) | 2D skeletons, mesh deformation, IK, state machines, atlas and MCP authoring | MIT claimed in repository; new project, run compatibility/security review before dependency |
| [jaisurya-dev-art/rigby2d](https://github.com/jaisurya-dev-art/rigby2d) | 2D rig editor, IK, mesh animation and multiple runtimes | Apache-2.0 repository metadata; inspect runtime dependencies and release stability |
| [DragonBones/DragonBonesJS](https://github.com/DragonBones/DragonBonesJS) | Skeletal animation data and runtime separation | MIT repository metadata; legacy candidate, validate maintenance and bundled asset provenance |
| [Rive](https://rive.app/) | State-machine-driven vector animation authoring/runtime | Product/runtime licensing and package terms differ from a general OSS codebase; optional adapter only |
| [Live2D Cubism SDK](https://www.live2d.com/en/sdk/about/) | Parameter-driven character animation | Proprietary SDK; optional licensed integration only |
| [goldfire/howler.js](https://github.com/goldfire/howler.js) | Audio sprites, browser autoplay handling and HTMLAudio fallback | MIT; study as audio adapter, not mandatory runtime dependency |
| [KilledByAPixel/ZzFX](https://github.com/KilledByAPixel/ZzFX) | Tiny procedural SFX generation | MIT; optional for retro/procedural audio |
| [Tone.js](https://github.com/Tonejs/Tone.js) | Sequencing and music synthesis | Authoring/editor tool, not default player runtime |
| [SoLoud](https://github.com/jarikomppa/soloud) | Cross-platform audio engine and mixer design | Native audio reference; native build footprint must be measured |
| [zeux/meshoptimizer](https://github.com/zeux/meshoptimizer) | Vertex/index cache optimization, simplification, quantization and gltfpack | Build-time pipeline; no runtime cost when preprocessed |
| [KhronosGroup/KTX-Software](https://github.com/KhronosGroup/KTX-Software) | KTX2 containers, Basis Universal and GPU texture formats | Build-time texture conversion; runtime extension detection and fallback required |
| [gltf-transform](https://github.com/donmccurdy/glTF-Transform) | glTF dedup, prune, resize, meshopt and KTX2 transforms | Build-time asset pipeline |
| [google/draco](https://github.com/google/draco) | Geometry compression | Optional model pipeline; decode CPU and WASM size must be measured |
| [KhronosGroup/glTF-Validator](https://github.com/KhronosGroup/glTF-Validator) | Structural and semantic glTF validation | CI/build validation gate |
| [colyseus/colyseus](https://github.com/colyseus/colyseus) | Authoritative multiplayer room/state model | Server-side optional; not part of offline single-player runtime |
| [heroiclabs/nakama](https://github.com/heroiclabs/nakama) | Backend services, matchmaking and authoritative multiplayer | Server-side optional; do not ship server SDK in tiny offline player |

## Representative repositories directly inspected in Run 5

GitHub repository metadata and README content were retrieved for: LittleJS, Phaser, PixiJS, melonJS, PlayCanvas, Defold, GDevelop, Godot, Box2D, Rapier, Planck.js, OpenBone, meshoptimizer, KTX-Software, javascript-racer and ssusnic/Pseudo-3d-Racer. The `pmndrs/cannon-es` lookup returned 404, so it is not treated as an active verified upstream in this pass. This was remote source review, not a local git clone.

Key observations:

- LittleJS explicitly combines a small runtime with 2D/3D rendering, physics, particles, audio and input; this supports a modular runtime but not importing all features into MUNGIL.
- Phaser and PixiJS show why scene lifecycle and rendering/batching should be independent contracts.
- melonJS is a particularly relevant 2D/2.5D candidate because it describes orthogonal/perspective cameras, tilemaps, polygon physics and WebGPU/WebGL2/Canvas fallback in a small no-dependency package.
- PlayCanvas provides a strong editor/runtime separation and explicit WebGL2/WebGPU backend model.
- Box2D's current README emphasizes CCD, geometric character movement, data-oriented design, replay and cross-platform determinism; those are better references for correctness than arbitrary thread-count targets.
- Rapier is a 2D/3D physics option, but its WASM package size, async loading and device compatibility should be opt-in.
- OpenBone is a promising new 2D skeletal/interactive animation project; its breadth is interesting but maturity, versioning, output conformance and security require independent validation.
- The pseudo-3D racer tutorials are useful for projection math, but their own documentation warns about mobile performance. They must not be treated as ready-made low-end mobile engines.

## Proposed MUNGIL architecture derived from the research

### Authoring and export separation

- **Editor shell:** project browser, scene hierarchy, inspector, viewport, timeline, asset browser, build/export, diagnostics and AI/MCP. Heavy editor tools remain outside the shipped game runtime.
- **Project format:** versioned JSON manifest plus immutable asset IDs; migrations are explicit and reversible.
- **Runtime kernel:** lifecycle, fixed-step clock, event queue, input actions, deterministic seed, scene state, resource scope, diagnostics and capability profile.
- **Renderer adapters:** Canvas2D (broadest fallback), WebGL2 (main mobile 2D/3D path), optional WebGPU (capability-gated). Renderer selection is per project and can be downgraded without changing gameplay state.
- **World adapters:** orthographic 2D, isometric 2.5D, perspective 3D, pseudo-3D road projection and grid raycaster. Share input, scene lifecycle and resource contracts; do not force one projection model on all genres.
- **Physics adapters:** built-in AABB/circle/capsule/grid collision for simple genres; optional Planck/Box2D for 2D rigid bodies; optional Rapier for advanced 2D/3D character and rigid-body requirements.
- **Gameplay modules:** FSM, event conditions/actions, behavior trees, navigation, combat, inventory, dialogue, vehicle, platformer, strategy and simulation systems. Genre packs are optional compositions, not hardwired core code.
- **Animation:** sprite sheets and flipbooks first; skeletal 2D with optional OpenBone/Rigby runtime; 3D glTF animation through existing Three.js path. Motion matching, cloth, facial rigs and physics constraints are optional high-tier systems.
- **Audio:** WebAudio bus + HTMLAudio fallback, audio sprites, voice/music streaming, bounded voices, suspend/resume and disposal. Audio generation/authoring stays build-time.
- **Asset pipeline:** validate manifest, scan dimensions/format, atlas packing, audio transcode, glTF prune/meshopt, KTX2/Basis texture conversion, LOD generation, checksums and dependency graph. Heavy transforms happen at build time, not on a phone.
- **Multiplayer:** optional transport adapter and server-authoritative simulation; offline projects must not download multiplayer code.
- **Diagnostics:** rolling frame time, long-frame count, memory estimates, resource counts, context-loss events, asset load failures, crash-safe bounded logs. Telemetry is opt-in and privacy-preserving.

### Compatibility tiers

| Tier | Target | Renderer | Features |
|---|---|---|---|
| T0 — legacy / constrained | Android 5+, old WebView, low RAM, Canvas capable | Canvas2D; optional legacy WebGL1 adapter if separately implemented and verified | 2D, pixel art, UI, tilemap, basic pseudo-3D, simple collision and sprite animation |
| T1 — baseline mobile | Updated Android WebView with WebGL2 | WebGL2 / Canvas2D fallback | Batched 2D, isometric, 2.5D, low-poly 3D, baked lighting, instancing where supported |
| T2 — modern mobile | Newer GPU/WebView with measured headroom | WebGL2; WebGPU only after feature checks | Better post-processing, higher LOD, advanced animation and optional compute features |
| T3 — desktop / high-end | Desktop GPUs and modern browsers | WebGPU/WebGL2 | Advanced shadows, high-poly assets, editor preview and optional advanced simulation |

**Important:** the current Aetherfall workspace uses Three.js `WebGLRenderer`. Official Three.js documentation states that WebGL 1 support was removed in r163. Therefore that particular renderer cannot be the Android 5 legacy backend. Android 5+ support requires a separate Canvas2D/legacy-WebGL adapter or a separately pinned older renderer build; it cannot be asserted from `minSdk` alone.

## License and provenance gate

- Confirm license at the exact pinned commit, not only repository metadata.
- Keep upstream copyright and license notices for adapted code.
- Audit all npm transitive dependencies and bundled native libraries.
- Check assets, demo music, sample characters, fonts and textures separately.
- Do not copy assets from the OutRun tutorial repository; its README identifies borrowed sprites and project-specific music.
- Treat Defold's `NOASSERTION` repository metadata as requiring manual license-file review; do not label it MIT.
- Treat new/small projects as candidates, not production-certified components.

## Next research actions

1. Resolve the repository list to exact commits and inspect source trees / build workflows.
2. Read license files and dependency manifests at each pinned revision.
3. Build small isolated benchmarks for sprite batching, texture atlas sizes, 2.5D projection and collision broadphase.
4. Run browser and Android WebView compatibility tests on Android 5, Android 8, Android 10+ and the itel A70 target.
5. Adopt only the smallest tested subsystem that measurably improves the current implementation.
