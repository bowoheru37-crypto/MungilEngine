# MUNGIL Run 14 — Implementation Addendum

## 1. Runtime architecture kept intact
The increment extends the current renderer-neutral project/runtime interfaces. It does not bundle whole third-party engines together, replace the fixed-step core, or create duplicate physics/render authorities. Canvas2D remains the compatibility path; WebGL2 is optional and capability-gated.

## 2. Sprite rendering and atlas workflow
- The WebGL2 2D batch renderer supports textured sprites from registered atlas pages, frame UVs, tint, alpha, rotation/pivot and ordered sprite runs. It remains a 2D/2.5D renderer, not perspective 3D.
- The deterministic shelf packer produces bounded atlas page/frame metadata and a Canvas2D page composer with padding/extrusion.
- Studio's `Build Sprite Atlas · 512px` workflow reads eligible images from the local Asset Vault sequentially, limits the atlas to one 512×512 page and 64 entries, decodes one image at a time, exports PNG + JSON, and releases temporary bitmap/object-URL/canvas resources. Images larger than 508 px in either dimension are skipped to reserve edge padding.
- Atlas generation is a standalone asset export; current Studio does not yet wire the exported atlas automatically into every scene sprite or expose a full animation timeline editor.

## 3. Sprite animation and VFX
- Sprite clip sampling supports loop, once and ping-pong progression using explicit elapsed time and bounded frame arrays.
- Particle simulation uses bounded structure-of-arrays storage and deterministic seeded behavior; Tier 0 budgets remain intentionally small. The runtime API exists, but a full particle/VFX authoring panel, curves editor, collision module and graph authoring tool are not included.

## 4. Audio
- WebAudio manager supports bus routing, capped voices, preview lifecycle and bounded clip decoding. Run 14 narrows Studio preview to 4 MiB compressed, 30 seconds maximum, and 12 MiB maximum decoded PCM buffer. The decoded byte check occurs after browser decoding; it does not prevent all transient decoder allocations.
- Long-form BGM streaming, adaptive music stems, spatial HRTF, material convolution/reverb and a production SFX library are not implemented. The correct architectural split is short effects in decoded buffers and long tracks via media-element streaming where needed.

## 5. glTF and playable export
- Existing glTF preflight checks container/JSON/reference structure and import constraints before local vault persistence. Khronos glTF-Validator remains a recommended CI/build adapter for standards-level JSON/GLB/resource validation; it is not shipped/bundled in Run 14.
- HTML5 output is a playable offline 2D platformer vertical slice with keyboard/touch controls, a fixed-step update cap, pause-on-hidden, a restrictive CSP, escaped title/JSON data and output/node ceilings. Arbitrary binary Asset Vault resources are currently counted/reported as excluded rather than embedded.

## 6. Generator/agent scheduler
- The local task pipeline now finds the next dependency-ready task in authored order instead of assuming the array is already topologically sorted.
- Duplicate IDs, self-dependencies and unknown dependencies are rejected; cycles are reported; pending tasks are skipped after hard failure or abort.
- Execution remains sequential to bound CPU/memory on entry-level devices. This is not a hosted LLM call, multi-process agent cluster, 128-worker job system or automatic model training.

## 7. Android/PWA synchronization
- One standalone Studio HTML is copied to PWA `platform/index.html` and Android `assets/studio.html`; the matching browser runtime bundle is copied to both runtime paths.
- Android package metadata is set to `com.mungil.mobile`, versionCode 14, versionName `1.4.0-dev.14`, minSdk 21, compile/target SDK 36, AndroidX WebKit 1.14.0.
- `minSdk 21` does not ensure feature parity on Android 5 WebView. Modern and legacy paths remain capability-gated.
