# MUNGIL Run 11 — Technical Audit

## Findings addressed
- Browser MIME metadata is untrusted; intake now derives supported formats from file signatures.
- Import work could otherwise create unbounded memory pressure; the intake is sequential and has explicit per-file, total-size, file-count, image-dimension and JSON-size ceilings.
- User-supplied filenames can carry traversal/control characters; the intake rejects path separators and control characters before creating project paths.
- Unsupported/malformed files fail closed.
- SHA-256 is computed for provenance/integrity metadata; it is not an authenticity guarantee.
- Cancellation is checked between reads and before hashing each subsequent file.

## Residual risks
- `inspectAssetFiles()` allocates one complete ArrayBuffer per file. It is not streaming and may still be too memory-intensive for large media on low-RAM devices.
- Signature detection is not full decoding. Crafted image/audio/video files may pass header checks but fail in their decoder.
- GLB check validates the outer magic/version/declared size and first JSON chunk marker/length only. It does not validate all chunks, JSON schema, buffer references or binary accessors.
- glTF JSON files with external resources are not resolved or sandboxed by this preflight. Do not pass their URIs directly to network fetch or a loader without a separate allowlisted resolver.
- No archive formats are accepted; this avoids archive-bomb expansion in the current path.
- File bytes are not persisted. A successful result means metadata preflight passed, not that an asset is imported into the project or visible in the renderer.
- Web Crypto SubtleCrypto must be available; otherwise the function fails closed with `CRYPTO_SUBTLE_UNAVAILABLE`.
- Chromium headless DOM capture timed out in this environment, so no visual browser UI pass is claimed.
- No physical device profiling, Android lint/build, signing, APK/AAB, or API21 WebView validation was performed.

## Platform policy
- Keep Tier 0 defaults conservative: small file ceilings, sequential decode, low resolution textures, static lighting, 30 FPS target, and explicit disposal.
- Do not assume Android Go WebView has the same memory budget as desktop Chrome.
- Keep WebGL2 optional and retain Canvas2D legacy behavior for compatible 2D workflows.
- Do not label this engine fully compatible with all 2D/2.5D/3D genres or all Android 5+ devices until each capability is tested and version-gated.
