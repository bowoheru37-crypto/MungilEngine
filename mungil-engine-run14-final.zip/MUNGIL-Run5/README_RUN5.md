# MUNGIL Engine — Run 5 delivery

This package preserves the uploaded Aetherfall workspace, the earlier MUNGIL editor sidecar and the original Canvas2D sample as separate artifacts. They are not falsely presented as one fully integrated product.

## Contents

- `aetherfall-workspace/` — uploaded React/Three.js game workspace with Run 5 runtime hardening and reusable genre/rendering primitives.
- `mungil-editor-sidecar/` — reversible MUNGIL editor extension prototype, collision editor and MCP server.
- `samples/archipelago-drift-original.html` — original Canvas2D sample, preserved unchanged.
- `samples/archipelago-drift-run5.html` — improved mobile-friendly Canvas2D sample with touch joystick, dash, fixed-step simulation and visibility lifecycle.
- `ENGINE_REFERENCE_RESEARCH_RUN5.md` — 60 curated repository references across runtime/rendering, pseudo-3D, mobile engines, physics/ECS/AI, animation/audio, asset optimization and multiplayer.
- `GENRE_SUPPORT_MATRIX_RUN5.md` — genre and art-direction composition matrix with honest implementation-status labels.
- `RUN5_IMPLEMENTATION_ADDENDUM.md` — new runtime modules and security/performance decisions.
- `RUN5_TECHNICAL_AUDIT.md` — verification results and unresolved blockers.

## Runtime modules

`src/game/runtime/` includes the fixed-step clock, resource scope, device profile, quality governor, seeded RNG, table-driven FSM, runtime kernel, project contracts, object pool, uniform-grid broadphase, isometric/pseudo-3D/raycaster math, renderer capability resolver, art-direction/genre budgets, memory budget and bounded asset/storage validation.

## Run checks

Aetherfall workspace:
- `node --experimental-strip-types --test src/game/runtime/core.test.ts`
- `tsc --noEmit --strict --target ES2022 --lib ES2022,DOM --module ESNext --moduleResolution bundler --allowImportingTsExtensions --skipLibCheck src/game/runtime/core.ts src/game/runtime/contracts.ts src/game/runtime/kernel.ts src/game/runtime/pool.ts src/game/runtime/projection.ts src/game/runtime/spatial.ts src/game/runtime/capabilities.ts src/game/runtime/profiles.ts src/game/runtime/memory.ts src/game/runtime/index.ts`

MUNGIL sidecar:
- `node tests/run.js`
- `node tests/mcp-smoke.js`

## Status and limitations

- No repository clone is claimed. GitHub metadata/README research was performed remotely for a representative subset; the catalog is a shortlist, not a code-import report.
- No APK/AAB was built or signed; no physical itel A70 benchmark was performed.
- The Aetherfall workspace is not the full MUNGIL visual editor. The sidecar remains pending verified editor integration seams.
- Full workspace test failures caused by existing fixture expectations and missing unpacked dependencies are documented in the technical audit.
- Android 5 compatibility is not established by a minSdk declaration. Current Three.js WebGL renderer requires a compatible WebGL2 context; a separate legacy backend is still needed.
