# MUNGIL Run 13

Run 13 continues Run 12 with bounded image preview and Sprite-to-Asset-Vault assignment. Open `../mungil-studio-run13.html` for the standalone Studio. The engine source is in `aetherfall-workspace/src/game/runtime`.

See `RUN13_IMPLEMENTATION_ADDENDUM.md`, `RUN13_TECHNICAL_AUDIT.md`, `ENGINE_REFERENCE_RESEARCH_RUN13.md`, and `LAYER_CAPABILITY_MATRIX_RUN13.md` for implementation, limits, references and capability status.

Validation: 69/69 runtime tests, strict runtime TypeScript check, browser runtime smoke, Studio inline script syntax and four ZIP integrity checks passed. No Android APK/AAB was built.
