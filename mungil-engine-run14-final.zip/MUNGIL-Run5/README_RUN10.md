# MUNGIL Run 10

Run 10 adds scene editor core, transactional batch history, bounded agent knowledge memory, Studio panels for scene hierarchy/inspector and knowledge search, plus Android WebViewAssetLoader hardening.

Start with:
- `RUN10_IMPLEMENTATION_ADDENDUM.md`
- `RUN10_TECHNICAL_AUDIT.md`
- `LAYER_CAPABILITY_MATRIX_RUN10.md`
- `ENGINE_REFERENCE_RESEARCH_RUN10.md`

Runtime tests: 57/57 pass. Browser bundle build and smoke test pass. Android release APK/AAB is not built; SDK Platform 36 is missing in the build environment.
