# MUNGIL Run 8 — Game Generator Platform Foundation

## Delivered in this increment

### 1. Browser-first MUNGIL Studio prototype
- `aetherfall-workspace/platform/index.html`: responsive mobile-first game generator workspace.
- Prompt input with genre/style/dimension inference, target profile selection, specialist-agent pipeline visualization, Canvas2D preview, editable keyboard bindings, deadzone control, audio mix controls, local project save and JSON manifest export.
- `platform/manifest.webmanifest`, `platform/sw.js`, and 192/512 PNG icons provide an installable-PWA shell when hosted over HTTPS or localhost.
- The prototype's generator is intentionally deterministic and local. It does not call a hosted LLM, generate art/music, or produce native app builds.

### 2. Runtime generator orchestration
- `src/game/runtime/generator/agent-pipeline.ts`: bounded prompt parser, project brief classification, ten-stage production plan, role assignment, dependency checks, sequential execution, abort handling and progress events.
- `AgentProvider` is the integration boundary for a real model/tool provider. No provider credentials or network backend are embedded.

### 3. Input and audio systems
- `controller-map.ts`: validated serializable action maps for touch/keyboard/gamepad, remapping, deadzone normalization and standard Gamepad snapshot adapter.
- `audio-manager.ts`: Web Audio mixer with explicit user-gesture unlock, master/music/SFX/ambience/UI buses, bounded clip registry, per-clip and global voice limits, fade stop, suspend/resume and disposal.
- Audio mixer has not yet been exercised against real Android WebView/browser audio devices.

### 4. Validation
- Runtime suite: 39/39 passing with Node's experimental TypeScript stripping.
- MUNGIL editor sidecar tests: passing.
- MUNGIL MCP smoke tests: passing when run from `mungil-editor-sidecar/`.
- Browser app JavaScript syntax check and HTML parser check: passing.
- Full workspace TypeScript check is blocked because dependencies/type definitions are not installed in this extracted workspace (`@types/node`, `vite/client`).
- Headless Chromium smoke attempt timed out; no visual browser/device test is claimed.
- Original MUNGIL HTML baseline SHA-256 remains `bd12f920c02c487cee9cc8617f2272dd57ddf489b232edd75c58ea8dffca8a53`.
- Original Archipelago Drift sample SHA-256 remains `a4a56f2e6cc516c0bdbf8e255782252d62358227d450853b60af2ca677d98911`.

## Explicit limitations
- The browser prototype is a UI/preview shell, not a finished Instaplay-equivalent cloud platform.
- Real AI inference, asset generation, music/SFX synthesis, collaboration, hosted storage, authentication, billing, job queues, server-side sandboxing and real export compilers are not connected.
- The Canvas preview is a lightweight illustrative 2D scene; it is not a full 2.5D/3D game renderer.
- Export UI currently emits a project manifest JSON. It does not compile APK/AAB, iOS, desktop, console or social-media video packages.
- Android/iOS/desktop/web and social distribution are targets in the roadmap, not universal support claims. Console distribution depends on proprietary platform SDKs and approvals.
- The original MUNGIL editor and Aetherfall workspace remain separate codebases. No brittle patch was applied to the original compiled editor.

## Next engineering gates
1. Implement an authenticated provider adapter and isolated job runner with quotas, cancellation, retries, output validation and human approval checkpoints.
2. Build asset import/transform pipeline: image/audio metadata, sprite atlases, audio transcodes, glTF validation, KTX2/Basis transcode variants and content hashes.
3. Add browser automation for prompt flow, save/load, controller remapping, PWA offline shell and memory/long-session checks.
4. Add WebGL2 2D/2.5D batch adapter; keep perspective 3D on a dedicated renderer path and keep Canvas2D as an honest 2D/2.5D fallback only.
5. Implement export adapters in phases: Web first, Android via reproducible CI/SDK build, then desktop/iOS with platform toolchains.
6. Measure on physical itel A70 before changing Tier 0 budgets. Do not use desktop timings as a proxy for phone performance.
