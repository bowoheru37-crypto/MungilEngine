# MUNGIL Run 9 — Technical Audit

## 1. Architecture decision
Use one project/document contract and one runtime lifecycle, but keep renderer, physics, asset and audio implementations behind adapters. Do not merge unrelated complete engines or load all high-cost systems into every project. Project genre/style kits are configuration and budgets, not proof that every game mechanic is implemented.

## 2. Run 9 risk review

| Area | Current state | Risk / next action |
|---|---|---|
| World scale | 1km cell coordinates, relative conversion, origin rebasing | Add camera/physics integration and precision tests at extreme cell boundaries |
| Jobs | Sequential bounded agent pipeline | Keep concurrency 1 on low-tier devices; add workers only for measured CPU-bound offline work |
| Memory | Byte-accounted LRU and bounded project/history/output structures | No 16GB device budget; establish per-tier budgets from measurements |
| Determinism | Fixed-step clock and seeded RNG | Floating-point physics is not cross-platform deterministic; fixed-point simulation/replay not implemented |
| Telemetry | No production crash telemetry | Add opt-in, privacy-preserving crash reports only after consent and data minimization |
| Asset import | Manifest validation and build recommendations | Add real image/audio/model decoders, malware scanning, archive-bomb limits, hashing and transcoding workers |
| PBR / virtual texture | Not implemented | Use tier-specific baked maps/atlases first; virtual texturing is not a low-end default |
| World simulation | Not implemented beyond reusable spatial broadphase | Add chunk streaming, schedules and ecosystem only as opt-in genre modules |
| Physics | Collision helpers and broadphase exist in separate runtime/editor code | No unified production physics solver; exact narrowphase, constraints and 3D solver still needed |
| Rendering | Canvas2D plus WebGL2 primitive batch | WebGL2 backend is not a full 3D renderer; add texture atlas, sprite batching, text/image pass, then separate perspective adapter |
| GI / RT / Nanite / Lumen | Not implemented | Use baked lightmaps, probes, LOD, culling and low-cost approximations; no RT on A70 target |
| Animation | No integrated production animation graph | Add sprite timelines first, then skeletal 2D/3D, IK and retargeting as separate optional systems |
| Gameplay AI | Prompt planning and provider contract only | NPC perception, tactical AI, dialogue memory and schedules are not implemented |
| Audio | WebAudio bus mixer exists | Need asset decode/streaming, music stem transitions, spatial audio and real audio tests |
| Controller | Editable map, deadzone and gamepad mapping | Add touch-layout editor persistence, accessibility and per-project profiles |
| Network | No authoritative multiplayer server | Do not claim 120Hz, 100-player or anti-cheat support |
| Editor | Project document, hierarchy validation, bounded undo/redo | Sidecar is not integrated into original MUNGIL editor state/undo/persistence seam |
| Distribution | PWA package and Android WebView source scaffold | No verified APK/AAB, iOS/desktop native exporters or social network publishing |

## 3. User-provided system count reconciliation
The supplied table names layers 0 through 10, which is **11 named layers**, and its listed entries total **51 systems**, not 12 layers / 54 systems. Run 9 proposes a new Layer 11 with three distribution/operations systems in `LAYER_CAPABILITY_MATRIX_RUN9.md`; this makes the proposed roadmap 12 layers / 54 system slots. It does not mean 54 systems or 300+ modules have already been implemented.

## 4. Low-end device profile
The official itel A70 specification lists T603 octa-core, Android 13 Go, 720×1612 display, 5000mAh battery and extended-RAM configurations. A70 RAM variants are low-end compared with desktop/game-authoring machines. Treat extended RAM as storage-backed expansion, not as an equivalent physical RAM budget.

Recommended starting tier (engineering target, not a measured benchmark):
- 30 FPS baseline; 60 FPS only when sustained profiling supports it.
- Render scale 1.0 or lower; avoid high-DPI overdraw.
- 512px texture ceiling for low tier; atlas sprites and nearest filtering for pixel art.
- 0 real-time dynamic lights, baked lighting, small particle and audio-voice caps.
- Chunked/lazy asset loading, bounded caches, explicit disposal, one generation task at a time.
- Thermal-aware quality reduction; preserve UI touch target dimensions when reducing game render resolution.

## 5. Android 5+ interpretation
`minSdk 21` only sets the installation floor. It does not guarantee a modern JavaScript/WebGL2 feature set in every old Android System WebView. The wrapper includes a syntax gate and a small Canvas2D legacy page; feature parity with modern Studio is intentionally not claimed for Android 5. Validate on actual API21 WebView builds before claiming support.

## 6. Binary and assembly
The web runtime is TypeScript compiled to JavaScript and bundled for browser/WebView. The Android wrapper uses the normal Gradle → D8/R8 → DEX/APK/AAB pipeline. Hand-written ARM assembly is not justified for this workload and would increase ABI, security and maintenance cost. Consider NDK/native code only after profiling proves a specific hot path cannot meet its budget in JavaScript/WebGL or platform APIs.

## 7. Security posture
- Imported asset paths reject absolute paths, backslashes, encoded paths, traversal segments and control characters.
- Asset descriptors enforce MIME-kind pairing, duplicate rejection, byte and dimension limits, optional SHA-256 format.
- Agent output rejects accessors, non-plain objects, prototype-sensitive keys, non-finite numbers and oversized/deep structures.
- Android WebView blocks cleartext and does not enable universal/file-to-file access. No remote origin is loaded.
- Local browser storage remains user-controlled and can be cleared by the OS; do not store credentials or secrets in project manifests.

## 8. Non-guarantees
No software can be certified “zero bugs”, “zero GC”, “zero crash”, “no heat”, “no lag” or “fully supports all genres/art styles” by static code review alone. JavaScript garbage collection is runtime-managed. The only valid performance claim is one backed by repeatable physical-device profiling and crash/session telemetry.
