# MUNGIL Run 11 — Reference Research

These references inform architecture choices; they are not copied engine implementations. Check each repository's current license, version, platform matrix and maintenance state before pinning dependencies.

## Asset validation and interchange
- Khronos glTF Validator: https://github.com/KhronosGroup/glTF-Validator — full glTF 2.0 validation reports; checks JSON/GLB structure, references, binary buffers, accessors, animation data, images and extensions. Use in CI/build validation rather than as a substitute for bounded intake.
- Khronos glTF specification and sample assets: https://github.com/KhronosGroup/glTF — interchange baseline and test assets.
- Khronos KTX-Software: https://github.com/KhronosGroup/KTX-Software — KTX/KTX2 tools, libraries and transcoders; use optional build-time and runtime adapters only when the target GPU format is supported.
- Three.js GLTFLoader documentation: https://threejs.org/docs/#examples/en/loaders/GLTFLoader — documents glTF extension support and explicit bitmap/resource disposal requirements.

## Browser renderer references
- PixiJS renderer documentation: https://github.com/pixijs/pixijs — renderer architecture covering WebGL/WebGL2, WebGPU and Canvas 2D. Use as a reference for renderer adapters and resource systems; do not bundle it beside a duplicate renderer without a concrete need.
- Phaser: https://github.com/phaserjs/phaser — HTML5 2D framework with Canvas/WebGL rendering and web/mobile workflows. Useful as a gameplay/editor UX and browser compatibility reference; do not replace the existing runtime without migration evidence.
- Three.js: https://github.com/mrdoob/three.js — optional 3D renderer reference; use GLTFLoader only in the 3D-capable profile and retain explicit GPU/bitmap disposal.

## Android performance and lifecycle
- Android Developers — improve performance: https://developer.android.com/topic/performance/improving-overview — optimize for low-RAM and Android Go devices, including startup, rendering, memory, battery and app size.
- Android Developers — WebView: https://developer.android.com/develop/ui/views/layout/webapps/webview — WebView has multi-process/native memory overhead; reuse and destroy instances correctly, and prevent unnecessary popup windows.
- Android Developers — WebView memory: https://developer.android.com/topic/performance/memory/guide/webview-memory — inspect both app and WebView renderer process memory when profiling.

## Adoption policy
- Treat PixiJS, Phaser, Three.js, KTX-Software and glTF Validator as reference projects or optional adapters, not modules to merge wholesale.
- Keep one runtime authority, one active renderer per project, one asset ownership model and explicit cleanup contracts.
- Pin exact releases and licenses during a dependency-adoption task; this run does not add any new npm dependency.
