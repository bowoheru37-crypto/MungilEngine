# MUNGIL Run 12 — Technical Audit

## Addressed
- Run 11 only inspected file signatures and metadata; Run 12 persists accepted original file blobs in IndexedDB.
- Storage growth is bounded by explicit tier limits, per-asset limits, entry count, LRU eviction, and pin protection.
- Concurrent writes are serialized to avoid capacity-planning races between simultaneous `put()` calls.
- Storage estimate and IndexedDB write failures are returned to the Studio rather than silently ignored.
- Persistent origin storage is opt-in through an explicit user-triggered UI action and is not requested during page load.

## Residual risks
- `navigator.storage.estimate()` is advisory and can be stale; it cannot reserve disk capacity. IndexedDB may still fail later.
- Browser origin storage remains best-effort unless persistent storage is granted; user-cleared data remains unrecoverable without export/backup.
- IndexedDB transaction behavior is implemented but not yet covered by a real-browser automated test in this increment.
- Blob persistence is not media decoding. Image/audio/model decode, memory ownership, GPU disposal, and renderer binding remain separate tasks.
- Existing glTF header checks are not a substitute for Khronos glTF Validator.
- Physical itel A70 / Android Go / API 21 tests, Android lint/build/signing, and APK/AAB release remain outstanding.

## Mobile policy
- Default Studio import uses Tier 0: 8 MiB maximum per asset, 24 MiB per batch, 2048 px image dimension.
- Preserve sequential import and avoid simultaneous full-resolution decode.
- Keep user-visible storage usage and deletion controls; never imply browser storage is a guaranteed backup.
