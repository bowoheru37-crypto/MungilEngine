# MUNGIL — Layer Capability Matrix (Run 14)

Legend: **Implemented** means a bounded code path exists with targeted tests; **Partial** means only selected foundations or one vertical slice exists; **Planned** means no production implementation; **High-end/server only** means the feature must not be assumed on Tier 0 Android. The 12th layer is distribution/operations added to the supplied Layers 0–10 roadmap; this is a roadmap grouping, not a claim of 54 complete systems.

| Layer | System group | Status | Run 14 implementation / exact boundary |
|---|---|---|---|
| 0 Foundation | scale, scheduling, memory, deterministic sim, crash telemetry | Partial | Fixed-step clock, seeded RNG, cell-scale coordinates/origin rebasing, resource scopes, bounded pools and LRU exist. Local agent tasks now execute sequentially in dependency order. No 128-worker fibers, 16GB budget or production crash/minidump telemetry. |
| 1 Asset pipeline | scan, materials, virtual textures, high-end geometry, validation | Partial | Manifest/signature intake, Asset Vault, bounded image preview, deterministic 512px atlas pack/composition, local glTF structural preflight. No photogrammetry/LiDAR, PBR+ renderer, 256K virtual textures, Nanite-style micro-poly or bundled Khronos validator. |
| 2 World simulation | streaming, climate, ecosystem, physics, crowd, procedural detail | Partial | World-scale math, origin rebasing, spatial broadphase and bounded helper systems. No full world streamer, climate/ecology, erosion, cloth/fluid/destruction solver or 10k living NPCs. |
| 3 Rendering | GI, shadows, reflection, sky, water, hair/skin, postprocess | Partial | Canvas2D compatibility renderer and WebGL2 2D/2.5D geometry + textured atlas sprite batching. No general perspective 3D renderer, GI, ray tracing, volumetrics, FFT ocean, strand hair, SSS or cinematic post stack. |
| 4 Character & animation | facial, motion matching, IK, deform, damage | Planned | Sprite clips support loop/once/ping-pong only. No skeletal database, FACS, IK, muscle/cloth or injury model. |
| 5 AI & gameplay | perception, tactics, scheduler, dialogue, combat | Partial | Local prompt planner, sanitization, bounded local knowledge store, skill outcome tracking and sequential dependency-aware task scheduler. No hosted LLM inference, autonomous training, NPC perception/tactics/dialogue or ballistic combat. |
| 6 Audio | spatial, reverb, dynamic score, foley | Partial | WebAudio buses/voice caps and bounded short-clip decode/preview. No HRTF, material convolution, adaptive BGM stems or full foley catalogue; long BGM streaming still needs a media-element path. |
| 7 Interaction & deep gameplay | context action, survival, vehicle, crime/law | Planned | Project node properties and controller action mapping provide editor foundations only; these game systems are not implemented. |
| 8 Network & persistence | authoritative networking, world persistence, anti-cheat | Partial | Local versioned project data and IndexedDB Asset Vault. No multiplayer authority, rollback, world persistence service or anti-cheat. |
| 9 Editor & dev tools | world editor, cinematic, profiler | Partial | Hierarchy, inspector, project history, local vault, sprite atlas PNG/JSON export, runtime APIs and constrained HTML5 platformer exporter. No terrain paint, sequencer, shader graph, full animation timeline or GPU profiler. |
| 10 Accessibility & polish | photo mode, accessibility, quality | Partial | Touch-first responsive shell, controller mapping, quality tiers and legacy Canvas2D fallback. Full accessibility audits, color-vision UI suite and photo mode are incomplete. |
| 11 Distribution & operations | web/native packaging, release operations | Partial | PWA shell and Android WebView source scaffold synchronized with Studio. No signed APK/AAB or end-device certification; only constrained HTML5 2D export is currently playable. |

## Device tiers
- **Tier 0 — itel A70 / entry Android:** design target only until measured. Use 30 FPS target, one active asset decode, small 512px atlas pages, small particle/voice budgets, Canvas2D fallback and static lighting. 30 FPS is not a measured result.
- **Tier 1 — mid-range:** allow more visible sprites, larger content packs and optional WebGL2 features after profiling.
- **Tier 2 — high end:** candidate for perspective 3D renderer, more complex material/lighting and larger simulations once implemented.
- **Build/server:** suitable for AI inference, photogrammetry, high-cost asset transcoding, large-world baking and multiplayer authority.

Android 5 API 21 is the wrapper's minimum install target, not a promise that each browser feature or WebGL2 path works in every old WebView.
