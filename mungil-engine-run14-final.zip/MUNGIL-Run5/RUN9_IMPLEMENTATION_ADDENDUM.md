# MUNGIL Run 9 — Implementation Addendum

## Scope
Run 9 continues the Run 8 workspace. It does not replace the original MUNGIL HTML editor or merge the separate Aetherfall Three.js application into it. Original baseline remains at `mungil-editor-sidecar/baseline/source.original.html`.

## Implemented

### Runtime and rendering
- `aetherfall-workspace/src/game/runtime/renderers/webgl2-2d.ts`
  - WebGL2 batch renderer for solid rect, circle, line and convex/fan-triangulated polygon primitives.
  - Bounded scene command count and vertex buffer; deterministic hex-color parser; stable layer ordering.
  - Reusable typed vertex buffer, low-power context request, explicit shader/program/buffer cleanup, resize caps, context-loss/restore handling.
  - Scope is 2D/2.5D primitives. It is not a perspective 3D renderer and does not yet draw text, image textures, skeletal meshes, PBR or post-processing.
- `world-scale.ts`
  - 1km cell coordinates with normalized local offsets, safe-integer cell checks, world translation, bounded relative coordinates and render-origin rebasing.
  - Keeps world coordinates in JS Number precision and emits nearby render-local coordinates; this is not a complete double-precision physics engine.
- Existing Canvas2D backend remains available as fallback for 2D/2.5D.

### Generator and security
- `generator/agent-pipeline.ts`
  - Provider output is now retained and passed to downstream tasks.
  - Output is recursively bounded to 64KiB, depth 12, bounded arrays/keys/strings; non-finite values, accessors, non-plain objects and prototype-sensitive keys are rejected.
  - Event callback exceptions do not abort generation. Provider cancellation is checked after awaited tasks.
  - Scheduler intentionally runs one provider task at a time. No external AI provider is configured.
- `asset-pipeline.ts`
  - Validates asset IDs, safe relative paths, MIME-kind pairing, duplicate IDs/paths, SHA-256 format, dimensions, per-file and total byte budgets.
  - Produces deterministic conversion recommendations (Basis, WebP, Opus, gzip). It does not perform the transcoding itself.

### Browser Studio integration
- Added a browser runtime entry and bundler:
  - `src/game/runtime/browser-entry.ts`
  - `scripts/build-runtime-browser.mjs`
  - `scripts/test-runtime-browser.mjs`
- Built `platform/runtime/mungil-runtime.js` as a dependency-free browser bundle (19 runtime modules, 112,459 bytes at this run).
- `platform/index.html` now imports the runtime bundle, uses the real local prompt planner and bounded sequential scheduler, and selects WebGL2 primitive rendering with Canvas2D adapter fallback.
- 3D prompts are identified, but the Studio preview explicitly reports that its perspective 3D renderer is pending; it does not pretend a 2D scene is 3D.
- UI generation is still local planning. No cloud model, image model, music model, AI tool-calling service, or generation backend is connected.

### Android shell
- `android/` is a source scaffold, not a built APK.
- `minSdk 21`, `compileSdk/targetSdk 36`, AGP 8.13.0, Gradle 8.13, Java 17, versionName 0.9.0/versionCode 9.
- WebView loads bundled local assets with JavaScript and DOM storage; cleartext traffic disabled; no network permission or remote code loading.
- `feature-modern.js` probes optional-chaining syntax. Newer WebViews load Studio; older WebViews route to `legacy.html`, an ES5-style Canvas2D local planner.
- Legacy mode is deliberately limited: it does not offer WebGL2, perspective 3D, AI network generation, remote assets, or native export.
- Release script enforces `--warning-mode fail`, lint warnings as errors, signed APK/AAB output and signature verification.

## Validation performed
- Runtime tests: 49/49 pass.
- Strict TypeScript check of runtime exports: pass.
- Browser bundle test: pass (runtime global, prompt planning, WebGL2 tessellation).
- Studio inline JavaScript syntax: pass.
- Android legacy and syntax-probe JavaScript syntax: pass.
- MUNGIL sidecar test suite: pass.
- MCP smoke test: pass when run from `mungil-editor-sidecar/` (the script uses a working-directory-relative path).
- Original MUNGIL source SHA-256 unchanged: `bd12f920c02c487cee9cc8617f2272dd57ddf489b232edd75c58ea8dffca8a53`.

## Not validated / release blockers
- Full application tests: two suites cannot load because workspace dependencies `@tanstack/react-start` and `jose` are not installed; other observed suites pass. Do not call the full suite green.
- Full application typecheck/build: not run; node_modules are absent.
- Android build: blocked because Android SDK Platform 36, Build Tools 36.0.0, Gradle 8.13, JDK 17 environment and release signing key are absent. Host Java is 21, not configured JDK 17.
- No APK/AAB, browser screenshot test, WebView API21 device test, Android 13 Go test, itel A70 device test, thermal test or frame-time measurement was produced.
- WebGL2 shader execution was not tested on a real GPU; unit tests cover scene validation and CPU tessellation, not GPU correctness/performance.
- AI provider integration, asset transcoding, multiplayer backend, native platform exporters, social publishing and production telemetry remain absent.
