# MUNGIL Run 11

Run 11 continues Run 10 and adds a bounded, offline asset intake preflight to the TypeScript runtime and Studio UI.

## Open / download
- Standalone Studio: `/mnt/data/mungil-run10/mungil-studio-run11.html`
- Full engine source: `/mnt/data/mungil-run10/mungil-engine-run11-final.zip`
- Runtime-only package: `/mnt/data/mungil-run10/mungil-runtime-run11.zip`
- PWA package: `/mnt/data/mungil-run10/mungil-studio-run11-pwa.zip`
- Android source scaffold: `/mnt/data/mungil-run10/mungil-android-run11-scaffold.zip`

## Run 11 validation
- 63/63 runtime tests pass.
- TypeScript strict runtime check passes.
- Browser bundle build and smoke test pass.
- Standalone Studio inline JavaScript syntax passes.
- Android Studio asset is byte-identical to the standalone Studio.
- Android manifest XML and PWA manifest JSON parse successfully.

## Not completed
- Android APK/AAB release build: SDK Platform 36 is missing from the build environment.
- Physical itel A70 / Android Go / API 21 device testing.
- Full glTF validation, actual image/audio/model decoding, transcoding, IndexedDB persistence, renderer-bound asset loading, and playable HTML5 project export.
- Remote LLM/agent provider, hosted asset pipeline, social publishing, or multiplayer backend.

See `RUN11_IMPLEMENTATION_ADDENDUM.md`, `RUN11_TECHNICAL_AUDIT.md`, and `ENGINE_REFERENCE_RESEARCH_RUN11.md`.
