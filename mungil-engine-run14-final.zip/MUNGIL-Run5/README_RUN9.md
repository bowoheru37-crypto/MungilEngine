# MUNGIL — Run 9

Run 9 builds on Run 8. Start here:

- `RUN9_IMPLEMENTATION_ADDENDUM.md` — implemented code and validation results.
- `RUN9_TECHNICAL_AUDIT.md` — architecture decisions, security, compatibility and release blockers.
- `LAYER_CAPABILITY_MATRIX_RUN9.md` — implementation status for the requested 12-layer / 54-slot roadmap.
- `ENGINE_REFERENCE_RESEARCH_RUN9.md` — device, Android, WebGL and engine references.
- `android/README.md` — Android 5+ WebView shell source and guarded release build instructions.
- `aetherfall-workspace/src/game/runtime/` — runtime modules.
- `aetherfall-workspace/platform/` — website/PWA source and generated browser runtime bundle.

## Important status
- The website is a local-first generator prototype with an actual runtime bundle, bounded local planner/scheduler, and WebGL2 2D/2.5D primitive preview plus Canvas2D fallback.
- It does not yet call a real AI provider or generate production assets/code automatically.
- The Android source scaffold targets API 21+, but no APK/AAB could be built in this environment because Android SDK, Gradle, JDK 17 and release signing credentials are absent.
- The WebGL2 batch backend is not a perspective 3D renderer. Existing Three.js Aetherfall remains a separate workspace.
- No physical itel A70 or Android 5 device benchmark has been performed.

See the audit documents before treating this as a production release.
