# MUNGIL Engine Reference Research — Run 10

This increment adds references that directly inform scene editing, memory safety, low-RAM Android, asset validation, WebView security and multi-agent orchestration. References are recommendations, not code copied into the runtime. Check each repository's current license and version before adopting code.

## Low-RAM Android and profiling
- Android Developers — Improve performance, including low-RAM and Android Go guidance: https://developer.android.com/topic/performance/improving-overview
- Android Developers — Diagnose stability, slow rendering, startup and memory: https://developer.android.com/topic/performance/issues
- Android Developers — Measuring app performance: https://developer.android.com/topic/performance/measuring-performance

## WebGL / renderer lifecycle
- MDN — WebGL best practices: https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API/WebGL_best_practices
  - Explicit GPU resource deletion, conservative VRAM budgets, context-loss handling, quality tiers, compressed textures.

## Asset formats and validation
- Khronos — glTF 2.0 specification: https://github.com/KhronosGroup/glTF
- Khronos — KHR_texture_basisu: https://github.com/KhronosGroup/glTF/tree/main/extensions/2.0/Khronos/KHR_texture_basisu
- Khronos — glTF-Validator: https://github.com/KhronosGroup/glTF-Validator
  - Validates glTF JSON, GLB structure, internal references, accessors, animation, images and extension data.

## Audio
- MDN — AudioWorklet: https://developer.mozilla.org/en-US/docs/Web/API/AudioWorklet
- MDN — Background audio processing with AudioWorklet: https://developer.mozilla.org/en-US/docs/Web/API/Web_Audio_API/Using_AudioWorklet

## Multi-agent orchestration
- OpenAI API — Function calling: https://developers.openai.com/api/docs/guides/function-calling
- OpenAI API — Tools overview: https://developers.openai.com/api/docs/guides/tools
- OpenAI API — Programmatic Tool Calling: https://developers.openai.com/api/docs/guides/tools-programmatic-tool-calling
  - Tool calls need application-side execution, schema validation, authorization and bounded outputs. Tool calling does not itself grant safe access to arbitrary project files or build commands.

## Android WebView security / API compatibility
- Android Developers — WebViewAssetLoader: https://developer.android.com/reference/androidx/webkit/WebViewAssetLoader
- Android Developers — WebView unsafe file inclusion: https://developer.android.com/privacy-and-security/risks/webview-unsafe-file-inclusion
- AndroidX WebKit release notes: https://developer.android.com/jetpack/androidx/releases/webkit
  - WebViewAssetLoader uses an HTTPS-like reserved appassets origin. WebKit 1.15 raises minSdk to 23; 1.16 raises it to 24. Run 10 therefore selects stable 1.14.0 for the API 21 floor.

## Integration strategy
1. Adopt glTF-Validator as a build-time validation tool only after checking npm package version/license and pinning it.
2. Evaluate KTX2/Basis transcoding in an offline build worker; runtime must transcode only to supported GPU formats and retain a fallback when needed.
3. Use AudioWorklet only for custom processing on secure contexts and feature-detect it; keep the WebAudio node graph as fallback.
4. Build model provider adapters around strict function schemas, output sanitization, per-tool allowlists, timeouts, cancellation and audit logs.
5. Keep WebViewAssetLoader dependency at an API21-compatible release unless the app minSdk is deliberately raised.
