# MUNGIL Run 11 — Implementation Addendum

## Scope
Run 11 continues from Run 10 without replacing the project document, runtime kernel, renderer adapters, scene editor, agent knowledge base, or Android wrapper. The increment focuses on a bounded asset-intake preflight.

## Implemented
- Added `inspectAssetFiles()` to `src/game/runtime/asset-pipeline.ts`.
- Sequential file inspection with cancellation checks between reads.
- Hard limits: 64 files, 32 MiB per file, 96 MiB total, 4096 px image dimensions, 2 MiB JSON/glTF text.
- Format detection from file signatures rather than the browser-provided MIME label.
- Initial signature support: PNG, JPEG, WebP, GIF, KTX2, WAV, Ogg, MP3, GLB v2, glTF 2.0 JSON, WOFF, WOFF2, TTF, MP4 and WebM.
- SHA-256 digest via Web Crypto; fail closed if SubtleCrypto is unavailable.
- Rejects unsafe filenames, invalid/unsupported signatures, inconsistent file size, oversized input, malformed dimensions, and cancelled work.
- Added `asset-pipeline.test.ts` with six tests.
- Added Studio panel `Asset intake & validation`, copied into the Android WebView Studio asset.
- Browser runtime bundle rebuilt and embedded in standalone Studio and Android Studio.

## Important boundaries
This is an intake/preflight stage, not a complete importer. It does not persist raw file bytes, decode or transcode media, validate all glTF buffer/accessor/animation references, inspect archives, scan malware, generate atlases, load models into the renderer, or create CDN upload records. The Studio panel explicitly communicates this.

GLB checking is a bounded header/first-JSON-chunk sanity check only. Use the official Khronos glTF Validator in a build/CI stage for full glTF 2.0 validation, including internal references, buffers, accessors, animations, images and extensions.

The SHA-256 path reads one file at a time, but still allocates an ArrayBuffer for the current file. The 32 MiB per-file and 96 MiB total ceilings are guardrails, not a guarantee of memory availability on every Android WebView. Reduce these defaults for constrained devices after physical profiling.

## Validation
- Runtime TypeScript strict check: passed.
- Runtime test suite: 63/63 passed (57 previous tests + 6 asset intake tests).
- Browser bundle build: passed, 21 modules, 140,790 bytes.
- Browser bundle smoke: passed.
- Standalone Studio inline JavaScript syntax: passed (2 inline scripts).
- Android Studio asset matches standalone Studio byte-for-byte.
- Android manifest XML and PWA manifest JSON: parsed successfully.
- ZIP integrity: passed for all four Run 11 archives.
- Chromium headless DOM capture was attempted but timed out in this environment; no visual UI pass is claimed.
- Physical Android/API 21/itel A70 tests: not run.
- Android APK/AAB: not built; Android SDK Platform 36 remains unavailable in the build environment.

## Next engineering increments
1. Persist imported blobs in a bounded IndexedDB asset vault with quota-aware eviction and explicit user deletion.
2. Add full glTF validation using a pinned Khronos validator build in CI, not the mobile runtime hot path.
3. Add decoder adapters for images/audio/glTF, all with cancellation and disposal ownership.
4. Bind image/sprite assets to the preview renderer and add a texture/sprite animation timeline.
5. Add real build/export packaging for a playable 2D/2.5D HTML5 vertical slice.
