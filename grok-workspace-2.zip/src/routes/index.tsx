import { createFileRoute } from "@tanstack/react-router";
import { KilatApp } from "@/game/KilatApp";

export const Route = createFileRoute("/")({ component: KilatApp });
