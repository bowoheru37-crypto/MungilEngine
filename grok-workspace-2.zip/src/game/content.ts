import { FLOOR, MAP_H, TILE, type Level, type Project, type Relic, type Stamp } from "@/engine/types";
import { packTiles } from "@/engine/pack";

export const OP = {
  face: 1,
  wait: 2,
  hop: 3,
  speed: 4,
  goto: 5,
  turn: 6,
} as const;

export const HOPPER_PROG = [
  OP.face,
  OP.wait,
  50,
  OP.hop,
  OP.speed,
  72,
  OP.wait,
  26,
  OP.speed,
  0,
  OP.wait,
  16,
  OP.goto,
  0,
];

const OP_NAME: Record<number, string> = {
  1: "hadap pemain",
  2: "tunggu",
  3: "lompat",
  4: "laju",
  5: "ulang",
  6: "balik",
};

export function disasm(prog: number[]): string[] {
  const lines: string[] = [];
  let i = 0;
  while (i < prog.length) {
    const op = prog[i] ?? 0;
    const at = String(i).padStart(2, "0");
    if (op === OP.wait || op === OP.speed || op === OP.goto) {
      lines.push(`${at}  ${OP_NAME[op] ?? "?"} ${prog[i + 1] ?? 0}`);
      i += 2;
    } else {
      lines.push(`${at}  ${OP_NAME[op] ?? "op " + op}`);
      i += 1;
    }
  }
  return lines;
}

export function rankFor(score: number): string {
  if (score >= 700) return "Juru senja";
  if (score >= 480) return "Penjaga lentera";
  if (score >= 260) return "Kurir malam";
  return "Pemula atap";
}

export function scoreOf(embers: number, foes: number, time: number, won: boolean): number {
  const clear = won ? 400 + Math.max(0, Math.floor(80 - time)) * 4 : 0;
  return embers * 25 + foes * 50 + clear;
}

export function relicMods(relic: Relic) {
  if (relic === "sepatu") return { speed: 118, pulseW: 20, hp: 3 };
  if (relic === "lentera") return { speed: 100, pulseW: 30, hp: 3 };
  return { speed: 100, pulseW: 20, hp: 4 };
}

export const RELICS: { id: Relic; name: string; hint: string }[] = [
  { id: "sepatu", name: "Sepatu ringan", hint: "Langkah lebih panjang" },
  { id: "lentera", name: "Lentera lebar", hint: "Denyut meraih lebih jauh" },
  { id: "napas", name: "Napas cadangan", hint: "Satu nyala tambahan" },
];

export const STORY = [
  "Malam ini lentera pasar tidak mau diam.",
  "Kau kurirnya. Atap basah, bayangan lapar.",
  "Denyut kecil membuyarkan ngengat dan peloncat.",
  "Sampai di bendera senja, tugas selesai.",
];

export const SYSTEMS = [
  {
    title: "Langkah tetap",
    body: "Fisika berjalan 60 kali per detik. Gambar menyusul di antara langkah, jadi lompatan tetap sama di layar 30 maupun 60.",
  },
  {
    title: "Gambar kecil",
    body: "Dunia digambar di kanvas kecil lalu dibesarkan utuh. Ponsel kelas awal, termasuk Itel A70, tidak memproses piksel layar penuh.",
  },
  {
    title: "Peta panggang",
    body: "Ubin dipanggang sekali. Mengambil bara hanya menghapus satu petak, bukan menggambar ulang seluruh atap.",
  },
  {
    title: "Kamera kedalaman",
    body: "Bulan, atap jauh, dan jemuran bergeser lebih lambat dari lapangan. Kedalaman semu tanpa kartu grafis.",
  },
  {
    title: "Bytecode penjaga",
    body: "Peloncat menjalankan daftar perintah pendek: hadap, tunggu, lompat, laju, ulang. Bukan skrip bebas — murah dan tetap.",
  },
  {
    title: "Fisika kurir",
    body: "Waktu coyote, simpan lompat, gravitasi lebih berat saat jatuh, pijakan searah, dan naik satu ubin otomatis.",
  },
  {
    title: "Paket RLE",
    body: "Ekspor studio merapatkan ubin berulang jadi teks pendek, lalu bisa dimuat lagi di mesin yang sama.",
  },
];

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function shuffle<T>(list: T[], rnd: () => number) {
  for (let i = list.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    const a = list[i] as T;
    list[i] = list[j] as T;
    list[j] = a;
  }
  return list;
}

const CHUNK = 18;

function idx(w: number, x: number, y: number) {
  return y * w + x;
}

function fillGround(tiles: Uint8Array, w: number, x0: number, x1: number, from = FLOOR) {
  for (let x = x0; x <= x1; x++) {
    if (x < 0 || x >= w) continue;
    for (let y = from; y < MAP_H; y++) tiles[idx(w, x, y)] = 1;
  }
}

function setTile(tiles: Uint8Array, w: number, x: number, y: number, id: number) {
  if (x < 0 || y < 0 || x >= w || y >= MAP_H) return;
  tiles[idx(w, x, y)] = id;
}

function dig(tiles: Uint8Array, w: number, x0: number, x1: number) {
  for (let x = x0; x <= x1; x++) {
    for (let y = FLOOR; y < MAP_H; y++) setTile(tiles, w, x, y, 0);
  }
}

function stamp(k: Stamp["k"], tx: number, ty: number, extra?: Partial<Stamp>): Stamp {
  const x = tx * TILE;
  const y = ty * TILE;
  return {
    k,
    x,
    y,
    minX: extra?.minX ?? x,
    maxX: extra?.maxX ?? x,
  };
}

type ChunkId = "flat" | "gap" | "stairs" | "hopper" | "moth" | "spikes" | "lift" | "finale";

function paintChunk(id: ChunkId, tiles: Uint8Array, w: number, ox: number, stamps: Stamp[]) {
  const x1 = ox + CHUNK - 1;
  if (id === "flat") {
    fillGround(tiles, w, ox, x1);
    setTile(tiles, w, ox + 4, 10, 5);
    setTile(tiles, w, ox + 6, 10, 4);
    setTile(tiles, w, ox + 12, 10, 4);
    dig(tiles, w, ox + 8, ox + 9);
    return;
  }
  if (id === "gap") {
    fillGround(tiles, w, ox, x1);
    dig(tiles, w, ox + 8, ox + 10);
    setTile(tiles, w, ox + 9, 8, 2);
    setTile(tiles, w, ox + 14, 10, 4);
    setTile(tiles, w, ox + 2, 10, 5);
    return;
  }
  if (id === "stairs") {
    fillGround(tiles, w, ox, x1);
    for (let s = 0; s < 3; s++) {
      for (let x = ox + 4 + s * 2; x < ox + 6 + s * 2; x++) {
        for (let y = FLOOR - 1 - s; y < FLOOR; y++) setTile(tiles, w, x, y, 6);
      }
    }
    setTile(tiles, w, ox + 9, 7, 4);
    setTile(tiles, w, ox + 15, 10, 4);
    return;
  }
  if (id === "hopper") {
    fillGround(tiles, w, ox, x1);
    setTile(tiles, w, ox + 6, 9, 2);
    setTile(tiles, w, ox + 7, 9, 2);
    setTile(tiles, w, ox + 8, 9, 2);
    stamps.push(stamp("hopper", ox + 7, 8));
    setTile(tiles, w, ox + 14, 10, 4);
    return;
  }
  if (id === "moth") {
    fillGround(tiles, w, ox, x1);
    dig(tiles, w, ox + 8, ox + 9);
    stamps.push(stamp("moth", ox + 7, 6, { minX: (ox + 4) * TILE, maxX: (ox + 13) * TILE }));
    setTile(tiles, w, ox + 15, 10, 4);
    return;
  }
  if (id === "spikes") {
    fillGround(tiles, w, ox, x1);
    for (let x = ox + 5; x <= ox + 11; x++) setTile(tiles, w, x, 10, 3);
    for (let x = ox + 5; x <= ox + 11; x += 2) setTile(tiles, w, x, 8, 2);
    setTile(tiles, w, ox + 6, 8, 2);
    setTile(tiles, w, ox + 15, 10, 4);
    return;
  }
  if (id === "lift") {
    fillGround(tiles, w, ox, ox + 4);
    fillGround(tiles, w, ox + 13, x1);
    const px = (ox + 5) * TILE;
    stamps.push(
      stamp("platform", ox + 5, 9, { minX: px, maxX: (ox + 11) * TILE }),
    );
    stamps.push(stamp("checkpoint", ox + 2, 10));
    setTile(tiles, w, ox + 15, 10, 4);
    return;
  }
  fillGround(tiles, w, ox, x1);
  setTile(tiles, w, ox + 2, 10, 5);
  setTile(tiles, w, ox + 3, 9, 5);
  stamps.push(stamp("hopper", ox + 6, 10));
  stamps.push(stamp("moth", ox + 9, 6, { minX: (ox + 8) * TILE, maxX: (ox + 14) * TILE }));
  setTile(tiles, w, ox + 12, 10, 4);
  stamps.push(stamp("checkpoint", ox + 1, 10));
  stamps.push(stamp("goal", ox + 15, 9));
}

export function buildRun(seed: number): Level {
  const order: ChunkId[] = ["gap", "stairs", "hopper", "moth", "spikes", "lift"];
  shuffle(order, mulberry32(seed || 1));
  const chunks: ChunkId[] = ["flat", ...order, "finale"];
  const w = chunks.length * CHUNK;
  const tiles = new Uint8Array(w * MAP_H);
  const stamps: Stamp[] = [stamp("player", 2, FLOOR - 2), stamp("checkpoint", 1, 10)];
  chunks.forEach((id, i) => paintChunk(id, tiles, w, i * CHUNK, stamps));
  return { w, h: MAP_H, tiles, stamps, seed, name: "Kurir Senja" };
}

export function sampleProject(): Project {
  const w = 22;
  const h = MAP_H;
  const tiles = new Uint8Array(w * h);
  fillGround(tiles, w, 0, w - 1);
  dig(tiles, w, 8, 10);
  setTile(tiles, w, 9, 8, 2);
  setTile(tiles, w, 5, 10, 4);
  setTile(tiles, w, 14, 10, 3);
  setTile(tiles, w, 16, 10, 4);
  setTile(tiles, w, 3, 10, 5);
  const stamps: Stamp[] = [
    stamp("player", 2, 9),
    stamp("hopper", 15, 10),
    stamp("goal", 19, 9),
  ];
  return { v: 1, name: "atap-coba", w, h, tiles: packTiles(tiles), stamps };
}

export function benchLevel(): Level {
  const w = 24;
  const tiles = new Uint8Array(w * MAP_H);
  fillGround(tiles, w, 0, w - 1);
  setTile(tiles, w, 6, 8, 2);
  setTile(tiles, w, 7, 8, 2);
  setTile(tiles, w, 8, 8, 2);
  setTile(tiles, w, 12, 6, 2);
  setTile(tiles, w, 13, 6, 2);
  setTile(tiles, w, 16, 10, 4);
  setTile(tiles, w, 4, 10, 5);
  return {
    w,
    h: MAP_H,
    tiles,
    stamps: [stamp("player", 2, 9)],
    seed: 0,
    name: "Meja uji",
  };
}

export const TILE_GUIDE: { id: number; name: string; note: string }[] = [
  { id: 1, name: "Atap", note: "Padat. Kurir tidak menembusnya." },
  { id: 6, name: "Peti", note: "Padat, tampak lain. Anak tangga." },
  { id: 2, name: "Papan", note: "Hanya menahan dari atas. Tarik bawah untuk jatuh." },
  { id: 3, name: "Duri", note: "Tidak padat. Menyerap satu nyala." },
  { id: 4, name: "Bara", note: "Diambil sekali. Menambah skor." },
  { id: 5, name: "Spanduk", note: "Hiasan. Tidak menahan tubuh." },
];
