import { useEffect, useRef, useState, type ReactNode } from "react";
import { BookOpen, Download, Pause, Play, RotateCcw, Square, Upload, Volume2, VolumeX } from "lucide-react";
import { audio } from "@/engine/audio";
import { blit, drawTile } from "@/engine/pixels";
import { projectToLevel } from "@/engine/pack";
import { Runtime } from "@/engine/runtime";
import {
  DEFAULT_PREFS,
  type Hud,
  type Prefs,
  type Project,
  type Quality,
  type Relic,
  type Tool,
} from "@/engine/types";
import {
  HERO_IDLE,
  MOTH,
  HOPPER,
} from "@/engine/pixels";
import {
  RELICS,
  STORY,
  SYSTEMS,
  TILE_GUIDE,
  benchLevel,
  buildRun,
  disasm,
  HOPPER_PROG,
  rankFor,
  sampleProject,
} from "@/game/content";

const EMPTY_HUD: Hud = {
  hp: 3,
  maxHp: 3,
  embers: 0,
  emberTotal: 0,
  foes: 0,
  time: 0,
  score: 0,
  phase: "play",
  atap: 1,
  atapTotal: 8,
  seed: 1,
  pulse: 0,
  message: "",
};

const TOOLS: { id: Tool; label: string }[] = [
  { id: "pan", label: "Geser" },
  { id: "solid", label: "Atap" },
  { id: "crate", label: "Peti" },
  { id: "oneway", label: "Papan" },
  { id: "spike", label: "Duri" },
  { id: "ember", label: "Bara" },
  { id: "banner", label: "Kain" },
  { id: "erase", label: "Hapus" },
  { id: "player", label: "Kurir" },
  { id: "moth", label: "Ngengat" },
  { id: "hopper", label: "Peloncat" },
  { id: "platform", label: "Pijakan" },
  { id: "checkpoint", label: "Lentera" },
  { id: "goal", label: "Bendera" },
];

function loadPrefs(): Prefs {
  try {
    const raw = localStorage.getItem("kilat-v1");
    if (!raw) return DEFAULT_PREFS;
    const parsed = JSON.parse(raw) as Partial<Prefs>;
    if (parsed.v !== 1) return DEFAULT_PREFS;
    return { ...DEFAULT_PREFS, ...parsed };
  } catch {
    return DEFAULT_PREFS;
  }
}

function savePrefs(prefs: Prefs) {
  localStorage.setItem("kilat-v1", JSON.stringify(prefs));
}

function loadStudio(): Project {
  try {
    const raw = localStorage.getItem("kilat-studio");
    if (!raw) return sampleProject();
    const parsed = JSON.parse(raw) as Project;
    if (parsed.v !== 1 || !parsed.tiles) return sampleProject();
    return parsed;
  } catch {
    return sampleProject();
  }
}

function formatTime(time: number) {
  const s = Math.max(0, Math.floor(time));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

export function KilatApp() {
  const [screen, setScreen] = useState<"home" | "play" | "studio" | "bench" | "library">("home");
  const [prefs, setPrefs] = useState<Prefs>(DEFAULT_PREFS);
  const [story, setStory] = useState(false);
  const [seed, setSeed] = useState(1);

  useEffect(() => {
    setPrefs(loadPrefs());
  }, []);

  useEffect(() => {
    const unlock = () => audio.unlock();
    window.addEventListener("pointerdown", unlock);
    return () => window.removeEventListener("pointerdown", unlock);
  }, []);

  function update(next: Prefs) {
    setPrefs(next);
    savePrefs(next);
  }

  return (
    <div className="flex h-dvh flex-col bg-ink text-paper">
      {screen === "home" ? (
        <Home
          prefs={prefs}
          onPrefs={update}
          onPlay={(relic) => {
            update({ ...prefs, relic });
            setSeed((Math.random() * 0xfffff) | 0 || 1);
            setScreen("play");
          }}
          onStudio={() => setScreen("studio")}
          onBench={() => setScreen("bench")}
          onLibrary={() => setScreen("library")}
          onStory={() => setStory(true)}
        />
      ) : null}
      {screen === "library" ? <Library onBack={() => setScreen("home")} sound={prefs.sound} /> : null}
      {screen === "play" || screen === "studio" || screen === "bench" ? (
        <Stage
          key={`${screen}-${seed}-${prefs.relic}`}
          mode={screen}
          prefs={prefs}
          seed={seed}
          onPrefs={update}
          onExit={() => setScreen("home")}
          onReseed={() => setSeed((Math.random() * 0xfffff) | 0 || 1)}
        />
      ) : null}
      {story ? (
        <div className="fixed inset-0 z-20 flex items-end justify-center bg-ink/80 p-4 sm:items-center">
          <div className="w-full max-w-md rounded-card border border-line bg-ink-2 p-5">
            <p className="font-display text-2xl text-gold">Kurir Senja</p>
            <div className="mt-4 flex flex-col gap-3">
              {STORY.map((line) => (
                <p key={line} className="text-paper">
                  {line}
                </p>
              ))}
            </div>
            <button
              type="button"
              className="mt-5 w-full rounded-card bg-ember px-4 py-3 font-display text-lg text-ink"
              onClick={() => setStory(false)}
            >
              Tutup kisah
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Home({
  prefs,
  onPrefs,
  onPlay,
  onStudio,
  onBench,
  onLibrary,
  onStory,
}: {
  prefs: Prefs;
  onPrefs: (prefs: Prefs) => void;
  onPlay: (relic: Relic) => void;
  onStudio: () => void;
  onBench: () => void;
  onLibrary: () => void;
  onStory: () => void;
}) {
  return (
    <div className="safe-t safe-b flex flex-1 flex-col overflow-y-auto">
      <div className="mx-auto flex w-full max-w-md flex-1 flex-col gap-5 px-4 py-5">
        <header className="flex items-end justify-between gap-3">
          <div>
            <p className="font-display text-4xl leading-none text-paper">KILAT</p>
            <p className="mt-2 text-paper-dim">Mesin saku untuk layar kecil</p>
          </div>
          <Mascot />
        </header>
        <section className="rounded-card border border-line bg-ink-2 p-4">
          <div className="flex items-center gap-2">
            <span className="flicker inline-block size-2 rounded-full bg-ember" />
            <h1 className="font-display text-2xl">Kurir Senja</h1>
          </div>
          <p className="mt-2 text-paper-dim">
            Antar lentera melewati atap pasar malam. Lompat celah, denyut bayangan, jangan jatuh.
          </p>
          <div className="mt-4 grid grid-cols-3 gap-2">
            {RELICS.map((relic) => (
              <button
                key={relic.id}
                type="button"
                onClick={() => onPrefs({ ...prefs, relic: relic.id })}
                className={
                  "rounded-2xl border px-2 py-3 text-left " +
                  (prefs.relic === relic.id ? "border-gold bg-ink text-paper" : "border-line bg-ink text-paper-dim")
                }
              >
                <span className="block text-sm text-paper">{relic.name}</span>
                <span className="mt-1 block text-sm">{relic.hint}</span>
              </button>
            ))}
          </div>
          <button
            type="button"
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-card bg-ember px-4 py-3 font-display text-xl text-ink"
            onClick={() => onPlay(prefs.relic)}
          >
            <Play className="size-5" aria-hidden />
            Main
          </button>
          {prefs.best > 0 ? (
            <p className="mt-3 text-sm text-gold">Rekor {prefs.best}</p>
          ) : (
            <p className="mt-3 text-sm text-paper-dim">Rekor tersimpan di ponsel ini.</p>
          )}
        </section>
        <div className="grid grid-cols-3 gap-2">
          <button type="button" className="rounded-card border border-line bg-ink-2 px-2 py-3 text-sm" onClick={onStudio}>
            Studio
          </button>
          <button type="button" className="rounded-card border border-line bg-ink-2 px-2 py-3 text-sm" onClick={onBench}>
            Meja uji
          </button>
          <button type="button" className="rounded-card border border-line bg-ink-2 px-2 py-3 text-sm" onClick={onLibrary}>
            Pustaka
          </button>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {(["hemat", "pas", "halus"] as Quality[]).map((quality) => (
            <button
              key={quality}
              type="button"
              onClick={() => onPrefs({ ...prefs, quality })}
              className={
                "rounded-full border px-3 py-2 text-sm " +
                (prefs.quality === quality ? "border-gold text-gold" : "border-line text-paper-dim")
              }
            >
              {quality === "hemat" ? "Hemat" : quality === "pas" ? "Pas" : "Halus"}
            </button>
          ))}
          <button
            type="button"
            className="ml-auto inline-flex items-center gap-2 rounded-full border border-line px-3 py-2 text-sm"
            onClick={() => onPrefs({ ...prefs, sound: !prefs.sound })}
          >
            {prefs.sound ? <Volume2 className="size-4" /> : <VolumeX className="size-4" />}
            {prefs.sound ? "Suara nyala" : "Suara mati"}
          </button>
        </div>
        <button type="button" className="self-start text-sm text-gold" onClick={onStory}>
          Baca kisah
        </button>
      </div>
    </div>
  );
}

function Mascot() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    let last = performance.now();
    let t = 0;
    const frame = (now: number) => {
      t += Math.min(0.05, (now - last) / 1000);
      last = now;
      ctx.clearRect(0, 0, 64, 64);
      const rows = HERO_IDLE[Math.floor(t * 3) % 2] ?? HERO_IDLE[0]!;
      blit(ctx, rows, 8, 6, 2, false);
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, []);
  return <canvas ref={ref} width={64} height={64} className="pixel size-16 shrink-0" aria-hidden />;
}

function Stage({
  mode,
  prefs,
  seed,
  onPrefs,
  onExit,
  onReseed,
}: {
  mode: "play" | "studio" | "bench";
  prefs: Prefs;
  seed: number;
  onPrefs: (prefs: Prefs) => void;
  onExit: () => void;
  onReseed: () => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const runtimeRef = useRef<Runtime | null>(null);
  const prefsRef = useRef(prefs);
  prefsRef.current = prefs;
  const [hud, setHud] = useState<Hud>(EMPTY_HUD);
  const [paused, setPaused] = useState(false);
  const [tool, setTool] = useState<Tool>("solid");
  const [testing, setTesting] = useState(false);
  const [coarse, setCoarse] = useState(false);
  const drag = useRef<{ x: number; y: number; panning: boolean } | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const runtime = new Runtime(canvas, {
      quality: prefs.quality,
      sound: prefs.sound,
      haptic: prefs.haptic,
      reduce,
      onHud: (next) => setHud((prev) => (sameHud(prev, next) ? prev : next)),
      onScore: (score) => {
        const current = prefsRef.current;
        if (score > current.best && mode === "play") onPrefs({ ...current, best: score });
      },
    });
    runtimeRef.current = runtime;
    if (mode === "play") runtime.startRun(buildRun(seed), prefs.relic);
    else if (mode === "bench") runtime.startBench(benchLevel());
    else runtime.startEdit(projectToLevel(loadStudio()));
    const onResize = () => runtime.resize();
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      runtime.destroy();
      runtimeRef.current = null;
    };
  }, [mode, seed]);

  useEffect(() => {
    const query = window.matchMedia("(pointer: coarse)");
    const update = () => setCoarse(query.matches || window.innerWidth < 860);
    update();
    query.addEventListener("change", update);
    window.addEventListener("resize", update);
    return () => {
      query.removeEventListener("change", update);
      window.removeEventListener("resize", update);
    };
  }, []);

  useEffect(() => {
    runtimeRef.current?.setPaused(paused);
  }, [paused]);

  useEffect(() => {
    runtimeRef.current?.setQuality(prefs.quality);
    runtimeRef.current?.setSound(prefs.sound);
    runtimeRef.current?.setHaptic(prefs.haptic);
  }, [prefs.quality, prefs.sound, prefs.haptic]);

  function persistStudio() {
    if (mode !== "studio" || !runtimeRef.current) return;
    localStorage.setItem("kilat-studio", JSON.stringify(runtimeRef.current.exportProject()));
  }

  const showTouch = coarse && hud.phase === "play" && !paused;
  const title = mode === "play" ? "Kurir Senja" : mode === "bench" ? "Meja uji" : "Studio";

  return (
    <div className="safe-t flex min-h-0 flex-1 flex-col">
      <header className="flex items-center gap-3 px-3 py-2">
        <button type="button" className="rounded-full border border-line px-3 py-2 text-sm" onClick={onExit}>
          Kembali
        </button>
        <div className="min-w-0 flex-1">
          <p className="truncate font-display text-lg leading-none">{title}</p>
          <p className="truncate text-sm text-paper-dim">{hud.message || statusLine(hud, mode)}</p>
        </div>
        {hud.phase === "play" ? (
          <button
            type="button"
            aria-label={paused ? "Lanjut" : "Jeda"}
            className="rounded-full border border-line p-2"
            onClick={() => setPaused((value) => !value)}
          >
            {paused ? <Play className="size-5" /> : <Pause className="size-5" />}
          </button>
        ) : null}
      </header>
      <div className="relative min-h-0 flex-1 bg-ink">
        <canvas
          ref={canvasRef}
          className="pixel h-full w-full touch-none object-contain"
          onContextMenu={(event) => event.preventDefault()}
          onPointerDown={(event) => {
            if (mode !== "studio" || testing || hud.phase !== "edit") return;
            event.currentTarget.setPointerCapture(event.pointerId);
            drag.current = { x: event.clientX, y: event.clientY, panning: tool === "pan" };
            if (tool !== "pan") runtimeRef.current?.paint(tool, event.clientX, event.clientY);
          }}
          onPointerMove={(event) => {
            if (mode !== "studio") return;
            runtimeRef.current?.hover(event.clientX, event.clientY);
            if (!drag.current) return;
            if (drag.current.panning) {
              runtimeRef.current?.pan(event.clientX - drag.current.x, event.clientY - drag.current.y);
              drag.current = { ...drag.current, x: event.clientX, y: event.clientY };
            } else runtimeRef.current?.paint(tool, event.clientX, event.clientY);
          }}
          onPointerUp={() => {
            drag.current = null;
            persistStudio();
          }}
        />
        {hud.phase === "win" || hud.phase === "dead" ? (
          <Overlay title={hud.phase === "win" ? "Lentera sampai" : "Lentera padam"}>
            <p className="text-gold">{rankFor(hud.score)}</p>
            <p className="text-paper-dim">
              Skor {hud.score} · waktu {formatTime(hud.time)} · rute {hud.seed}
            </p>
            {prefs.best > 0 ? <p className="text-sm text-paper-dim">Rekor {Math.max(prefs.best, hud.score)}</p> : null}
            {mode === "play" ? (
              <>
                <button
                  type="button"
                  className="btn-ember"
                  onClick={() => runtimeRef.current?.startRun(buildRun(seed), prefs.relic)}
                >
                  Ulang rute
                </button>
                <button type="button" className="btn-ghost" onClick={onReseed}>
                  Rute baru
                </button>
              </>
            ) : (
              <button
                type="button"
                className="btn-ember"
                onClick={() => {
                  runtimeRef.current?.stopTest();
                  setTesting(false);
                }}
              >
                Kembali ke studio
              </button>
            )}
            <button type="button" className="btn-ghost" onClick={onExit}>
              Beranda
            </button>
          </Overlay>
        ) : null}
        {paused && hud.phase === "play" ? (
          <Overlay title="Jeda">
            <button type="button" className="btn-ember" onClick={() => setPaused(false)}>
              Lanjut
            </button>
            <button type="button" className="btn-ghost" onClick={() => onPrefs({ ...prefs, sound: !prefs.sound })}>
              {prefs.sound ? "Matikan suara" : "Nyalakan suara"}
            </button>
            <button type="button" className="btn-ghost" onClick={onExit}>
              Ke beranda
            </button>
          </Overlay>
        ) : null}
        {hud.phase !== "edit" ? (
          <div className="pointer-events-none absolute inset-x-3 top-3 flex items-center justify-between text-sm">
            <div className="flex gap-1">
              {Array.from({ length: hud.maxHp }, (_, i) => (
                <span key={i} className={"size-3 rounded-full " + (i < hud.hp ? "bg-ember" : "bg-line")} />
              ))}
            </div>
            <span className="rounded-full bg-ink/80 px-2 py-1 text-gold">
              {hud.embers}/{hud.emberTotal} bara
              {hud.atapTotal > 0 ? ` · atap ${hud.atap}/${hud.atapTotal}` : ""}
            </span>
          </div>
        ) : null}
      </div>
      {mode === "studio" ? (
        <StudioBar
          tool={tool}
          testing={testing}
          onTool={setTool}
          onTest={() => {
            if (testing) {
              runtimeRef.current?.stopTest();
              setTesting(false);
            } else {
              persistStudio();
              runtimeRef.current?.playtest();
              setTesting(true);
            }
          }}
          onExport={() => {
            const project = runtimeRef.current?.exportProject();
            if (!project) return;
            const blob = new Blob([JSON.stringify(project)], { type: "application/json" });
            const url = URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.href = url;
            link.download = "kilat-panggung.json";
            link.click();
            URL.revokeObjectURL(url);
          }}
          onImport={(project) => {
            runtimeRef.current?.startEdit(projectToLevel(project));
            localStorage.setItem("kilat-studio", JSON.stringify(project));
            setTesting(false);
          }}
          onReset={() => {
            const sample = sampleProject();
            runtimeRef.current?.startEdit(projectToLevel(sample));
            localStorage.setItem("kilat-studio", JSON.stringify(sample));
            setTesting(false);
          }}
        />
      ) : null}
      {mode === "bench" && hud.phase === "play" && !paused ? (
        <div className="flex gap-2 overflow-x-auto px-3 py-2">
          <Chip onClick={() => runtimeRef.current?.spawnKind("moth")}>Ngengat</Chip>
          <Chip onClick={() => runtimeRef.current?.spawnKind("hopper")}>Peloncat</Chip>
          <Chip onClick={() => runtimeRef.current?.spawnKind("platform")}>Pijakan</Chip>
          <Chip onClick={() => runtimeRef.current?.nudge("shake")}>Guncang</Chip>
          <Chip onClick={() => runtimeRef.current?.nudge("burst")}>Letusan</Chip>
          <Chip onClick={() => runtimeRef.current?.nudge("note")}>Nada</Chip>
        </div>
      ) : null}
      {showTouch ? (
        <div className="safe-b grid grid-cols-[1fr_auto] items-end gap-3 px-3 pt-2">
          <Stick onChange={(x) => runtimeRef.current?.setWish(x)} />
          <div className="flex items-end gap-2">
            <Round
              label="Turun"
              onDown={() => runtimeRef.current?.setDrop(true)}
              onUp={() => runtimeRef.current?.setDrop(false)}
            />
            <Round
              label="Denyut"
              hot={hud.pulse <= 0}
              onDown={() => runtimeRef.current?.tapPulse()}
              onUp={() => undefined}
            />
            <Round
              label="Lompat"
              primary
              onDown={() => runtimeRef.current?.setJump(true)}
              onUp={() => runtimeRef.current?.setJump(false)}
            />
          </div>
        </div>
      ) : (
        <div className="safe-b px-4 py-3 text-sm text-paper-dim">
          A kiri · D kanan · W lompat · J denyut · S turun papan
        </div>
      )}
    </div>
  );
}

function statusLine(hud: Hud, mode: string) {
  if (hud.phase === "edit") return "Sentuh petak. Uji memakai mesin yang sama.";
  if (mode === "bench") return "Coba fisika, kawanan, dan kamera.";
  return `Skor ${hud.score}`;
}

function sameHud(a: Hud, b: Hud) {
  return (
    a.hp === b.hp &&
    a.maxHp === b.maxHp &&
    a.embers === b.embers &&
    a.emberTotal === b.emberTotal &&
    a.foes === b.foes &&
    a.phase === b.phase &&
    a.atap === b.atap &&
    a.score === b.score &&
    a.pulse === b.pulse &&
    a.message === b.message &&
    Math.floor(a.time) === Math.floor(b.time)
  );
}

function Overlay({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-ink/75 p-4">
      <div className="flex w-full max-w-sm flex-col gap-3 rounded-card border border-line bg-ink-2 p-4">
        <h2 className="font-display text-3xl">{title}</h2>
        {children}
      </div>
    </div>
  );
}

function Stick({ onChange }: { onChange: (x: number) => void }) {
  const origin = useRef<{ x: number; y: number } | null>(null);
  return (
    <div
      className="relative h-28 w-28 touch-none rounded-full border border-line bg-ink-2"
      onPointerDown={(event) => {
        event.preventDefault();
        event.currentTarget.setPointerCapture(event.pointerId);
        origin.current = { x: event.clientX, y: event.clientY };
      }}
      onPointerMove={(event) => {
        if (!origin.current) return;
        const dx = event.clientX - origin.current.x;
        onChange(Math.max(-1, Math.min(1, dx / 36)));
      }}
      onPointerUp={() => {
        origin.current = null;
        onChange(0);
      }}
      onPointerCancel={() => {
        origin.current = null;
        onChange(0);
      }}
    >
      <span className="absolute inset-0 flex items-center justify-center text-sm text-paper-dim">Geser</span>
    </div>
  );
}

function Round({
  label,
  primary,
  hot = true,
  onDown,
  onUp,
}: {
  label: string;
  primary?: boolean;
  hot?: boolean;
  onDown: () => void;
  onUp: () => void;
}) {
  return (
    <button
      type="button"
      className={
        "touch-none rounded-full px-3 py-4 text-sm " +
        (primary ? "bg-ember text-ink" : "border border-line bg-ink-2 text-paper") +
        (hot ? "" : " opacity-50")
      }
      onPointerDown={(event) => {
        event.preventDefault();
        onDown();
      }}
      onPointerUp={onUp}
      onPointerCancel={onUp}
      onPointerLeave={onUp}
    >
      {label}
    </button>
  );
}

function Chip({ children, onClick }: { children: ReactNode; onClick: () => void }) {
  return (
    <button type="button" className="shrink-0 rounded-full border border-line px-3 py-2 text-sm" onClick={onClick}>
      {children}
    </button>
  );
}

function StudioBar({
  tool,
  testing,
  onTool,
  onTest,
  onExport,
  onImport,
  onReset,
}: {
  tool: Tool;
  testing: boolean;
  onTool: (tool: Tool) => void;
  onTest: () => void;
  onExport: () => void;
  onImport: (project: Project) => void;
  onReset: () => void;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  return (
    <div className="flex flex-col gap-2 border-t border-line px-3 py-2">
      <div className="flex gap-2 overflow-x-auto">
        {TOOLS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => onTool(item.id)}
            className={
              "shrink-0 rounded-full border px-3 py-2 text-sm " +
              (tool === item.id ? "border-gold text-gold" : "border-line text-paper-dim")
            }
          >
            {item.label}
          </button>
        ))}
      </div>
      <div className="flex gap-2">
        <button type="button" className="btn-ember flex-1" onClick={onTest}>
          {testing ? <Square className="size-4" /> : <Play className="size-4" />}
          {testing ? "Stop" : "Uji"}
        </button>
        <button type="button" className="btn-ghost" onClick={onExport} aria-label="Ekspor">
          <Download className="size-4" />
        </button>
        <button type="button" className="btn-ghost" onClick={() => fileRef.current?.click()} aria-label="Impor">
          <Upload className="size-4" />
        </button>
        <button type="button" className="btn-ghost" onClick={onReset} aria-label="Contoh">
          <RotateCcw className="size-4" />
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="application/json"
          className="hidden"
          onChange={(event) => {
            const file = event.target.files?.[0];
            if (!file) return;
            void file.text().then((text) => {
              try {
                const project = JSON.parse(text) as Project;
                if (project.v === 1) onImport(project);
              } catch {
                /* abaikan berkas rusak */
              }
            });
          }}
        />
      </div>
    </div>
  );
}

function Library({ onBack, sound }: { onBack: () => void; sound: boolean }) {
  return (
    <div className="safe-t safe-b flex flex-1 flex-col overflow-y-auto">
      <div className="mx-auto flex w-full max-w-md flex-col gap-6 px-4 py-5">
        <header className="flex items-center gap-3">
          <button type="button" className="rounded-full border border-line px-3 py-2 text-sm" onClick={onBack}>
            Kembali
          </button>
          <div>
            <p className="flex items-center gap-2 font-display text-2xl">
              <BookOpen className="size-5 text-gold" /> Pustaka
            </p>
            <p className="text-sm text-paper-dim">Bawaan mesin, dipakai Kurir Senja.</p>
          </div>
        </header>
        <section>
          <h2 className="font-display text-xl">Ubin</h2>
          <div className="mt-3 grid grid-cols-2 gap-2">
            {TILE_GUIDE.map((tile) => (
              <div key={tile.id} className="rounded-2xl border border-line bg-ink-2 p-3">
                <TileSwatch id={tile.id} />
                <p className="mt-2 text-paper">{tile.name}</p>
                <p className="text-sm text-paper-dim">{tile.note}</p>
              </div>
            ))}
          </div>
        </section>
        <section>
          <h2 className="font-display text-xl">Makhluk</h2>
          <div className="mt-3 grid grid-cols-3 gap-2">
            <SpriteCard title="Kurir" rows={HERO_IDLE[0]!} />
            <SpriteCard title="Ngengat" rows={MOTH[0]!} />
            <SpriteCard title="Peloncat" rows={HOPPER[0]!} />
          </div>
        </section>
        <section>
          <h2 className="font-display text-xl">Bytecode peloncat</h2>
          <ol className="mt-3 rounded-card border border-line bg-ink-2 p-3 font-mono text-sm text-paper-dim">
            {disasm(HOPPER_PROG).map((line) => (
              <li key={line}>{line}</li>
            ))}
          </ol>
        </section>
        <section>
          <h2 className="font-display text-xl">Suara</h2>
          <div className="mt-3 flex flex-wrap gap-2">
            <Chip
              onClick={() => {
                if (sound) {
                  audio.unlock();
                  audio.jump();
                }
              }}
            >
              Lompat
            </Chip>
            <Chip
              onClick={() => {
                if (sound) {
                  audio.unlock();
                  audio.coin();
                }
              }}
            >
              Bara
            </Chip>
            <Chip
              onClick={() => {
                if (sound) {
                  audio.unlock();
                  audio.hit();
                }
              }}
            >
              Benturan
            </Chip>
          </div>
        </section>
        <section className="flex flex-col gap-3 pb-6">
          <h2 className="font-display text-xl">Sistem</h2>
          {SYSTEMS.map((system) => (
            <article key={system.title} className="rounded-card border border-line bg-ink-2 p-3">
              <h3 className="text-paper">{system.title}</h3>
              <p className="mt-1 text-sm text-paper-dim">{system.body}</p>
            </article>
          ))}
        </section>
      </div>
    </div>
  );
}

function TileSwatch({ id }: { id: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    ctx.clearRect(0, 0, 16, 16);
    ctx.fillStyle = "#1a2230";
    ctx.fillRect(0, 0, 16, 16);
    drawTile(ctx, id, 0, 0, 0);
  }, [id]);
  return <canvas ref={ref} width={16} height={16} className="pixel h-10 w-10" />;
}

function SpriteCard({ title, rows }: { title: string; rows: string[] }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    ctx.clearRect(0, 0, 48, 48);
    blit(ctx, rows, 8, 4, 2, false);
  }, [rows]);
  return (
    <div className="rounded-2xl border border-line bg-ink-2 p-2 text-center">
      <canvas ref={ref} width={48} height={48} className="pixel mx-auto h-12 w-12" />
      <p className="mt-1 text-sm">{title}</p>
    </div>
  );
}
