export const TILE = 16;
export const MAP_H = 14;
export const FLOOR = 11;

export type Relic = "sepatu" | "lentera" | "napas";
export type Quality = "hemat" | "pas" | "halus";
export type Tool =
  | "solid"
  | "crate"
  | "oneway"
  | "spike"
  | "ember"
  | "banner"
  | "erase"
  | "player"
  | "moth"
  | "hopper"
  | "platform"
  | "checkpoint"
  | "goal"
  | "pan";

export type StampKind = "player" | "moth" | "hopper" | "platform" | "checkpoint" | "goal";

export type Stamp = {
  k: StampKind;
  x: number;
  y: number;
  minX: number;
  maxX: number;
};

export type Project = {
  v: 1;
  name: string;
  w: number;
  h: number;
  tiles: string;
  stamps: Stamp[];
};

export type Level = {
  w: number;
  h: number;
  tiles: Uint8Array;
  stamps: Stamp[];
  seed: number;
  name: string;
};

export type Hud = {
  hp: number;
  maxHp: number;
  embers: number;
  emberTotal: number;
  foes: number;
  time: number;
  score: number;
  phase: "play" | "win" | "dead" | "edit";
  atap: number;
  atapTotal: number;
  seed: number;
  pulse: number;
  message: string;
};

export type Prefs = {
  v: 1;
  best: number;
  relic: Relic;
  quality: Quality;
  sound: boolean;
  haptic: boolean;
};

export const DEFAULT_PREFS: Prefs = {
  v: 1,
  best: 0,
  relic: "sepatu",
  quality: "pas",
  sound: true,
  haptic: true,
};

export type ControlsProbe = {
  getYaw: () => number;
  getSpeed: () => number;
  getX: () => number;
  getY: () => number;
  getFacing: () => number;
  setKeys: (codes: string[]) => void;
  setSteer: (v: number) => void;
};

declare global {
  interface Window {
    __controlsTest?: ControlsProbe;
    __kilatPhase?: string;
  }
}
