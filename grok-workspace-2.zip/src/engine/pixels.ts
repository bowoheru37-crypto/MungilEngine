const PAL: Record<string, string> = {
  o: "#16110e",
  s: "#e7b48c",
  S: "#c48b62",
  h: "#1c140f",
  r: "#ff6b2c",
  j: "#243056",
  J: "#3d4e7a",
  e: "#e85d04",
  p: "#2e2926",
  b: "#100e0c",
  m: "#e7c36a",
  M: "#a97832",
  f: "#fff4d2",
  F: "#ff9a1f",
  c: "#6b4634",
  C: "#8d5b42",
  B: "#e4c2a4",
  L: "#2a211c",
  w: "#8b93ab",
  W: "#343a4e",
  n: "#f3ecdf",
  d: "#6a4634",
  D: "#3a2418",
};

function spr(rows: string[], w: number): string[] {
  for (const row of rows) {
    if (row.length !== w) throw new Error(`sprite ${row.length} != ${w}: ${row}`);
  }
  return rows;
}

export const HERO_IDLE = [
  spr(
    [
      "................",
      "................",
      ".....oooo.......",
      "....osssso......",
      "....ohhsso......",
      "....osssso.r....",
      ".....osso.......",
      "....ojjjjo......",
      "...ojjJjjjo.....",
      "...ojjjjjeo.....",
      "....ojjo.mm.....",
      "....opo.mFfo....",
      "...opppo.mMo....",
      "...oppppo.mm....",
      "...op..po.......",
      "...op..po.......",
      "....b..b........",
      "................",
      "................",
      "................",
    ],
    16,
  ),
  spr(
    [
      "................",
      "................",
      ".....oooo.......",
      "....osSsso......",
      "....ohhsso......",
      "....osssso.r....",
      ".....osso.......",
      "....ojjjjo......",
      "...ojjJjjjo.....",
      "...ojjjjjeo.....",
      "....ojjo.mm.....",
      "....opo.mffo....",
      "...opppo.mMo....",
      "...oppppo.mm....",
      "...op..po.......",
      "...op..po.......",
      "....b..b........",
      "................",
      "................",
      "................",
    ],
    16,
  ),
];

export const HERO_RUN = [
  spr(
    [
      "................",
      "................",
      ".....oooo.......",
      "....osssso......",
      "....ohhsso......",
      "....osssso.r....",
      ".....osso.......",
      "....ojjjjo......",
      "...ojjJjjjo.....",
      "...ojjjjjeo.....",
      "....ojjo.mm.....",
      "....opo.mFfo....",
      "...opppo.mMo....",
      "...op..po.mm....",
      "..op....po......",
      "..b......b......",
      "................",
      "................",
      "................",
      "................",
    ],
    16,
  ),
  spr(
    [
      "................",
      ".....oooo.......",
      "....osssso......",
      "....ohhsso......",
      "....osssso.r....",
      ".....osso.......",
      "....ojjjjo......",
      "...ojjJjjjo.....",
      "...ojjjjjeo.....",
      "....ojjo.mm.....",
      "....opo.mffo....",
      "...opppo.mMo....",
      "...oppppo.mm....",
      "....oppo........",
      "....bbbb........",
      "................",
      "................",
      "................",
      "................",
      "................",
    ],
    16,
  ),
  spr(
    [
      "................",
      "................",
      ".....oooo.......",
      "....osssso......",
      "....ohhsso......",
      "....osssso.r....",
      ".....osso.......",
      "....ojjjjo......",
      "...ojjJjjjo.....",
      "...ojjjjjeo.....",
      "....ojjo.mm.....",
      "....opo.mFfo....",
      "...opppo.mMo....",
      "...op..po.mm....",
      "..op....po......",
      "..b......b......",
      "................",
      "................",
      "................",
      "................",
    ],
    16,
  ),
  spr(
    [
      "................",
      ".....oooo.......",
      "....osSsso......",
      "....ohhsso......",
      "....osssso.r....",
      ".....osso.......",
      "....ojjjjo......",
      "...ojjJjjjo.....",
      "...ojjjjjeo.....",
      "....ojjo.mm.....",
      "....opo.mfFo....",
      "...opppo.mMo....",
      "...opp..po......",
      "....oppo..mm....",
      "....bbbb........",
      "................",
      "................",
      "................",
      "................",
      "................",
    ],
    16,
  ),
];

export const HERO_JUMP = [
  spr(
    [
      "................",
      ".....oooo.......",
      "....osssso......",
      "....ohhsso......",
      "....osssso.r....",
      ".....osso.......",
      "....ojjjjo......",
      "...ojjJjjjo.....",
      "...ojjjjjeo.....",
      "....ojjo.mm.....",
      "....opo.mFfo....",
      "...opppo.mMo....",
      "...oppppo.mm....",
      "....oppo........",
      "....o..o........",
      "................",
      "................",
      "................",
      "................",
      "................",
    ],
    16,
  ),
  spr(
    [
      "................",
      "................",
      ".....oooo.......",
      "....osssso......",
      "....ohhsso......",
      "....osssso.r....",
      ".....osso.......",
      "....ojjjjo......",
      "...ojjJjjjo.....",
      "...ojjjjjeo.....",
      "....ojjo.mm.....",
      "....opo.mFfo....",
      "...opppo.mMo....",
      "...o.pp.o.mm....",
      "..b......b......",
      "................",
      "................",
      "................",
      "................",
      "................",
    ],
    16,
  ),
];

export const MOTH = [
  spr(
    [
      "................",
      ".oWWW......WWWo.",
      "owwwwwo..owwwwo.",
      "oWwoooowwwooowWo",
      ".oW....oWWo...Wo",
      "..oo...oo...oo..",
      "....or....ro....",
      ".....oooooo.....",
      "................",
      "................",
    ],
    16,
  ),
  spr(
    [
      "................",
      "................",
      ".oWWWW....WWWWo.",
      "owwwwwwwwwwwwwwo",
      "oWwoooowwwooowWo",
      ".oo....oWWo...o.",
      "....or....ro....",
      ".....oooooo.....",
      "................",
      "................",
    ],
    16,
  ),
];

export const HOPPER = [
  spr(
    [
      "................",
      "................",
      "................",
      ".....oooo.......",
      "....oCCCCo......",
      "...oCBr.BCo.....",
      "...oCBBBBCo.....",
      "....oCCCCo......",
      ".....oLLo.......",
      "....oLLLLo......",
      "....oL..Lo......",
      ".....o..o.......",
      "................",
      "................",
      "................",
      "................",
    ],
    16,
  ),
  spr(
    [
      "................",
      ".....oooo.......",
      "....oCCCCo......",
      "...oCBr.BCo.....",
      "...oCBBBBCo.....",
      "....oCCCCo......",
      ".....oLLo.......",
      ".....oLLo.......",
      ".....oLLo.......",
      "....oL..Lo......",
      "................",
      "................",
      "................",
      "................",
      "................",
      "................",
    ],
    16,
  ),
];

export const LANTERN = spr(
  [
    "...mm...",
    "..mFFm..",
    "..mffm..",
    "...mm...",
    "....oo..",
    "....oo..",
    "...oooo.",
    "..onnnno",
    "..onrrno",
    "...oooo.",
  ],
  8,
);

const FONT: Record<string, string[]> = {
  "0": ["ooo", "o.o", "o.o", "o.o", "ooo"],
  "1": [".o.", "oo.", ".o.", ".o.", "ooo"],
  "2": ["ooo", "..o", "ooo", "o..", "ooo"],
  "3": ["ooo", "..o", "ooo", "..o", "ooo"],
  "4": ["o.o", "o.o", "ooo", "..o", "..o"],
  "5": ["ooo", "o..", "ooo", "..o", "ooo"],
  "6": ["ooo", "o..", "ooo", "o.o", "ooo"],
  "7": ["ooo", "..o", ".o.", ".o.", ".o."],
  "8": ["ooo", "o.o", "ooo", "o.o", "ooo"],
  "9": ["ooo", "o.o", "ooo", "..o", "ooo"],
  "+": [".....", "..o..", ".ooo.", "..o..", "....."],
  "-": [".....", ".....", ".ooo.", ".....", "....."],
};

export function blit(
  ctx: CanvasRenderingContext2D,
  rows: string[],
  x: number,
  y: number,
  scale: number,
  flip: boolean,
) {
  const h = rows.length;
  const w = rows[0]?.length ?? 0;
  const dw = w * scale;
  ctx.save();
  if (flip) {
    ctx.translate(Math.round(x + dw), Math.round(y));
    ctx.scale(-1, 1);
  } else {
    ctx.translate(Math.round(x), Math.round(y));
  }
  for (let yy = 0; yy < h; yy++) {
    const row = rows[yy] ?? "";
    let xx = 0;
    while (xx < row.length) {
      const ch = row[xx] ?? ".";
      const color = PAL[ch];
      if (!color) {
        xx++;
        continue;
      }
      let x2 = xx + 1;
      while (x2 < row.length && row[x2] === ch) x2++;
      ctx.fillStyle = color;
      ctx.fillRect(xx * scale, yy * scale, (x2 - xx) * scale, scale);
      xx = x2;
    }
  }
  ctx.restore();
}

export function drawGlyph(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  color: string,
  scale = 2,
) {
  let cx = x;
  for (const ch of text) {
    const rows = FONT[ch];
    if (!rows) {
      cx += 4 * scale;
      continue;
    }
    ctx.fillStyle = color;
    for (let yy = 0; yy < rows.length; yy++) {
      const row = rows[yy] ?? "";
      for (let xx = 0; xx < row.length; xx++) {
        if (row[xx] === "o") ctx.fillRect(cx + xx * scale, y + yy * scale, scale, scale);
      }
    }
    cx += (rows[0].length + 1) * scale;
  }
}

export function drawTile(ctx: CanvasRenderingContext2D, id: number, x: number, y: number, t: number) {
  if (id === 1 || id === 6) {
    ctx.fillStyle = id === 6 ? "#4e3428" : "#3a2c24";
    ctx.fillRect(x, y, 16, 16);
    ctx.fillStyle = id === 6 ? "#6b4a36" : "#5c4636";
    ctx.fillRect(x, y, 16, 3);
    ctx.fillStyle = "#241810";
    ctx.fillRect(x, y + 15, 16, 1);
    ctx.fillStyle = "#2a1e18";
    ctx.fillRect(x + (id === 6 ? 4 : 8), y + 3, 1, 6);
    ctx.fillRect(x, y + 9, 16, 1);
    return;
  }
  if (id === 2) {
    ctx.fillStyle = "#6a4634";
    ctx.fillRect(x, y + 4, 16, 5);
    ctx.fillStyle = "#e7c36a";
    ctx.fillRect(x + 2, y + 6, 2, 2);
    ctx.fillRect(x + 11, y + 6, 2, 2);
    ctx.fillStyle = "#3a2418";
    ctx.fillRect(x, y + 9, 16, 1);
    return;
  }
  if (id === 3) {
    ctx.fillStyle = "#d9d2c4";
    for (let i = 0; i < 3; i++) {
      const x0 = x + 1 + i * 5;
      ctx.beginPath();
      ctx.moveTo(x0, y + 15);
      ctx.lineTo(x0 + 2, y + 6);
      ctx.lineTo(x0 + 4, y + 15);
      ctx.fill();
    }
    return;
  }
  if (id === 4) {
    const hot = Math.floor(t * 8) % 2 === 0;
    ctx.fillStyle = "#a97832";
    ctx.fillRect(x + 5, y + 10, 6, 4);
    ctx.fillStyle = hot ? "#fff4d2" : "#ff9a1f";
    ctx.fillRect(x + 6, y + 5, 4, 5);
    ctx.fillStyle = "#ff6b2c";
    ctx.fillRect(x + 7, y + 3, 2, 3);
    return;
  }
  if (id === 5) {
    ctx.fillStyle = "#241810";
    ctx.fillRect(x + 7, y, 2, 16);
    ctx.fillStyle = "#ff6b2c";
    ctx.fillRect(x + 9, y + 2, 6, 8);
    ctx.fillStyle = "#e7c36a";
    ctx.fillRect(x + 9, y + 6, 6, 2);
  }
}

export function paintSkyline(ctx: CanvasRenderingContext2D) {
  const roofs = [28, 46, 18, 54, 36, 22, 48, 30, 58, 24, 40];
  let x = 0;
  for (let i = 0; i < roofs.length; i++) {
    const w = 28 + ((i * 17) % 22);
    const h = roofs[i] ?? 30;
    ctx.fillStyle = i % 2 === 0 ? "#1a2030" : "#221c28";
    ctx.fillRect(x, 120 - h, w, h);
    ctx.fillStyle = "#e7c36a";
    for (let wy = 120 - h + 6; wy < 112; wy += 8) {
      for (let wx = x + 4; wx < x + w - 4; wx += 8) {
        if ((wx + wy + i) % 16 === 0) ctx.fillRect(wx, wy, 2, 2);
      }
    }
    x += w + 6;
  }
}

export function paintWires(ctx: CanvasRenderingContext2D) {
  ctx.strokeStyle = "#3a3126";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(0, 28);
  ctx.bezierCurveTo(80, 40, 140, 18, 240, 30);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(0, 52);
  ctx.bezierCurveTo(100, 40, 180, 64, 320, 48);
  ctx.stroke();
  const cloth = ["#ff6b2c", "#e7c36a", "#f3ecdf", "#8d5b42"];
  for (let i = 0; i < 8; i++) {
    ctx.fillStyle = cloth[i % cloth.length] ?? "#ff6b2c";
    ctx.fillRect(18 + i * 38, 32 + (i % 3) * 6, 8, 10);
  }
}
