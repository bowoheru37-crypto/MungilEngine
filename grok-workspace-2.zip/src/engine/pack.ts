import type { Level, Project, Stamp } from "@/engine/types";

export function packTiles(tiles: Uint8Array): string {
  let out = "";
  let i = 0;
  while (i < tiles.length) {
    const value = tiles[i] ?? 0;
    let n = 1;
    while (i + n < tiles.length && tiles[i + n] === value && n < 35) n++;
    out += n.toString(36) + value.toString(36);
    i += n;
  }
  return out;
}

export function unpackTiles(packed: string, length: number): Uint8Array {
  const tiles = new Uint8Array(length);
  let i = 0;
  let cursor = 0;
  while (i + 1 < packed.length && cursor < length) {
    const n = parseInt(packed[i] ?? "1", 36);
    const value = parseInt(packed[i + 1] ?? "0", 36);
    const count = Number.isFinite(n) ? Math.max(1, n) : 1;
    const id = Number.isFinite(value) ? value : 0;
    for (let k = 0; k < count && cursor < length; k++) tiles[cursor++] = id;
    i += 2;
  }
  return tiles;
}

export function levelToProject(level: Level): Project {
  return {
    v: 1,
    name: level.name,
    w: level.w,
    h: level.h,
    tiles: packTiles(level.tiles),
    stamps: level.stamps.map((stamp) => ({ ...stamp })),
  };
}

export function projectToLevel(project: Project): Level {
  const w = Math.max(8, Math.min(80, project.w | 0));
  const h = Math.max(10, Math.min(24, project.h | 0));
  const tiles = unpackTiles(project.tiles || "", w * h);
  const stamps: Stamp[] = (project.stamps ?? []).filter(
    (stamp) =>
      stamp &&
      typeof stamp.x === "number" &&
      typeof stamp.y === "number" &&
      typeof stamp.k === "string",
  );
  return { w, h, tiles, stamps, seed: 0, name: project.name || "panggung" };
}
