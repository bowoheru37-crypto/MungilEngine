import { audio } from "@/engine/audio";
import {
  HERO_IDLE,
  HERO_JUMP,
  HERO_RUN,
  HOPPER,
  LANTERN,
  MOTH,
  blit,
  drawGlyph,
  drawTile,
  paintSkyline,
  paintWires,
} from "@/engine/pixels";
import { levelToProject } from "@/engine/pack";
import {
  FLOOR,
  TILE,
  type ControlsProbe,
  type Hud,
  type Level,
  type Project,
  type Quality,
  type Relic,
  type Stamp,
  type StampKind,
  type Tool,
} from "@/engine/types";
import { HOPPER_PROG, OP, relicMods, scoreOf } from "@/game/content";

const STEP = 1 / 60;
const GRAV_UP = 860;
const GRAV_DOWN = 1560;
const JUMP_V = -322;
const COYOTE = 0.11;
const BUFFER = 0.12;
const TERMINAL = 460;
const PMAX = 96;

type Kind = StampKind;

type Actor = {
  on: boolean;
  kind: Kind;
  x: number;
  y: number;
  px: number;
  py: number;
  w: number;
  h: number;
  vx: number;
  vy: number;
  facing: 1 | -1;
  hp: number;
  hurt: number;
  grounded: boolean;
  coyote: number;
  jumpBuf: number;
  drop: number;
  pc: number;
  wait: number;
  minX: number;
  maxX: number;
  var1: number;
  originY: number;
  jumpCut: boolean;
};

type Floater = { on: boolean; x: number; y: number; vy: number; life: number; text: string };

const COLORS = ["#ff6b2c", "#e7c36a", "#fff4d2", "#f3ecdf", "#8d5b42"];

function blank(): Actor {
  return {
    on: false,
    kind: "player",
    x: 0,
    y: 0,
    px: 0,
    py: 0,
    w: 12,
    h: 22,
    vx: 0,
    vy: 0,
    facing: 1,
    hp: 3,
    hurt: 0,
    grounded: false,
    coyote: 0,
    jumpBuf: 0,
    drop: 0,
    pc: 0,
    wait: 0,
    minX: 0,
    maxX: 0,
    var1: -1,
    originY: 0,
    jumpCut: false,
  };
}

function metrics(kind: Kind): { w: number; h: number } {
  if (kind === "player") return { w: 12, h: 22 };
  if (kind === "moth") return { w: 18, h: 12 };
  if (kind === "hopper") return { w: 14, h: 15 };
  if (kind === "platform") return { w: 36, h: 8 };
  if (kind === "goal") return { w: 14, h: 30 };
  return { w: 14, h: 18 };
}

export class Runtime {
  private readonly canvas: HTMLCanvasElement;
  private readonly ctx: CanvasRenderingContext2D;
  private readonly onHud: (hud: Hud) => void;
  private readonly onScore: (score: number) => void;
  private raf = 0;
  private last = 0;
  private acc = 0;
  private time = 0;
  private hidden = false;
  private reduce = false;
  private level: Level = { w: 8, h: 14, tiles: new Uint8Array(8 * 14), stamps: [], seed: 1, name: "" };
  private actors: Actor[] = [];
  private player: Actor | null = null;
  private mode: "run" | "studio" | "bench" = "run";
  private sandbox = false;
  private phase: Hud["phase"] = "play";
  private relic: Relic = "sepatu";
  private speed = 100;
  private pulseW = 20;
  private maxHp = 3;
  private embers = 0;
  private emberTotal = 0;
  private foes = 0;
  private spawnX = 32;
  private spawnY = 120;
  private camX = 0;
  private camY = 0;
  private viewW = 240;
  private viewH = 208;
  private quality: Quality = "pas";
  private trauma = 0;
  private flash = 0;
  private pulseT = 0;
  private pulseCd = 0;
  private message = "";
  private messageT = 0;
  private hoverX = -1;
  private hoverY = -1;
  private editBackup: Level | null = null;
  private bake: HTMLCanvasElement;
  private bctx: CanvasRenderingContext2D;
  private skyline: HTMLCanvasElement;
  private wires: HTMLCanvasElement;
  private sky: CanvasGradient | null = null;
  private keys = new Set<string>();
  private qa = new Set<string>();
  private wish = 0;
  private steer = 0;
  private jumpHeld = false;
  private dropHeld = false;
  private pulseTap = false;
  private jumpPrev = false;
  private pulsePrev = false;
  private dropPrev = false;
  private px = new Float32Array(PMAX);
  private py = new Float32Array(PMAX);
  private pvx = new Float32Array(PMAX);
  private pvy = new Float32Array(PMAX);
  private plife = new Float32Array(PMAX);
  private pcol = new Uint8Array(PMAX);
  private phead = 0;
  private pcap = 48;
  private floats: Floater[] = Array.from({ length: 6 }, () => ({
    on: false,
    x: 0,
    y: 0,
    vy: 0,
    life: 0,
    text: "",
  }));
  private ghost = blank();
  private haptic = true;
  private suspended = false;
  private hudTick = 0;
  private removed: Array<() => void> = [];

  constructor(
    canvas: HTMLCanvasElement,
    opts: {
      onHud: (hud: Hud) => void;
      onScore: (score: number) => void;
      quality: Quality;
      sound: boolean;
      haptic: boolean;
      reduce: boolean;
    },
  ) {
    this.canvas = canvas;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("kanvas");
    this.ctx = ctx;
    this.onHud = opts.onHud;
    this.onScore = opts.onScore;
    this.quality = opts.quality;
    this.haptic = opts.haptic;
    this.reduce = opts.reduce;
    audio.setMuted(!opts.sound);
    this.pcap = opts.quality === "hemat" ? 28 : opts.quality === "halus" ? 80 : 48;
    this.bake = document.createElement("canvas");
    const bctx = this.bake.getContext("2d");
    if (!bctx) throw new Error("peta");
    this.bctx = bctx;
    this.skyline = document.createElement("canvas");
    this.skyline.width = 480;
    this.skyline.height = 120;
    paintSkyline(this.skyline.getContext("2d")!);
    this.wires = document.createElement("canvas");
    this.wires.width = 320;
    this.wires.height = 80;
    paintWires(this.wires.getContext("2d")!);
    for (let i = 0; i < 40; i++) this.actors.push(blank());
    this.bind();
    this.resize();
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    for (const off of this.removed) off();
    this.removed = [];
    if (window.__controlsTest) delete window.__controlsTest;
  }

  setQuality(q: Quality) {
    this.quality = q;
    this.pcap = q === "hemat" ? 28 : q === "halus" ? 80 : 48;
    this.resize();
  }

  setSound(on: boolean) {
    audio.setMuted(!on);
    if (on) audio.unlock();
  }

  setHaptic(on: boolean) {
    this.haptic = on;
  }

  setPaused(paused: boolean) {
    this.suspended = paused;
    if (paused) {
      this.jumpHeld = false;
      this.dropHeld = false;
      this.wish = 0;
    }
  }

  setWish(x: number) {
    this.wish = Math.max(-1, Math.min(1, x));
  }

  setJump(held: boolean) {
    this.jumpHeld = held;
  }

  setDrop(held: boolean) {
    this.dropHeld = held;
  }

  tapPulse() {
    this.pulseTap = true;
  }

  resize() {
    const parent = this.canvas.parentElement;
    if (!parent) return;
    const box = parent.getBoundingClientRect();
    if (box.width < 8 || box.height < 8) return;
    const aspect = box.width / box.height;
    const cap = this.quality === "hemat" ? 260 : this.quality === "halus" ? 400 : 320;
    let bw: number;
    let bh: number;
    if (aspect < 1) {
      bh = cap;
      bw = Math.round(bh * aspect);
      if (bw < 188) {
        bw = 188;
        bh = Math.round(bw / aspect);
      }
    } else {
      bw = cap;
      bh = Math.round(bw / aspect);
      if (bh < 150) {
        bh = 150;
        bw = Math.round(bh * aspect);
      }
    }
    this.viewW = Math.max(160, bw & ~1);
    this.viewH = Math.max(140, bh & ~1);
    this.canvas.width = this.viewW;
    this.canvas.height = this.viewH;
    this.ctx.imageSmoothingEnabled = false;
    this.sky = this.ctx.createLinearGradient(0, 0, 0, this.viewH);
    this.sky.addColorStop(0, "#1a2230");
    this.sky.addColorStop(0.55, "#3c2a38");
    this.sky.addColorStop(1, "#6a3a28");
  }

  startRun(level: Level, relic: Relic) {
    this.mode = "run";
    this.sandbox = false;
    this.relic = relic;
    this.load(level, "play");
    this.message = "Kiri-kanan, lompat, denyut";
    this.messageT = 4.2;
  }

  startBench(level: Level) {
    this.mode = "bench";
    this.sandbox = true;
    this.relic = "lentera";
    this.load(level, "play");
    this.message = "Meja uji — lompat, denyut, jatuhkan";
    this.messageT = 3;
  }

  startEdit(level: Level) {
    this.mode = "studio";
    this.sandbox = false;
    this.relic = "sepatu";
    this.editBackup = null;
    this.load(level, "edit");
    this.camX = 0;
    this.camY = Math.min(0, (level.h * TILE - this.viewH) / 2);
  }

  playtest() {
    if (this.phase !== "edit") return;
    this.editBackup = cloneLevel(this.level);
    this.load(this.level, "play");
    this.sandbox = false;
    this.mode = "studio";
  }

  stopTest() {
    if (!this.editBackup) {
      this.phase = "edit";
      this.pushHud(true);
      return;
    }
    this.load(this.editBackup, "edit");
    this.editBackup = null;
    this.mode = "studio";
  }

  exportProject(): Project {
    return levelToProject(this.level);
  }

  paint(tool: Tool, clientX: number, clientY: number) {
    if (this.phase !== "edit") return;
    const world = this.clientToWorld(clientX, clientY);
    if (!world) return;
    if (tool === "pan") return;
    const tx = Math.floor(world.x / TILE);
    const ty = Math.floor(world.y / TILE);
    if (tx < 0 || ty < 0 || tx >= this.level.w || ty >= this.level.h) return;
    const tileTool: Record<string, number> = {
      solid: 1,
      crate: 6,
      oneway: 2,
      spike: 3,
      ember: 4,
      banner: 5,
      erase: 0,
    };
    if (tool in tileTool) {
      this.level.tiles[ty * this.level.w + tx] = tileTool[tool] ?? 0;
      if (tool === "erase") this.level.stamps = this.level.stamps.filter((s) => !sameCell(s, tx, ty));
      this.bakeCell(tx, ty);
      return;
    }
    const kind = tool as Kind;
    if (!["player", "moth", "hopper", "platform", "checkpoint", "goal"].includes(kind)) return;
    const x = tx * TILE;
    const y = ty * TILE;
    if (kind === "player" || kind === "goal") {
      this.level.stamps = this.level.stamps.filter((s) => s.k !== kind);
    } else {
      const hit = this.level.stamps.findIndex((s) => s.k === kind && sameCell(s, tx, ty));
      if (hit >= 0) {
        this.level.stamps.splice(hit, 1);
        return;
      }
    }
    this.level.stamps.push({
      k: kind,
      x,
      y,
      minX: kind === "platform" ? x - 48 : kind === "moth" ? x - 40 : x,
      maxX: kind === "platform" ? x + 64 : kind === "moth" ? x + 56 : x,
    });
  }

  hover(clientX: number, clientY: number) {
    const world = this.clientToWorld(clientX, clientY);
    if (!world) {
      this.hoverX = -1;
      return;
    }
    this.hoverX = Math.floor(world.x / TILE);
    this.hoverY = Math.floor(world.y / TILE);
  }

  pan(dx: number, dy: number) {
    const scale = this.canvas.width / Math.max(1, this.contentRect().w);
    this.camX = clamp(this.camX - dx * scale, -20, Math.max(0, this.level.w * TILE - this.viewW + 20));
    this.camY = clamp(this.camY - dy * scale, -40, Math.max(0, this.level.h * TILE - this.viewH + 40));
  }

  spawnKind(kind: Kind) {
    if (!this.player) return;
    const x = this.player.x + this.player.facing * 28;
    const y = kind === "moth" ? this.player.y - 36 : this.player.y;
    this.level.stamps.push({
      k: kind,
      x,
      y,
      minX: x - 40,
      maxX: x + 70,
    });
    this.awaken(kind, x, y, x - 40, x + 70);
  }

  nudge(kind: "shake" | "burst" | "note") {
    if (kind === "shake") this.shake(0.7);
    if (kind === "burst" && this.player) {
      this.burst(this.player.x, this.player.y, 14, 1);
      audio.denyut();
    }
    if (kind === "note") audio.coin();
  }

  private load(level: Level, phase: Hud["phase"]) {
    this.level = level;
    this.phase = phase;
    this.time = 0;
    this.embers = 0;
    this.foes = 0;
    this.acc = 0;
    this.trauma = 0;
    const mods = relicMods(this.relic);
    this.speed = mods.speed;
    this.pulseW = mods.pulseW;
    this.maxHp = mods.hp;
    this.emberTotal = 0;
    for (const id of level.tiles) if (id === 4) this.emberTotal++;
    this.bake.width = level.w * TILE;
    this.bake.height = level.h * TILE;
    this.bctx.imageSmoothingEnabled = false;
    this.rebake();
    for (const a of this.actors) a.on = false;
    this.player = null;
    if (phase !== "edit") {
      for (const s of level.stamps) this.awaken(s.k, s.x, s.y, s.minX, s.maxX);
      if (!this.player) this.awaken("player", TILE * 2, FLOOR * TILE - 22, 0, 0);
      if (this.player) {
        this.spawnX = this.player.x;
        this.spawnY = this.player.y;
        this.player.hp = this.maxHp;
        this.camX = this.player.x - this.viewW * 0.35;
        this.camY = this.centeredY(this.player.y);
      }
    }
    this.pushHud(true);
  }

  private awaken(kind: Kind, x: number, y: number, minX: number, maxX: number) {
    const actor = this.actors.find((a) => !a.on) ?? blank();
    if (!this.actors.includes(actor)) this.actors.push(actor);
    const size = metrics(kind);
    Object.assign(actor, blank(), {
      on: true,
      kind,
      x,
      y,
      px: x,
      py: y,
      w: size.w,
      h: size.h,
      facing: 1 as const,
      hp: kind === "player" ? this.maxHp : 1,
      minX,
      maxX,
      originY: y,
      var1: -1,
    });
    if (kind === "player") this.player = actor;
    return actor;
  }

  private bind() {
    const down = (e: KeyboardEvent) => {
      this.keys.add(e.code);
      if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) e.preventDefault();
    };
    const up = (e: KeyboardEvent) => this.keys.delete(e.code);
    const blur = () => {
      this.keys.clear();
      this.jumpHeld = false;
      this.dropHeld = false;
      this.wish = 0;
    };
    const vis = () => {
      this.hidden = document.hidden;
      if (!document.hidden) audio.unlock();
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    window.addEventListener("blur", blur);
    document.addEventListener("visibilitychange", vis);
    this.removed.push(() => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      window.removeEventListener("blur", blur);
      document.removeEventListener("visibilitychange", vis);
    });
    const probe: ControlsProbe = {
      getYaw: () => 0,
      getSpeed: () => this.player?.vx ?? 0,
      getX: () => this.player?.x ?? 0,
      getY: () => this.player?.y ?? 0,
      getFacing: () => this.player?.facing ?? 1,
      setKeys: (codes) => {
        this.qa = new Set(codes);
      },
      setSteer: (v) => {
        this.steer = v;
      },
    };
    window.__controlsTest = probe;
  }

  private loop = (now: number) => {
    const dt = Math.min(0.1, (now - this.last) / 1000 || 0);
    this.last = now;
    if (!this.hidden && !this.suspended && this.phase === "play") {
      this.acc += dt;
      let steps = 0;
      while (this.acc >= STEP && steps < 4) {
        this.sim(STEP);
        this.acc -= STEP;
        steps++;
      }
    } else {
      this.time += dt;
      if (this.messageT > 0) this.messageT -= dt;
    }
    const alpha = this.phase === "play" ? this.acc / STEP : 1;
    this.render(alpha);
    audio.tick();
    window.__kilatPhase = this.phase;
    this.raf = requestAnimationFrame(this.loop);
  };

  private sample() {
    const has = (code: string) => this.keys.has(code) || this.qa.has(code);
    let axis = (has("KeyD") || has("ArrowRight") ? 1 : 0) - (has("KeyA") || has("ArrowLeft") ? 1 : 0);
    if (axis === 0 && Math.abs(this.steer) > 0.05) axis = -this.steer;
    if (axis === 0) axis = this.wish;
    const jump = this.jumpHeld || has("Space") || has("KeyW") || has("ArrowUp");
    const drop = this.dropHeld || has("KeyS") || has("ArrowDown");
    const pulse = this.pulseTap || has("KeyJ") || has("KeyK");
    this.pulseTap = false;
    return { axis: Math.max(-1, Math.min(1, axis)), jump, drop, pulse };
  }

  private sim(dt: number) {
    this.time += dt;
    if (this.messageT > 0) this.messageT -= dt;
    const input = this.sample();
    for (const actor of this.actors) {
      if (!actor.on) continue;
      actor.px = actor.x;
      actor.py = actor.y;
    }
    this.stepPlatforms(dt);
    this.carry();
    const player = this.player;
    if (player?.on) this.stepPlayer(player, dt, input);
    for (const actor of this.actors) {
      if (!actor.on || actor.kind !== "hopper") continue;
      this.stepHopper(actor, dt);
    }
    for (const actor of this.actors) {
      if (!actor.on || actor.kind !== "moth") continue;
      this.stepMoth(actor, dt);
    }
    if (player?.on && this.phase === "play") this.interact(player, dt, input.pulse && !this.pulsePrev);
    this.pulsePrev = input.pulse;
    this.jumpPrev = input.jump;
    let i = 0;
    const cap = this.pcap;
    for (let n = 0; n < cap; n++) {
      const life = this.plife[n] ?? 0;
      if (life <= 0) continue;
      this.plife[n] = life - dt;
      this.px[n] = (this.px[n] ?? 0) + (this.pvx[n] ?? 0) * dt;
      this.py[n] = (this.py[n] ?? 0) + (this.pvy[n] ?? 0) * dt;
      this.pvy[n] = (this.pvy[n] ?? 0) + 280 * dt;
      i++;
    }
    for (const floater of this.floats) {
      if (!floater.on) continue;
      floater.life -= dt;
      floater.y += floater.vy * dt;
      if (floater.life <= 0) floater.on = false;
    }
    if (this.trauma > 0) this.trauma = Math.max(0, this.trauma - dt * 1.8);
    if (this.flash > 0) this.flash -= dt;
    this.followCamera(dt);
    this.hudTick += dt;
    if (this.hudTick > 0.12) {
      this.hudTick = 0;
      this.pushHud(false);
    }
  }

  private stepPlatforms(dt: number) {
    for (const actor of this.actors) {
      if (!actor.on || actor.kind !== "platform" || actor.maxX <= actor.minX) continue;
      actor.x += actor.facing * 46 * dt;
      if (actor.x < actor.minX) {
        actor.x = actor.minX;
        actor.facing = 1;
      } else if (actor.x > actor.maxX) {
        actor.x = actor.maxX;
        actor.facing = -1;
      }
    }
  }

  private carry() {
    const player = this.player;
    if (!player || player.var1 < 0) return;
    const plat = this.actors[player.var1];
    if (!plat?.on || plat.kind !== "platform") {
      player.var1 = -1;
      return;
    }
    player.x += plat.x - plat.px;
  }

  private stepPlayer(
    player: Actor,
    dt: number,
    input: { axis: number; jump: boolean; drop: boolean },
  ) {
    const was = player.grounded;
    if (was) player.coyote = COYOTE;
    else player.coyote = Math.max(0, player.coyote - dt);
    if (input.jump && !this.jumpPrev) player.jumpBuf = BUFFER;
    else player.jumpBuf = Math.max(0, player.jumpBuf - dt);
    if (input.drop) player.drop = 0.14;
    else player.drop = Math.max(0, player.drop - dt);
    const target = input.axis * this.speed;
    const rate = (was ? 1700 : 980) * dt;
    const diff = target - player.vx;
    player.vx += Math.abs(diff) <= rate ? diff : Math.sign(diff) * rate;
    if (input.axis < -0.15) player.facing = -1;
    else if (input.axis > 0.15) player.facing = 1;
    let g = player.vy < 0 ? GRAV_UP : GRAV_DOWN;
    if (Math.abs(player.vy) < 46) g *= 0.55;
    player.vy = Math.min(TERMINAL, player.vy + g * dt);
    if (!input.jump && player.vy < 0 && !player.jumpCut) {
      player.vy *= 0.48;
      player.jumpCut = true;
    }
    if (player.jumpBuf > 0 && !was && player.coyote > 0) {
      player.vy = JUMP_V;
      player.jumpBuf = 0;
      player.coyote = 0;
      player.jumpCut = false;
      audio.jump();
    }
    const fall = player.vy;
    player.grounded = false;
    this.moveBody(player, dt, was);
    if (player.grounded && player.jumpBuf > 0) {
      player.vy = JUMP_V;
      player.grounded = false;
      player.jumpBuf = 0;
      player.jumpCut = false;
      player.y += player.vy * dt;
      audio.jump();
    } else if (player.grounded && !was && fall > 120) {
      this.burst(player.x + player.w / 2, player.y + player.h, 4, 4);
      audio.land();
    }
    if (player.y > this.level.h * TILE) {
      this.hurt(0);
      if (this.phase === "play") this.respawn();
    }
  }

  private stepHopper(actor: Actor, dt: number) {
    if (actor.wait > 0) actor.wait -= 1;
    else this.op(actor);
    const was = actor.grounded;
    let g = actor.vy < 0 ? GRAV_UP : GRAV_DOWN;
    actor.vy = Math.min(TERMINAL, actor.vy + g * dt);
    actor.grounded = false;
    this.moveBody(actor, dt, was);
    if (was && actor.grounded && Math.abs(actor.vx) > 8 && Math.abs(actor.x - actor.px) < 0.2) {
      actor.facing = actor.facing === 1 ? -1 : 1;
      actor.vx = actor.facing * Math.abs(actor.vx);
    }
    if (actor.maxX > actor.minX) {
      if (actor.x < actor.minX) {
        actor.x = actor.minX;
        actor.facing = 1;
        actor.vx = Math.abs(actor.vx);
      } else if (actor.x > actor.maxX) {
        actor.x = actor.maxX;
        actor.facing = -1;
        actor.vx = -Math.abs(actor.vx);
      }
    }
    if (actor.y > this.level.h * TILE) actor.on = false;
  }

  private op(actor: Actor) {
    const prog = HOPPER_PROG;
    const op = prog[actor.pc];
    const player = this.player;
    if (op === undefined) {
      actor.pc = 0;
      return;
    }
    if (op === OP.face) {
      actor.pc += 1;
      if (player) actor.facing = player.x < actor.x ? -1 : 1;
    } else if (op === OP.wait) {
      actor.wait = prog[actor.pc + 1] ?? 0;
      actor.pc += 2;
    } else if (op === OP.hop) {
      actor.pc += 1;
      if (actor.grounded) actor.vy = -250;
    } else if (op === OP.speed) {
      const speed = prog[actor.pc + 1] ?? 0;
      actor.pc += 2;
      actor.vx = actor.facing * speed;
    } else if (op === OP.goto) {
      actor.pc = prog[actor.pc + 1] ?? 0;
    } else if (op === OP.turn) {
      actor.pc += 1;
      actor.facing = actor.facing === 1 ? -1 : 1;
    } else actor.pc += 1;
  }

  private stepMoth(actor: Actor, dt: number) {
    actor.originY = actor.originY || actor.py;
    const player = this.player;
    const close = !!player && Math.abs(player.x - actor.x) < 70 && player.y > actor.y + 6;
    if (close) actor.y += 78 * dt;
    else {
      const home = actor.originY + Math.sin(this.time * 3 + actor.x) * 8;
      actor.y += (home - actor.y) * Math.min(1, dt * 4);
    }
    actor.x += actor.facing * 30 * dt;
    if (actor.maxX > actor.minX) {
      if (actor.x < actor.minX) {
        actor.x = actor.minX;
        actor.facing = 1;
      } else if (actor.x > actor.maxX) {
        actor.x = actor.maxX;
        actor.facing = -1;
      }
    }
    if (this.overlapsSolid(actor.x, actor.y, actor.w, actor.h)) actor.y -= 30 * dt;
  }

  private interact(player: Actor, dt: number, pulseEdge: boolean) {
    if (pulseEdge && this.pulseCd <= 0) {
      this.pulseT = 0.12;
      this.pulseCd = 0.34;
      audio.denyut();
      this.buzz(8);
    }
    if (this.pulseT > 0) this.pulseT -= dt;
    if (this.pulseCd > 0) this.pulseCd -= dt;
    const rect = this.pulseRect(player);
    for (let i = 0; i < this.actors.length; i++) {
      const actor = this.actors[i];
      if (!actor?.on || actor === player) continue;
      if (actor.kind === "checkpoint" && overlap(player, actor)) {
        this.spawnX = actor.x;
        this.spawnY = actor.y + actor.h - player.h;
        if (actor.var1 !== 1) {
          actor.var1 = 1;
          audio.coin();
        }
      } else if (actor.kind === "goal" && overlap(player, actor)) {
        this.finish(true);
      } else if (actor.kind === "platform") {
        if (player.drop <= 0 && this.landPlatform(player, actor)) player.var1 = i;
      } else if ((actor.kind === "moth" || actor.kind === "hopper") && actor.on) {
        if (this.pulseT > 0 && overlapRect(actor, rect)) {
          actor.on = false;
          this.foes += 1;
          this.burst(actor.x, actor.y, 10, 0);
          this.floatAt(actor.x, actor.y, "+50");
          this.shake(0.35);
          this.flash = 0.05;
          audio.denyut();
          this.pushHud(true);
        } else if (player.hurt <= 0 && overlap(player, actor)) {
          const knock = player.x < actor.x ? -110 : 110;
          this.hurt(knock);
        }
      }
    }
    if (player.var1 >= 0) {
      const plat = this.actors[player.var1];
      if (!plat?.on || !this.stillOn(player, plat)) player.var1 = -1;
    }
    this.collect(player);
    if (player.hurt > 0) player.hurt -= dt;
  }

  private collect(player: Actor) {
    const x0 = Math.floor(player.x / TILE);
    const x1 = Math.floor((player.x + player.w - 0.01) / TILE);
    const y0 = Math.floor(player.y / TILE);
    const y1 = Math.floor((player.y + player.h - 0.01) / TILE);
    let spiked = false;
    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        const id = this.tile(tx, ty);
        if (id === 4) {
          this.level.tiles[ty * this.level.w + tx] = 0;
          this.embers += 1;
          this.burst(tx * TILE + 8, ty * TILE + 8, 8, 1);
          this.floatAt(tx * TILE, ty * TILE, "+25");
          audio.coin();
          this.bakeCell(tx, ty);
          this.pushHud(true);
        } else if (id === 3) spiked = true;
      }
    }
    if (spiked) this.hurt(player.facing * -80);
  }

  private hurt(knock: number) {
    const player = this.player;
    if (!player || player.hurt > 0 || this.phase !== "play") return;
    player.hurt = this.sandbox ? 0.45 : 0.95;
    player.vy = -150;
    player.vx = knock;
    player.grounded = false;
    this.shake(0.5);
    this.flash = 0.08;
    audio.hit();
    this.buzz(18);
    if (this.sandbox) return;
    player.hp -= 1;
    this.pushHud(true);
    if (player.hp <= 0) this.finish(false);
  }

  private respawn() {
    const player = this.player;
    if (!player || this.phase !== "play") return;
    player.x = this.spawnX;
    player.y = this.spawnY;
    player.px = player.x;
    player.py = player.y;
    player.vx = 0;
    player.vy = 0;
    player.var1 = -1;
  }

  private finish(win: boolean) {
    if (this.phase !== "play") return;
    this.phase = win ? "win" : "dead";
    if (win) {
      audio.win();
      this.shake(0.25);
    }
    this.onScore(this.currentScore());
    this.pushHud(true);
  }

  private moveBody(actor: Actor, dt: number, allowStep: boolean) {
    actor.x += actor.vx * dt;
    if (this.overlapsSolid(actor.x, actor.y, actor.w, actor.h)) {
      let stepped = false;
      if (allowStep) {
        for (let rise = 1; rise <= TILE; rise++) {
          if (!this.overlapsSolid(actor.x, actor.y - rise, actor.w, actor.h)) {
            actor.y -= rise;
            stepped = true;
            break;
          }
        }
      }
      if (!stepped) {
        if (actor.vx > 0) actor.x = this.flushX(actor, 1);
        else actor.x = this.flushX(actor, -1);
        actor.vx = 0;
      }
    }
    actor.y += actor.vy * dt;
    this.resolveY(actor);
  }

  private resolveY(actor: Actor) {
    const x0 = Math.floor((actor.x + 1) / TILE);
    const x1 = Math.floor((actor.x + actor.w - 1.01) / TILE);
    if (actor.vy >= 0) {
      const y1 = Math.floor((actor.y + actor.h - 0.01) / TILE);
      const prev = actor.py + actor.h;
      for (let ty = Math.floor(actor.y / TILE); ty <= y1; ty++) {
        for (let tx = x0; tx <= x1; tx++) {
          const id = this.tile(tx, ty);
          const top = ty * TILE;
          if (id === 1 || id === 6) {
            actor.y = top - actor.h;
            actor.vy = 0;
            actor.grounded = true;
            return;
          }
          if (id === 2 && actor.drop <= 0 && prev <= top + 1 && actor.y + actor.h >= top) {
            actor.y = top - actor.h;
            actor.vy = 0;
            actor.grounded = true;
            return;
          }
        }
      }
    } else {
      const y0 = Math.floor(actor.y / TILE);
      for (let ty = y0; ty <= Math.floor((actor.y + actor.h) / TILE); ty++) {
        for (let tx = x0; tx <= x1; tx++) {
          const id = this.tile(tx, ty);
          if (id === 1 || id === 6) {
            actor.y = (ty + 1) * TILE;
            actor.vy = 0;
            return;
          }
        }
      }
    }
  }

  private landPlatform(player: Actor, plat: Actor) {
    if (player.vy < 0 || player.drop > 0) return false;
    const prev = player.py + player.h;
    if (prev > plat.y + 3) return false;
    if (player.x + player.w <= plat.x + 1 || player.x >= plat.x + plat.w - 1) return false;
    if (player.y + player.h < plat.y || player.y > plat.y + plat.h) return false;
    player.y = plat.y - player.h;
    player.vy = 0;
    player.grounded = true;
    return true;
  }

  private stillOn(player: Actor, plat: Actor) {
    return (
      player.grounded &&
      player.x + player.w > plat.x + 2 &&
      player.x < plat.x + plat.w - 2 &&
      Math.abs(player.y + player.h - plat.y) < 2.5
    );
  }

  private overlapsSolid(x: number, y: number, w: number, h: number) {
    const x0 = Math.floor((x + 0.5) / TILE);
    const x1 = Math.floor((x + w - 0.5) / TILE);
    const y0 = Math.floor((y + 1) / TILE);
    const y1 = Math.floor((y + h - 2) / TILE);
    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        const id = this.tile(tx, ty);
        if (id === 1 || id === 6) return true;
      }
    }
    return false;
  }

  private flushX(actor: Actor, dir: 1 | -1) {
    const y0 = Math.floor((actor.y + 2) / TILE);
    const y1 = Math.floor((actor.y + actor.h - 3) / TILE);
    if (dir > 0) {
      const x1 = Math.floor((actor.x + actor.w - 0.01) / TILE);
      for (let tx = x1; tx >= x1 - 2; tx--) {
        for (let ty = y0; ty <= y1; ty++) {
          if (this.tile(tx, ty) === 1 || this.tile(tx, ty) === 6) return tx * TILE - actor.w;
        }
      }
    } else {
      const x0 = Math.floor(actor.x / TILE);
      for (let tx = x0; tx <= x0 + 2; tx++) {
        for (let ty = y0; ty <= y1; ty++) {
          if (this.tile(tx, ty) === 1 || this.tile(tx, ty) === 6) return (tx + 1) * TILE;
        }
      }
    }
    return actor.px;
  }

  private tile(tx: number, ty: number) {
    if (tx < 0 || tx >= this.level.w) return 1;
    if (ty < 0 || ty >= this.level.h) return 0;
    return this.level.tiles[ty * this.level.w + tx] ?? 0;
  }

  private followCamera(dt: number) {
    if (this.phase === "edit" || !this.player) return;
    const player = this.player;
    const ix = player.px + (player.x - player.px);
    const iy = player.py + (player.y - player.py);
    const targetX = ix + player.w / 2 - this.viewW * 0.42 + player.facing * 28;
    const targetY = this.centeredY(iy);
    const k = 1 - Math.exp(-8 * dt);
    const maxX = Math.max(0, this.level.w * TILE - this.viewW);
    const maxY = Math.max(0, this.level.h * TILE - this.viewH);
    this.camX += (clamp(targetX, 0, maxX) - this.camX) * k;
    this.camY += (clamp(targetY, 0, maxY) - this.camY) * k;
  }

  private centeredY(feet: number) {
    const mapH = this.level.h * TILE;
    if (mapH <= this.viewH) return (mapH - this.viewH) / 2;
    return feet - this.viewH * 0.62;
  }

  private rebake() {
    const { w, h, tiles } = this.level;
    this.bctx.clearRect(0, 0, this.bake.width, this.bake.height);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) this.paintCell(x, y, tiles[y * w + x] ?? 0);
    }
  }

  private bakeCell(tx: number, ty: number) {
    this.paintCell(tx, ty, this.tile(tx, ty));
  }

  private paintCell(tx: number, ty: number, id: number) {
    const x = tx * TILE;
    const y = ty * TILE;
    this.bctx.clearRect(x, y, TILE, TILE);
    if ((id === 0 || id === 4) && ty >= FLOOR) {
      this.bctx.fillStyle = "#120c0a";
      this.bctx.fillRect(x, y, TILE, TILE);
    }
    if (id && id !== 4) drawTile(this.bctx, id, x, y, 0);
  }

  private render(alpha: number) {
    const ctx = this.ctx;
    const a = Number.isFinite(alpha) ? alpha : 1;
    ctx.imageSmoothingEnabled = false;
    if (this.sky) {
      ctx.fillStyle = this.sky;
      ctx.fillRect(0, 0, this.viewW, this.viewH);
    }
    const shake = this.trauma * this.trauma * (this.reduce ? 0 : 5);
    const sx = Math.round((Math.random() * 2 - 1) * shake);
    const sy = Math.round((Math.random() * 2 - 1) * shake);
    const camX = Math.round(this.camX) + sx;
    const camY = Math.round(this.camY) + sy;
    ctx.fillStyle = "#f3ecdf";
    ctx.beginPath();
    ctx.arc(this.viewW * 0.78 - camX * 0.04, 28 - camY * 0.02, 9, 0, Math.PI * 2);
    ctx.fill();
    const sw = this.skyline.width;
    const shift = ((Math.round(camX * 0.2) % sw) + sw) % sw;
    const horizon = Math.round(this.viewH * 0.36);
    ctx.drawImage(this.skyline, -shift, horizon);
    ctx.drawImage(this.skyline, -shift + sw, horizon);
    const ww = this.wires.width;
    const wshift = ((Math.round(camX * 0.45) % ww) + ww) % ww;
    ctx.drawImage(this.wires, -wshift, horizon + 28);
    ctx.drawImage(this.wires, -wshift + ww, horizon + 36);
    this.blitBake(camX, camY);
    const x0 = Math.max(0, Math.floor(camX / TILE) - 1);
    const x1 = Math.min(this.level.w - 1, Math.floor((camX + this.viewW) / TILE) + 1);
    const y0 = Math.max(0, Math.floor(camY / TILE) - 1);
    const y1 = Math.min(this.level.h - 1, Math.floor((camY + this.viewH) / TILE) + 1);
    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        if (this.tile(tx, ty) === 4) drawTile(ctx, 4, tx * TILE - camX, ty * TILE - camY, this.time);
      }
    }
    const order: Kind[] = ["platform", "checkpoint", "goal", "hopper", "moth", "player"];
    for (const kind of order) {
      for (const actor of this.actors) {
        if (!actor.on || actor.kind !== kind) continue;
        if (actor === this.player && actor.hurt > 0 && Math.floor(actor.hurt * 16) % 2 === 0) continue;
        const ix = actor.px + (actor.x - actor.px) * a - camX;
        const iy = actor.py + (actor.y - actor.py) * a - camY;
        this.drawActor(actor, ix, iy);
      }
    }
    if (this.player && this.pulseT > 0) {
      const player = this.player;
      const rect = this.pulseRect(player);
      const iy = player.py + (player.y - player.py) * a;
      ctx.fillStyle = "#ff6b2c";
      ctx.globalAlpha = 0.85;
      ctx.fillRect(rect.x - camX, rect.y - player.y + iy - camY, rect.w, rect.h);
      ctx.globalAlpha = 1;
    }
    for (let n = 0; n < this.pcap; n++) {
      if ((this.plife[n] ?? 0) <= 0) continue;
      ctx.fillStyle = COLORS[this.pcol[n] ?? 0] ?? "#fff4d2";
      ctx.fillRect(Math.round((this.px[n] ?? 0) - camX), Math.round((this.py[n] ?? 0) - camY), 2, 2);
    }
    for (const floater of this.floats) {
      if (!floater.on) continue;
      drawGlyph(ctx, floater.text, Math.round(floater.x - camX), Math.round(floater.y - camY), "#e7c36a", 2);
    }
    if (this.phase === "edit") {
      ctx.globalAlpha = 0.18;
      ctx.strokeStyle = "#f3ecdf";
      ctx.beginPath();
      for (let tx = x0; tx <= x1; tx++) {
        ctx.moveTo(tx * TILE - camX, 0);
        ctx.lineTo(tx * TILE - camX, this.viewH);
      }
      for (let ty = y0; ty <= y1; ty++) {
        ctx.moveTo(0, ty * TILE - camY);
        ctx.lineTo(this.viewW, ty * TILE - camY);
      }
      ctx.stroke();
      ctx.globalAlpha = 1;
      if (this.hoverX >= 0) {
        ctx.strokeStyle = "#e7c36a";
        ctx.strokeRect(this.hoverX * TILE - camX, this.hoverY * TILE - camY, TILE, TILE);
      }
      for (const stamp of this.level.stamps) {
        const size = metrics(stamp.k);
        this.ghost.on = true;
        this.ghost.kind = stamp.k;
        this.ghost.x = stamp.x;
        this.ghost.y = stamp.y;
        this.ghost.w = size.w;
        this.ghost.h = size.h;
        this.ghost.facing = 1;
        this.ghost.grounded = true;
        this.ghost.vx = 0;
        this.ghost.vy = 0;
        this.drawActor(this.ghost, stamp.x - camX, stamp.y - camY);
      }
    }
    if (this.flash > 0) {
      ctx.fillStyle = `rgba(255,107,44,${Math.min(0.35, this.flash * 3)})`;
      ctx.fillRect(0, 0, this.viewW, this.viewH);
    }
  }

  private blitBake(camX: number, camY: number) {
    const sx = Math.max(0, camX);
    const sy = Math.max(0, camY);
    const dx = camX < 0 ? -camX : 0;
    const dy = camY < 0 ? -camY : 0;
    const sw = Math.min(this.bake.width - sx, this.viewW - dx);
    const sh = Math.min(this.bake.height - sy, this.viewH - dy);
    if (sw > 0 && sh > 0) this.ctx.drawImage(this.bake, sx, sy, sw, sh, dx, dy, sw, sh);
  }

  private drawActor(actor: Actor, x: number, y: number) {
    const ctx = this.ctx;
    if (actor.kind === "player") {
      let frame = HERO_IDLE[Math.floor(this.time * 3) % 2] ?? HERO_IDLE[0]!;
      if (!actor.grounded) frame = actor.vy < 30 ? HERO_JUMP[0]! : HERO_JUMP[1]!;
      else if (Math.abs(actor.vx) > 18) frame = HERO_RUN[Math.floor(this.time * 10) % 4] ?? HERO_RUN[0]!;
      blit(ctx, frame, x + actor.w / 2 - 16, y + actor.h - 39, 2, actor.facing === -1);
      return;
    }
    if (actor.kind === "moth") {
      const frame = MOTH[Math.floor(this.time * 8 + actor.x) % 2] ?? MOTH[0]!;
      blit(ctx, frame, x + actor.w / 2 - 16, y + actor.h - 20, 2, actor.facing === -1);
      return;
    }
    if (actor.kind === "hopper") {
      const frame = HOPPER[actor.grounded ? 0 : 1]!;
      blit(ctx, frame, x + actor.w / 2 - 16, y + actor.h - 32, 2, actor.facing === -1);
      return;
    }
    if (actor.kind === "platform") {
      ctx.fillStyle = "#6a4634";
      ctx.fillRect(Math.round(x), Math.round(y), actor.w, actor.h);
      ctx.fillStyle = "#e7c36a";
      ctx.fillRect(Math.round(x) + 4, Math.round(y) + 3, 3, 3);
      ctx.fillRect(Math.round(x) + actor.w - 7, Math.round(y) + 3, 3, 3);
      return;
    }
    if (actor.kind === "checkpoint") {
      blit(ctx, LANTERN, x + 1, y, 2, false);
      if (actor.var1 === 1) {
        ctx.fillStyle = "#e7c36a";
        ctx.fillRect(Math.round(x) + 6, Math.round(y) + 4, 4, 4);
      }
      return;
    }
    ctx.fillStyle = "#241810";
    ctx.fillRect(Math.round(x) + 4, Math.round(y), 3, actor.h);
    const wave = Math.round(Math.sin(this.time * 6) * 1);
    ctx.fillStyle = "#ff6b2c";
    ctx.fillRect(Math.round(x) + 7, Math.round(y) + 4, 12, 8);
    ctx.fillStyle = "#e7c36a";
    ctx.fillRect(Math.round(x) + 7, Math.round(y) + 8 + wave, 12, 3);
  }

  private pulseRect(player: Actor) {
    return {
      x: player.facing === 1 ? player.x + player.w - 2 : player.x - this.pulseW + 2,
      y: player.y + 4,
      w: this.pulseW,
      h: 14,
    };
  }

  private burst(x: number, y: number, n: number, col: number) {
    for (let i = 0; i < n; i++) {
      const slot = this.phead % this.pcap;
      this.phead++;
      const ang = (i / n) * Math.PI * 2;
      const sp = 20 + (i % 5) * 12;
      this.px[slot] = x;
      this.py[slot] = y;
      this.pvx[slot] = Math.cos(ang) * sp;
      this.pvy[slot] = Math.sin(ang) * sp - 20;
      this.plife[slot] = 0.35 + (i % 3) * 0.08;
      this.pcol[slot] = (col + i) % COLORS.length;
    }
  }

  private floatAt(x: number, y: number, text: string) {
    const slot = this.floats.find((f) => !f.on) ?? this.floats[0]!;
    slot.on = true;
    slot.x = x;
    slot.y = y;
    slot.vy = -28;
    slot.life = 0.7;
    slot.text = text;
  }

  private shake(n: number) {
    if (this.reduce) return;
    this.trauma = Math.min(1, this.trauma + n);
  }

  private buzz(ms: number) {
    if (!this.haptic || this.reduce) return;
    navigator.vibrate?.(ms);
  }

  private currentScore() {
    return scoreOf(this.embers, this.foes, this.time, this.phase === "win");
  }

  private pushHud(force: boolean) {
    if (!force && this.hudTick < 0) return;
    const player = this.player;
    const atapTotal = this.mode === "run" ? Math.round(this.level.w / 18) : 0;
    const atap = player ? Math.min(atapTotal, Math.floor(player.x / (18 * TILE)) + 1) : 1;
    const hud: Hud = {
      hp: player?.hp ?? 0,
      maxHp: this.maxHp,
      embers: this.embers,
      emberTotal: this.emberTotal,
      foes: this.foes,
      time: this.time,
      score: this.currentScore(),
      phase: this.phase,
      atap,
      atapTotal,
      seed: this.level.seed,
      pulse: this.pulseCd > 0 ? this.pulseCd : 0,
      message: this.messageT > 0 ? this.message : "",
    };
    this.onHud(hud);
  }

  private contentRect() {
    const rect = this.canvas.getBoundingClientRect();
    const scale = Math.min(rect.width / this.viewW, rect.height / this.viewH);
    const w = this.viewW * scale;
    const h = this.viewH * scale;
    return { x: rect.left + (rect.width - w) / 2, y: rect.top + (rect.height - h) / 2, w, h };
  }

  private clientToWorld(clientX: number, clientY: number) {
    const box = this.contentRect();
    if (clientX < box.x || clientY < box.y || clientX > box.x + box.w || clientY > box.y + box.h) return null;
    const sx = ((clientX - box.x) / box.w) * this.viewW;
    const sy = ((clientY - box.y) / box.h) * this.viewH;
    return { x: sx + this.camX, y: sy + this.camY };
  }
}

function overlap(a: Actor, b: Actor) {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}

function overlapRect(a: Actor, r: { x: number; y: number; w: number; h: number }) {
  return a.x < r.x + r.w && a.x + a.w > r.x && a.y < r.y + r.h && a.y + a.h > r.y;
}

function sameCell(stamp: Stamp, tx: number, ty: number) {
  return Math.floor(stamp.x / TILE) === tx && Math.floor(stamp.y / TILE) === ty;
}

function cloneLevel(level: Level): Level {
  return {
    ...level,
    tiles: new Uint8Array(level.tiles),
    stamps: level.stamps.map((stamp) => ({ ...stamp })),
  };
}

function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v));
}
