const PATTERN = [220, 261.6, 329.6, 261.6, 293.7, 261.6, 246.9, 196];

export class AudioBus {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private next = 0;
  private step = 0;
  private voices = 0;
  muted = false;
  music = false;

  unlock() {
    if (typeof window === "undefined") return;
    const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    if (!this.ctx) {
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.9;
      this.master.connect(this.ctx.destination);
      const buffer = this.ctx.createBuffer(1, this.ctx.sampleRate, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
      this.noise = buffer;
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    if (!this.muted && !this.music) this.startMusic();
  }

  setMuted(muted: boolean) {
    this.muted = muted;
    if (!this.master || !this.ctx) return;
    this.master.gain.setTargetAtTime(muted ? 0 : 0.9, this.ctx.currentTime, 0.03);
    if (!muted) this.startMusic();
  }

  tick() {
    if (!this.ctx || this.muted || !this.music) return;
    const t = this.ctx.currentTime;
    if (this.next < t) this.next = t + 0.05;
    while (this.next < t + 0.25) {
      this.toneAt(this.next, PATTERN[this.step] ?? 220, 0.22, "triangle", 0.035);
      this.step = (this.step + 1) % PATTERN.length;
      this.next += 0.3;
    }
  }

  private startMusic() {
    if (!this.ctx || this.muted) return;
    this.music = true;
    this.next = this.ctx.currentTime + 0.05;
  }

  jump() {
    this.tone(520, 0.09, "square", 0.05);
    this.tone(780, 0.07, "square", 0.03);
  }

  land() {
    this.tone(140, 0.06, "sine", 0.04);
  }

  coin() {
    this.tone(880, 0.06, "square", 0.04);
    this.tone(1320, 0.08, "square", 0.03);
  }

  hit() {
    this.noiseBurst(0.12, 0.08);
    this.tone(90, 0.1, "sawtooth", 0.04);
  }

  denyut() {
    this.tone(180, 0.08, "square", 0.05);
    this.tone(420, 0.1, "triangle", 0.04);
  }

  win() {
    this.tone(523, 0.12, "triangle", 0.05);
    this.tone(659, 0.14, "triangle", 0.05);
    this.tone(784, 0.2, "triangle", 0.05);
  }

  private tone(freq: number, dur: number, type: OscillatorType, gain: number) {
    if (!this.ctx) return;
    this.toneAt(this.ctx.currentTime, freq, dur, type, gain);
  }

  private toneAt(time: number, freq: number, dur: number, type: OscillatorType, gain: number) {
    if (!this.ctx || !this.master || this.muted || this.voices > 6) return;
    const osc = this.ctx.createOscillator();
    const amp = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, time);
    amp.gain.setValueAtTime(gain, time);
    amp.gain.exponentialRampToValueAtTime(0.0008, time + dur);
    osc.connect(amp);
    amp.connect(this.master);
    osc.start(time);
    osc.stop(time + dur + 0.02);
    this.voices++;
    osc.onended = () => {
      this.voices = Math.max(0, this.voices - 1);
    };
  }

  private noiseBurst(dur: number, gain: number) {
    if (!this.ctx || !this.master || !this.noise || this.muted) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noise;
    const amp = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 800;
    const t = this.ctx.currentTime;
    amp.gain.setValueAtTime(gain, t);
    amp.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    src.connect(filter);
    filter.connect(amp);
    amp.connect(this.master);
    src.start(t);
    src.stop(t + dur);
  }
}

export const audio = new AudioBus();
