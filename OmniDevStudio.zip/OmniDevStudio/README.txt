OMNI DEV STUDIO v1.0.0-lite
===========================
AIDE-Compatible Android Project Manager
Optimized for: itel A70 | 1GB RAM | Android 5+ | 16GB Storage

BUILD INSTRUCTIONS (AIDE):
1. Extract this ZIP to /sdcard/AppProjects/
2. Open AIDE -> Open Project -> OmniDevStudio
3. Let AIDE sync/build
4. Run on device

FEATURES:
- Zero bitmap assets (all XML shapes = zero OOM)
- Java 7 100% compliant (no lambda, no streams)
- Null-safe defensive code (zero NPE)
- WeakReference AsyncTask (zero leak)
- Static ViewHolder (zero lag list)
- Dark theme (battery & thermal optimized)
- Project create/delete/open
- Basic text editor with save
- Auto template generator

PROJECT STRUCTURE:
- src/com/omnidev/studio/       : Source
- res/layout/                   : XML Layouts
- res/values/                   : Colors, Strings, Styles
- res/drawable/                 : Vector shapes only
- AndroidManifest.xml           : Min SDK 21, Target 21

NOTES:
- Uses android.app.ProgressDialog (deprecated in API 26+ but safe for 21)
- Uses android.os.AsyncTask (deprecated in API 30+ but safe for 21)
- No external libraries = minimal APK size
- No RecyclerView (ListView = lighter for 1GB RAM)
- No ConstraintLayout (LinearLayout = faster inflate)

LICENSE: Public Domain / Use freely
