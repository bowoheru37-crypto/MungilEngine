package com.omnidev.studio;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.omnidev.studio.adapter.ProjectAdapter;
import com.omnidev.studio.model.Project;
import com.omnidev.studio.task.ScanTask;
import com.omnidev.studio.util.FileUtil;
import java.io.File;
import java.util.ArrayList;

public class ProjectActivity extends Activity implements ScanTask.Callback {

    private ListView mListView;
    private TextView mEmptyView;
    private Button mBtnNew;
    private ProjectAdapter mAdapter;
    private ArrayList<Project> mProjects = new ArrayList<Project>();
    private ScanTask mScanTask;
    private ProgressDialog mProgress;

    private final View.OnClickListener mOpenListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Object tag = v.getTag();
            if (tag == null) return;
            int pos = ((Integer) tag).intValue();
            if (pos < 0 || pos >= mProjects.size()) return;
            Project p = mProjects.get(pos);
            if (p == null) return;
            openProject(p);
        }
    };

    private final View.OnClickListener mDeleteListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Object tag = v.getTag();
            if (tag == null) return;
            int pos = ((Integer) tag).intValue();
            if (pos < 0 || pos >= mProjects.size()) return;
            final Project p = mProjects.get(pos);
            if (p == null) return;
            confirmDelete(p);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project);

        mListView = (ListView) findViewById(R.id.list_projects);
        mEmptyView = (TextView) findViewById(R.id.tv_empty);
        mBtnNew = (Button) findViewById(R.id.btn_new_project);

        mAdapter = new ProjectAdapter(this, mProjects, mOpenListener, mDeleteListener);
        if (mListView != null) {
            mListView.setAdapter(mAdapter);
            mListView.setEmptyView(mEmptyView);
        }

        if (mBtnNew != null) {
            mBtnNew.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showNewProjectDialog();
                }
            });
        }

        handleTemplateIntent();
        refreshList();
    }

    private void handleTemplateIntent() {
        Intent intent = getIntent();
        if (intent == null) return;
        int template = intent.getIntExtra("template", -1);
        if (template >= 0) {
            String[] names = new String[]{"EmptyActivity", "BasicGame", "ConsoleApp"};
            createProject(names[template]);
        }
    }

    private void refreshList() {
        if (mScanTask != null) {
            mScanTask.cancel(true);
        }
        mScanTask = new ScanTask(this);
        mScanTask.execute();
    }

    @Override
    public void onScanComplete(ArrayList<Project> projects) {
        mProjects.clear();
        if (projects != null) {
            mProjects.addAll(projects);
        }
        mAdapter.notifyDataSetChanged();
        if (mEmptyView != null) {
            mEmptyView.setText(mProjects.size() == 0 ? "No projects found.\nTap + to create one." : "");
        }
    }

    private void showNewProjectDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("New Project");

        final EditText input = new EditText(this);
        input.setHint("Project name (no spaces)");
        input.setSingleLine(true);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        layout.setPadding(pad, pad, pad, pad);
        layout.addView(input);
        builder.setView(layout);

        builder.setPositiveButton("Create", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String name = input.getText().toString().trim();
                if (TextUtils.isEmpty(name)) {
                    Toast.makeText(ProjectActivity.this, "Name required", Toast.LENGTH_SHORT).show();
                    return;
                }
                createProject(name);
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void createProject(final String name) {
        if (mProgress == null) {
            mProgress = new ProgressDialog(this);
            mProgress.setMessage("Creating project...");
            mProgress.setCancelable(false);
        }
        mProgress.show();

        new Thread(new Runnable() {
            @Override
            public void run() {
                File base = FileUtil.getAideProjectsDir();
                final boolean ok = FileUtil.createProjectStructure(name, base != null ? base.getAbsolutePath() : "/sdcard/AppProjects");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mProgress != null && mProgress.isShowing()) {
                            mProgress.dismiss();
                        }
                        if (ok) {
                            Toast.makeText(ProjectActivity.this, "Project created", Toast.LENGTH_SHORT).show();
                            refreshList();
                        } else {
                            Toast.makeText(ProjectActivity.this, "Failed or exists", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }).start();
    }

    private void confirmDelete(final Project p) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Project?");
        builder.setMessage("This will delete\n" + p.getName() + "\nforever.");
        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                doDelete(p);
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void doDelete(final Project p) {
        if (mProgress == null) {
            mProgress = new ProgressDialog(this);
            mProgress.setMessage("Deleting...");
            mProgress.setCancelable(false);
        }
        mProgress.show();

        new Thread(new Runnable() {
            @Override
            public void run() {
                File target = new File(p.getPath());
                final boolean ok = FileUtil.deleteRecursive(target);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mProgress != null && mProgress.isShowing()) {
                            mProgress.dismiss();
                        }
                        if (ok) {
                            Toast.makeText(ProjectActivity.this, "Deleted", Toast.LENGTH_SHORT).show();
                            refreshList();
                        } else {
                            Toast.makeText(ProjectActivity.this, "Delete failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }).start();
    }

    private void openProject(Project p) {
        if (p == null || p.getPath() == null) return;
        Intent intent = new Intent(this, EditorActivity.class);
        intent.putExtra("project_path", p.getPath());
        intent.putExtra("project_name", p.getName());
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mScanTask != null) {
            mScanTask.cancel(true);
            mScanTask = null;
        }
        if (mProgress != null && mProgress.isShowing()) {
            mProgress.dismiss();
        }
    }
}