package com.omnidev.studio.task;

import android.os.AsyncTask;
import android.os.Environment;
import com.omnidev.studio.model.Project;
import com.omnidev.studio.util.FileUtil;
import java.io.File;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ScanTask extends AsyncTask<Void, Void, ArrayList<Project>> {
    public interface Callback {
        void onScanComplete(ArrayList<Project> projects);
    }

    private final WeakReference<Callback> mCallbackRef;

    public ScanTask(Callback callback) {
        this.mCallbackRef = new WeakReference<Callback>(callback);
    }

    @Override
    protected ArrayList<Project> doInBackground(Void... params) {
        ArrayList<Project> list = new ArrayList<Project>();
        File base = FileUtil.getAideProjectsDir();
        if (base == null || !base.exists()) return list;

        File[] dirs = base.listFiles();
        if (dirs == null) return list;

        for (int i = 0; i < dirs.length; i++) {
            if (isCancelled()) break;
            File d = dirs[i];
            if (d == null || !d.isDirectory()) continue;

            boolean hasManifest = new File(d, "AndroidManifest.xml").exists();
            boolean hasProps = new File(d, "project.properties").exists();
            boolean isValid = hasManifest || hasProps;

            list.add(new Project(d.getName(), d.getAbsolutePath(), d.lastModified(), isValid));
        }

        Collections.sort(list, new Comparator<Project>() {
            @Override
            public int compare(Project a, Project b) {
                if (a == null || b == null) return 0;
                long diff = b.getLastModified() - a.getLastModified();
                return diff > 0 ? 1 : (diff < 0 ? -1 : 0);
            }
        });

        return list;
    }

    @Override
    protected void onPostExecute(ArrayList<Project> result) {
        Callback cb = mCallbackRef.get();
        if (cb != null && !isCancelled()) {
            cb.onScanComplete(result);
        }
    }
}