package com.omnidev.studio.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.omnidev.studio.R;
import com.omnidev.studio.model.Project;
import java.util.ArrayList;
import java.util.List;

public class ProjectAdapter extends BaseAdapter {
    private final Context mContext;
    private final LayoutInflater mInflater;
    private final List<Project> mData;
    private final View.OnClickListener mDeleteListener;
    private final View.OnClickListener mOpenListener;

    public ProjectAdapter(Context context, List<Project> data,
                          View.OnClickListener openListener,
                          View.OnClickListener deleteListener) {
        this.mContext = context;
        this.mInflater = LayoutInflater.from(context);
        this.mData = data != null ? data : new ArrayList<Project>();
        this.mOpenListener = openListener;
        this.mDeleteListener = deleteListener;
    }

    public void updateData(List<Project> data) {
        mData.clear();
        if (data != null) {
            mData.addAll(data);
        }
        notifyDataSetChanged();
    }

    @Override
    public int getCount() { return mData.size(); }

    @Override
    public Object getItem(int position) {
        return position >= 0 && position < mData.size() ? mData.get(position) : null;
    }

    @Override
    public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_project, parent, false);
            holder = new ViewHolder();
            holder.tvName = (TextView) convertView.findViewById(R.id.tv_name);
            holder.tvPath = (TextView) convertView.findViewById(R.id.tv_path);
            holder.tvStatus = (TextView) convertView.findViewById(R.id.tv_status);
            holder.btnOpen = (TextView) convertView.findViewById(R.id.btn_open);
            holder.btnDelete = (TextView) convertView.findViewById(R.id.btn_delete);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Project p = mData.get(position);
        if (p != null) {
            holder.tvName.setText(p.getName());
            holder.tvPath.setText(p.getPath());
            holder.tvStatus.setText(p.isValid() ? "VALID" : "INCOMPLETE");
            holder.tvStatus.setTextColor(p.isValid() 
                ? 0xFF4CAF50 : 0xFFFF9800);

            holder.btnOpen.setTag(Integer.valueOf(position));
            holder.btnOpen.setOnClickListener(mOpenListener);

            holder.btnDelete.setTag(Integer.valueOf(position));
            holder.btnDelete.setOnClickListener(mDeleteListener);
        }

        return convertView;
    }

    private static class ViewHolder {
        TextView tvName;
        TextView tvPath;
        TextView tvStatus;
        TextView btnOpen;
        TextView btnDelete;
    }
}