package com.omnidev.studio.util;

import android.util.Log;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public final class FileUtil {
    private static final String TAG = "FileUtil";

    private FileUtil() {}

    public static boolean createProjectStructure(String projectName, String basePath) {
        if (projectName == null || basePath == null) return false;
        if (projectName.trim().length() == 0) return false;

        File root = new File(basePath, projectName);
        if (root.exists()) return false;

        boolean ok = true;
        ok &= mkdirs(new File(root, "src/com/" + projectName.toLowerCase().replace(" ", "_")));
        ok &= mkdirs(new File(root, "res/layout"));
        ok &= mkdirs(new File(root, "res/values"));
        ok &= mkdirs(new File(root, "res/drawable"));

        if (!ok) return false;

        // Create minimal AndroidManifest.xml
        String manifest = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
            "<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\"\n" +
            "    package=\"com." + projectName.toLowerCase().replace(" ", "_") + "\"\n" +
            "    android:versionCode=\"1\"\n" +
            "    android:versionName=\"1.0\">\n" +
            "    <uses-sdk android:minSdkVersion=\"21\" android:targetSdkVersion=\"21\"/>\n" +
            "    <application android:label=\"@string/app_name\" android:theme=\"@android:style/Theme.Holo.Light\">\n" +
            "        <activity android:name=\".MainActivity\">\n" +
            "            <intent-filter>\n" +
            "                <action android:name=\"android.intent.action.MAIN\"/>\n" +
            "                <category android:name=\"android.intent.category.LAUNCHER\"/>\n" +
            "            </intent-filter>\n" +
            "        </activity>\n" +
            "    </application>\n" +
            "</manifest>";

        ok &= writeStringToFile(new File(root, "AndroidManifest.xml"), manifest);

        // Create project.properties
        ok &= writeStringToFile(new File(root, "project.properties"), "target=android-21\n");

        // Create strings.xml
        String strings = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n" +
            "    <string name=\"app_name\">" + projectName + "</string>\n" +
            "</resources>";
        ok &= writeStringToFile(new File(root, "res/values/strings.xml"), strings);

        // Create MainActivity.java template
        String pkg = "com." + projectName.toLowerCase().replace(" ", "_");
        String mainAct = "package " + pkg + ";\n\n" +
            "import android.app.Activity;\n" +
            "import android.os.Bundle;\n\n" +
            "public class MainActivity extends Activity {\n" +
            "    @Override\n" +
            "    protected void onCreate(Bundle savedInstanceState) {\n" +
            "        super.onCreate(savedInstanceState);\n" +
            "        setContentView(R.layout.activity_main);\n" +
            "    }\n}";
        ok &= writeStringToFile(new File(root, "src/" + pkg.replace(".", "/") + "/MainActivity.java"), mainAct);

        // Create activity_main.xml
        String layout = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
            "<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\"\n" +
            "    android:layout_width=\"match_parent\"\n" +
            "    android:layout_height=\"match_parent\"\n" +
            "    android:orientation=\"vertical\"\n" +
            "    android:gravity=\"center\">\n" +
            "    <TextView\n" +
            "        android:layout_width=\"wrap_content\"\n" +
            "        android:layout_height=\"wrap_content\"\n" +
            "        android:text=\"Hello, " + projectName + "!\"\n" +
            "        android:textSize=\"18sp\"/>\n" +
            "</LinearLayout>";
        ok &= writeStringToFile(new File(root, "res/layout/activity_main.xml"), layout);

        return ok;
    }

    private static boolean mkdirs(File dir) {
        return dir != null && dir.mkdirs();
    }

    public static boolean deleteRecursive(File file) {
        if (file == null) return false;
        boolean ok = true;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (int i = 0; i < children.length; i++) {
                    ok &= deleteRecursive(children[i]);
                }
            }
        }
        ok &= file.delete();
        return ok;
    }

    public static String readFileToString(File file) {
        if (file == null || !file.exists()) return "";
        StringBuilder sb = new StringBuilder();
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } catch (IOException e) {
            Log.e(TAG, "Read error", e);
        } finally {
            if (br != null) {
                try { br.close(); } catch (IOException ignored) {}
            }
        }
        return sb.toString();
    }

    public static boolean writeStringToFile(File file, String content) {
        if (file == null || content == null) return false;
        BufferedWriter bw = null;
        try {
            bw = new BufferedWriter(new FileWriter(file));
            bw.write(content);
            return true;
        } catch (IOException e) {
            Log.e(TAG, "Write error", e);
            return false;
        } finally {
            if (bw != null) {
                try { bw.close(); } catch (IOException ignored) {}
            }
        }
    }

    public static File getAideProjectsDir() {
        File sdcard = android.os.Environment.getExternalStorageDirectory();
        if (sdcard == null) return null;
        File aide = new File(sdcard, "AppProjects");
        if (!aide.exists()) {
            aide.mkdirs();
        }
        return aide;
    }
}