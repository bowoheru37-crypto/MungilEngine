package com.omnidev.studio;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity implements View.OnClickListener {

    private Button mBtnProjects;
    private Button mBtnTemplates;
    private Button mBtnSettings;
    private Button mBtnAbout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mBtnProjects = (Button) findViewById(R.id.btn_projects);
        mBtnTemplates = (Button) findViewById(R.id.btn_templates);
        mBtnSettings = (Button) findViewById(R.id.btn_settings);
        mBtnAbout = (Button) findViewById(R.id.btn_about);

        if (mBtnProjects != null) mBtnProjects.setOnClickListener(this);
        if (mBtnTemplates != null) mBtnTemplates.setOnClickListener(this);
        if (mBtnSettings != null) mBtnSettings.setOnClickListener(this);
        if (mBtnAbout != null) mBtnAbout.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btn_projects) {
            startActivity(new Intent(this, ProjectActivity.class));
        } else if (id == R.id.btn_templates) {
            showTemplatesDialog();
        } else if (id == R.id.btn_settings) {
            showSettingsDialog();
        } else if (id == R.id.btn_about) {
            showAboutDialog();
        }
    }

    private void showTemplatesDialog() {
        final String[] items = new String[]{
            "Empty Activity",
            "Basic Game (SurfaceView)",
            "Console App"
        };
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Quick Templates");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(MainActivity.this, ProjectActivity.class);
                intent.putExtra("template", which);
                startActivity(intent);
            }
        });
        builder.setNegativeButton("Close", null);
        builder.show();
    }

    private void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Optimize for itel A70");
        builder.setMessage("Device Profile Applied:\n" +
            "• Heap Limit: Standard\n" +
            "• Animations: Reduced\n" +
            "• Render: Software fallback ready\n" +
            "• GC: Optimized allocations\n" +
            "• Storage: External SD aware");
        builder.setPositiveButton("OK", null);
        builder.show();
    }

    private void showAboutDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Omni Dev Studio");
        builder.setMessage("Version 1.0.0-lite\n" +
            "Optimized for low-end devices\n" +
            "1GB RAM | Android 5+ | 16GB Storage\n" +
            "Zero bloat. Zero leak. Zero lag.");
        builder.setPositiveButton("OK", null);
        builder.show();
    }
}