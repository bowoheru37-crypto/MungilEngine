package com.omnidev.studio;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.omnidev.studio.util.FileUtil;
import java.io.File;

public class EditorActivity extends Activity {

    private TextView mTvTitle;
    private EditText mEditor;
    private Button mBtnSave;
    private Button mBtnBack;
    private String mProjectPath;
    private String mProjectName;
    private String mFilePath;
    private boolean mIsModified = false;
    private String mOriginalContent = "";

    private final TextWatcher mTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            mIsModified = true;
            updateTitle();
        }

        @Override
        public void afterTextChanged(Editable s) {}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        mTvTitle = (TextView) findViewById(R.id.tv_title);
        mEditor = (EditText) findViewById(R.id.et_editor);
        mBtnSave = (Button) findViewById(R.id.btn_save);
        mBtnBack = (Button) findViewById(R.id.btn_back);

        Intent intent = getIntent();
        if (intent != null) {
            mProjectPath = intent.getStringExtra("project_path");
            mProjectName = intent.getStringExtra("project_name");
        }

        if (mProjectPath == null) {
            Toast.makeText(this, "Invalid project", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Default open MainActivity.java
        File srcDir = new File(mProjectPath, "src");
        mFilePath = findFirstJavaFile(srcDir);
        if (mFilePath == null) {
            mFilePath = mProjectPath + "/AndroidManifest.xml";
        }

        loadFile();

        if (mEditor != null) {
            mEditor.addTextChangedListener(mTextWatcher);
        }

        if (mBtnSave != null) {
            mBtnSave.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    saveFile();
                }
            });
        }

        if (mBtnBack != null) {
            mBtnBack.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onBackPressed();
                }
            });
        }

        updateTitle();
    }

    private String findFirstJavaFile(File dir) {
        if (dir == null || !dir.exists()) return null;
        File[] files = dir.listFiles();
        if (files == null) return null;
        for (int i = 0; i < files.length; i++) {
            File f = files[i];
            if (f == null) continue;
            if (f.isDirectory()) {
                String found = findFirstJavaFile(f);
                if (found != null) return found;
            } else if (f.getName().endsWith(".java")) {
                return f.getAbsolutePath();
            }
        }
        return null;
    }

    private void loadFile() {
        if (mFilePath == null) return;
        File f = new File(mFilePath);
        mOriginalContent = FileUtil.readFileToString(f);
        if (mEditor != null) {
            mEditor.setText(mOriginalContent);
            mEditor.setSelection(0);
        }
        mIsModified = false;
        updateTitle();
    }

    private void saveFile() {
        if (mFilePath == null || mEditor == null) return;
        String content = mEditor.getText().toString();
        File f = new File(mFilePath);
        boolean ok = FileUtil.writeStringToFile(f, content);
        if (ok) {
            mOriginalContent = content;
            mIsModified = false;
            updateTitle();
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Save failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateTitle() {
        if (mTvTitle == null) return;
        String name = mProjectName != null ? mProjectName : "Editor";
        mTvTitle.setText(name + (mIsModified ? " *" : ""));
    }

    @Override
    public void onBackPressed() {
        if (mIsModified) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Unsaved Changes");
            builder.setMessage("Discard changes?");
            builder.setPositiveButton("Discard", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    EditorActivity.super.onBackPressed();
                }
            });
            builder.setNegativeButton("Cancel", null);
            builder.show();
        } else {
            super.onBackPressed();
        }
    }
}