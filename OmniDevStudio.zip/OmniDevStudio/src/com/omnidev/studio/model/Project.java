package com.omnidev.studio.model;

import java.io.Serializable;

public class Project implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String name;
    private final String path;
    private final long lastModified;
    private final boolean isValid;

    public Project(String name, String path, long lastModified, boolean isValid) {
        this.name = name;
        this.path = path;
        this.lastModified = lastModified;
        this.isValid = isValid;
    }

    public String getName() { return name; }
    public String getPath() { return path; }
    public long getLastModified() { return lastModified; }
    public boolean isValid() { return isValid; }
}