//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CjDRki7u.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-B-d1YtDz.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B-d1YtDz.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DThL0OSP.js"]
	}
} });
//#endregion
export { tsrStartManifest };
