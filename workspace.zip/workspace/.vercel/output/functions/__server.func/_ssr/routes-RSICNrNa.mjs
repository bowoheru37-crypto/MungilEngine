import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Sparkles, c as Footprints, i as Swords, l as Crosshair, n as Volume2, o as Heart, s as Gem, t as VolumeX } from "../_libs/lucide-react.mjs";
import { A as PlaneGeometry, C as MeshBasicMaterial, D as OctahedronGeometry, E as Object3D, F as SphereGeometry, I as TorusGeometry, L as Vector2, M as RingGeometry, N as SRGBColorSpace, O as PerspectiveCamera, P as Scene, R as Vector3, S as Mesh, T as MeshStandardMaterial, _ as IcosahedronGeometry, a as Box3, b as LoopOnce, c as CapsuleGeometry, d as CylinderGeometry, f as DirectionalLight, g as HemisphereLight, h as Group, i as AnimationMixer, j as Raycaster, k as Plane, l as Color, m as Fog, n as clone, o as BoxGeometry, p as DodecahedronGeometry, r as WebGLRenderer, s as BufferAttribute, t as GLTFLoader, u as ConeGeometry, v as InstancedBufferAttribute, w as MeshPhysicalMaterial, x as LoopRepeat, y as InstancedMesh } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-RSICNrNa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Q = (partial) => ({
	radius: 3,
	speed: 18,
	...partial
});
var CHAMPS = {
	vanguard: {
		id: "vanguard",
		name: "Kael",
		title: "Dawn Vanguard",
		role: "Melee bruiser",
		blurb: "Closes the gap, shrugs a hit, and spins the lane apart.",
		range: 2.35,
		hp: 820,
		mana: 280,
		speed: 7.15,
		ad: 64,
		color: 13206842,
		swatch: "primary",
		abilities: [
			Q({
				key: "Q",
				name: "Rift Charge",
				blurb: "Dash to your cursor, cutting anyone you pass.",
				cd: 7.5,
				mana: 40,
				kind: "dash",
				dmg: 80,
				range: 9,
				radius: 1.5,
				speed: 28
			}),
			Q({
				key: "E",
				name: "Earthbreak",
				blurb: "Slam the ground. Damages and slows nearby foes.",
				cd: 8,
				mana: 50,
				kind: "aoe",
				dmg: 95,
				range: 3.4,
				radius: 3.4
			}),
			Q({
				key: "R",
				name: "Bulwark",
				blurb: "Raise a shield and surge forward faster.",
				cd: 13,
				mana: 55,
				kind: "buff",
				dmg: 0,
				range: 0
			}),
			Q({
				key: "F",
				name: "Sundering Spin",
				blurb: "Whirl, shredding everyone around you.",
				cd: 30,
				mana: 90,
				kind: "aoe",
				dmg: 190,
				range: 4.6,
				radius: 4.6
			})
		]
	},
	arcanist: {
		id: "arcanist",
		name: "Lyra",
		title: "Rift Arcanist",
		role: "Ranged mage",
		blurb: "Hurls bolts and calls a star down on the siege line.",
		range: 8.2,
		hp: 560,
		mana: 460,
		speed: 6.55,
		ad: 40,
		color: 7260384,
		swatch: "mana",
		abilities: [
			Q({
				key: "Q",
				name: "Arc Bolt",
				blurb: "A fast bolt toward your cursor.",
				cd: 3.6,
				mana: 30,
				kind: "projectile",
				dmg: 88,
				range: 15,
				speed: 24,
				radius: .45
			}),
			Q({
				key: "E",
				name: "Nova Ring",
				blurb: "Burst of rift fire around you.",
				cd: 9,
				mana: 55,
				kind: "aoe",
				dmg: 78,
				range: 4.8,
				radius: 4.8
			}),
			Q({
				key: "R",
				name: "Frost Bind",
				blurb: "A slow orb that bites and chills.",
				cd: 11,
				mana: 60,
				kind: "projectile",
				dmg: 48,
				range: 13,
				speed: 16,
				radius: .55
			}),
			Q({
				key: "F",
				name: "Starfall",
				blurb: "Mark the ground. A star crashes there.",
				cd: 32,
				mana: 110,
				kind: "rain",
				dmg: 220,
				range: 16,
				radius: 4.4
			})
		]
	},
	ranger: {
		id: "ranger",
		name: "Soren",
		title: "Wild Ranger",
		role: "Ranged skirmisher",
		blurb: "Kites from the treeline, snares a path, rains arrows.",
		range: 7.4,
		hp: 620,
		mana: 340,
		speed: 7.35,
		ad: 56,
		color: 8240746,
		swatch: "ranger",
		abilities: [
			Q({
				key: "Q",
				name: "Piercing Shot",
				blurb: "An arrow that punches through a line.",
				cd: 4.5,
				mana: 28,
				kind: "projectile",
				dmg: 76,
				range: 16,
				speed: 30,
				radius: .4
			}),
			Q({
				key: "E",
				name: "Snare Trap",
				blurb: "Drop a trap at your feet. It arms, then roots.",
				cd: 12,
				mana: 45,
				kind: "trap",
				dmg: 46,
				range: 2,
				radius: 2.1
			}),
			Q({
				key: "R",
				name: "Volley",
				blurb: "A fan of arrows toward your cursor.",
				cd: 8.5,
				mana: 48,
				kind: "cone",
				dmg: 62,
				range: 10,
				radius: .7
			}),
			Q({
				key: "F",
				name: "Arrow Rain",
				blurb: "Blanket an area. Anything standing there bleeds.",
				cd: 30,
				mana: 100,
				kind: "rain",
				dmg: 170,
				range: 15,
				radius: 5
			})
		]
	}
};
var CHAMP_ORDER = [
	"vanguard",
	"arcanist",
	"ranger"
];
var ITEMS = [
	{
		id: "blade",
		name: "Sundersword",
		blurb: "+16 attack",
		cost: 380
	},
	{
		id: "heart",
		name: "Heartstone",
		blurb: "+150 health, +4 armor",
		cost: 380
	},
	{
		id: "arcanum",
		name: "Rift Arcanum",
		blurb: "+26 power, +45 mana",
		cost: 380
	},
	{
		id: "boots",
		name: "Swiftstriders",
		blurb: "+1.05 move speed",
		cost: 300
	}
];
var ALLY_NAMES = ["Bram", "Nima"];
var ENEMY_NAMES = [
	"Vex",
	"Mora",
	"Isk"
];
function otherChamps(id) {
	return CHAMP_ORDER.filter((c) => c !== id);
}
var TRACKS = [
	null,
	{
		wave: "triangle",
		gain: .05
	},
	{
		wave: "sine",
		gain: .028
	},
	{
		wave: "sine",
		gain: .07
	},
	{
		wave: "sine",
		gain: .04
	},
	{
		wave: "sine",
		gain: .03
	},
	{
		wave: "sine",
		gain: .018
	},
	null
];
function readVar(data, at) {
	let value = 0;
	for (let k = 0; k < 4; k++) {
		const byte = data[at.i++] ?? 0;
		value = value << 7 | byte & 127;
		if ((byte & 128) === 0) break;
	}
	return value;
}
function parseScore(data) {
	if (data.length < 14 || String.fromCharCode(data[0], data[1], data[2], data[3]) !== "MThd") return {
		notes: [],
		duration: 1
	};
	const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
	const hlen = view.getUint32(4);
	const tracks = view.getUint16(10);
	const div = view.getUint16(12) || 480;
	let cursor = 8 + hlen;
	const tempos = [{
		tick: 0,
		mpq: 5e5
	}];
	const raw = [];
	for (let track = 0; track < tracks && cursor + 8 <= data.length; track++) {
		if (String.fromCharCode(...data.slice(cursor, cursor + 4)) !== "MTrk") break;
		const len = view.getUint32(cursor + 4);
		cursor += 8;
		const end = cursor + len;
		let tick = 0;
		let running = 0;
		while (cursor < end) {
			const at = { i: cursor };
			tick += readVar(data, at);
			cursor = at.i;
			let status = data[cursor] ?? 0;
			if (status & 128) {
				cursor += 1;
				running = status;
			} else status = running;
			if (status === 255) {
				const type = data[cursor] ?? 0;
				cursor += 1;
				const meta = { i: cursor };
				const size = readVar(data, meta);
				cursor = meta.i;
				if (type === 81 && size === 3) {
					const mpq = (data[cursor] ?? 0) << 16 | (data[cursor + 1] ?? 0) << 8 | (data[cursor + 2] ?? 0);
					tempos.push({
						tick,
						mpq
					});
				}
				cursor += size;
				continue;
			}
			if (status === 240 || status === 247) {
				const sys = { i: cursor };
				const size = readVar(data, sys);
				cursor = sys.i + size;
				continue;
			}
			const kind = status & 240;
			if (kind === 128 || kind === 144) {
				const note = data[cursor] ?? 0;
				const vel = kind === 128 ? 0 : data[cursor + 1] ?? 0;
				cursor += 2;
				raw.push({
					tick,
					track,
					note,
					vel
				});
			} else if (kind === 192 || kind === 208) cursor += 1;
			else cursor += 2;
		}
	}
	tempos.sort((a, b) => a.tick - b.tick);
	const toTime = (tick) => {
		let time = 0;
		let last = 0;
		let mpq = 5e5;
		for (const seg of tempos) {
			if (seg.tick >= tick) break;
			time += (seg.tick - last) * mpq / div / 1e6;
			last = seg.tick;
			mpq = seg.mpq;
		}
		return time + (tick - last) * mpq / div / 1e6;
	};
	const open = /* @__PURE__ */ new Map();
	const notes = [];
	let duration = 1;
	for (const ev of raw) {
		const time = toTime(ev.tick);
		duration = Math.max(duration, time);
		const key = `${ev.track}:${ev.note}`;
		if (ev.vel <= 0) {
			const start = open.get(key);
			open.delete(key);
			const spec = TRACKS[ev.track] ?? null;
			if (!start || !spec) continue;
			const dur = Math.min(3.2, Math.max(.08, time - start.time));
			notes.push({
				time: start.time,
				dur,
				freq: 440 * 2 ** ((ev.note - 69) / 12),
				gain: spec.gain * (start.vel / 127),
				wave: spec.wave
			});
		} else open.set(key, {
			time,
			vel: ev.vel
		});
	}
	const kept = [];
	const buckets = /* @__PURE__ */ new Map();
	for (const note of notes) {
		const key = Math.floor(note.time / .09);
		const list = buckets.get(key) ?? [];
		list.push(note);
		buckets.set(key, list);
	}
	for (const list of buckets.values()) {
		list.sort((a, b) => b.gain - a.gain);
		kept.push(...list.slice(0, 4));
	}
	kept.sort((a, b) => a.time - b.time);
	return {
		notes: kept,
		duration: duration + .4
	};
}
var ALBUM = [
	"/music/light-beyond-the-veil.mid",
	"/music/a-thousand-silent-stars.mid",
	"/music/where-the-heart-finds-quiet.mid",
	"/music/faith-beyond-the-visible.mid",
	"/music/the-light-we-walk-by.mid",
	"/music/in-every-horizon.mid",
	"/music/the-earth-within-us.mid",
	"/music/when-morning-finds-the-night.mid",
	"/music/when-truth-arrives.mid",
	"/music/light-upon-the-heart.mid"
];
function createAudio() {
	let ctx = null;
	let master = null;
	let music = null;
	let sfx = null;
	let isMuted = false;
	let musicStarted = false;
	let score = null;
	let scoreOrigin = 0;
	let scoreIndex = 0;
	let pumpTimer = 0;
	let trackIndex = 0;
	let loadingTrack = false;
	function ensure() {
		if (ctx) return;
		ctx = new (window.AudioContext || window.webkitAudioContext)({ latencyHint: "interactive" });
		master = ctx.createGain();
		music = ctx.createGain();
		sfx = ctx.createGain();
		music.gain.value = .16;
		sfx.gain.value = .55;
		master.gain.value = isMuted ? 0 : .85;
		music.connect(master);
		sfx.connect(master);
		master.connect(ctx.destination);
	}
	function playNote(note, when) {
		if (!ctx || !music) return;
		const osc = ctx.createOscillator();
		const gain = ctx.createGain();
		osc.type = note.wave;
		osc.frequency.setValueAtTime(note.freq, when);
		gain.gain.setValueAtTime(1e-4, when);
		gain.gain.exponentialRampToValueAtTime(Math.max(2e-4, note.gain), when + .018);
		gain.gain.exponentialRampToValueAtTime(1e-4, when + note.dur);
		osc.connect(gain);
		gain.connect(music);
		osc.start(when);
		osc.stop(when + note.dur + .03);
		osc.onended = () => {
			osc.disconnect();
			gain.disconnect();
		};
	}
	function pumpScore() {
		if (!ctx || !music || !score || isMuted) return;
		const now = ctx.currentTime;
		const local = now - scoreOrigin;
		if (local > score.duration) {
			advanceTrack();
			return;
		}
		const horizon = local + 1.15;
		while (scoreIndex < score.notes.length) {
			const note = score.notes[scoreIndex];
			if (!note || note.time > horizon) break;
			scoreIndex += 1;
			const when = scoreOrigin + note.time;
			if (when >= now - .03) playNote(note, Math.max(when, now + .01));
		}
	}
	function advanceTrack() {
		if (!ctx || loadingTrack) return;
		loadingTrack = true;
		trackIndex = (trackIndex + 1) % ALBUM.length;
		const url = ALBUM[trackIndex] ?? ALBUM[0];
		fetch(url).then((res) => {
			if (!res.ok) throw new Error("score");
			return res.arrayBuffer();
		}).then((buf) => {
			const next = parseScore(new Uint8Array(buf));
			if (!next.notes.length || !ctx) throw new Error("empty score");
			score = next;
			scoreOrigin = ctx.currentTime + .08;
			scoreIndex = 0;
			loadingTrack = false;
		}).catch(() => {
			loadingTrack = false;
		});
	}
	function startScore() {
		if (!ctx || !music || musicStarted) return;
		musicStarted = true;
		scoreOrigin = ctx.currentTime + .15;
		fetch(ALBUM[0]).then((res) => res.arrayBuffer()).then((buf) => {
			score = parseScore(new Uint8Array(buf));
			if (!score.notes.length) throw new Error("empty score");
			pumpScore();
			pumpTimer = window.setInterval(pumpScore, 280);
		}).catch(() => {
			musicStarted = false;
			startPad();
		});
	}
	function startPad() {
		if (!ctx || !music || musicStarted) return;
		musicStarted = true;
		const filter = ctx.createBiquadFilter();
		filter.type = "lowpass";
		filter.frequency.value = 480;
		const g = ctx.createGain();
		g.gain.value = .22;
		const mk = (freq, type, detune = 0) => {
			const o = ctx.createOscillator();
			o.type = type;
			o.frequency.value = freq;
			o.detune.value = detune;
			o.connect(filter);
			o.start();
			return o;
		};
		mk(98, "triangle");
		mk(146.8, "sine", 6);
		mk(196, "sine", -4);
		filter.connect(g);
		g.connect(music);
	}
	function tone(freq, dur, type, gain, slide = 0) {
		if (!ctx || !sfx || isMuted) return;
		const t = ctx.currentTime;
		const o = ctx.createOscillator();
		const g = ctx.createGain();
		o.type = type;
		o.frequency.setValueAtTime(freq, t);
		if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
		g.gain.setValueAtTime(1e-4, t);
		g.gain.exponentialRampToValueAtTime(gain, t + .015);
		g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
		o.connect(g);
		g.connect(sfx);
		o.start(t);
		o.stop(t + dur + .02);
		o.onended = () => {
			o.disconnect();
			g.disconnect();
		};
	}
	function noise(dur, gain) {
		if (!ctx || !sfx || isMuted) return;
		const t = ctx.currentTime;
		const len = Math.floor(ctx.sampleRate * dur);
		const buf = ctx.createBuffer(1, len, ctx.sampleRate);
		const data = buf.getChannelData(0);
		for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len);
		const src = ctx.createBufferSource();
		src.buffer = buf;
		const g = ctx.createGain();
		const f = ctx.createBiquadFilter();
		f.type = "highpass";
		f.frequency.value = 400;
		g.gain.value = gain;
		src.connect(f);
		f.connect(g);
		g.connect(sfx);
		src.start(t);
		src.onended = () => {
			src.disconnect();
			g.disconnect();
			f.disconnect();
		};
	}
	return {
		unlock() {
			ensure();
			if (ctx && ctx.state === "suspended") ctx.resume();
			startScore();
		},
		setMuted(m) {
			isMuted = m;
			if (master && ctx) master.gain.setTargetAtTime(m ? 0 : .85, ctx.currentTime, .03);
		},
		toggleMuted() {
			this.setMuted(!isMuted);
			return isMuted;
		},
		muted: () => isMuted,
		hit(big) {
			noise(big ? .12 : .05, big ? .35 : .18);
			tone(big ? 140 : 220 + Math.random() * 40, big ? .16 : .07, "square", big ? .08 : .04, big ? -60 : -80);
		},
		cast(kind) {
			if (kind === "dash") tone(180, .18, "sawtooth", .05, 220);
			else if (kind === "rain" || kind === "aoe") tone(90, .28, "triangle", .08, -40);
			else tone(420 + Math.random() * 80, .12, "sine", .06, 140);
		},
		die() {
			tone(180, .3, "triangle", .08, -120);
		},
		level() {
			tone(523, .1, "sine", .06);
			tone(659, .14, "sine", .05);
		},
		tower() {
			tone(80, .35, "square", .07, -30);
			noise(.2, .25);
		},
		end(win) {
			if (win) {
				tone(392, .15, "triangle", .07);
				tone(523, .18, "triangle", .07);
				tone(659, .28, "sine", .07);
			} else tone(196, .3, "sawtooth", .05, -80);
		},
		ui() {
			tone(640, .05, "sine", .04);
		},
		dispose() {
			if (pumpTimer) window.clearInterval(pumpTimer);
			pumpTimer = 0;
			score = null;
		}
	};
}
/** Mid, top (+X), bot (−X). Dawn marches index-up from +Z toward −Z. */
var LANES = [
	[
		{
			x: 0,
			z: 64
		},
		{
			x: 0,
			z: 42
		},
		{
			x: 0,
			z: 20
		},
		{
			x: 0,
			z: 0
		},
		{
			x: 0,
			z: -20
		},
		{
			x: 0,
			z: -42
		},
		{
			x: 0,
			z: -64
		}
	],
	[
		{
			x: 8,
			z: 64
		},
		{
			x: 30,
			z: 60
		},
		{
			x: 54,
			z: 52
		},
		{
			x: 70,
			z: 32
		},
		{
			x: 74,
			z: 8
		},
		{
			x: 68,
			z: -18
		},
		{
			x: 52,
			z: -40
		},
		{
			x: 28,
			z: -58
		},
		{
			x: 8,
			z: -64
		}
	],
	[
		{
			x: -8,
			z: 64
		},
		{
			x: -30,
			z: 60
		},
		{
			x: -54,
			z: 52
		},
		{
			x: -70,
			z: 32
		},
		{
			x: -74,
			z: 8
		},
		{
			x: -68,
			z: -18
		},
		{
			x: -52,
			z: -40
		},
		{
			x: -28,
			z: -58
		},
		{
			x: -8,
			z: -64
		}
	]
];
var LANE_NAMES = [
	"Mid",
	"East",
	"West"
];
var TOWERS = [
	{
		team: 0,
		lane: 0,
		tier: 1,
		x: 0,
		z: 38
	},
	{
		team: 0,
		lane: 0,
		tier: 2,
		x: 0,
		z: 56
	},
	{
		team: 0,
		lane: 1,
		tier: 1,
		x: 58,
		z: 40
	},
	{
		team: 0,
		lane: 1,
		tier: 2,
		x: 36,
		z: 58
	},
	{
		team: 0,
		lane: 2,
		tier: 1,
		x: -58,
		z: 40
	},
	{
		team: 0,
		lane: 2,
		tier: 2,
		x: -36,
		z: 58
	},
	{
		team: 1,
		lane: 0,
		tier: 1,
		x: 0,
		z: -38
	},
	{
		team: 1,
		lane: 0,
		tier: 2,
		x: 0,
		z: -56
	},
	{
		team: 1,
		lane: 1,
		tier: 1,
		x: 58,
		z: -40
	},
	{
		team: 1,
		lane: 1,
		tier: 2,
		x: 36,
		z: -58
	},
	{
		team: 1,
		lane: 2,
		tier: 1,
		x: -58,
		z: -40
	},
	{
		team: 1,
		lane: 2,
		tier: 2,
		x: -36,
		z: -58
	}
];
var NEXUS = [{
	team: 0,
	x: 0,
	z: 78
}, {
	team: 1,
	x: 0,
	z: -78
}];
var FOUNTAINS = [{
	team: 0,
	x: 0,
	z: 70
}, {
	team: 1,
	x: 0,
	z: -70
}];
var CAMPS = [
	{
		id: "wolves-dawn",
		x: 34,
		z: 24,
		kind: "wolf",
		count: 3,
		hp: 150,
		ad: 14,
		name: "Thicket Wolf"
	},
	{
		id: "golem-dawn",
		x: -38,
		z: 18,
		kind: "golem",
		count: 1,
		hp: 480,
		ad: 32,
		name: "Moss Golem"
	},
	{
		id: "spirits-dusk",
		x: 30,
		z: -30,
		kind: "spirit",
		count: 2,
		hp: 190,
		ad: 18,
		name: "Rift Spirit"
	},
	{
		id: "wolves-dusk",
		x: -32,
		z: -26,
		kind: "wolf",
		count: 3,
		hp: 150,
		ad: 14,
		name: "Thicket Wolf"
	}
];
var BOSS = {
	x: 50,
	z: -6,
	name: "Rift Colossus"
};
var SHRINES = [
	{
		id: "gale",
		x: 52,
		z: 48,
		name: "Gale Shrine",
		kind: "haste"
	},
	{
		id: "blood",
		x: -54,
		z: -4,
		name: "Blood Shrine",
		kind: "lifesteal"
	},
	{
		id: "aegis",
		x: 16,
		z: -54,
		name: "Aegis Shrine",
		kind: "shield"
	}
];
var RUINS = [
	{
		x: 22,
		z: 14,
		rot: .4,
		h: 3.2
	},
	{
		x: 18,
		z: 18,
		rot: .2,
		h: 2.1
	},
	{
		x: -20,
		z: -16,
		rot: 1.1,
		h: 3.6
	},
	{
		x: -16,
		z: -12,
		rot: .6,
		h: 1.8
	},
	{
		x: 44,
		z: -22,
		rot: .9,
		h: 2.6
	}
];
function hash(ix, iz) {
	let n = Math.imul(ix, 374761393) + Math.imul(iz, 668265263);
	n = Math.imul(n ^ n >>> 13, 1274126177);
	return ((n ^ n >>> 16) >>> 0) / 4294967296;
}
function fade(t) {
	return t * t * (3 - 2 * t);
}
function noise(x, z) {
	const x0 = Math.floor(x);
	const z0 = Math.floor(z);
	const fx = x - x0;
	const fz = z - z0;
	const sx = fade(fx);
	const sz = fade(fz);
	const a = hash(x0, z0);
	const b = hash(x0 + 1, z0);
	const c = hash(x0, z0 + 1);
	const d = hash(x0 + 1, z0 + 1);
	return a + (b - a) * sx + (c - a) * sz + (a - b - c + d) * sx * sz;
}
function smooth(edge0, edge1, x) {
	const t = Math.max(0, Math.min(1, (x - edge0) / (edge1 - edge0)));
	return t * t * (3 - 2 * t);
}
function segDist(px, pz, ax, az, bx, bz) {
	const abx = bx - ax;
	const abz = bz - az;
	const den = abx * abx + abz * abz || 1;
	const t = Math.max(0, Math.min(1, ((px - ax) * abx + (pz - az) * abz) / den));
	const dx = px - (ax + abx * t);
	const dz = pz - (az + abz * t);
	return Math.hypot(dx, dz);
}
function laneDist(x, z) {
	let best = 999;
	for (const lane of LANES) for (let i = 0; i < lane.length - 1; i++) {
		const a = lane[i];
		const b = lane[i + 1];
		if (!a || !b) continue;
		best = Math.min(best, segDist(x, z, a.x, a.z, b.x, b.z));
	}
	return best;
}
function riverCenterX(z) {
	return Math.sin(z * .045) * 16 + Math.sin(z * .013) * 5;
}
function riverDist(x, z) {
	return Math.abs(x - riverCenterX(z));
}
function terrainHeight(x, z) {
	const rd = riverDist(x, z);
	const ld = laneDist(x, z);
	const n = noise(x * .028, z * .028) * 6.2 + noise(x * .07 + 9, z * .07) * 1.5 - 1.4;
	const riverCut = smooth(2.4, 12, rd);
	let h = n * (.28 + .72 * riverCut) - (1 - riverCut) * 1.65;
	const flat = 1 - smooth(2.2, 7.5, ld);
	h = h * (1 - flat * .9) + .22 * flat * .9;
	const dawn = Math.hypot(x, z - 76);
	const dusk = Math.hypot(x, z + 76);
	if (dawn < 18) h = h * smooth(8, 18, dawn) * .55 + .28;
	if (dusk < 18) h = h * smooth(8, 18, dusk) * .55 + .28;
	const edge = Math.max(Math.abs(x), Math.abs(z));
	if (edge > 82) h += smooth(82, 102, edge) * 16;
	return h;
}
function groundY(x, z) {
	return Math.max(terrainHeight(x, z), -.18);
}
function mix(a, b, t) {
	return {
		r: a.r + (b.r - a.r) * t,
		g: a.g + (b.g - a.g) * t,
		b: a.b + (b.b - a.b) * t
	};
}
var GRASS = {
	r: .29,
	g: .46,
	b: .27
};
var GRASS_HI = {
	r: .42,
	g: .58,
	b: .3
};
var PATH = {
	r: .48,
	g: .38,
	b: .24
};
var SAND = {
	r: .62,
	g: .52,
	b: .34
};
var WET = {
	r: .18,
	g: .28,
	b: .26
};
var ROCK = {
	r: .48,
	g: .46,
	b: .4
};
var PLAZA = {
	r: .55,
	g: .5,
	b: .4
};
function terrainColor(x, z, h) {
	let c = mix(GRASS, GRASS_HI, noise(x * .12, z * .12));
	const rd = riverDist(x, z);
	const ld = laneDist(x, z);
	if (ld < 6) c = mix(c, PATH, 1 - smooth(1.2, 6, ld));
	if (rd < 9) c = mix(c, SAND, 1 - smooth(3.2, 9, rd));
	if (h < -.15) c = mix(c, WET, smooth(-.15, -1.1, -h));
	if (h > 3.2) c = mix(c, ROCK, smooth(3.2, 7, h));
	const plaza = Math.min(Math.hypot(x, z - 76), Math.hypot(x, z + 76));
	if (plaza < 14) c = mix(c, PLAZA, 1 - smooth(4, 14, plaza));
	return c;
}
function buildTrees() {
	const out = [];
	let seed = 19;
	const rnd = () => {
		seed = seed * 16807 % 2147483647;
		return (seed & 268435455) / 268435455;
	};
	for (let i = 0; i < 700 && out.length < 150; i++) {
		const x = (rnd() - .5) * 176;
		const z = (rnd() - .5) * 176;
		if (Math.max(Math.abs(x), Math.abs(z)) > 86) continue;
		if (laneDist(x, z) < 6.5) continue;
		if (riverDist(x, z) < 6) continue;
		if (Math.hypot(x, z - 76) < 16 || Math.hypot(x, z + 76) < 16) continue;
		if (Math.hypot(x - BOSS.x, z - BOSS.z) < 8) continue;
		for (const camp of CAMPS) if (Math.hypot(x - camp.x, z - camp.z) < 6) continue;
		let blocked = false;
		for (const camp of CAMPS) if (Math.hypot(x - camp.x, z - camp.z) < 7) blocked = true;
		for (const s of SHRINES) if (Math.hypot(x - s.x, z - s.z) < 5) blocked = true;
		if (blocked) continue;
		const h = terrainHeight(x, z);
		if (h < .35 || h > 6) continue;
		out.push({
			x,
			z,
			s: .75 + rnd() * .7,
			kind: rnd() > .55 ? 1 : 0
		});
	}
	return out;
}
var TREES = buildTrees();
function pushOutOfTrees(x, z, radius) {
	let px = x;
	let pz = z;
	for (const t of TREES) {
		const min = radius + .45 * t.s;
		const dx = px - t.x;
		const dz = pz - t.z;
		const d = Math.hypot(dx, dz);
		if (d < min && d > 1e-4) {
			const k = (min - d) / d;
			px += dx * k;
			pz += dz * k;
		}
	}
	return {
		x: px,
		z: pz
	};
}
function clampWorld(x, z) {
	return {
		x: Math.max(-90, Math.min(90, x)),
		z: Math.max(-90, Math.min(90, z))
	};
}
function heroSpawn(which, index) {
	if (which === "player") return {
		x: 0,
		z: 66,
		lane: 0,
		yaw: 0
	};
	if (which === "ally") return index === 0 ? {
		x: 12,
		z: 66,
		lane: 1,
		yaw: 0
	} : {
		x: -12,
		z: 66,
		lane: 2,
		yaw: 0
	};
	if (index === 0) return {
		x: 0,
		z: -66,
		lane: 0,
		yaw: Math.PI
	};
	if (index === 1) return {
		x: 12,
		z: -66,
		lane: 1,
		yaw: Math.PI
	};
	return {
		x: -12,
		z: -66,
		lane: 2,
		yaw: Math.PI
	};
}
var STEP_CAP_MINIONS = 48;
function makeEnt(p, id) {
	return {
		id,
		alive: true,
		x: 0,
		z: 0,
		yaw: 0,
		radius: .55,
		hp: 100,
		maxHp: 100,
		mana: 0,
		maxMana: 0,
		speed: 0,
		ad: 10,
		ap: 0,
		armor: 0,
		level: 1,
		xp: 0,
		gold: 0,
		atkRange: 1.6,
		atkCd: 1,
		atkTimer: 0,
		champ: null,
		cds: [
			0,
			0,
			0,
			0
		],
		slowT: 0,
		shield: 0,
		shieldT: 0,
		hasteT: 0,
		lifestealT: 0,
		teamBuffT: 0,
		lane: 0,
		wp: 0,
		dir: 1,
		homeX: 0,
		homeZ: 0,
		leash: 14,
		aggro: false,
		focus: -1,
		respawn: 0,
		hitFlash: 0,
		attackAnim: 0,
		vel: 0,
		lastAttacker: -1,
		recent: [],
		itemCounts: [
			0,
			0,
			0,
			0
		],
		kills: 0,
		deaths: 0,
		assists: 0,
		cs: 0,
		baseHp: 100,
		baseMana: 0,
		baseAd: 10,
		baseSpeed: 3,
		baseArmor: 0,
		player: false,
		specialT: 4,
		dashT: 0,
		dashVX: 0,
		dashVZ: 0,
		dashDmg: 0,
		dashHits: [],
		ranged: false,
		tier: 0,
		campId: "",
		creepKind: "",
		aiCast: 0,
		...p
	};
}
function createSim() {
	let nextId = 1;
	const ents = [];
	const projs = Array.from({ length: 48 }, () => deadProj());
	const rings = Array.from({ length: 20 }, () => ({
		alive: false,
		x: 0,
		z: 0,
		r: 1,
		life: 0,
		max: 1,
		color: 14987610
	}));
	const traps = Array.from({ length: 8 }, () => ({
		alive: false,
		team: 0,
		x: 0,
		z: 0,
		life: 0,
		arm: 0,
		dmg: 0,
		owner: -1,
		radius: 2,
		slow: 1.2
	}));
	const floats = Array.from({ length: 28 }, () => ({
		alive: false,
		x: 0,
		z: 0,
		y: 2,
		text: "",
		life: 0,
		color: "#e7efe6"
	}));
	let floatCursor = 0;
	const camps = CAMPS.map((c) => ({
		...c,
		ids: [],
		down: false,
		timer: -1
	}));
	const shrines = SHRINES.map((s) => ({
		...s,
		ready: 0,
		channel: 0
	}));
	let phase = "menu";
	let time = 0;
	let waveT = 6;
	let wave = 0;
	let dawnKills = 0;
	let duskKills = 0;
	const events = [];
	const strikes = [];
	let player;
	function deadProj() {
		return {
			alive: false,
			team: 0,
			x: 0,
			z: 0,
			vx: 0,
			vz: 0,
			dmg: 0,
			life: 0,
			radius: .4,
			owner: -1,
			kind: "bolt",
			pierce: false,
			slow: 0,
			hits: []
		};
	}
	function byId(id) {
		for (const e of ents) if (e.id === id) return e;
		return null;
	}
	function add(p) {
		const e = makeEnt(p, nextId++);
		ents.push(e);
		return e;
	}
	function announce(text) {
		events.push({
			type: "announce",
			text
		});
	}
	function applyBuild(e) {
		const blade = e.itemCounts[0] ?? 0;
		const heart = e.itemCounts[1] ?? 0;
		const arc = e.itemCounts[2] ?? 0;
		const boots = e.itemCounts[3] ?? 0;
		const lv = e.level - 1;
		e.maxHp = e.baseHp + lv * 52 + heart * 150;
		e.maxMana = e.baseMana + lv * 22 + arc * 45;
		e.ad = e.baseAd + lv * 6 + blade * 16;
		e.ap = lv * 5 + arc * 26;
		e.speed = e.baseSpeed + boots * 1.05;
		e.armor = e.baseArmor + heart * 4;
		e.hp = Math.min(e.hp, e.maxHp);
		e.mana = Math.min(e.mana, e.maxMana);
	}
	function applyChamp(e, id, gold) {
		const def = CHAMPS[id];
		e.champ = id;
		e.baseHp = def.hp;
		e.baseMana = def.mana;
		e.baseAd = def.ad;
		e.baseSpeed = def.speed;
		e.baseArmor = e.player ? 14 : 12;
		e.atkRange = def.range;
		e.atkCd = def.range > 4 ? .92 : .7;
		e.ranged = def.range > 4;
		e.radius = .55;
		e.level = 1;
		e.xp = 0;
		e.gold = gold;
		e.itemCounts = [
			0,
			0,
			0,
			0
		];
		e.cds = [
			0,
			0,
			0,
			0
		];
		e.kills = 0;
		e.deaths = 0;
		e.assists = 0;
		e.cs = 0;
		applyBuild(e);
		e.hp = e.maxHp;
		e.mana = e.maxMana;
	}
	function placeHero(e, which, index) {
		const s = heroSpawn(which, index);
		e.x = s.x;
		e.z = s.z;
		e.homeX = s.x;
		e.homeZ = s.z;
		e.yaw = s.yaw;
		e.lane = s.lane;
		e.wp = which === "enemy" ? LANES[s.lane].length - 1 : 0;
		e.dir = which === "enemy" ? -1 : 1;
		e.alive = true;
		e.respawn = 0;
		e.dashT = 0;
		e.slowT = 0;
		e.shield = 0;
		e.aggro = false;
	}
	function bootstrap() {
		for (const t of TOWERS) add({
			kind: "tower",
			team: t.team,
			name: `${t.team === 0 ? "Dawn" : "Dusk"} ${LANE_NAMES[t.lane]} tower`,
			x: t.x,
			z: t.z,
			homeX: t.x,
			homeZ: t.z,
			lane: t.lane,
			tier: t.tier,
			hp: t.tier === 2 ? 1100 : 860,
			maxHp: t.tier === 2 ? 1100 : 860,
			radius: 1.55,
			armor: 22,
			ad: 46,
			atkRange: 9.2,
			atkCd: .95,
			atkTimer: .4
		});
		for (const n of NEXUS) add({
			kind: "nexus",
			team: n.team,
			name: n.team === 0 ? "Dawn Conduit" : "Dusk Conduit",
			x: n.x,
			z: n.z,
			homeX: n.x,
			homeZ: n.z,
			hp: 2800,
			maxHp: 2800,
			radius: 2.3,
			armor: 28
		});
		player = add({
			kind: "hero",
			team: 0,
			name: "Kael",
			player: true,
			gold: 500
		});
		applyChamp(player, "vanguard", 500);
		placeHero(player, "player", 0);
		const allies = otherChamps("vanguard");
		ALLY_NAMES.forEach((name, i) => {
			const e = add({
				kind: "hero",
				team: 0,
				name,
				player: false
			});
			applyChamp(e, allies[i] ?? "ranger", 500);
			placeHero(e, "ally", i);
		});
		ENEMY_NAMES.forEach((name, i) => {
			const e = add({
				kind: "hero",
				team: 1,
				name,
				player: false
			});
			applyChamp(e, [
				"vanguard",
				"arcanist",
				"ranger"
			][i] ?? "vanguard", 500);
			placeHero(e, "enemy", i);
		});
		const boss = add({
			kind: "boss",
			team: 2,
			name: BOSS.name,
			x: BOSS.x,
			z: BOSS.z,
			homeX: BOSS.x,
			homeZ: BOSS.z,
			hp: 2400,
			maxHp: 2400,
			radius: 1.8,
			armor: 18,
			ad: 42,
			atkRange: 3.1,
			atkCd: 1.15,
			speed: 3.1,
			baseSpeed: 3.1,
			leash: 18,
			creepKind: "boss"
		});
		boss.alive = true;
		for (const camp of camps) spawnCamp(camp);
	}
	function spawnCamp(camp) {
		camp.ids = [];
		camp.down = false;
		camp.timer = -1;
		for (let i = 0; i < camp.count; i++) {
			const ang = i / camp.count * Math.PI * 2;
			const e = add({
				kind: "creep",
				team: 2,
				name: camp.name,
				x: camp.x + Math.cos(ang) * 1.4,
				z: camp.z + Math.sin(ang) * 1.4,
				homeX: camp.x,
				homeZ: camp.z,
				hp: camp.hp,
				maxHp: camp.hp,
				ad: camp.ad,
				radius: camp.kind === "golem" ? 1.05 : .48,
				armor: camp.kind === "golem" ? 10 : 2,
				atkRange: camp.kind === "spirit" ? 6.5 : 1.7,
				atkCd: 1.1,
				speed: camp.kind === "golem" ? 2.6 : 4.2,
				baseSpeed: camp.kind === "golem" ? 2.6 : 4.2,
				ranged: camp.kind === "spirit",
				leash: 12,
				campId: camp.id,
				creepKind: camp.kind,
				yaw: ang
			});
			camp.ids.push(e.id);
		}
	}
	function resetStructures() {
		for (const e of ents) {
			if (e.kind === "tower" || e.kind === "nexus") {
				e.alive = true;
				e.hp = e.maxHp;
				e.x = e.homeX;
				e.z = e.homeZ;
			}
			if (e.kind === "boss") {
				e.alive = true;
				e.hp = e.maxHp;
				e.x = e.homeX;
				e.z = e.homeZ;
				e.aggro = false;
				e.focus = -1;
				e.respawn = 0;
			}
		}
		for (let i = ents.length - 1; i >= 0; i--) {
			const e = ents[i];
			if (e && (e.kind === "minion" || e.kind === "creep")) ents.splice(i, 1);
		}
		for (const c of camps) spawnCamp(c);
		for (const p of projs) p.alive = false;
		for (const t of traps) t.alive = false;
		for (const r of rings) r.alive = false;
		strikes.length = 0;
		for (const s of shrines) {
			s.ready = 0;
			s.channel = 0;
		}
	}
	function ring(x, z, r, color, life) {
		const slot = rings.find((n) => !n.alive) ?? rings[0];
		if (!slot) return;
		slot.alive = true;
		slot.x = x;
		slot.z = z;
		slot.r = r;
		slot.life = life;
		slot.max = life;
		slot.color = color;
	}
	function floater(x, z, text, color) {
		const f = floats[floatCursor % floats.length];
		floatCursor++;
		if (!f) return;
		f.alive = true;
		f.x = x;
		f.z = z;
		f.y = 2.1;
		f.text = text;
		f.life = .85;
		f.color = color;
	}
	function launch(owner, x, z, tx, tz, speed, dmg, kind, opts) {
		const p = projs.find((n) => !n.alive);
		if (!p) return;
		const dx = tx - x;
		const dz = tz - z;
		const len = Math.hypot(dx, dz) || 1;
		p.alive = true;
		p.team = owner.team;
		p.x = x;
		p.z = z;
		p.vx = dx / len * speed;
		p.vz = dz / len * speed;
		p.dmg = dmg;
		p.life = opts?.life ?? 1.35;
		p.radius = opts?.radius ?? .42;
		p.owner = owner.id;
		p.kind = kind;
		p.pierce = !!opts?.pierce;
		p.slow = opts?.slow ?? 0;
		p.hits.length = 0;
	}
	function hostilePair(a, b) {
		if (!b.alive || a.id === b.id) return false;
		if (a.team === b.team) return false;
		if (a.team === 2 && b.team === 2) return false;
		if (b.team === 2 && (a.kind === "tower" || a.kind === "minion" || a.kind === "nexus")) return false;
		if (a.team === 2 && (b.kind === "tower" || b.kind === "minion" || b.kind === "nexus")) return false;
		return true;
	}
	function dist(a, b) {
		return Math.hypot(a.x - b.x, a.z - b.z);
	}
	function noteRecent(target, id) {
		const found = target.recent.find((r) => r.id === id);
		if (found) found.t = time;
		else target.recent.push({
			id,
			t: time
		});
		if (target.recent.length > 6) target.recent.shift();
	}
	function grantXp(e, amount) {
		if (e.kind !== "hero" || !e.alive) return;
		e.xp += amount;
		let guard = 0;
		while (e.level < 12 && e.xp >= 70 + e.level * 36 && guard++ < 12) {
			e.xp -= 70 + e.level * 36;
			e.level += 1;
			const before = e.maxHp;
			applyBuild(e);
			e.hp = Math.min(e.maxHp, e.hp + (e.maxHp - before));
			e.mana = Math.min(e.maxMana, e.mana + 22);
			if (e.player) {
				events.push({ type: "level" });
				announce(`Level ${e.level}`);
				floater(e.x, e.z, `Level ${e.level}`, "#e4b15a");
			}
		}
	}
	function hurt(target, raw, attacker, slow = 0) {
		if (!target.alive || raw <= 0 || phase !== "play") return;
		let amount = raw;
		if (attacker && attacker.teamBuffT > 0) amount *= 1.18;
		if (target.kind === "nexus") {
			if (ents.some((t) => t.alive && t.kind === "tower" && t.team === target.team)) amount *= .3;
		}
		let rest = amount * (100 / (100 + Math.max(0, target.armor)));
		if (target.shield > 0) {
			const used = Math.min(target.shield, rest);
			target.shield -= used;
			rest -= used;
		}
		target.hp -= rest;
		target.hitFlash = .14;
		if (attacker) {
			target.lastAttacker = attacker.id;
			noteRecent(target, attacker.id);
			if (attacker.lifestealT > 0 && attacker.alive) attacker.hp = Math.min(attacker.maxHp, attacker.hp + rest * .25);
			if (target.team === 2) {
				target.aggro = true;
				target.focus = attacker.id;
			}
		}
		if (slow > 0) target.slowT = Math.max(target.slowT, slow);
		if (rest > 8) floater(target.x, target.z, `${Math.round(rest)}`, attacker?.player ? "#f2d7a2" : target.player ? "#d4524a" : "#e7efe6");
		events.push({
			type: "hit",
			big: rest > 80
		});
		if (target.hp <= 0) onDeath(target, attacker);
	}
	function onDeath(target, attacker) {
		target.alive = false;
		target.hp = 0;
		target.dashT = 0;
		target.shield = 0;
		events.push({ type: "die" });
		if (target.kind === "hero") {
			target.deaths += 1;
			target.respawn = 5 + target.level * 1.15;
			if (target.team === 0) duskKills += 1;
			else dawnKills += 1;
			if (attacker && attacker.kind === "hero" && attacker.team !== target.team) {
				attacker.kills += 1;
				attacker.gold += 150 + target.level * 14;
				grantXp(attacker, 100 + target.level * 12);
				floater(attacker.x, attacker.z, `+${150 + target.level * 14}g`, "#e4b15a");
				for (const rec of target.recent) {
					if (rec.id === attacker.id || time - rec.t > 8) continue;
					const ally = byId(rec.id);
					if (ally && ally.alive && ally.kind === "hero" && ally.team === attacker.team) {
						ally.assists += 1;
						ally.gold += 70;
						grantXp(ally, 48);
					}
				}
				events.push({
					type: "kill",
					text: `${attacker.name} felled ${target.name}`
				});
			} else events.push({
				type: "kill",
				text: `${target.name} has fallen`
			});
			if (target.player) announce("Slain — the conduit calls you back");
			return;
		}
		if (target.kind === "minion") {
			if (attacker && attacker.kind === "hero" && attacker.team !== target.team) {
				attacker.gold += 22;
				attacker.cs += 1;
				grantXp(attacker, 26);
			}
			return;
		}
		if (target.kind === "creep") {
			if (attacker && attacker.kind === "hero") {
				attacker.gold += 34;
				attacker.cs += 1;
				grantXp(attacker, 40);
				floater(target.x, target.z, "+34g", "#e4b15a");
			}
			const camp = camps.find((c) => c.id === target.campId);
			if (camp) {
				camp.ids = camp.ids.filter((id) => id !== target.id);
				if (camp.ids.length === 0) {
					camp.down = true;
					camp.timer = 32;
				}
			}
			return;
		}
		if (target.kind === "boss") {
			target.respawn = 80;
			announce("The Rift Colossus falls — spoils to the slayer's side");
			if (attacker) {
				const team = attacker.team === 2 ? 0 : attacker.team;
				for (const e of ents) if (e.kind === "hero" && e.team === team) {
					e.gold += e.id === attacker.id ? 220 : 80;
					e.teamBuffT = Math.max(e.teamBuffT, 22);
					grantXp(e, e.id === attacker.id ? 160 : 70);
				}
				floater(target.x, target.z, "Colossus down", "#e4b15a");
			}
			return;
		}
		if (target.kind === "tower") {
			events.push({ type: "tower" });
			announce(`${target.name} has fallen`);
			const team = attacker && attacker.team !== 2 ? attacker.team : target.team === 0 ? 1 : 0;
			for (const e of ents) if (e.kind === "hero" && e.team === team && e.alive) {
				e.gold += e.id === attacker?.id ? 160 : 90;
				grantXp(e, 80);
			}
			return;
		}
		if (target.kind === "nexus") {
			const win = target.team === 1;
			phase = win ? "victory" : "defeat";
			events.push({
				type: "end",
				win,
				text: win ? "The Dusk Conduit shatters" : "The Dawn Conduit has fallen"
			});
			announce(win ? "Victory — the rift is yours" : "Defeat — dusk swallows the dawn");
		}
	}
	function reviveHero(e) {
		e.alive = true;
		applyBuild(e);
		e.hp = e.maxHp;
		e.mana = e.maxMana;
		e.x = e.homeX;
		e.z = e.homeZ;
		e.yaw = e.team === 0 ? 0 : Math.PI;
		e.cds = [
			0,
			0,
			0,
			0
		];
		e.slowT = 0;
		e.shield = 0;
		e.dashT = 0;
		e.respawn = 0;
		if (e.player) announce("You return at the Dawn fountain");
	}
	function moveToward(e, tx, tz, dt) {
		const dx = tx - e.x;
		const dz = tz - e.z;
		const len = Math.hypot(dx, dz);
		if (len < .2) {
			e.vel = 0;
			return;
		}
		const slow = e.slowT > 0 ? .55 : 1;
		const haste = e.hasteT > 0 ? 1.28 : 1;
		const spd = e.speed * slow * haste;
		const step = Math.min(len, spd * dt);
		e.x += dx / len * step;
		e.z += dz / len * step;
		e.yaw = dampAngle(e.yaw, Math.atan2(-dx / len, -dz / len), 8, dt);
		e.vel = step / dt;
	}
	function separate(e) {
		let x = e.x;
		let z = e.z;
		for (const o of ents) {
			if (!o.alive || o.id === e.id) continue;
			if (o.kind === "minion" && e.kind === "minion") continue;
			const min = e.radius + (o.kind === "tower" || o.kind === "nexus" ? o.radius : o.kind === "hero" ? o.radius * .85 : 0);
			if (min <= 0) continue;
			if (o.kind !== "tower" && o.kind !== "nexus" && o.kind !== "hero" && o.kind !== "boss") continue;
			const dx = x - o.x;
			const dz = z - o.z;
			const d = Math.hypot(dx, dz);
			if (d < min && d > 1e-4) {
				x += dx / d * (min - d);
				z += dz / d * (min - d);
			}
		}
		if (e.kind === "hero") {
			const pushed = pushOutOfTrees(x, z, e.radius);
			x = pushed.x;
			z = pushed.z;
		}
		const c = clampWorld(x, z);
		e.x = c.x;
		e.z = c.z;
	}
	function tryHit(attacker, target) {
		if (attacker.atkTimer > 0 || !target.alive) return;
		if (dist(attacker, target) > attacker.atkRange + target.radius * .4) return;
		attacker.atkTimer = attacker.atkCd;
		attacker.attackAnim = .28;
		attacker.yaw = Math.atan2(-(target.x - attacker.x), -(target.z - attacker.z));
		const dmg = attacker.kind === "hero" ? attacker.ad : attacker.ad * (attacker.kind === "tower" ? 1 : 1);
		if (attacker.ranged || attacker.kind === "tower") launch(attacker, attacker.x, attacker.z, target.x, target.z, attacker.kind === "tower" ? 16 : 20, dmg, "shot", {
			radius: .35,
			life: 1.1
		});
		else hurt(target, dmg, attacker);
	}
	function nearest(e, range, filter) {
		let best = null;
		let bestD = range;
		for (const o of ents) {
			if (!filter(o)) continue;
			const d = dist(e, o);
			if (d < bestD) {
				bestD = d;
				best = o;
			}
		}
		return best;
	}
	function tickHeroPlayer(e, input, dt) {
		if (!e.alive) return;
		for (let i = 0; i < 4; i++) e.cds[i] = Math.max(0, (e.cds[i] ?? 0) - dt);
		const ox = e.x;
		const oz = e.z;
		if (e.dashT > 0) {
			e.dashT -= dt;
			e.x += e.dashVX * dt;
			e.z += e.dashVZ * dt;
			e.vel = Math.hypot(e.dashVX, e.dashVZ);
			for (const o of ents) {
				if (!hostilePair(e, o) || e.dashHits.includes(o.id)) continue;
				if (Math.hypot(o.x - e.x, o.z - e.z) < o.radius + 1.25) {
					e.dashHits.push(o.id);
					hurt(o, e.dashDmg, e, .35);
				}
			}
		} else {
			const len = Math.hypot(input.wishX, input.wishZ);
			if (len > .08) {
				const slow = e.slowT > 0 ? .55 : 1;
				const haste = e.hasteT > 0 ? 1.28 : 1;
				const spd = e.speed * slow * haste;
				const mx = input.wishX / len;
				const mz = input.wishZ / len;
				e.x += mx * spd * dt;
				e.z += mz * spd * dt;
				e.yaw = dampAngle(e.yaw, Math.atan2(-mx, -mz), 10, dt);
			}
		}
		separate(e);
		e.vel = Math.hypot(e.x - ox, e.z - oz) / dt;
		if (input.cast >= 0) cast(e, input.cast, input.aimX, input.aimZ);
		if (input.attack) {
			const tgt = acquirePlayerTarget(e, input.aimX, input.aimZ);
			if (tgt) tryHit(e, tgt);
		}
	}
	function acquirePlayerTarget(e, aimX, aimZ) {
		let best = null;
		let bestScore = 2.6;
		let fallback = null;
		let fallbackD = e.atkRange + .8;
		for (const o of ents) {
			if (!hostilePair(e, o)) continue;
			const dSelf = dist(e, o);
			const dAim = Math.hypot(o.x - aimX, o.z - aimZ);
			if (dSelf <= e.atkRange + o.radius * .35 && dAim < bestScore) {
				best = o;
				bestScore = dAim;
			}
			if (dSelf < fallbackD) {
				fallback = o;
				fallbackD = dSelf;
			}
		}
		return best ?? fallback;
	}
	function cast(e, slot, aimX, aimZ) {
		if (!e.champ || !e.alive) return;
		const def = CHAMPS[e.champ].abilities[slot];
		if (!def) return;
		if ((e.cds[slot] ?? 0) > 0 || e.mana < def.mana) return;
		e.mana -= def.mana;
		e.cds[slot] = def.cd * Math.max(.7, 1 - (e.level - 1) * .02);
		const dmg = (def.dmg + e.ap * .55 + e.level * 3) * (e.teamBuffT > 0 ? 1.18 : 1);
		const dx = aimX - e.x;
		const dz = aimZ - e.z;
		const len = Math.hypot(dx, dz);
		const fx = len > .4 ? dx / len : -Math.sin(e.yaw);
		const fz = len > .4 ? dz / len : -Math.cos(e.yaw);
		events.push({
			type: "cast",
			kind: def.kind
		});
		if (def.kind === "dash") {
			e.dashT = Math.min(def.range, Math.max(3.5, len)) / def.speed;
			e.dashVX = fx * def.speed;
			e.dashVZ = fz * def.speed;
			e.dashDmg = dmg;
			e.dashHits = [];
			e.yaw = Math.atan2(-fx, -fz);
			ring(e.x, e.z, 1.2, 14987610, .25);
			return;
		}
		if (def.kind === "aoe") {
			ring(e.x, e.z, def.radius, e.team === 0 ? 14987610 : 13914698, .35);
			for (const o of ents) {
				if (!hostilePair(e, o)) continue;
				if (dist(e, o) <= def.radius + o.radius) hurt(o, dmg, e, .8);
			}
			return;
		}
		if (def.kind === "buff") {
			e.shield = 90 + e.level * 14 + e.ap * .4;
			e.shieldT = 4.5;
			e.hasteT = Math.max(e.hasteT, 3.2);
			ring(e.x, e.z, 1.6, 14987610, .4);
			floater(e.x, e.z, "Shield", "#e4b15a");
			return;
		}
		if (def.kind === "projectile") {
			const reach = def.range;
			const tx = e.x + fx * reach;
			const tz = e.z + fz * reach;
			const slow = def.name === "Frost Bind" ? 1.4 : 0;
			launch(e, e.x, e.z, tx, tz, def.speed, dmg, def.name === "Piercing Shot" ? "pierce" : "bolt", {
				pierce: def.name === "Piercing Shot",
				slow,
				radius: .48,
				life: reach / def.speed + .05
			});
			e.yaw = Math.atan2(-fx, -fz);
			return;
		}
		if (def.kind === "cone") {
			e.yaw = Math.atan2(-fx, -fz);
			ring(e.x + fx * 2, e.z + fz * 2, 1.4, 8240746, .25);
			for (const o of ents) {
				if (!hostilePair(e, o)) continue;
				const ox = o.x - e.x;
				const oz = o.z - e.z;
				const od = Math.hypot(ox, oz);
				if (od > def.range + o.radius) continue;
				if (ox / (od || 1) * fx + oz / (od || 1) * fz > .62) hurt(o, dmg, e);
			}
			return;
		}
		if (def.kind === "trap") {
			const slotT = traps.find((t) => !t.alive);
			if (slotT) {
				slotT.alive = true;
				slotT.team = e.team;
				slotT.x = e.x + fx * 1.5;
				slotT.z = e.z + fz * 1.5;
				slotT.life = 7;
				slotT.arm = .55;
				slotT.dmg = dmg;
				slotT.owner = e.id;
				slotT.radius = def.radius;
				slotT.slow = 1.5;
			}
			return;
		}
		if (def.kind === "rain") {
			const tx = e.x + fx * Math.min(def.range, Math.max(2, len));
			const tz = e.z + fz * Math.min(def.range, Math.max(2, len));
			ring(tx, tz, def.radius, 13914698, .55);
			strikes.push({
				t: time + .42,
				x: tx,
				z: tz,
				r: def.radius,
				dmg,
				owner: e.id,
				slow: .45
			});
		}
	}
	function aiHero(e, dt) {
		if (!e.alive) return;
		for (let i = 0; i < 4; i++) e.cds[i] = Math.max(0, (e.cds[i] ?? 0) - dt);
		e.aiCast -= dt;
		const fountain = FOUNTAINS.find((f) => f.team === e.team);
		if (e.hp < e.maxHp * .28) {
			moveToward(e, fountain.x, fountain.z, dt);
			separate(e);
			if (Math.hypot(e.x - fountain.x, e.z - fountain.z) < 8) aiBuy(e);
			return;
		}
		const foe = nearest(e, 12, (o) => o.kind === "hero" && hostilePair(e, o)) || nearest(e, 10, (o) => (o.kind === "minion" || o.kind === "tower" || o.kind === "nexus") && hostilePair(e, o));
		if (foe) {
			if (dist(e, foe) > e.atkRange + foe.radius * .2) moveToward(e, foe.x, foe.z, dt);
			else {
				e.vel *= .8;
				e.yaw = dampAngle(e.yaw, Math.atan2(-(foe.x - e.x), -(foe.z - e.z)), 8, dt);
			}
			separate(e);
			tryHit(e, foe);
			if (e.aiCast <= 0 && e.champ) {
				const slot = pickAiCast(e, foe);
				if (slot >= 0) {
					cast(e, slot, foe.x, foe.z);
					e.aiCast = 1.35;
				}
			}
			return;
		}
		const lane = LANES[e.lane] ?? LANES[0];
		const wp = lane[Math.max(0, Math.min(lane.length - 1, e.wp))];
		moveToward(e, wp.x, wp.z, dt);
		separate(e);
		if (Math.hypot(e.x - wp.x, e.z - wp.z) < 2.4) {
			const next = e.wp + e.dir;
			if (next >= 0 && next < lane.length) e.wp = next;
		}
		if (Math.hypot(e.x - fountain.x, e.z - fountain.z) < 9 && e.gold >= 300) aiBuy(e);
	}
	function pickAiCast(e, foe) {
		if (!e.champ) return -1;
		const abs = CHAMPS[e.champ].abilities;
		const d = dist(e, foe);
		let best = -1;
		let score = -1;
		abs.forEach((ab, i) => {
			if ((e.cds[i] ?? 0) > 0 || e.mana < ab.mana) return;
			let s = ab.dmg;
			if (ab.kind === "buff" && e.hp < e.maxHp * .6) s = 200;
			if ((ab.kind === "projectile" || ab.kind === "rain" || ab.kind === "cone") && d > ab.range) return;
			if (ab.kind === "dash" && d > 3 && d < ab.range + 2) s += 40;
			if (ab.kind === "aoe" && d > ab.radius) s *= .2;
			if (s > score) {
				score = s;
				best = i;
			}
		});
		return best;
	}
	function aiBuy(e) {
		const order = e.ranged ? [
			3,
			2,
			0,
			1
		] : [
			3,
			1,
			0,
			2
		];
		for (const idx of order) {
			const item = ITEMS[idx];
			if (!item) continue;
			if ((e.itemCounts[idx] ?? 0) >= 2) continue;
			if (e.gold >= item.cost) {
				e.gold -= item.cost;
				e.itemCounts[idx] = (e.itemCounts[idx] ?? 0) + 1;
				applyBuild(e);
				e.hp = Math.min(e.maxHp, e.hp + 40);
				return;
			}
		}
	}
	function tickMinion(e, dt) {
		const foe = nearest(e, 7.2, (o) => hostilePair(e, o) && (o.kind === "minion" || o.kind === "hero" || o.kind === "tower" || o.kind === "nexus"));
		if (foe) {
			if (dist(e, foe) > e.atkRange) moveToward(e, foe.x, foe.z, dt);
			else e.vel = 0;
			tryHit(e, foe);
			return;
		}
		const lane = LANES[e.lane] ?? LANES[0];
		const wp = lane[Math.max(0, Math.min(lane.length - 1, e.wp))];
		moveToward(e, wp.x, wp.z, dt);
		if (Math.hypot(e.x - wp.x, e.z - wp.z) < 1.6) {
			const next = e.wp + e.dir;
			if (next >= 0 && next < lane.length) e.wp = next;
		}
	}
	function tickTower(e) {
		let minion = null;
		let minD = e.atkRange;
		let hero = null;
		let heroD = e.atkRange;
		for (const o of ents) {
			if (!o.alive || o.team === e.team || o.team === 2) continue;
			if (o.kind !== "minion" && o.kind !== "hero") continue;
			const d = dist(e, o);
			if (o.kind === "minion" && d < minD) {
				minion = o;
				minD = d;
			}
			if (o.kind === "hero" && d < heroD) {
				hero = o;
				heroD = d;
			}
		}
		const tgt = minion || hero;
		if (tgt) tryHit(e, tgt);
	}
	function tickCreep(e, dt) {
		const homeD = Math.hypot(e.x - e.homeX, e.z - e.homeZ);
		const focus = e.focus >= 0 ? byId(e.focus) : null;
		const focusFar = !focus || !focus.alive || homeD > e.leash || Math.hypot(focus.x - e.homeX, focus.z - e.homeZ) > e.leash + 1;
		if (!e.aggro || focusFar) {
			e.aggro = false;
			e.focus = -1;
			if (e.hp < e.maxHp && homeD < 1.2) e.hp = Math.min(e.maxHp, e.hp + e.maxHp * .25 * dt);
			if (homeD > .8) moveToward(e, e.homeX, e.homeZ, dt);
			else e.vel = 0;
			return;
		}
		if (focus) {
			if (dist(e, focus) > e.atkRange) moveToward(e, focus.x, focus.z, dt);
			tryHit(e, focus);
		}
	}
	function tickBoss(e, dt) {
		e.specialT -= dt;
		const homeD = Math.hypot(e.x - e.homeX, e.z - e.homeZ);
		if (!e.aggro) {
			const near = nearest(e, 8, (o) => o.kind === "hero" && o.alive);
			if (near) {
				e.aggro = true;
				e.focus = near.id;
				announce("The Rift Colossus stirs");
			}
			return;
		}
		const focus = e.focus >= 0 ? byId(e.focus) : null;
		if (homeD > e.leash || !focus || !focus.alive) {
			e.aggro = false;
			e.focus = -1;
			e.hp = e.maxHp;
			moveToward(e, e.homeX, e.homeZ, dt);
			return;
		}
		if (dist(e, focus) > e.atkRange) moveToward(e, focus.x, focus.z, dt);
		else tryHit(e, focus);
		if (e.specialT <= 0) {
			e.specialT = 5.4;
			ring(e.x, e.z, 4.4, 13914698, .4);
			for (const o of ents) if (o.kind === "hero" && o.alive && dist(e, o) < 4.6) hurt(o, 55 + e.ad * .4, e, .5);
		}
	}
	function spawnWave() {
		if (ents.filter((e) => e.alive && e.kind === "minion").length >= STEP_CAP_MINIONS) return;
		wave += 1;
		for (let lane = 0; lane < 3; lane++) for (const team of [0, 1]) {
			const pts = LANES[lane];
			const start = team === 0 ? 0 : pts.length - 1;
			const dir = team === 0 ? 1 : -1;
			const origin = pts[start];
			const next = pts[Math.max(0, Math.min(pts.length - 1, start + dir))];
			const dx = next.x - origin.x;
			const dz = next.z - origin.z;
			const len = Math.hypot(dx, dz) || 1;
			const px = -dz / len;
			const pz = dx / len;
			for (let k = 0; k < 3; k++) {
				if (ents.filter((e) => e.alive && e.kind === "minion").length >= STEP_CAP_MINIONS) return;
				const ranged = k === 2;
				add({
					kind: "minion",
					team,
					name: ranged ? "Archer" : "Footman",
					x: origin.x + px * (k - 1) * .85,
					z: origin.z + pz * (k - 1) * .85,
					lane,
					wp: start + dir,
					dir,
					yaw: team === 0 ? 0 : Math.PI,
					hp: ranged ? 210 : 320,
					maxHp: ranged ? 210 : 320,
					ad: ranged ? 18 : 16,
					armor: 2,
					radius: .42,
					atkRange: ranged ? 6 : 1.55,
					atkCd: ranged ? 1.15 : .9,
					speed: 3.45,
					baseSpeed: 3.45,
					ranged
				});
			}
		}
	}
	function tickProjectiles(dt) {
		for (const p of projs) {
			if (!p.alive) continue;
			p.x += p.vx * dt;
			p.z += p.vz * dt;
			p.life -= dt;
			if (p.life <= 0) {
				p.alive = false;
				continue;
			}
			const owner = byId(p.owner);
			for (const e of ents) {
				if (!e.alive) continue;
				if (owner) {
					if (!hostilePair(owner, e)) continue;
				} else if (e.team === p.team || e.team === 2) continue;
				if (p.hits.includes(e.id)) continue;
				if (Math.hypot(e.x - p.x, e.z - p.z) <= e.radius + p.radius) {
					hurt(e, p.dmg, owner, p.slow);
					p.hits.push(e.id);
					if (!p.pierce) {
						p.alive = false;
						break;
					}
				}
			}
		}
	}
	function tickTraps(dt) {
		for (const t of traps) {
			if (!t.alive) continue;
			t.life -= dt;
			t.arm -= dt;
			if (t.life <= 0) {
				t.alive = false;
				continue;
			}
			if (t.arm > 0) continue;
			const owner = byId(t.owner);
			for (const e of ents) {
				if (!e.alive || !owner || !hostilePair(owner, e)) continue;
				if (Math.hypot(e.x - t.x, e.z - t.z) <= t.radius + e.radius) {
					hurt(e, t.dmg, owner, t.slow);
					ring(t.x, t.z, t.radius, 8240746, .3);
					t.alive = false;
					break;
				}
			}
		}
	}
	function tickStatus(e, dt) {
		e.hitFlash = Math.max(0, e.hitFlash - dt);
		e.attackAnim = Math.max(0, e.attackAnim - dt);
		e.slowT = Math.max(0, e.slowT - dt);
		e.hasteT = Math.max(0, e.hasteT - dt);
		e.lifestealT = Math.max(0, e.lifestealT - dt);
		e.teamBuffT = Math.max(0, e.teamBuffT - dt);
		e.shieldT = Math.max(0, e.shieldT - dt);
		if (e.shieldT <= 0) e.shield = 0;
		e.atkTimer = Math.max(0, e.atkTimer - dt);
		if (e.alive && e.kind === "hero") {
			e.mana = Math.min(e.maxMana, e.mana + (4 + e.level) * dt);
			const f = FOUNTAINS.find((n) => n.team === e.team);
			if (f && Math.hypot(e.x - f.x, e.z - f.z) < 9) {
				e.hp = Math.min(e.maxHp, e.hp + e.maxHp * .09 * dt);
				e.mana = Math.min(e.maxMana, e.mana + e.maxMana * .14 * dt);
			}
		}
	}
	function tickShrines(dt) {
		const p = player;
		for (const s of shrines) {
			s.ready = Math.max(0, s.ready - dt);
			if (!p.alive || phase !== "play") {
				s.channel = 0;
				continue;
			}
			if (Math.hypot(p.x - s.x, p.z - s.z) < 2.4 && s.ready <= 0) {
				s.channel += dt;
				if (s.channel > 1.5) {
					s.channel = 0;
					s.ready = 36;
					if (s.kind === "haste") p.hasteT = Math.max(p.hasteT, 8);
					if (s.kind === "lifesteal") p.lifestealT = Math.max(p.lifestealT, 10);
					if (s.kind === "shield") {
						p.shield = Math.max(p.shield, 160 + p.level * 8);
						p.shieldT = 8;
					}
					announce(`${s.name} answers`);
					ring(s.x, s.z, 2.2, 14987610, .6);
				}
			} else s.channel = 0;
		}
	}
	function nearFountain(e = player) {
		const f = FOUNTAINS.find((n) => n.team === e.team);
		if (!f) return false;
		return Math.hypot(e.x - f.x, e.z - f.z) < 10;
	}
	bootstrap();
	return {
		ents,
		projs,
		rings,
		traps,
		floats,
		get phase() {
			return phase;
		},
		set phase(v) {
			phase = v;
		},
		get time() {
			return time;
		},
		events,
		get dawnKills() {
			return dawnKills;
		},
		get duskKills() {
			return duskKills;
		},
		get wave() {
			return wave;
		},
		shrines,
		player: () => player,
		nearFountain,
		setPreview(id) {
			if (phase !== "menu") return;
			applyChamp(player, id, 500);
			player.name = CHAMPS[id].name;
			placeHero(player, "player", 0);
			const allies = ents.filter((e) => e.kind === "hero" && e.team === 0 && !e.player);
			const rest = otherChamps(id);
			allies.forEach((e, i) => {
				applyChamp(e, rest[i] ?? "ranger", 500);
				e.name = ALLY_NAMES[i] ?? e.name;
				placeHero(e, "ally", i);
			});
		},
		start(id) {
			resetStructures();
			dawnKills = 0;
			duskKills = 0;
			wave = 0;
			waveT = 5;
			time = 0;
			const heroes = ents.filter((e) => e.kind === "hero");
			player = heroes.find((e) => e.player);
			applyChamp(player, id, 500);
			player.name = CHAMPS[id].name;
			placeHero(player, "player", 0);
			const allies = heroes.filter((e) => e.team === 0 && !e.player);
			const foes = heroes.filter((e) => e.team === 1);
			const rest = otherChamps(id);
			allies.forEach((e, i) => {
				applyChamp(e, rest[i] ?? "ranger", 500);
				e.name = ALLY_NAMES[i] ?? "Ally";
				placeHero(e, "ally", i);
			});
			const foeChamps = [
				id,
				rest[0] ?? "arcanist",
				rest[1] ?? "ranger"
			];
			foes.forEach((e, i) => {
				applyChamp(e, foeChamps[i] ?? "vanguard", 500);
				e.name = ENEMY_NAMES[i] ?? "Foe";
				placeHero(e, "enemy", i);
			});
			phase = "play";
			announce("Hold the lanes. Break the Dusk Conduit.");
		},
		togglePause() {
			if (phase === "play") phase = "pause";
			else if (phase === "pause") phase = "play";
		},
		buy(id) {
			if (phase !== "play" || !player.alive) return false;
			if (!nearFountain(player)) return false;
			const idx = ITEMS.findIndex((it) => it.id === id);
			const item = ITEMS[idx];
			if (!item || idx < 0) return false;
			if ((player.itemCounts[idx] ?? 0) >= 3) return false;
			if (player.gold < item.cost) return false;
			player.gold -= item.cost;
			player.itemCounts[idx] = (player.itemCounts[idx] ?? 0) + 1;
			const ratio = player.hp / player.maxHp;
			applyBuild(player);
			player.hp = Math.min(player.maxHp, Math.max(ratio * player.maxHp, player.hp));
			floater(player.x, player.z, item.name, "#e4b15a");
			return true;
		},
		towersUp(team) {
			return ents.filter((e) => e.alive && e.kind === "tower" && e.team === team).length;
		},
		step(dt, input) {
			if (phase !== "play") return;
			time += dt;
			waveT -= dt;
			if (waveT <= 0) {
				waveT = 18;
				spawnWave();
			}
			for (const camp of camps) if (camp.down) {
				camp.timer -= dt;
				if (camp.timer <= 0) spawnCamp(camp);
			}
			for (const e of ents) {
				tickStatus(e, dt);
				if (!e.alive && e.kind === "hero") {
					e.respawn -= dt;
					if (e.respawn <= 0) reviveHero(e);
					continue;
				}
				if (!e.alive && e.kind === "boss") {
					e.respawn -= dt;
					if (e.respawn <= 0) {
						e.alive = true;
						e.hp = e.maxHp;
						e.x = e.homeX;
						e.z = e.homeZ;
						e.aggro = false;
						e.focus = -1;
						announce("The Rift Colossus wakes again");
					}
					continue;
				}
				if (!e.alive) continue;
				if (e.player) tickHeroPlayer(e, input, dt);
				else if (e.kind === "hero") aiHero(e, dt);
				else if (e.kind === "minion") tickMinion(e, dt);
				else if (e.kind === "tower") tickTower(e);
				else if (e.kind === "creep") tickCreep(e, dt);
				else if (e.kind === "boss") tickBoss(e, dt);
			}
			tickProjectiles(dt);
			tickTraps(dt);
			tickShrines(dt);
			for (let i = strikes.length - 1; i >= 0; i--) {
				const s = strikes[i];
				if (!s || time < s.t) continue;
				const owner = byId(s.owner);
				ring(s.x, s.z, s.r, 14987610, .4);
				if (owner) for (const o of ents) {
					if (!hostilePair(owner, o)) continue;
					if (Math.hypot(o.x - s.x, o.z - s.z) <= s.r + o.radius * .3) hurt(o, s.dmg, owner, s.slow);
				}
				strikes.splice(i, 1);
			}
			for (const f of floats) {
				if (!f.alive) continue;
				f.life -= dt;
				f.y += dt * 1.4;
				if (f.life <= 0) f.alive = false;
			}
			for (const r of rings) {
				if (!r.alive) continue;
				r.life -= dt;
				if (r.life <= 0) r.alive = false;
			}
			for (let i = ents.length - 1; i >= 0; i--) {
				const e = ents[i];
				if (e && !e.alive && (e.kind === "minion" || e.kind === "creep")) ents.splice(i, 1);
			}
		}
	};
}
function dampAngle(current, target, rate, dt) {
	return current + Math.atan2(Math.sin(target - current), Math.cos(target - current)) * (1 - Math.exp(-rate * dt));
}
var template = null;
var clips = [];
var scale = 1;
var foot = 0;
var pending = null;
var TINT = {
	vanguard: 16774890,
	arcanist: 12969970,
	ranger: 14019524
};
function heraldReady() {
	return template !== null;
}
function loadHerald() {
	if (template) return Promise.resolve();
	if (pending) return pending;
	pending = new Promise((resolve) => {
		new GLTFLoader().load("/models/herald.glb", (gltf) => {
			template = gltf.scene;
			clips = gltf.animations;
			template.updateMatrixWorld(true);
			const box = new Box3().setFromObject(template);
			scale = 1.7 / Math.max(.001, box.max.y - box.min.y);
			foot = -box.min.y * scale;
			template.traverse((obj) => {
				const mesh = obj;
				if (!mesh.isMesh) return;
				mesh.castShadow = false;
				mesh.receiveShadow = false;
				mesh.geometry.boundingSphere ?? mesh.geometry.computeBoundingSphere();
				if (mesh.geometry.boundingSphere) mesh.geometry.boundingSphere.radius *= 1.45;
				mesh.frustumCulled = true;
			});
			resolve();
		}, void 0, () => resolve());
	});
	return pending;
}
function modeOf(pose) {
	if (!pose.alive) return "sit";
	if (pose.dashT > 0) return "jump";
	if (pose.attackAnim > .12 && pose.vel < 1.2) return "jump";
	if (pose.slowT > 0 && pose.vel < 3.2) return "crouch";
	if (pose.vel > 5.3) return "run";
	if (pose.vel > .4) return "walk";
	return "idle";
}
function createHerald(champ, team) {
	if (!template) return null;
	const model = clone(template);
	model.scale.setScalar(scale);
	model.position.y = foot;
	const mats = [];
	model.traverse((obj) => {
		const mesh = obj;
		if (!mesh.isMesh) return;
		const mat = mesh.material.clone();
		mat.color = new Color(TINT[champ]);
		if (team === 1) mat.color.multiply(new Color(15179928));
		mesh.material = mat;
		mesh.castShadow = false;
		mesh.receiveShadow = false;
		mesh.frustumCulled = true;
		mats.push(mat);
	});
	const root = new Group();
	root.add(model);
	const mixer = new AnimationMixer(model);
	const actions = {};
	for (const clip of clips) {
		const name = clip.name;
		if (name !== "walk" && name !== "run" && name !== "jump" && name !== "crouch" && name !== "sit") continue;
		const action = mixer.clipAction(clip);
		action.enabled = true;
		if (name === "jump" || name === "sit") {
			action.setLoop(LoopOnce, 1);
			action.clampWhenFinished = true;
		} else action.setLoop(LoopRepeat, Infinity);
		actions[name] = action;
	}
	const walk = actions.walk;
	if (walk) {
		walk.play();
		walk.time = walk.getClip().duration * .22;
		walk.paused = true;
		mixer.update(0);
	}
	let current = "idle";
	let clipName = "walk";
	let flashed = false;
	let lodDebt = 0;
	function play(nextMode) {
		const nextClip = nextMode === "idle" ? "walk" : nextMode;
		const action = actions[nextClip];
		if (!action) return;
		if (nextClip !== clipName) {
			const prev = actions[clipName === "idle" ? "walk" : clipName];
			action.reset();
			if (nextClip === "jump" || nextClip === "sit") {
				action.setLoop(LoopOnce, 1);
				action.clampWhenFinished = true;
			}
			action.fadeIn(.16).play();
			prev?.fadeOut(.16);
			clipName = nextClip;
		}
		if (nextMode === "idle") action.paused = true;
		else {
			action.paused = false;
			action.timeScale = nextMode === "run" ? 1.15 : nextMode === "crouch" ? .75 : 1;
		}
		current = nextMode;
	}
	return {
		object: root,
		step(pose, dt, dist = 0) {
			const next = modeOf(pose);
			if (next !== current) play(next);
			else if (actions[clipName]) {
				const action = actions[clipName];
				if (next === "walk") action.timeScale = Math.min(1.35, Math.max(.7, pose.vel / 3.5));
				else if (next === "run") action.timeScale = Math.min(1.4, Math.max(.85, pose.vel / 6.4));
			}
			const budget = dist > 48 ? .28 : dist > 26 ? .08 : 0;
			if (budget > 0) {
				lodDebt += dt;
				if (lodDebt < budget) return;
				dt = lodDebt;
				lodDebt = 0;
			} else lodDebt = 0;
			mixer.update(Math.min(dt, .08));
			const hot = pose.hitFlash > 0;
			if (hot !== flashed) {
				flashed = hot;
				for (const mat of mats) {
					mat.emissive.setHex(hot ? 16773584 : 0);
					mat.emissiveIntensity = hot ? .45 : 0;
				}
			}
		},
		dispose() {
			mixer.stopAllAction();
			for (const mat of mats) mat.dispose();
		}
	};
}
var SIZE = 200;
var SEG = 72;
function createWorld(canvas) {
	const renderer = new WebGLRenderer({
		canvas,
		antialias: true,
		alpha: false,
		powerPreference: "high-performance"
	});
	renderer.outputColorSpace = SRGBColorSpace;
	renderer.toneMapping = 4;
	renderer.toneMappingExposure = 1.08;
	renderer.shadowMap.enabled = true;
	renderer.shadowMap.type = 1;
	const coarse = typeof window !== "undefined" && window.matchMedia("(pointer: coarse)").matches;
	renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, coarse ? 1.25 : 1.6));
	const scene = new Scene();
	scene.background = new Color(9353420);
	scene.fog = new Fog(13227460, 48, 145);
	loadHerald();
	const camera = new PerspectiveCamera(52, 1, .12, 280);
	camera.position.set(0, 24, 48);
	const hemi = new HemisphereLight(16770754, 4086336, .85);
	scene.add(hemi);
	const sun = new DirectionalLight(16774109, 1.65);
	sun.position.set(48, 72, 26);
	sun.castShadow = true;
	sun.shadow.mapSize.set(1024, 1024);
	sun.shadow.camera.near = 12;
	sun.shadow.camera.far = 180;
	sun.shadow.camera.left = -78;
	sun.shadow.camera.right = 78;
	sun.shadow.camera.top = 78;
	sun.shadow.camera.bottom = -78;
	sun.shadow.bias = -4e-4;
	scene.add(sun);
	scene.add(sun.target);
	const skyGeo = new SphereGeometry(190, 18, 12);
	const skyPos = skyGeo.attributes.position;
	const skyCols = new Float32Array(skyPos.count * 3);
	const topC = new Color("#6aa4c9");
	const horC = new Color("#f3d7a6");
	const botC = new Color("#8aa56a");
	const tmpC = new Color();
	for (let i = 0; i < skyPos.count; i++) {
		const y = skyPos.getY(i) / 190;
		if (y < 0) tmpC.copy(botC).lerp(horC, y + 1);
		else tmpC.copy(horC).lerp(topC, Math.min(1, y * 1.6));
		skyCols[i * 3] = tmpC.r;
		skyCols[i * 3 + 1] = tmpC.g;
		skyCols[i * 3 + 2] = tmpC.b;
	}
	skyGeo.setAttribute("color", new BufferAttribute(skyCols, 3));
	const sky = new Mesh(skyGeo, new MeshBasicMaterial({
		vertexColors: true,
		side: 1,
		depthWrite: false,
		fog: false
	}));
	scene.add(sky);
	const groundGeo = new PlaneGeometry(SIZE, SIZE, SEG, SEG);
	groundGeo.rotateX(-Math.PI / 2);
	const gPos = groundGeo.attributes.position;
	const gCols = new Float32Array(gPos.count * 3);
	const gc = new Color();
	for (let i = 0; i < gPos.count; i++) {
		const x = gPos.getX(i);
		const z = gPos.getZ(i);
		const h = terrainHeight(x, z);
		gPos.setY(i, h);
		const col = terrainColor(x, z, h);
		gc.setRGB(col.r, col.g, col.b);
		gCols[i * 3] = gc.r;
		gCols[i * 3 + 1] = gc.g;
		gCols[i * 3 + 2] = gc.b;
	}
	groundGeo.setAttribute("color", new BufferAttribute(gCols, 3));
	groundGeo.computeVertexNormals();
	const ground = new Mesh(groundGeo, new MeshStandardMaterial({
		vertexColors: true,
		roughness: .94,
		metalness: .02
	}));
	ground.receiveShadow = true;
	scene.add(ground);
	const water = new Mesh(new PlaneGeometry(SIZE, SIZE), new MeshPhysicalMaterial({
		color: 2780546,
		transparent: true,
		opacity: .72,
		roughness: .18,
		metalness: .04
	}));
	water.rotation.x = -Math.PI / 2;
	water.position.y = -.28;
	scene.add(water);
	const trunkGeo = new CylinderGeometry(.16, .24, 1.3, 5);
	const leafGeoA = new ConeGeometry(.9, 1.8, 6);
	const leafGeoB = new IcosahedronGeometry(.72, 0);
	const trunkMat = new MeshStandardMaterial({
		color: 6047284,
		roughness: .9
	});
	const leafMatA = new MeshStandardMaterial({
		color: 3107384,
		roughness: .85
	});
	const leafMatB = new MeshStandardMaterial({
		color: 4095298,
		roughness: .85
	});
	const trunks = new InstancedMesh(trunkGeo, trunkMat, TREES.length);
	const leavesA = new InstancedMesh(leafGeoA, leafMatA, TREES.length);
	const leavesB = new InstancedMesh(leafGeoB, leafMatB, TREES.length);
	const dummy = new Object3D();
	let aCount = 0;
	let bCount = 0;
	TREES.forEach((t, i) => {
		const y = groundY(t.x, t.z);
		dummy.position.set(t.x, y + .65 * t.s, t.z);
		dummy.scale.setScalar(t.s);
		dummy.rotation.set(0, i, 0);
		dummy.updateMatrix();
		trunks.setMatrixAt(i, dummy.matrix);
		dummy.position.set(t.x, y + 1.7 * t.s, t.z);
		dummy.scale.setScalar(t.s);
		dummy.updateMatrix();
		if (t.kind === 0) leavesA.setMatrixAt(aCount++, dummy.matrix);
		else leavesB.setMatrixAt(bCount++, dummy.matrix);
	});
	trunks.count = TREES.length;
	leavesA.count = aCount;
	leavesB.count = bCount;
	scene.add(trunks, leavesA, leavesB);
	const rockGeo = new DodecahedronGeometry(.7, 0);
	const rockMat = new MeshStandardMaterial({
		color: 9077882,
		roughness: .92
	});
	const rocks = new InstancedMesh(rockGeo, rockMat, 40);
	let ri = 0;
	for (let k = 0; k < 40; k++) {
		const x = Math.sin(k * 12.3) * 70;
		const z = Math.cos(k * 9.1) * 70;
		if (Math.hypot(x, z - 70) < 18) continue;
		const y = groundY(x, z);
		if (y < .4) continue;
		dummy.position.set(x, y + .2, z);
		dummy.rotation.set(k, k * .5, 0);
		dummy.scale.setScalar(.5 + k % 5 * .18);
		dummy.updateMatrix();
		rocks.setMatrixAt(ri++, dummy.matrix);
	}
	rocks.count = ri;
	scene.add(rocks);
	const stone = new MeshStandardMaterial({
		color: 10130054,
		roughness: .88
	});
	for (const r of RUINS) {
		const col = new Mesh(new CylinderGeometry(.35, .45, r.h, 6), stone);
		col.position.set(r.x, groundY(r.x, r.z) + r.h * .45, r.z);
		col.rotation.y = r.rot;
		col.castShadow = true;
		scene.add(col);
	}
	const shrineMat = new MeshStandardMaterial({
		color: 14987610,
		emissive: 9069600,
		emissiveIntensity: .45,
		roughness: .4
	});
	for (const s of SHRINES) {
		const y = groundY(s.x, s.z);
		const ring = new Mesh(new TorusGeometry(1.3, .08, 6, 16), shrineMat);
		ring.rotation.x = Math.PI / 2;
		ring.position.set(s.x, y + .15, s.z);
		const gem = new Mesh(new OctahedronGeometry(.28), shrineMat);
		gem.position.set(s.x, y + 1.1, s.z);
		scene.add(ring, gem);
	}
	const dawnGem = new MeshStandardMaterial({
		color: 14987610,
		emissive: 14987610,
		emissiveIntensity: .55,
		roughness: .35
	});
	const duskGem = new MeshStandardMaterial({
		color: 13914698,
		emissive: 13914698,
		emissiveIntensity: .5,
		roughness: .35
	});
	const neutralGem = new MeshStandardMaterial({
		color: 13022346,
		emissive: 6969906,
		emissiveIntensity: .3,
		roughness: .5
	});
	const groups = /* @__PURE__ */ new Map();
	const minionMesh = new InstancedMesh(new CapsuleGeometry(.28, .45, 3, 6), new MeshStandardMaterial({
		color: 16777215,
		roughness: .7
	}), 54);
	minionMesh.instanceColor = new InstancedBufferAttribute(/* @__PURE__ */ new Float32Array(162), 3);
	minionMesh.castShadow = true;
	minionMesh.count = 0;
	scene.add(minionMesh);
	const shotMesh = new InstancedMesh(new SphereGeometry(.22, 8, 6), new MeshStandardMaterial({
		color: 16777215,
		emissive: 2232576,
		roughness: .4
	}), 48);
	shotMesh.instanceColor = new InstancedBufferAttribute(/* @__PURE__ */ new Float32Array(144), 3);
	shotMesh.count = 0;
	scene.add(shotMesh);
	const ringPool = [];
	for (let i = 0; i < 16; i++) {
		const m = new Mesh(new RingGeometry(.8, .95, 24), new MeshBasicMaterial({
			color: 14987610,
			transparent: true,
			opacity: .8,
			side: 2
		}));
		m.rotation.x = -Math.PI / 2;
		m.visible = false;
		scene.add(m);
		ringPool.push(m);
	}
	const aimRing = new Mesh(new RingGeometry(.35, .48, 20), new MeshBasicMaterial({
		color: 15200230,
		transparent: true,
		opacity: .8,
		side: 2
	}));
	aimRing.rotation.x = -Math.PI / 2;
	aimRing.visible = false;
	scene.add(aimRing);
	const clock = { t: 0 };
	let camX = 0;
	let camY = 18;
	let camZ = 40;
	let focusX = 0;
	let focusZ = 0;
	const projV = new Vector3();
	const col = new Color();
	let viewW = 1;
	let viewH = 1;
	function resize() {
		const w = canvas.clientWidth || window.innerWidth;
		const h = canvas.clientHeight || window.innerHeight;
		viewW = w;
		viewH = h;
		renderer.setSize(w, h, false);
		camera.aspect = w / Math.max(1, h);
		camera.updateProjectionMatrix();
	}
	function teamMat(team) {
		return team === 0 ? dawnGem : team === 1 ? duskGem : neutralGem;
	}
	function makeHero(champ, team) {
		const g = new Group();
		const cloth = new Color(champ === "arcanist" ? 2383474 : champ === "ranger" ? 2972210 : 6965800);
		const bodyMat = new MeshStandardMaterial({
			color: cloth,
			roughness: .72
		});
		const skin = new MeshStandardMaterial({
			color: 14135434,
			roughness: .65
		});
		const metal = new MeshStandardMaterial({
			color: team === 1 ? 9058874 : 13206842,
			roughness: .45,
			metalness: .35
		});
		const body = new Mesh(new CapsuleGeometry(.34, .62, 4, 8), bodyMat);
		body.position.y = .95;
		body.castShadow = true;
		const head = new Mesh(new SphereGeometry(.24, 10, 8), skin);
		head.position.y = 1.68;
		head.castShadow = true;
		const sash = new Mesh(new BoxGeometry(.5, .12, .16), teamMat(team));
		sash.position.set(0, 1.15, .28);
		const weapon = new Group();
		weapon.position.set(.38, 1.05, .05);
		if (champ === "vanguard") {
			const blade = new Mesh(new BoxGeometry(.08, .08, 1.15), metal);
			blade.position.set(0, 0, .55);
			const guard = new Mesh(new BoxGeometry(.32, .08, .08), metal);
			weapon.add(blade, guard);
		} else if (champ === "arcanist") {
			const staff = new Mesh(new CylinderGeometry(.045, .045, 1.5, 6), new MeshStandardMaterial({
				color: 4863012,
				roughness: .8
			}));
			staff.rotation.x = Math.PI / 2;
			staff.position.z = .2;
			const orb = new Mesh(new SphereGeometry(.16, 10, 8), team === 1 ? duskGem : dawnGem);
			orb.position.set(0, 0, .95);
			weapon.add(staff, orb);
		} else {
			const bow = new Mesh(new TorusGeometry(.38, .035, 6, 14, Math.PI), new MeshStandardMaterial({
				color: 7031338,
				roughness: .7
			}));
			bow.rotation.y = Math.PI / 2;
			bow.rotation.z = Math.PI / 2;
			weapon.add(bow);
		}
		g.add(body, head, sash, weapon);
		g.userData = {
			champ,
			weapon,
			mats: [bodyMat, metal]
		};
		return g;
	}
	function makeTower(team) {
		const g = new Group();
		const base = new Mesh(new CylinderGeometry(1.25, 1.55, 1.1, 8), stone);
		base.position.y = .55;
		base.castShadow = true;
		const shaft = new Mesh(new CylinderGeometry(.62, .95, 3.8, 8), stone);
		shaft.position.y = 2.9;
		shaft.castShadow = true;
		const gem = new Mesh(new OctahedronGeometry(.48), teamMat(team));
		gem.position.y = 5.15;
		g.add(base, shaft, gem);
		g.userData = { gem };
		return g;
	}
	function makeNexus(team) {
		const g = new Group();
		const base = new Mesh(new CylinderGeometry(1.8, 2.2, .8, 8), stone);
		base.position.y = .4;
		base.castShadow = true;
		const gem = new Mesh(new OctahedronGeometry(1.05), teamMat(team));
		gem.position.y = 2.3;
		const halo = new Mesh(new TorusGeometry(1.5, .06, 6, 20), teamMat(team));
		halo.rotation.x = Math.PI / 2;
		halo.position.y = .9;
		g.add(base, gem, halo);
		g.userData = {
			gem,
			halo
		};
		return g;
	}
	function makeCreep(e) {
		const g = new Group();
		if (e.kind === "boss" || e.creepKind === "golem") {
			const body = new Mesh(new DodecahedronGeometry(e.kind === "boss" ? 1.15 : .85, 0), new MeshStandardMaterial({
				color: 7172952,
				roughness: .86
			}));
			body.position.y = e.kind === "boss" ? 1.3 : .9;
			body.castShadow = true;
			const eye = new Mesh(new SphereGeometry(.12, 8, 6), duskGem);
			eye.position.set(.2, body.position.y + .2, .55);
			g.add(body, eye);
		} else if (e.creepKind === "spirit") {
			const body = new Mesh(new SphereGeometry(.42, 10, 8), new MeshStandardMaterial({
				color: 10475752,
				emissive: 3831944,
				emissiveIntensity: .6,
				transparent: true,
				opacity: .9
			}));
			body.position.y = .9;
			g.add(body);
		} else {
			const body = new Mesh(new CapsuleGeometry(.28, .35, 3, 6), new MeshStandardMaterial({
				color: 4866104,
				roughness: .8
			}));
			body.position.y = .5;
			body.rotation.z = Math.PI / 2;
			body.castShadow = true;
			g.add(body);
		}
		return g;
	}
	function releaseHero(g) {
		const dispose = g.userData.dispose;
		dispose?.();
		if (!g.userData.herald) g.traverse((obj) => {
			const mesh = obj;
			if (!mesh.isMesh) return;
			mesh.geometry?.dispose();
			const mat = mesh.material;
			if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
			else mat?.dispose();
		});
		scene.remove(g);
	}
	function ensureGroup(e) {
		const prev = groups.get(e.id);
		if (e.kind === "hero") {
			const champ = e.champ ?? "vanguard";
			const skinned = heraldReady();
			if (prev && Boolean(prev.userData.herald) === skinned && prev.userData.champ === champ && prev.userData.team === e.team) return prev;
			if (prev) releaseHero(prev);
			if (skinned) {
				const actor = createHerald(champ, e.team);
				if (actor) {
					actor.object.userData = {
						herald: true,
						champ,
						team: e.team,
						step: actor.step,
						dispose: actor.dispose
					};
					groups.set(e.id, actor.object);
					scene.add(actor.object);
					return actor.object;
				}
			}
			const g = makeHero(champ, e.team);
			g.userData.champ = champ;
			g.userData.team = e.team;
			groups.set(e.id, g);
			scene.add(g);
			return g;
		}
		if (prev) return prev;
		let g;
		if (e.kind === "tower") g = makeTower(e.team);
		else if (e.kind === "nexus") g = makeNexus(e.team);
		else g = makeCreep(e);
		groups.set(e.id, g);
		scene.add(g);
		return g;
	}
	function placeRing(mesh, ring) {
		const mat = mesh.material;
		mat.color.setHex(ring.color);
		mat.opacity = Math.max(.15, ring.life / ring.max);
		const y = groundY(ring.x, ring.z) + .18;
		mesh.position.set(ring.x, y, ring.z);
		const s = ring.r * (1.05 - .15 * (ring.life / ring.max));
		mesh.scale.setScalar(s);
		mesh.visible = true;
	}
	function render(sim, dt, camYaw, aimX, aimZ, showAim) {
		clock.t += dt;
		const player = sim.player();
		const menu = sim.phase === "menu";
		const seen = /* @__PURE__ */ new Set();
		let mi = 0;
		let si = 0;
		for (const e of sim.ents) {
			if (e.kind === "minion") {
				if (!e.alive || mi >= 54) continue;
				const y = groundY(e.x, e.z);
				dummy.position.set(e.x, y + .55, e.z);
				dummy.rotation.set(0, e.yaw + Math.PI, 0);
				dummy.scale.setScalar(e.ranged ? .85 : 1);
				dummy.updateMatrix();
				minionMesh.setMatrixAt(mi, dummy.matrix);
				col.setHex(e.team === 0 ? 14987610 : 13914698);
				if (e.hitFlash > 0) col.setHex(16777215);
				minionMesh.setColorAt(mi, col);
				mi++;
				continue;
			}
			if (e.kind === "hero") {
				const g = ensureGroup(e);
				seen.add(e.id);
				const show = e.alive || e.respawn > 0;
				g.visible = show;
				if (show) {
					g.position.set(e.x, groundY(e.x, e.z), e.z);
					g.rotation.y = e.yaw + Math.PI;
					const step = g.userData.step;
					if (step) {
						const dist = Math.hypot(camera.position.x - e.x, camera.position.z - e.z);
						step({
							champ: e.champ,
							team: e.team,
							vel: e.vel,
							alive: e.alive,
							dashT: e.dashT,
							slowT: e.slowT,
							attackAnim: e.attackAnim,
							hitFlash: e.hitFlash
						}, dt, dist);
					} else {
						const bob = Math.sin(clock.t * (e.vel > .5 ? 9 : 2) + e.id) * (e.vel > .5 ? .05 : .02);
						g.position.y += bob;
						const weapon = g.userData.weapon;
						if (weapon) weapon.rotation.x = e.attackAnim > 0 ? Math.sin((.28 - e.attackAnim) * 12) * -1.1 : 0;
					}
				}
				continue;
			}
			if (!e.alive && e.kind !== "tower" && e.kind !== "nexus" && e.kind !== "boss") continue;
			const g = ensureGroup(e);
			seen.add(e.id);
			g.visible = e.alive;
			if (!e.alive) continue;
			const y = groundY(e.x, e.z);
			g.position.set(e.x, y, e.z);
			g.rotation.y = e.yaw + Math.PI;
			const weapon = g.userData.weapon;
			if (weapon) weapon.rotation.x = e.attackAnim > 0 ? Math.sin((.28 - e.attackAnim) * 12) * -1.1 : 0;
			const mats = g.userData.mats;
			if (mats) for (const m of mats) {
				m.emissive.setHex(e.hitFlash > 0 ? 16773848 : 0);
				m.emissiveIntensity = e.hitFlash > 0 ? .55 : 0;
			}
			const gem = g.userData.gem;
			if (gem) gem.rotation.y = clock.t * .8;
			const halo = g.userData.halo;
			if (halo) halo.rotation.z = clock.t * .4;
		}
		for (const id of [...groups.keys()]) {
			const g = groups.get(id);
			if (!g || seen.has(id)) continue;
			g.userData.dispose?.();
			scene.remove(g);
			groups.delete(id);
		}
		minionMesh.count = mi;
		minionMesh.instanceMatrix.needsUpdate = true;
		if (minionMesh.instanceColor) minionMesh.instanceColor.needsUpdate = true;
		for (const p of sim.projs) {
			if (!p.alive || si >= 48) continue;
			const y = groundY(p.x, p.z) + 1.05;
			dummy.position.set(p.x, y, p.z);
			dummy.rotation.set(0, 0, 0);
			dummy.scale.setScalar(p.kind === "pierce" ? .7 : 1);
			dummy.updateMatrix();
			shotMesh.setMatrixAt(si, dummy.matrix);
			col.setHex(p.team === 0 ? 15914122 : p.team === 1 ? 16743026 : 14149615);
			if (p.kind === "pierce") col.setHex(14153156);
			shotMesh.setColorAt(si, col);
			si++;
		}
		shotMesh.count = si;
		shotMesh.instanceMatrix.needsUpdate = true;
		if (shotMesh.instanceColor) shotMesh.instanceColor.needsUpdate = true;
		ringPool.forEach((m) => {
			m.visible = false;
		});
		let riRing = 0;
		for (const r of sim.rings) {
			if (!r.alive || riRing >= ringPool.length) continue;
			const mesh = ringPool[riRing++];
			if (mesh) placeRing(mesh, r);
		}
		for (const t of sim.traps) {
			if (!t.alive || riRing >= ringPool.length) continue;
			const mesh = ringPool[riRing++];
			if (!mesh) continue;
			placeRing(mesh, {
				alive: true,
				x: t.x,
				z: t.z,
				r: t.radius * (t.arm > 0 ? .55 : 1),
				life: t.life,
				max: 7,
				color: t.arm > 0 ? 9675673 : 8240746
			});
		}
		if (showAim && !menu) {
			aimRing.visible = true;
			aimRing.position.set(aimX, groundY(aimX, aimZ) + .2, aimZ);
		} else aimRing.visible = false;
		const py = groundY(player.x, player.z);
		if (menu) {
			const ang = clock.t * .08;
			const tx = Math.sin(ang) * 46;
			const tz = Math.cos(ang) * 34;
			const k = 1 - Math.exp(-.6 * dt);
			camX += (tx - camX) * k;
			camY += (26 - camY) * k;
			camZ += (tz - camZ) * k;
			camera.position.set(camX, camY, camZ);
			camera.lookAt(0, 2, 0);
		} else {
			const fx = -Math.sin(camYaw);
			const fz = -Math.cos(camYaw);
			const dist = coarse ? 13.5 : 12;
			const wantX = player.x - fx * dist;
			const wantZ = player.z - fz * dist;
			let wantY = py + (coarse ? 8.2 : 6.6);
			const gy = groundY(wantX, wantZ) + 1.4;
			if (wantY < gy) wantY = gy;
			const k = 1 - Math.exp(-5.5 * dt);
			focusX += (player.x - focusX) * k;
			focusZ += (player.z - focusZ) * k;
			camX += (wantX - camX) * k;
			camY += (wantY - camY) * k;
			camZ += (wantZ - camZ) * k;
			let sx = camX;
			let sy = camY;
			let sz = camZ;
			if (player.hitFlash > .04) {
				sx += (Math.random() - .5) * .18;
				sy += (Math.random() - .5) * .1;
			}
			camera.position.set(sx, sy, sz);
			camera.lookAt(focusX, py + 1.25, focusZ);
		}
		sun.target.position.set(player.x, 0, player.z);
		sun.target.updateMatrixWorld();
		renderer.render(scene, camera);
	}
	function snap(sim, camYaw) {
		const p = sim.player();
		const fx = -Math.sin(camYaw);
		const fz = -Math.cos(camYaw);
		const py = groundY(p.x, p.z);
		camX = p.x - fx * 12;
		camZ = p.z - fz * 12;
		camY = py + 6.6;
		focusX = p.x;
		focusZ = p.z;
	}
	function project(x, y, z) {
		projV.set(x, y, z);
		projV.project(camera);
		return {
			x: (projV.x * .5 + .5) * viewW,
			y: (-projV.y * .5 + .5) * viewH,
			visible: projV.z < 1 && projV.z > -1
		};
	}
	resize();
	return {
		resize,
		render,
		snap,
		project,
		width: () => viewW,
		height: () => viewH,
		camera,
		dispose() {
			renderer.dispose();
			scene.traverse((obj) => {
				const mesh = obj;
				if (mesh.geometry) mesh.geometry.dispose();
				const mat = mesh.material;
				if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
				else mat?.dispose();
			});
		}
	};
}
var SAVE_KEY = "aetherfall-record-v1";
function loadRecord() {
	try {
		const raw = localStorage.getItem(SAVE_KEY);
		if (!raw) return {
			wins: 0,
			bestKills: 0,
			bestCs: 0
		};
		const parsed = JSON.parse(raw);
		return {
			wins: Number(parsed.wins) || 0,
			bestKills: Number(parsed.bestKills) || 0,
			bestCs: Number(parsed.bestCs) || 0
		};
	} catch {
		return {
			wins: 0,
			bestKills: 0,
			bestCs: 0
		};
	}
}
function fmt(t) {
	const s = Math.max(0, Math.floor(t));
	return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}
function createGame(canvas, overlay, hud, hooks) {
	const audio = createAudio();
	const sim = createSim();
	const view = createWorld(canvas);
	const keys = /* @__PURE__ */ new Set();
	let qaKeys = null;
	let camYaw = 0;
	let stickX = 0;
	let stickY = 0;
	let camTurn = 0;
	let attackHeld = false;
	let attackPulse = false;
	let pendingCast = -1;
	const castWas = [
		false,
		false,
		false,
		false
	];
	let aimX = 0;
	let aimZ = 50;
	let pointerSeen = false;
	let shopPulse = false;
	let bWas = false;
	let last = performance.now();
	let acc = 0;
	let raf = 0;
	let running = true;
	let lastPhase = "menu";
	const record = loadRecord();
	const raycaster = new Raycaster();
	const pointer = new Vector2();
	const plane = new Plane(new Vector3(0, 1, 0), -.2);
	const hit = new Vector3();
	const barPool = makePool(overlay, 22, barHtml());
	const floatPool = makePool(overlay, 16, "");
	function held(code) {
		return (qaKeys ?? keys).has(code);
	}
	function setAim(clientX, clientY) {
		const rect = canvas.getBoundingClientRect();
		if (rect.width < 1 || rect.height < 1) return;
		pointer.set((clientX - rect.left) / rect.width * 2 - 1, -((clientY - rect.top) / rect.height) * 2 + 1);
		raycaster.setFromCamera(pointer, view.camera);
		if (raycaster.ray.intersectPlane(plane, hit)) {
			aimX = hit.x;
			aimZ = hit.z;
		}
	}
	function stats() {
		const p = sim.player();
		return {
			win: sim.phase === "victory",
			name: p.name,
			kills: p.kills,
			deaths: p.deaths,
			assists: p.assists,
			cs: p.cs,
			gold: Math.floor(p.gold),
			level: p.level,
			time: sim.time
		};
	}
	function saveRecord(win) {
		const p = sim.player();
		if (win) record.wins += 1;
		record.bestKills = Math.max(record.bestKills, p.kills);
		record.bestCs = Math.max(record.bestCs, p.cs);
		localStorage.setItem(SAVE_KEY, JSON.stringify(record));
		hooks.onRecord({ ...record });
	}
	let dragging = false;
	let moved = false;
	let downX = 0;
	let downY = 0;
	const onKeyDown = (e) => {
		if (e.code === "Space" || e.code.startsWith("Arrow")) e.preventDefault();
		keys.add(e.code);
		if (e.code === "Escape") sim.togglePause();
	};
	const onKeyUp = (e) => keys.delete(e.code);
	const onBlur = () => {
		keys.clear();
		attackHeld = false;
		camTurn = 0;
		stickX = 0;
		stickY = 0;
	};
	const onPointerDown = (e) => {
		audio.unlock();
		if (e.button !== 0 && e.button !== 2) return;
		dragging = true;
		moved = false;
		downX = e.clientX;
		downY = e.clientY;
		canvas.setPointerCapture(e.pointerId);
	};
	const onPointerMove = (e) => {
		pointerSeen = true;
		setAim(e.clientX, e.clientY);
		if (!dragging) return;
		if ((e.clientX - downX) ** 2 + (e.clientY - downY) ** 2 > 20) moved = true;
		camYaw -= e.movementX * .005;
	};
	const onPointerUp = (e) => {
		if (!moved && e.button === 0 && sim.phase === "play") {
			pointerSeen = true;
			setAim(e.clientX, e.clientY);
			attackPulse = true;
		}
		dragging = false;
	};
	const onContext = (e) => e.preventDefault();
	const onVis = () => {
		if (document.visibilityState === "visible") audio.unlock();
		else keys.clear();
	};
	const onResize = () => view.resize();
	window.addEventListener("keydown", onKeyDown);
	window.addEventListener("keyup", onKeyUp);
	window.addEventListener("blur", onBlur);
	canvas.addEventListener("pointerdown", onPointerDown);
	canvas.addEventListener("pointermove", onPointerMove);
	canvas.addEventListener("pointerup", onPointerUp);
	canvas.addEventListener("contextmenu", onContext);
	document.addEventListener("visibilitychange", onVis);
	window.addEventListener("resize", onResize);
	window.__controlsTest = {
		getYaw: () => sim.player().yaw,
		getSpeed: () => sim.player().vel,
		setKeys: (codes) => {
			qaKeys = new Set(codes);
		}
	};
	function gather() {
		const p = sim.player();
		const fx = -Math.sin(camYaw);
		const fz = -Math.cos(camYaw);
		const rx = Math.cos(camYaw);
		const rz = -Math.sin(camYaw);
		let mx = 0;
		let mz = 0;
		if (held("KeyW") || held("ArrowUp")) {
			mx += fx;
			mz += fz;
		}
		if (held("KeyS") || held("ArrowDown")) {
			mx -= fx;
			mz -= fz;
		}
		if (held("KeyD") || held("ArrowRight")) {
			mx += rx;
			mz += rz;
		}
		if (held("KeyA") || held("ArrowLeft")) {
			mx -= rx;
			mz -= rz;
		}
		if (Math.hypot(stickX, stickY) > .18) {
			mx += fx * stickY + rx * stickX;
			mz += fz * stickY + rz * stickX;
		}
		let cast = -1;
		const codes = [
			"KeyQ",
			"KeyE",
			"KeyR",
			"KeyF"
		];
		for (let i = 0; i < 4; i++) {
			const down = held(codes[i] ?? "");
			if (down && !castWas[i]) cast = i;
			castWas[i] = down;
		}
		if (pendingCast >= 0) {
			cast = pendingCast;
			pendingCast = -1;
		}
		if (!pointerSeen) {
			aimX = p.x - Math.sin(p.yaw) * 6;
			aimZ = p.z - Math.cos(p.yaw) * 6;
		}
		const attack = attackHeld || held("Space") || attackPulse;
		attackPulse = false;
		const bDown = held("KeyB");
		if (bDown && !bWas && sim.phase === "play") {
			shopPulse = true;
			hooks.onShop();
		}
		bWas = bDown;
		return {
			wishX: mx,
			wishZ: mz,
			aimX,
			aimZ,
			attack,
			cast
		};
	}
	let hitClock = 0;
	function frame(now) {
		if (!running) return;
		const dt = Math.min(.05, (now - last) / 1e3);
		last = now;
		camYaw += camTurn * 1.7 * dt;
		if (sim.phase === "play") {
			acc += dt;
			let steps = 0;
			while (acc >= 1 / 60 && steps < 4) {
				sim.step(1 / 60, gather());
				acc -= 1 / 60;
				steps++;
			}
			for (const ev of sim.events) if (ev.type === "hit") {
				if (now - hitClock > 80) {
					hitClock = now;
					audio.hit(ev.big);
				}
			} else if (ev.type === "cast" && ev.kind) audio.cast(ev.kind);
			else if (ev.type === "level") audio.level();
			else if (ev.type === "tower") audio.tower();
			else if (ev.type === "announce" && ev.text) hooks.onAnnounce(ev.text);
			else if (ev.type === "kill" && ev.text) hooks.onFeed(ev.text);
			else if (ev.type === "end") {
				audio.end(!!ev.win);
				saveRecord(!!ev.win);
				hooks.onEnd(stats());
			}
			sim.events.length = 0;
		}
		if (sim.phase !== lastPhase) {
			lastPhase = sim.phase;
			hooks.onPhase(sim.phase);
		}
		view.render(sim, dt, camYaw, aimX, aimZ, sim.phase === "play" && pointerSeen);
		paintHud(sim, hud.current);
		paintWorld(sim, view, barPool, floatPool);
		raf = requestAnimationFrame(frame);
	}
	raf = requestAnimationFrame(frame);
	view.resize();
	hooks.onRecord({ ...record });
	hooks.onPhase("menu");
	return {
		start(id) {
			audio.unlock();
			audio.ui();
			sim.start(id);
			camYaw = 0;
			pointerSeen = false;
			view.snap(sim, camYaw);
			lastPhase = "menu";
		},
		preview(id) {
			sim.setPreview(id);
		},
		buy(id) {
			const ok = sim.buy(id);
			if (ok) audio.ui();
			return ok;
		},
		cast(slot) {
			pendingCast = slot;
			audio.unlock();
		},
		setStick(x, y) {
			stickX = x;
			stickY = y;
		},
		setCamTurn(v) {
			camTurn = v;
		},
		setAttackHeld(v) {
			attackHeld = v;
			if (v) audio.unlock();
		},
		togglePause() {
			sim.togglePause();
		},
		toMenu() {
			sim.phase = "menu";
		},
		toggleMute() {
			audio.unlock();
			return audio.toggleMuted();
		},
		openShopRequested: () => shopPulse,
		consumeShopRequest() {
			shopPulse = false;
		},
		stats,
		dispose() {
			running = false;
			cancelAnimationFrame(raf);
			window.removeEventListener("keydown", onKeyDown);
			window.removeEventListener("keyup", onKeyUp);
			window.removeEventListener("blur", onBlur);
			window.removeEventListener("resize", onResize);
			canvas.removeEventListener("pointerdown", onPointerDown);
			canvas.removeEventListener("pointermove", onPointerMove);
			canvas.removeEventListener("pointerup", onPointerUp);
			canvas.removeEventListener("contextmenu", onContext);
			document.removeEventListener("visibilitychange", onVis);
			if (window.__controlsTest) delete window.__controlsTest;
			view.dispose();
			audio.dispose();
			overlay.replaceChildren();
		}
	};
}
function barHtml() {
	return "<div class=\"bf-name\" style=\"font:600 10px Outfit,sans-serif;text-align:center;color:#e7efe6;text-shadow:0 1px 2px #101612;white-space:nowrap\"></div><div style=\"height:5px;background:#101612cc;border-radius:99px;overflow:hidden\"><div class=\"bf-fill\" style=\"height:100%;width:100%;transform-origin:left;background:#e4b15a\"></div></div>";
}
function makePool(overlay, n, html) {
	const pool = [];
	for (let i = 0; i < n; i++) {
		const el = document.createElement("div");
		el.style.cssText = "position:absolute;left:0;top:0;width:74px;transform:translate(-50%,-120%);pointer-events:none;display:none;font:700 13px Outfit,sans-serif;text-shadow:0 1px 2px #101612";
		if (html) el.innerHTML = html;
		overlay.appendChild(el);
		pool.push(el);
	}
	return pool;
}
function paintHud(sim, h) {
	const p = sim.player();
	const play = sim.phase === "play" || sim.phase === "pause";
	if (!play && sim.phase !== "victory" && sim.phase !== "defeat") return;
	if (h.hp) h.hp.style.transform = `scaleX(${Math.max(0, p.hp / Math.max(1, p.maxHp))})`;
	if (h.hpText) h.hpText.textContent = `${Math.ceil(Math.max(0, p.hp))} / ${Math.ceil(p.maxHp)}`;
	if (h.mp) h.mp.style.transform = `scaleX(${p.maxMana ? Math.max(0, p.mana / p.maxMana) : 0})`;
	if (h.mpText) h.mpText.textContent = `${Math.ceil(Math.max(0, p.mana))} / ${Math.ceil(p.maxMana)}`;
	if (h.gold) h.gold.textContent = `${Math.floor(p.gold)}`;
	if (h.shopGold) h.shopGold.textContent = `${Math.floor(p.gold)} gold`;
	if (h.level) h.level.textContent = `${p.level}`;
	if (h.name) h.name.textContent = p.name;
	if (h.timer) h.timer.textContent = fmt(sim.time);
	if (h.kda) h.kda.textContent = `${p.kills} / ${p.deaths} / ${p.assists}`;
	if (h.cs) h.cs.textContent = `${p.cs} cs`;
	if (h.dawn) h.dawn.textContent = `${sim.dawnKills}`;
	if (h.dusk) h.dusk.textContent = `${sim.duskKills}`;
	const duskTowers = sim.towersUp(1);
	if (h.objective) h.objective.textContent = duskTowers > 0 ? `Dusk towers ${duskTowers}` : "Conduit exposed";
	const near = sim.nearFountain();
	if (h.fountain) h.fountain.textContent = near ? "Fountain — press B to equip" : "Roam the rift. Siege the lanes.";
	if (h.shopNote) h.shopNote.textContent = near ? "Dawn fountain is open" : "Return to the Dawn fountain to buy";
	const buffs = [];
	if (p.shield > 1) buffs.push("Shield");
	if (p.hasteT > 0) buffs.push("Gale");
	if (p.lifestealT > 0) buffs.push("Blood");
	if (p.teamBuffT > 0) buffs.push("Colossus");
	if (p.slowT > 0) buffs.push("Slowed");
	if (h.buff) h.buff.textContent = buffs.join(" · ");
	if (h.respawn) {
		h.respawn.style.display = play && !p.alive ? "flex" : "none";
		const label = h.respawn.querySelector("strong");
		if (label) label.textContent = `${Math.ceil(Math.max(0, p.respawn))}`;
	}
	const abs = CHAMPS[p.champ ?? "vanguard"].abilities;
	for (let i = 0; i < 4; i++) {
		const cd = p.cds[i] ?? 0;
		const max = abs[i]?.cd ?? 1;
		const shade = h.shades[i];
		const label = h.cds[i];
		if (shade) shade.style.transform = `scaleY(${cd > 0 ? Math.min(1, cd / max) : 0})`;
		if (label) label.textContent = cd > .05 ? cd.toFixed(1) : "";
	}
	for (let i = 0; i < 4; i++) {
		const el = h.counts[i];
		if (el) el.textContent = `${p.itemCounts[i] ?? 0}/3`;
	}
	drawMinimap(h.minimap, sim);
}
function drawMinimap(canvasMap, sim) {
	if (!canvasMap) return;
	const ctx = canvasMap.getContext("2d");
	if (!ctx) return;
	const S = canvasMap.width;
	ctx.clearRect(0, 0, S, S);
	ctx.fillStyle = "#15211c";
	ctx.fillRect(0, 0, S, S);
	ctx.strokeStyle = "#2a6d82";
	ctx.lineWidth = 3;
	ctx.beginPath();
	for (let z = -90; z <= 90; z += 8) {
		const px = (Math.sin(z * .045) * 16 + 100) / 200 * S;
		const py = (z + 100) / 200 * S;
		if (z === -90) ctx.moveTo(px, py);
		else ctx.lineTo(px, py);
	}
	ctx.stroke();
	for (const e of sim.ents) {
		if (!e.alive) continue;
		const x = (e.x + 100) / 200 * S;
		const y = (e.z + 100) / 200 * S;
		ctx.fillStyle = e.team === 0 ? "#e4b15a" : e.team === 1 ? "#d4524a" : "#c6b48a";
		if (e.kind === "minion") ctx.fillRect(x - 1, y - 1, 2, 2);
		else if (e.kind === "tower" || e.kind === "nexus") ctx.fillRect(x - 3, y - 3, 6, 6);
		else if (e.player) {
			ctx.beginPath();
			ctx.arc(x, y, 4.5, 0, Math.PI * 2);
			ctx.fill();
			ctx.strokeStyle = "#e7efe6";
			ctx.lineWidth = 1.5;
			ctx.stroke();
		} else {
			ctx.beginPath();
			ctx.arc(x, y, e.kind === "boss" ? 4 : 3, 0, Math.PI * 2);
			ctx.fill();
		}
	}
}
function paintWorld(sim, view, barPool, floatPool) {
	const p = sim.player();
	let bi = 0;
	for (const e of sim.ents) {
		const el = barPool[bi];
		if (!el) break;
		if (!(e.alive && sim.phase !== "menu" && (e.kind === "hero" || e.kind === "tower" || e.kind === "nexus" || e.kind === "boss" || e.hp < e.maxHp && Math.hypot(e.x - p.x, e.z - p.z) < 20))) continue;
		const lift = e.kind === "tower" || e.kind === "nexus" ? 6.3 : e.kind === "boss" ? 3.3 : 2.4;
		const pt = view.project(e.x, groundY(e.x, e.z) + lift, e.z);
		if (!pt.visible) continue;
		el.style.display = "block";
		el.style.left = `${pt.x}px`;
		el.style.top = `${pt.y}px`;
		const name = el.querySelector(".bf-name");
		const fill = el.querySelector(".bf-fill");
		if (name) name.textContent = e.player ? "" : e.name;
		if (fill) {
			fill.style.transform = `scaleX(${Math.max(.04, e.hp / Math.max(1, e.maxHp))})`;
			fill.style.background = e.team === 0 ? "#e4b15a" : e.team === 1 ? "#d4524a" : "#c6b48a";
		}
		bi++;
	}
	for (let i = bi; i < barPool.length; i++) {
		const el = barPool[i];
		if (el) el.style.display = "none";
	}
	let fi = 0;
	for (const f of sim.floats) {
		const el = floatPool[fi];
		if (!el || !f.alive || sim.phase === "menu") continue;
		const pt = view.project(f.x, groundY(f.x, f.z) + f.y, f.z);
		if (!pt.visible) continue;
		el.style.display = "block";
		el.style.left = `${pt.x}px`;
		el.style.top = `${pt.y}px`;
		el.style.color = f.color;
		el.style.opacity = String(Math.min(1, f.life * 1.5));
		el.textContent = f.text;
		fi++;
	}
	for (let i = fi; i < floatPool.length; i++) {
		const el = floatPool[i];
		if (el) el.style.display = "none";
	}
}
var SWATCH = {
	vanguard: "bg-primary text-primary-fg",
	arcanist: "bg-mana text-bg",
	ranger: "bg-ranger text-bg"
};
var ICONS = {
	vanguard: Swords,
	arcanist: Sparkles,
	ranger: Crosshair
};
var ITEM_ICONS = [
	Swords,
	Heart,
	Gem,
	Footprints
];
function emptyHud() {
	return {
		hp: null,
		hpText: null,
		mp: null,
		mpText: null,
		gold: null,
		level: null,
		name: null,
		timer: null,
		kda: null,
		cs: null,
		dawn: null,
		dusk: null,
		objective: null,
		fountain: null,
		buff: null,
		respawn: null,
		shopGold: null,
		shopNote: null,
		cds: [
			null,
			null,
			null,
			null
		],
		shades: [
			null,
			null,
			null,
			null
		],
		counts: [
			null,
			null,
			null,
			null
		],
		minimap: null
	};
}
function RiftApp() {
	const canvasRef = (0, import_react.useRef)(null);
	const overlayRef = (0, import_react.useRef)(null);
	const hud = (0, import_react.useRef)(emptyHud());
	const gameRef = (0, import_react.useRef)(null);
	const [phase, setPhase] = (0, import_react.useState)("menu");
	const [champ, setChamp] = (0, import_react.useState)("vanguard");
	const [shop, setShop] = (0, import_react.useState)(false);
	const [muted, setMuted] = (0, import_react.useState)(false);
	const [banner, setBanner] = (0, import_react.useState)("Three lanes cut a wild rift. Break the far conduit.");
	const [feed, setFeed] = (0, import_react.useState)([]);
	const [record, setRecord] = (0, import_react.useState)({
		wins: 0,
		bestKills: 0,
		bestCs: 0
	});
	const [end, setEnd] = (0, import_react.useState)(null);
	const champRef = (0, import_react.useRef)(champ);
	champRef.current = champ;
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const overlay = overlayRef.current;
		if (!canvas || !overlay) return;
		const game = createGame(canvas, overlay, hud, {
			onPhase: (next) => {
				setPhase(next);
				if (next === "menu") setShop(false);
			},
			onAnnounce: (text) => {
				if (!text) return;
				setBanner(text);
			},
			onFeed: (text) => {
				setFeed((prev) => [text, ...prev].slice(0, 4));
			},
			onRecord: setRecord,
			onEnd: setEnd,
			onShop: () => setShop((open) => !open)
		});
		gameRef.current = game;
		return () => {
			game.dispose();
			gameRef.current = null;
		};
	}, []);
	const def = CHAMPS[champ];
	const playing = phase === "play" || phase === "pause";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh w-full overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "absolute inset-0 h-full w-full touch-none",
				"aria-label": "Aetherfall battlefield"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: overlayRef,
				className: "pointer-events-none absolute inset-0 overflow-hidden"
			}),
			phase === "menu" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 flex items-end justify-center p-3 md:items-stretch md:justify-start md:p-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "pointer-events-auto flex max-h-[82%] w-full flex-col gap-4 overflow-y-auto rounded-2xl border border-border bg-surface/92 p-4 shadow-lg backdrop-blur-md md:max-h-none md:w-[26rem] md:p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold tracking-widest text-primary uppercase",
								children: "Open-world rift"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display mt-1 text-4xl text-fg",
								children: "Aetherfall"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: "A living battlefield: three siege lanes, jungle shrines, and a colossus in the wild. Every champion wears the same rift-born form — walk, run, leap, crouch, and fall — with a different kit. Score: Light Beyond the Veil."
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-2",
							children: CHAMP_ORDER.map((id) => {
								const c = CHAMPS[id];
								const Icon = ICONS[id];
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										setChamp(id);
										gameRef.current?.preview(id);
									},
									className: `flex items-center gap-3 rounded-xl border px-3 py-3 text-left ${id === champ ? "border-primary bg-surface-2" : "border-border bg-bg/40"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `flex h-11 w-11 items-center justify-center rounded-lg ${SWATCH[id]}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
											className: "size-5",
											"aria-hidden": true
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block font-display text-lg leading-tight",
											children: c.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "block text-xs text-muted",
											children: [
												c.title,
												" · ",
												c.role
											]
										})]
									})]
								}, id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-fg",
							children: def.blurb
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "grid grid-cols-2 gap-2 text-xs text-muted",
							children: def.abilities.map((ab) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-lg border border-border bg-bg/50 px-2 py-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold text-primary",
										children: ab.key
									}),
									" ",
									ab.name
								]
							}, ab.key))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setFeed([]);
								setEnd(null);
								setShop(false);
								gameRef.current?.start(champRef.current);
							},
							className: "min-h-12 rounded-xl bg-primary px-4 py-3 font-display text-lg text-primary-fg",
							children: "Start Battle"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs leading-relaxed text-muted",
							children: "WASD moves. Drag to orbit the camera. Click or Space strikes. Q E R F cast toward the cursor. B opens the fountain shop. On a phone, use the stick and buttons."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								"Victories ",
								record.wins,
								" · best kills ",
								record.bestKills,
								" · best farm ",
								record.bestCs
							]
						})
					]
				})
			}),
			playing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-2 p-3 md:p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pointer-events-auto rounded-xl border border-border bg-surface/85 px-3 py-2 backdrop-blur-md",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-widest text-primary uppercase",
								children: "Dawn"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								ref: (el) => {
									hud.current.dawn = el;
								},
								className: "font-display text-2xl leading-none",
								children: "0"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pointer-events-none max-w-xs text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									ref: (el) => {
										hud.current.timer = el;
									},
									className: "font-display text-lg",
									children: "0:00"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									ref: (el) => {
										hud.current.objective = el;
									},
									className: "text-xs text-muted",
									children: "Dusk towers"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 hidden text-sm text-fg md:block",
									children: banner
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pointer-events-auto rounded-xl border border-border bg-surface/85 px-3 py-2 text-right backdrop-blur-md",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs tracking-widest text-accent uppercase",
									children: "Dusk"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									ref: (el) => {
										hud.current.dusk = el;
									},
									className: "font-display text-2xl leading-none",
									children: "0"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "pointer-events-auto flex h-11 w-11 items-center justify-center rounded-xl border border-border bg-surface/85 text-fg",
								"aria-label": muted ? "Unmute" : "Mute",
								onClick: () => {
									const next = gameRef.current?.toggleMute() ?? false;
									setMuted(next);
								},
								children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5" })
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
					ref: (el) => {
						hud.current.minimap = el;
					},
					width: 168,
					height: 168,
					className: "pointer-events-none absolute top-28 left-3 h-24 w-24 rounded-xl border border-border bg-surface md:top-24 md:left-auto md:right-3 md:h-40 md:w-40",
					"aria-hidden": true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "pointer-events-none absolute top-36 left-3 hidden max-w-xs flex-col gap-1 md:flex",
					children: feed.map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-md bg-surface/80 px-2 py-1 text-xs text-fg",
						children: line
					}, `${line}-${i}`))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					ref: (el) => {
						hud.current.respawn = el;
					},
					className: "pointer-events-none absolute inset-x-0 top-1/3 hidden items-center justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-xl border border-border bg-surface/90 px-5 py-4 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm text-muted",
							children: "Slain. Returning in"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "font-display text-4xl text-primary",
							children: "5"
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
					className: "pointer-events-none absolute inset-x-0 bottom-0 z-10 p-3 md:p-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end gap-3 md:flex-col md:items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pointer-events-auto flex shrink-0 flex-col gap-2 md:hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stick, { onChange: (x, y) => gameRef.current?.setStick(x, y) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CamButton, {
									label: "Orbit left",
									onHold: (v) => gameRef.current?.setCamTurn(v ? -1 : 0)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CamButton, {
									label: "Orbit right",
									onHold: (v) => gameRef.current?.setCamTurn(v ? 1 : 0),
									flip: true
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pointer-events-auto flex min-w-0 flex-1 flex-col gap-2 md:w-full md:max-w-lg md:items-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									ref: (el) => {
										hud.current.buff = el;
									},
									className: "h-4 text-right text-xs text-primary md:text-center"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "w-full rounded-2xl border border-border bg-surface/88 px-3 py-2 backdrop-blur-md",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mb-1 flex items-baseline justify-between gap-2 text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "truncate",
												children: [
													"Lv ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														ref: (el) => {
															hud.current.level = el;
														},
														children: "1"
													}),
													" ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														ref: (el) => {
															hud.current.name = el;
														},
														className: "font-display text-sm text-fg",
														children: "Kael"
													})
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "shrink-0 text-muted",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														ref: (el) => {
															hud.current.kda = el;
														},
														children: "0 / 0 / 0"
													}),
													" · ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														ref: (el) => {
															hud.current.cs = el;
														},
														children: "0 cs"
													})
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-4 overflow-hidden rounded-full bg-bg",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												ref: (el) => {
													hud.current.hp = el;
												},
												className: "h-full w-full origin-left bg-accent"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-1 flex justify-between gap-2 text-xs text-muted",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												ref: (el) => {
													hud.current.hpText = el;
												},
												className: "shrink-0",
												children: "0 / 0"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												ref: (el) => {
													hud.current.fountain = el;
												},
												className: "truncate",
												children: "Roam the rift."
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-1 h-3 overflow-hidden rounded-full bg-bg",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												ref: (el) => {
													hud.current.mp = el;
												},
												className: "h-full w-full origin-left bg-mana"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-1 flex items-center justify-between gap-2 text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												ref: (el) => {
													hud.current.mpText = el;
												},
												className: "text-muted",
												children: "0 / 0"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "rounded-full border border-border bg-bg/70 px-2 py-1 text-primary",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														ref: (el) => {
															hud.current.gold = el;
														},
														children: "500"
													}), " g"]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => setShop((open) => !open),
													className: "min-h-11 rounded-full border border-border bg-surface px-3 py-2 text-fg",
													children: "Shop"
												})]
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 justify-items-end gap-2 md:flex md:justify-center",
									children: [def.abilities.map((ab, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										title: `${ab.name}: ${ab.blurb}`,
										onClick: () => gameRef.current?.cast(i),
										className: "relative h-11 w-11 overflow-hidden rounded-xl border border-border bg-surface-2 text-fg md:h-16 md:w-16",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-display text-lg leading-none",
												children: ab.key
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "hidden truncate px-1 text-xs text-muted md:block",
												children: ab.name.split(" ")[0]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												ref: (el) => {
													hud.current.shades[i] = el;
												},
												className: "absolute inset-0 origin-bottom bg-bg/75",
												style: { transform: "scaleY(0)" }
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												ref: (el) => {
													hud.current.cds[i] = el;
												},
												className: "absolute inset-0 flex items-center justify-center text-xs font-semibold"
											})
										]
									}, ab.key)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "flex h-11 w-11 flex-col items-center justify-center rounded-xl bg-primary text-primary-fg md:hidden",
										onPointerDown: () => gameRef.current?.setAttackHeld(true),
										onPointerUp: () => gameRef.current?.setAttackHeld(false),
										onPointerLeave: () => gameRef.current?.setAttackHeld(false),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swords, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs",
											children: "Hit"
										})]
									})]
								})
							]
						})]
					})
				}),
				shop && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-3 top-20 z-20 mx-auto max-w-lg rounded-2xl border border-border bg-surface p-4 shadow-lg md:inset-x-auto md:top-auto md:right-6 md:bottom-6 md:w-96",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl",
							children: "Quartermaster"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							ref: (el) => {
								hud.current.shopNote = el;
							},
							className: "text-xs text-muted",
							children: "Fountain"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								ref: (el) => {
									hud.current.shopGold = el;
								},
								className: "text-sm text-primary",
								children: "500 gold"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-xs text-muted",
								onClick: () => setShop(false),
								children: "Close"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-2",
						children: ITEMS.map((item, i) => {
							const Icon = ITEM_ICONS[i] ?? Swords;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => gameRef.current?.buy(item.id),
								className: "flex min-h-12 w-full items-center gap-3 rounded-xl border border-border bg-bg/40 px-3 py-2 text-left",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										className: "size-5 text-primary",
										"aria-hidden": true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-sm",
											children: item.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-xs text-muted",
											children: item.blurb
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-right text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "block text-primary",
											children: [item.cost, "g"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											ref: (el) => {
												hud.current.counts[i] = el;
											},
											className: "text-muted",
											children: "0/3"
										})]
									})
								]
							}) }, item.id);
						})
					})]
				})
			] }),
			phase === "pause" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 flex items-center justify-center bg-bg/55 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-sm rounded-2xl border border-border bg-surface p-6 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl",
							children: "Hold"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "The rift waits."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-4 min-h-12 w-full rounded-xl bg-primary text-primary-fg",
							onClick: () => gameRef.current?.togglePause(),
							children: "Resume"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-2 min-h-12 w-full rounded-xl border border-border",
							onClick: () => gameRef.current?.toMenu(),
							children: "Leave the rift"
						})
					]
				})
			}),
			(phase === "victory" || phase === "defeat") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 flex items-center justify-center bg-bg/60 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-sm rounded-2xl border border-border bg-surface p-6 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-primary uppercase",
							children: phase === "victory" ? "Dawn holds" : "Dusk holds"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display mt-1 text-4xl",
							children: phase === "victory" ? "Victory" : "Defeat"
						}),
						end && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm text-muted",
							children: [
								end.name,
								" · level ",
								end.level,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								end.kills,
								" / ",
								end.deaths,
								" / ",
								end.assists,
								" · ",
								end.cs,
								" farm · ",
								end.gold,
								" gold"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-5 min-h-12 w-full rounded-xl bg-primary font-display text-lg text-primary-fg",
							onClick: () => {
								setEnd(null);
								gameRef.current?.start(champRef.current);
							},
							children: "Rematch"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-2 min-h-12 w-full rounded-xl border border-border",
							onClick: () => gameRef.current?.toMenu(),
							children: "Choose another champion"
						})
					]
				})
			})
		]
	});
}
function Stick({ onChange }) {
	const ref = (0, import_react.useRef)(null);
	const knob = (0, import_react.useRef)({
		x: 0,
		y: 0
	});
	const [pos, setPos] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	function apply(clientX, clientY) {
		const el = ref.current;
		if (!el) return;
		const r = el.getBoundingClientRect();
		const max = r.width * .34;
		let dx = clientX - (r.left + r.width / 2);
		let dy = clientY - (r.top + r.height / 2);
		const len = Math.hypot(dx, dy) || 1;
		if (len > max) {
			dx = dx / len * max;
			dy = dy / len * max;
		}
		knob.current = {
			x: dx,
			y: dy
		};
		setPos({
			x: dx,
			y: dy
		});
		onChange(dx / max, -dy / max);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: "relative h-24 w-24 touch-none rounded-full border border-border bg-surface/80",
		onPointerDown: (e) => {
			e.currentTarget.setPointerCapture(e.pointerId);
			apply(e.clientX, e.clientY);
		},
		onPointerMove: (e) => {
			if (e.currentTarget.hasPointerCapture(e.pointerId)) apply(e.clientX, e.clientY);
		},
		onPointerUp: (e) => {
			if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
			knob.current = {
				x: 0,
				y: 0
			};
			setPos({
				x: 0,
				y: 0
			});
			onChange(0, 0);
		},
		"aria-label": "Move",
		role: "application",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute h-11 w-11 rounded-full bg-primary",
			style: {
				left: `calc(50% - 1.375rem + ${pos.x}px)`,
				top: `calc(50% - 1.375rem + ${pos.y}px)`
			}
		})
	});
}
function CamButton({ label, onHold, flip }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		className: "h-11 min-w-11 rounded-xl border border-border bg-surface/90 px-3 text-sm text-fg",
		onPointerDown: () => onHold(true),
		onPointerUp: () => onHold(false),
		onPointerLeave: () => onHold(false),
		children: flip ? "Right" : "Left"
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RiftApp, {});
}
//#endregion
export { Home as component };
