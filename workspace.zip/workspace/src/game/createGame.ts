import * as THREE from "three";
import { CHAMPS, type ChampId, type ItemId } from "@/game/content";
import { createAudio } from "@/game/audio";
import { createSim, type InputState, type Phase, type Sim } from "@/game/sim";
import { createWorld } from "@/game/render";
import { groundY } from "@/game/terrain";

export interface HudEls {
  hp: HTMLDivElement | null;
  hpText: HTMLElement | null;
  mp: HTMLDivElement | null;
  mpText: HTMLElement | null;
  gold: HTMLElement | null;
  level: HTMLElement | null;
  name: HTMLElement | null;
  timer: HTMLElement | null;
  kda: HTMLElement | null;
  cs: HTMLElement | null;
  dawn: HTMLElement | null;
  dusk: HTMLElement | null;
  objective: HTMLElement | null;
  fountain: HTMLElement | null;
  buff: HTMLElement | null;
  respawn: HTMLElement | null;
  shopGold: HTMLElement | null;
  shopNote: HTMLElement | null;
  cds: (HTMLElement | null)[];
  shades: (HTMLElement | null)[];
  counts: (HTMLElement | null)[];
  minimap: HTMLCanvasElement | null;
}

export interface EndStats {
  win: boolean;
  name: string;
  kills: number;
  deaths: number;
  assists: number;
  cs: number;
  gold: number;
  level: number;
  time: number;
}

export interface RecordStats {
  wins: number;
  bestKills: number;
  bestCs: number;
}

const SAVE_KEY = "aetherfall-record-v1";

export interface GameHandle {
  start: (id: ChampId) => void;
  preview: (id: ChampId) => void;
  buy: (id: ItemId) => boolean;
  cast: (slot: number) => void;
  setStick: (x: number, y: number) => void;
  setCamTurn: (v: number) => void;
  setAttackHeld: (held: boolean) => void;
  togglePause: () => void;
  toMenu: () => void;
  toggleMute: () => boolean;
  openShopRequested: () => boolean;
  consumeShopRequest: () => void;
  stats: () => EndStats;
  dispose: () => void;
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys?: (codes: string[]) => void;
    };
  }
}

function loadRecord(): RecordStats {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return { wins: 0, bestKills: 0, bestCs: 0 };
    const parsed = JSON.parse(raw) as Partial<RecordStats>;
    return {
      wins: Number(parsed.wins) || 0,
      bestKills: Number(parsed.bestKills) || 0,
      bestCs: Number(parsed.bestCs) || 0,
    };
  } catch {
    return { wins: 0, bestKills: 0, bestCs: 0 };
  }
}

function fmt(t: number) {
  const s = Math.max(0, Math.floor(t));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

export function createGame(
  canvas: HTMLCanvasElement,
  overlay: HTMLElement,
  hud: { current: HudEls },
  hooks: {
    onPhase: (phase: Phase) => void;
    onAnnounce: (text: string) => void;
    onFeed: (text: string) => void;
    onRecord: (record: RecordStats) => void;
    onEnd: (stats: EndStats) => void;
    onShop: () => void;
  },
): GameHandle {
  const audio = createAudio();
  const sim = createSim();
  const view = createWorld(canvas);
  const keys = new Set<string>();
  let qaKeys: Set<string> | null = null;
  let camYaw = 0;
  let stickX = 0;
  let stickY = 0;
  let camTurn = 0;
  let attackHeld = false;
  let attackPulse = false;
  let pendingCast = -1;
  const castWas = [false, false, false, false];
  let aimX = 0;
  let aimZ = 50;
  let pointerSeen = false;
  let shopPulse = false;
  let bWas = false;
  let last = performance.now();
  let acc = 0;
  let raf = 0;
  let running = true;
  let lastPhase: Phase = "menu";
  const record = loadRecord();

  const raycaster = new THREE.Raycaster();
  const pointer = new THREE.Vector2();
  const plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -0.2);
  const hit = new THREE.Vector3();

  const barPool = makePool(overlay, 22, barHtml());
  const floatPool = makePool(overlay, 16, "");

  function held(code: string) {
    return (qaKeys ?? keys).has(code);
  }

  function setAim(clientX: number, clientY: number) {
    const rect = canvas.getBoundingClientRect();
    if (rect.width < 1 || rect.height < 1) return;
    pointer.set(((clientX - rect.left) / rect.width) * 2 - 1, -((clientY - rect.top) / rect.height) * 2 + 1);
    raycaster.setFromCamera(pointer, view.camera);
    if (raycaster.ray.intersectPlane(plane, hit)) {
      aimX = hit.x;
      aimZ = hit.z;
    }
  }

  function stats(): EndStats {
    const p = sim.player();
    return {
      win: sim.phase === "victory",
      name: p.name,
      kills: p.kills,
      deaths: p.deaths,
      assists: p.assists,
      cs: p.cs,
      gold: Math.floor(p.gold),
      level: p.level,
      time: sim.time,
    };
  }

  function saveRecord(win: boolean) {
    const p = sim.player();
    if (win) record.wins += 1;
    record.bestKills = Math.max(record.bestKills, p.kills);
    record.bestCs = Math.max(record.bestCs, p.cs);
    localStorage.setItem(SAVE_KEY, JSON.stringify(record));
    hooks.onRecord({ ...record });
  }

  let dragging = false;
  let moved = false;
  let downX = 0;
  let downY = 0;

  const onKeyDown = (e: KeyboardEvent) => {
    if (e.code === "Space" || e.code.startsWith("Arrow")) e.preventDefault();
    keys.add(e.code);
    if (e.code === "Escape") sim.togglePause();
  };
  const onKeyUp = (e: KeyboardEvent) => keys.delete(e.code);
  const onBlur = () => {
    keys.clear();
    attackHeld = false;
    camTurn = 0;
    stickX = 0;
    stickY = 0;
  };
  const onPointerDown = (e: PointerEvent) => {
    audio.unlock();
    if (e.button !== 0 && e.button !== 2) return;
    dragging = true;
    moved = false;
    downX = e.clientX;
    downY = e.clientY;
    canvas.setPointerCapture(e.pointerId);
  };
  const onPointerMove = (e: PointerEvent) => {
    pointerSeen = true;
    setAim(e.clientX, e.clientY);
    if (!dragging) return;
    if ((e.clientX - downX) ** 2 + (e.clientY - downY) ** 2 > 20) moved = true;
    camYaw -= e.movementX * 0.005;
  };
  const onPointerUp = (e: PointerEvent) => {
    if (!moved && e.button === 0 && sim.phase === "play") {
      pointerSeen = true;
      setAim(e.clientX, e.clientY);
      attackPulse = true;
    }
    dragging = false;
  };
  const onContext = (e: Event) => e.preventDefault();
  const onVis = () => {
    if (document.visibilityState === "visible") audio.unlock();
    else keys.clear();
  };
  const onResize = () => view.resize();

  window.addEventListener("keydown", onKeyDown);
  window.addEventListener("keyup", onKeyUp);
  window.addEventListener("blur", onBlur);
  canvas.addEventListener("pointerdown", onPointerDown);
  canvas.addEventListener("pointermove", onPointerMove);
  canvas.addEventListener("pointerup", onPointerUp);
  canvas.addEventListener("contextmenu", onContext);
  document.addEventListener("visibilitychange", onVis);
  window.addEventListener("resize", onResize);

  window.__controlsTest = {
    getYaw: () => sim.player().yaw,
    getSpeed: () => sim.player().vel,
    setKeys: (codes: string[]) => {
      qaKeys = new Set(codes);
    },
  };

  function gather(): InputState {
    const p = sim.player();
    const fx = -Math.sin(camYaw);
    const fz = -Math.cos(camYaw);
    const rx = Math.cos(camYaw);
    const rz = -Math.sin(camYaw);
    let mx = 0;
    let mz = 0;
    if (held("KeyW") || held("ArrowUp")) {
      mx += fx;
      mz += fz;
    }
    if (held("KeyS") || held("ArrowDown")) {
      mx -= fx;
      mz -= fz;
    }
    if (held("KeyD") || held("ArrowRight")) {
      mx += rx;
      mz += rz;
    }
    if (held("KeyA") || held("ArrowLeft")) {
      mx -= rx;
      mz -= rz;
    }
    if (Math.hypot(stickX, stickY) > 0.18) {
      mx += fx * stickY + rx * stickX;
      mz += fz * stickY + rz * stickX;
    }
    let cast = -1;
    const codes = ["KeyQ", "KeyE", "KeyR", "KeyF"];
    for (let i = 0; i < 4; i++) {
      const down = held(codes[i] ?? "");
      if (down && !castWas[i]) cast = i;
      castWas[i] = down;
    }
    if (pendingCast >= 0) {
      cast = pendingCast;
      pendingCast = -1;
    }
    if (!pointerSeen) {
      aimX = p.x - Math.sin(p.yaw) * 6;
      aimZ = p.z - Math.cos(p.yaw) * 6;
    }
    const attack = attackHeld || held("Space") || attackPulse;
    attackPulse = false;
    const bDown = held("KeyB");
    if (bDown && !bWas && sim.phase === "play") {
      shopPulse = true;
      hooks.onShop();
    }
    bWas = bDown;
    return { wishX: mx, wishZ: mz, aimX, aimZ, attack, cast };
  }

  let hitClock = 0;
  function frame(now: number) {
    if (!running) return;
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    camYaw += camTurn * 1.7 * dt;
    if (sim.phase === "play") {
      acc += dt;
      let steps = 0;
      while (acc >= 1 / 60 && steps < 4) {
        sim.step(1 / 60, gather());
        acc -= 1 / 60;
        steps++;
      }
      for (const ev of sim.events) {
        if (ev.type === "hit") {
          if (now - hitClock > 80) {
            hitClock = now;
            audio.hit(ev.big);
          }
        } else if (ev.type === "cast" && ev.kind) audio.cast(ev.kind);
        else if (ev.type === "level") audio.level();
        else if (ev.type === "tower") audio.tower();
        else if (ev.type === "announce" && ev.text) hooks.onAnnounce(ev.text);
        else if (ev.type === "kill" && ev.text) hooks.onFeed(ev.text);
        else if (ev.type === "end") {
          audio.end(!!ev.win);
          saveRecord(!!ev.win);
          hooks.onEnd(stats());
        }
      }
      sim.events.length = 0;
    }
    if (sim.phase !== lastPhase) {
      lastPhase = sim.phase;
      hooks.onPhase(sim.phase);
    }
    view.render(sim, dt, camYaw, aimX, aimZ, sim.phase === "play" && pointerSeen);
    paintHud(sim, hud.current);
    paintWorld(sim, view, barPool, floatPool);
    raf = requestAnimationFrame(frame);
  }

  raf = requestAnimationFrame(frame);
  view.resize();
  hooks.onRecord({ ...record });
  hooks.onPhase("menu");

  return {
    start(id) {
      audio.unlock();
      audio.ui();
      sim.start(id);
      camYaw = 0;
      pointerSeen = false;
      view.snap(sim, camYaw);
      lastPhase = "menu";
    },
    preview(id) {
      sim.setPreview(id);
    },
    buy(id) {
      const ok = sim.buy(id);
      if (ok) audio.ui();
      return ok;
    },
    cast(slot) {
      pendingCast = slot;
      audio.unlock();
    },
    setStick(x, y) {
      stickX = x;
      stickY = y;
    },
    setCamTurn(v) {
      camTurn = v;
    },
    setAttackHeld(v) {
      attackHeld = v;
      if (v) audio.unlock();
    },
    togglePause() {
      sim.togglePause();
    },
    toMenu() {
      sim.phase = "menu";
    },
    toggleMute() {
      audio.unlock();
      return audio.toggleMuted();
    },
    openShopRequested: () => shopPulse,
    consumeShopRequest() {
      shopPulse = false;
    },
    stats,
    dispose() {
      running = false;
      cancelAnimationFrame(raf);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", onBlur);
      window.removeEventListener("resize", onResize);
      canvas.removeEventListener("pointerdown", onPointerDown);
      canvas.removeEventListener("pointermove", onPointerMove);
      canvas.removeEventListener("pointerup", onPointerUp);
      canvas.removeEventListener("contextmenu", onContext);
      document.removeEventListener("visibilitychange", onVis);
      if (window.__controlsTest) delete window.__controlsTest;
      view.dispose();
      audio.dispose();
      overlay.replaceChildren();
    },
  };
}

function barHtml() {
  return '<div class="bf-name" style="font:600 10px Outfit,sans-serif;text-align:center;color:#e7efe6;text-shadow:0 1px 2px #101612;white-space:nowrap"></div><div style="height:5px;background:#101612cc;border-radius:99px;overflow:hidden"><div class="bf-fill" style="height:100%;width:100%;transform-origin:left;background:#e4b15a"></div></div>';
}

function makePool(overlay: HTMLElement, n: number, html: string) {
  const pool: HTMLDivElement[] = [];
  for (let i = 0; i < n; i++) {
    const el = document.createElement("div");
    el.style.cssText =
      "position:absolute;left:0;top:0;width:74px;transform:translate(-50%,-120%);pointer-events:none;display:none;font:700 13px Outfit,sans-serif;text-shadow:0 1px 2px #101612";
    if (html) el.innerHTML = html;
    overlay.appendChild(el);
    pool.push(el);
  }
  return pool;
}

function paintHud(sim: Sim, h: HudEls) {
  const p = sim.player();
  const play = sim.phase === "play" || sim.phase === "pause";
  if (!play && sim.phase !== "victory" && sim.phase !== "defeat") return;
  if (h.hp) h.hp.style.transform = `scaleX(${Math.max(0, p.hp / Math.max(1, p.maxHp))})`;
  if (h.hpText) h.hpText.textContent = `${Math.ceil(Math.max(0, p.hp))} / ${Math.ceil(p.maxHp)}`;
  if (h.mp) h.mp.style.transform = `scaleX(${p.maxMana ? Math.max(0, p.mana / p.maxMana) : 0})`;
  if (h.mpText) h.mpText.textContent = `${Math.ceil(Math.max(0, p.mana))} / ${Math.ceil(p.maxMana)}`;
  if (h.gold) h.gold.textContent = `${Math.floor(p.gold)}`;
  if (h.shopGold) h.shopGold.textContent = `${Math.floor(p.gold)} gold`;
  if (h.level) h.level.textContent = `${p.level}`;
  if (h.name) h.name.textContent = p.name;
  if (h.timer) h.timer.textContent = fmt(sim.time);
  if (h.kda) h.kda.textContent = `${p.kills} / ${p.deaths} / ${p.assists}`;
  if (h.cs) h.cs.textContent = `${p.cs} cs`;
  if (h.dawn) h.dawn.textContent = `${sim.dawnKills}`;
  if (h.dusk) h.dusk.textContent = `${sim.duskKills}`;
  const duskTowers = sim.towersUp(1);
  if (h.objective) h.objective.textContent = duskTowers > 0 ? `Dusk towers ${duskTowers}` : "Conduit exposed";
  const near = sim.nearFountain();
  if (h.fountain) h.fountain.textContent = near ? "Fountain — press B to equip" : "Roam the rift. Siege the lanes.";
  if (h.shopNote) h.shopNote.textContent = near ? "Dawn fountain is open" : "Return to the Dawn fountain to buy";
  const buffs: string[] = [];
  if (p.shield > 1) buffs.push("Shield");
  if (p.hasteT > 0) buffs.push("Gale");
  if (p.lifestealT > 0) buffs.push("Blood");
  if (p.teamBuffT > 0) buffs.push("Colossus");
  if (p.slowT > 0) buffs.push("Slowed");
  if (h.buff) h.buff.textContent = buffs.join(" · ");
  if (h.respawn) {
    h.respawn.style.display = play && !p.alive ? "flex" : "none";
    const label = h.respawn.querySelector("strong");
    if (label) label.textContent = `${Math.ceil(Math.max(0, p.respawn))}`;
  }
  const abs = CHAMPS[p.champ ?? "vanguard"].abilities;
  for (let i = 0; i < 4; i++) {
    const cd = p.cds[i] ?? 0;
    const max = abs[i]?.cd ?? 1;
    const shade = h.shades[i];
    const label = h.cds[i];
    if (shade) shade.style.transform = `scaleY(${cd > 0 ? Math.min(1, cd / max) : 0})`;
    if (label) label.textContent = cd > 0.05 ? cd.toFixed(1) : "";
  }
  for (let i = 0; i < 4; i++) {
    const el = h.counts[i];
    if (el) el.textContent = `${p.itemCounts[i] ?? 0}/3`;
  }
  drawMinimap(h.minimap, sim);
}

function drawMinimap(canvasMap: HTMLCanvasElement | null, sim: Sim) {
  if (!canvasMap) return;
  const ctx = canvasMap.getContext("2d");
  if (!ctx) return;
  const S = canvasMap.width;
  ctx.clearRect(0, 0, S, S);
  ctx.fillStyle = "#15211c";
  ctx.fillRect(0, 0, S, S);
  ctx.strokeStyle = "#2a6d82";
  ctx.lineWidth = 3;
  ctx.beginPath();
  for (let z = -90; z <= 90; z += 8) {
    const x = Math.sin(z * 0.045) * 16;
    const px = ((x + 100) / 200) * S;
    const py = ((z + 100) / 200) * S;
    if (z === -90) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.stroke();
  for (const e of sim.ents) {
    if (!e.alive) continue;
    const x = ((e.x + 100) / 200) * S;
    const y = ((e.z + 100) / 200) * S;
    ctx.fillStyle = e.team === 0 ? "#e4b15a" : e.team === 1 ? "#d4524a" : "#c6b48a";
    if (e.kind === "minion") ctx.fillRect(x - 1, y - 1, 2, 2);
    else if (e.kind === "tower" || e.kind === "nexus") ctx.fillRect(x - 3, y - 3, 6, 6);
    else if (e.player) {
      ctx.beginPath();
      ctx.arc(x, y, 4.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#e7efe6";
      ctx.lineWidth = 1.5;
      ctx.stroke();
    } else {
      ctx.beginPath();
      ctx.arc(x, y, e.kind === "boss" ? 4 : 3, 0, Math.PI * 2);
      ctx.fill();
    }
  }
}

function paintWorld(
  sim: Sim,
  view: ReturnType<typeof createWorld>,
  barPool: HTMLDivElement[],
  floatPool: HTMLDivElement[],
) {
  const p = sim.player();
  let bi = 0;
  for (const e of sim.ents) {
    const el = barPool[bi];
    if (!el) break;
    const interesting =
      e.alive &&
      sim.phase !== "menu" &&
      (e.kind === "hero" || e.kind === "tower" || e.kind === "nexus" || e.kind === "boss" || (e.hp < e.maxHp && Math.hypot(e.x - p.x, e.z - p.z) < 20));
    if (!interesting) continue;
    const lift = e.kind === "tower" || e.kind === "nexus" ? 6.3 : e.kind === "boss" ? 3.3 : 2.4;
    const pt = view.project(e.x, groundY(e.x, e.z) + lift, e.z);
    if (!pt.visible) continue;
    el.style.display = "block";
    el.style.left = `${pt.x}px`;
    el.style.top = `${pt.y}px`;
    const name = el.querySelector(".bf-name");
    const fill = el.querySelector(".bf-fill") as HTMLElement | null;
    if (name) name.textContent = e.player ? "" : e.name;
    if (fill) {
      fill.style.transform = `scaleX(${Math.max(0.04, e.hp / Math.max(1, e.maxHp))})`;
      fill.style.background = e.team === 0 ? "#e4b15a" : e.team === 1 ? "#d4524a" : "#c6b48a";
    }
    bi++;
  }
  for (let i = bi; i < barPool.length; i++) {
    const el = barPool[i];
    if (el) el.style.display = "none";
  }
  let fi = 0;
  for (const f of sim.floats) {
    const el = floatPool[fi];
    if (!el || !f.alive || sim.phase === "menu") continue;
    const pt = view.project(f.x, groundY(f.x, f.z) + f.y, f.z);
    if (!pt.visible) continue;
    el.style.display = "block";
    el.style.left = `${pt.x}px`;
    el.style.top = `${pt.y}px`;
    el.style.color = f.color;
    el.style.opacity = String(Math.min(1, f.life * 1.5));
    el.textContent = f.text;
    fi++;
  }
  for (let i = fi; i < floatPool.length; i++) {
    const el = floatPool[i];
    if (el) el.style.display = "none";
  }
}
