import type { ChampId } from "@/game/content";

export type TeamId = 0 | 1 | 2;

export interface Waypoint {
  x: number;
  z: number;
}

/** Mid, top (+X), bot (−X). Dawn marches index-up from +Z toward −Z. */
export const LANES: Waypoint[][] = [
  [
    { x: 0, z: 64 },
    { x: 0, z: 42 },
    { x: 0, z: 20 },
    { x: 0, z: 0 },
    { x: 0, z: -20 },
    { x: 0, z: -42 },
    { x: 0, z: -64 },
  ],
  [
    { x: 8, z: 64 },
    { x: 30, z: 60 },
    { x: 54, z: 52 },
    { x: 70, z: 32 },
    { x: 74, z: 8 },
    { x: 68, z: -18 },
    { x: 52, z: -40 },
    { x: 28, z: -58 },
    { x: 8, z: -64 },
  ],
  [
    { x: -8, z: 64 },
    { x: -30, z: 60 },
    { x: -54, z: 52 },
    { x: -70, z: 32 },
    { x: -74, z: 8 },
    { x: -68, z: -18 },
    { x: -52, z: -40 },
    { x: -28, z: -58 },
    { x: -8, z: -64 },
  ],
];

export const LANE_NAMES = ["Mid", "East", "West"];

export interface TowerSite {
  team: 0 | 1;
  lane: number;
  tier: number;
  x: number;
  z: number;
}

export const TOWERS: TowerSite[] = [
  { team: 0, lane: 0, tier: 1, x: 0, z: 38 },
  { team: 0, lane: 0, tier: 2, x: 0, z: 56 },
  { team: 0, lane: 1, tier: 1, x: 58, z: 40 },
  { team: 0, lane: 1, tier: 2, x: 36, z: 58 },
  { team: 0, lane: 2, tier: 1, x: -58, z: 40 },
  { team: 0, lane: 2, tier: 2, x: -36, z: 58 },
  { team: 1, lane: 0, tier: 1, x: 0, z: -38 },
  { team: 1, lane: 0, tier: 2, x: 0, z: -56 },
  { team: 1, lane: 1, tier: 1, x: 58, z: -40 },
  { team: 1, lane: 1, tier: 2, x: 36, z: -58 },
  { team: 1, lane: 2, tier: 1, x: -58, z: -40 },
  { team: 1, lane: 2, tier: 2, x: -36, z: -58 },
];

export const NEXUS: { team: 0 | 1; x: number; z: number }[] = [
  { team: 0, x: 0, z: 78 },
  { team: 1, x: 0, z: -78 },
];

export const FOUNTAINS: { team: 0 | 1; x: number; z: number }[] = [
  { team: 0, x: 0, z: 70 },
  { team: 1, x: 0, z: -70 },
];

export interface CampSite {
  id: string;
  x: number;
  z: number;
  kind: "wolf" | "golem" | "spirit";
  count: number;
  hp: number;
  ad: number;
  name: string;
}

export const CAMPS: CampSite[] = [
  { id: "wolves-dawn", x: 34, z: 24, kind: "wolf", count: 3, hp: 150, ad: 14, name: "Thicket Wolf" },
  { id: "golem-dawn", x: -38, z: 18, kind: "golem", count: 1, hp: 480, ad: 32, name: "Moss Golem" },
  { id: "spirits-dusk", x: 30, z: -30, kind: "spirit", count: 2, hp: 190, ad: 18, name: "Rift Spirit" },
  { id: "wolves-dusk", x: -32, z: -26, kind: "wolf", count: 3, hp: 150, ad: 14, name: "Thicket Wolf" },
];

export const BOSS = { x: 50, z: -6, name: "Rift Colossus" };

export interface ShrineSite {
  id: string;
  x: number;
  z: number;
  name: string;
  kind: "haste" | "lifesteal" | "shield";
}

export const SHRINES: ShrineSite[] = [
  { id: "gale", x: 52, z: 48, name: "Gale Shrine", kind: "haste" },
  { id: "blood", x: -54, z: -4, name: "Blood Shrine", kind: "lifesteal" },
  { id: "aegis", x: 16, z: -54, name: "Aegis Shrine", kind: "shield" },
];

export const RUINS: { x: number; z: number; rot: number; h: number }[] = [
  { x: 22, z: 14, rot: 0.4, h: 3.2 },
  { x: 18, z: 18, rot: 0.2, h: 2.1 },
  { x: -20, z: -16, rot: 1.1, h: 3.6 },
  { x: -16, z: -12, rot: 0.6, h: 1.8 },
  { x: 44, z: -22, rot: 0.9, h: 2.6 },
];

export interface TreeSite {
  x: number;
  z: number;
  s: number;
  kind: number;
}

function hash(ix: number, iz: number): number {
  let n = Math.imul(ix, 374761393) + Math.imul(iz, 668265263);
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
}

function fade(t: number): number {
  return t * t * (3 - 2 * t);
}

function noise(x: number, z: number): number {
  const x0 = Math.floor(x);
  const z0 = Math.floor(z);
  const fx = x - x0;
  const fz = z - z0;
  const sx = fade(fx);
  const sz = fade(fz);
  const a = hash(x0, z0);
  const b = hash(x0 + 1, z0);
  const c = hash(x0, z0 + 1);
  const d = hash(x0 + 1, z0 + 1);
  return a + (b - a) * sx + (c - a) * sz + (a - b - c + d) * sx * sz;
}

function smooth(edge0: number, edge1: number, x: number): number {
  const t = Math.max(0, Math.min(1, (x - edge0) / (edge1 - edge0)));
  return t * t * (3 - 2 * t);
}

function segDist(px: number, pz: number, ax: number, az: number, bx: number, bz: number): number {
  const abx = bx - ax;
  const abz = bz - az;
  const den = abx * abx + abz * abz || 1;
  const t = Math.max(0, Math.min(1, ((px - ax) * abx + (pz - az) * abz) / den));
  const dx = px - (ax + abx * t);
  const dz = pz - (az + abz * t);
  return Math.hypot(dx, dz);
}

export function laneDist(x: number, z: number): number {
  let best = 999;
  for (const lane of LANES) {
    for (let i = 0; i < lane.length - 1; i++) {
      const a = lane[i];
      const b = lane[i + 1];
      if (!a || !b) continue;
      best = Math.min(best, segDist(x, z, a.x, a.z, b.x, b.z));
    }
  }
  return best;
}

export function riverCenterX(z: number): number {
  return Math.sin(z * 0.045) * 16 + Math.sin(z * 0.013) * 5;
}

export function riverDist(x: number, z: number): number {
  return Math.abs(x - riverCenterX(z));
}

export function terrainHeight(x: number, z: number): number {
  const rd = riverDist(x, z);
  const ld = laneDist(x, z);
  const n = noise(x * 0.028, z * 0.028) * 6.2 + noise(x * 0.07 + 9, z * 0.07) * 1.5 - 1.4;
  const riverCut = smooth(2.4, 12, rd);
  let h = n * (0.28 + 0.72 * riverCut) - (1 - riverCut) * 1.65;
  const flat = 1 - smooth(2.2, 7.5, ld);
  h = h * (1 - flat * 0.9) + 0.22 * flat * 0.9;
  const dawn = Math.hypot(x, z - 76);
  const dusk = Math.hypot(x, z + 76);
  if (dawn < 18) h = h * smooth(8, 18, dawn) * 0.55 + 0.28;
  if (dusk < 18) h = h * smooth(8, 18, dusk) * 0.55 + 0.28;
  const edge = Math.max(Math.abs(x), Math.abs(z));
  if (edge > 82) h += smooth(82, 102, edge) * 16;
  return h;
}

export function groundY(x: number, z: number): number {
  return Math.max(terrainHeight(x, z), -0.18);
}

export interface Rgb {
  r: number;
  g: number;
  b: number;
}

function mix(a: Rgb, b: Rgb, t: number): Rgb {
  return {
    r: a.r + (b.r - a.r) * t,
    g: a.g + (b.g - a.g) * t,
    b: a.b + (b.b - a.b) * t,
  };
}

const GRASS: Rgb = { r: 0.29, g: 0.46, b: 0.27 };
const GRASS_HI: Rgb = { r: 0.42, g: 0.58, b: 0.3 };
const PATH: Rgb = { r: 0.48, g: 0.38, b: 0.24 };
const SAND: Rgb = { r: 0.62, g: 0.52, b: 0.34 };
const WET: Rgb = { r: 0.18, g: 0.28, b: 0.26 };
const ROCK: Rgb = { r: 0.48, g: 0.46, b: 0.4 };
const PLAZA: Rgb = { r: 0.55, g: 0.5, b: 0.4 };

export function terrainColor(x: number, z: number, h: number): Rgb {
  const n = noise(x * 0.12, z * 0.12);
  let c = mix(GRASS, GRASS_HI, n);
  const rd = riverDist(x, z);
  const ld = laneDist(x, z);
  if (ld < 6) c = mix(c, PATH, 1 - smooth(1.2, 6, ld));
  if (rd < 9) c = mix(c, SAND, 1 - smooth(3.2, 9, rd));
  if (h < -0.15) c = mix(c, WET, smooth(-0.15, -1.1, -h));
  if (h > 3.2) c = mix(c, ROCK, smooth(3.2, 7, h));
  const plaza = Math.min(Math.hypot(x, z - 76), Math.hypot(x, z + 76));
  if (plaza < 14) c = mix(c, PLAZA, 1 - smooth(4, 14, plaza));
  return c;
}

export function buildTrees(): TreeSite[] {
  const out: TreeSite[] = [];
  let seed = 19;
  const rnd = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed & 0xfffffff) / 0xfffffff;
  };
  for (let i = 0; i < 700 && out.length < 150; i++) {
    const x = (rnd() - 0.5) * 176;
    const z = (rnd() - 0.5) * 176;
    if (Math.max(Math.abs(x), Math.abs(z)) > 86) continue;
    if (laneDist(x, z) < 6.5) continue;
    if (riverDist(x, z) < 6) continue;
    if (Math.hypot(x, z - 76) < 16 || Math.hypot(x, z + 76) < 16) continue;
    if (Math.hypot(x - BOSS.x, z - BOSS.z) < 8) continue;
    for (const camp of CAMPS) {
      if (Math.hypot(x - camp.x, z - camp.z) < 6) continue;
    }
    let blocked = false;
    for (const camp of CAMPS) {
      if (Math.hypot(x - camp.x, z - camp.z) < 7) blocked = true;
    }
    for (const s of SHRINES) {
      if (Math.hypot(x - s.x, z - s.z) < 5) blocked = true;
    }
    if (blocked) continue;
    const h = terrainHeight(x, z);
    if (h < 0.35 || h > 6) continue;
    out.push({ x, z, s: 0.75 + rnd() * 0.7, kind: rnd() > 0.55 ? 1 : 0 });
  }
  return out;
}

export const TREES = buildTrees();

export function pushOutOfTrees(x: number, z: number, radius: number): { x: number; z: number } {
  let px = x;
  let pz = z;
  for (const t of TREES) {
    const min = radius + 0.45 * t.s;
    const dx = px - t.x;
    const dz = pz - t.z;
    const d = Math.hypot(dx, dz);
    if (d < min && d > 0.0001) {
      const k = (min - d) / d;
      px += dx * k;
      pz += dz * k;
    }
  }
  return { x: px, z: pz };
}

export function clampWorld(x: number, z: number): { x: number; z: number } {
  return {
    x: Math.max(-90, Math.min(90, x)),
    z: Math.max(-90, Math.min(90, z)),
  };
}

export function heroSpawn(which: "player" | "ally" | "enemy", index: number): { x: number; z: number; lane: number; yaw: number } {
  if (which === "player") return { x: 0, z: 66, lane: 0, yaw: 0 };
  if (which === "ally") {
    return index === 0
      ? { x: 12, z: 66, lane: 1, yaw: 0 }
      : { x: -12, z: 66, lane: 2, yaw: 0 };
  }
  if (index === 0) return { x: 0, z: -66, lane: 0, yaw: Math.PI };
  if (index === 1) return { x: 12, z: -66, lane: 1, yaw: Math.PI };
  return { x: -12, z: -66, lane: 2, yaw: Math.PI };
}

export function champTint(id: ChampId): number {
  if (id === "arcanist") return 0x6ec8e0;
  if (id === "ranger") return 0x7dbe6a;
  return 0xc9853a;
}
