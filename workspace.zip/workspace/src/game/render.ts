import * as THREE from "three";
import type { ChampId } from "@/game/content";
import { createHerald, heraldReady, loadHerald, type HeraldPose } from "@/game/herald";
import type { Ent, Ring, Sim } from "@/game/sim";
import {
  RUINS,
  SHRINES,
  TREES,
  groundY,
  terrainColor,
  terrainHeight,
} from "@/game/terrain";

export interface WorldView {
  resize: () => void;
  render: (sim: Sim, dt: number, camYaw: number, aimX: number, aimZ: number, showAim: boolean) => void;
  snap: (sim: Sim, camYaw: number) => void;
  project: (x: number, y: number, z: number) => { x: number; y: number; visible: boolean };
  width: () => number;
  height: () => number;
  dispose: () => void;
  camera: THREE.PerspectiveCamera;
}

const SIZE = 200;
const SEG = 72;

export function createWorld(canvas: HTMLCanvasElement): WorldView {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: "high-performance" });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.08;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFShadowMap;
  const coarse = typeof window !== "undefined" && window.matchMedia("(pointer: coarse)").matches;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, coarse ? 1.25 : 1.6));

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x8eb8cc);
  scene.fog = new THREE.Fog(0xc9d5c4, 48, 145);
  void loadHerald();

  const camera = new THREE.PerspectiveCamera(52, 1, 0.12, 280);
  camera.position.set(0, 24, 48);

  const hemi = new THREE.HemisphereLight(0xffe6c2, 0x3e5a40, 0.85);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xfff3dd, 1.65);
  sun.position.set(48, 72, 26);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  sun.shadow.camera.near = 12;
  sun.shadow.camera.far = 180;
  sun.shadow.camera.left = -78;
  sun.shadow.camera.right = 78;
  sun.shadow.camera.top = 78;
  sun.shadow.camera.bottom = -78;
  sun.shadow.bias = -0.0004;
  scene.add(sun);
  scene.add(sun.target);

  const skyGeo = new THREE.SphereGeometry(190, 18, 12);
  const skyPos = skyGeo.attributes.position;
  const skyCols = new Float32Array(skyPos.count * 3);
  const topC = new THREE.Color("#6aa4c9");
  const horC = new THREE.Color("#f3d7a6");
  const botC = new THREE.Color("#8aa56a");
  const tmpC = new THREE.Color();
  for (let i = 0; i < skyPos.count; i++) {
    const y = skyPos.getY(i) / 190;
    if (y < 0) tmpC.copy(botC).lerp(horC, y + 1);
    else tmpC.copy(horC).lerp(topC, Math.min(1, y * 1.6));
    skyCols[i * 3] = tmpC.r;
    skyCols[i * 3 + 1] = tmpC.g;
    skyCols[i * 3 + 2] = tmpC.b;
  }
  skyGeo.setAttribute("color", new THREE.BufferAttribute(skyCols, 3));
  const sky = new THREE.Mesh(
    skyGeo,
    new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide, depthWrite: false, fog: false }),
  );
  scene.add(sky);

  const groundGeo = new THREE.PlaneGeometry(SIZE, SIZE, SEG, SEG);
  groundGeo.rotateX(-Math.PI / 2);
  const gPos = groundGeo.attributes.position;
  const gCols = new Float32Array(gPos.count * 3);
  const gc = new THREE.Color();
  for (let i = 0; i < gPos.count; i++) {
    const x = gPos.getX(i);
    const z = gPos.getZ(i);
    const h = terrainHeight(x, z);
    gPos.setY(i, h);
    const col = terrainColor(x, z, h);
    gc.setRGB(col.r, col.g, col.b);
    gCols[i * 3] = gc.r;
    gCols[i * 3 + 1] = gc.g;
    gCols[i * 3 + 2] = gc.b;
  }
  groundGeo.setAttribute("color", new THREE.BufferAttribute(gCols, 3));
  groundGeo.computeVertexNormals();
  const ground = new THREE.Mesh(
    groundGeo,
    new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.94, metalness: 0.02 }),
  );
  ground.receiveShadow = true;
  scene.add(ground);

  const water = new THREE.Mesh(
    new THREE.PlaneGeometry(SIZE, SIZE),
    new THREE.MeshPhysicalMaterial({
      color: 0x2a6d82,
      transparent: true,
      opacity: 0.72,
      roughness: 0.18,
      metalness: 0.04,
    }),
  );
  water.rotation.x = -Math.PI / 2;
  water.position.y = -0.28;
  scene.add(water);

  const trunkGeo = new THREE.CylinderGeometry(0.16, 0.24, 1.3, 5);
  const leafGeoA = new THREE.ConeGeometry(0.9, 1.8, 6);
  const leafGeoB = new THREE.IcosahedronGeometry(0.72, 0);
  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x5c4634, roughness: 0.9 });
  const leafMatA = new THREE.MeshStandardMaterial({ color: 0x2f6a38, roughness: 0.85 });
  const leafMatB = new THREE.MeshStandardMaterial({ color: 0x3e7d42, roughness: 0.85 });
  const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, TREES.length);
  const leavesA = new THREE.InstancedMesh(leafGeoA, leafMatA, TREES.length);
  const leavesB = new THREE.InstancedMesh(leafGeoB, leafMatB, TREES.length);
  const dummy = new THREE.Object3D();
  let aCount = 0;
  let bCount = 0;
  TREES.forEach((t, i) => {
    const y = groundY(t.x, t.z);
    dummy.position.set(t.x, y + 0.65 * t.s, t.z);
    dummy.scale.setScalar(t.s);
    dummy.rotation.set(0, i, 0);
    dummy.updateMatrix();
    trunks.setMatrixAt(i, dummy.matrix);
    dummy.position.set(t.x, y + 1.7 * t.s, t.z);
    dummy.scale.setScalar(t.s);
    dummy.updateMatrix();
    if (t.kind === 0) {
      leavesA.setMatrixAt(aCount++, dummy.matrix);
    } else {
      leavesB.setMatrixAt(bCount++, dummy.matrix);
    }
  });
  trunks.count = TREES.length;
  leavesA.count = aCount;
  leavesB.count = bCount;
  scene.add(trunks, leavesA, leavesB);

  const rockGeo = new THREE.DodecahedronGeometry(0.7, 0);
  const rockMat = new THREE.MeshStandardMaterial({ color: 0x8a847a, roughness: 0.92 });
  const rocks = new THREE.InstancedMesh(rockGeo, rockMat, 40);
  let ri = 0;
  for (let k = 0; k < 40; k++) {
    const x = Math.sin(k * 12.3) * 70;
    const z = Math.cos(k * 9.1) * 70;
    if (Math.hypot(x, z - 70) < 18) continue;
    const y = groundY(x, z);
    if (y < 0.4) continue;
    dummy.position.set(x, y + 0.2, z);
    dummy.rotation.set(k, k * 0.5, 0);
    dummy.scale.setScalar(0.5 + (k % 5) * 0.18);
    dummy.updateMatrix();
    rocks.setMatrixAt(ri++, dummy.matrix);
  }
  rocks.count = ri;
  scene.add(rocks);

  const stone = new THREE.MeshStandardMaterial({ color: 0x9a9286, roughness: 0.88 });
  for (const r of RUINS) {
    const col = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.45, r.h, 6), stone);
    col.position.set(r.x, groundY(r.x, r.z) + r.h * 0.45, r.z);
    col.rotation.y = r.rot;
    col.castShadow = true;
    scene.add(col);
  }

  const shrineMat = new THREE.MeshStandardMaterial({ color: 0xe4b15a, emissive: 0x8a6420, emissiveIntensity: 0.45, roughness: 0.4 });
  for (const s of SHRINES) {
    const y = groundY(s.x, s.z);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(1.3, 0.08, 6, 16), shrineMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.set(s.x, y + 0.15, s.z);
    const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.28), shrineMat);
    gem.position.set(s.x, y + 1.1, s.z);
    scene.add(ring, gem);
  }

  const dawnGem = new THREE.MeshStandardMaterial({ color: 0xe4b15a, emissive: 0xe4b15a, emissiveIntensity: 0.55, roughness: 0.35 });
  const duskGem = new THREE.MeshStandardMaterial({ color: 0xd4524a, emissive: 0xd4524a, emissiveIntensity: 0.5, roughness: 0.35 });
  const neutralGem = new THREE.MeshStandardMaterial({ color: 0xc6b48a, emissive: 0x6a5a32, emissiveIntensity: 0.3, roughness: 0.5 });

  const groups = new Map<number, THREE.Group>();
  const minionMesh = new THREE.InstancedMesh(
    new THREE.CapsuleGeometry(0.28, 0.45, 3, 6),
    new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.7 }),
    54,
  );
  minionMesh.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(54 * 3), 3);
  minionMesh.castShadow = true;
  minionMesh.count = 0;
  scene.add(minionMesh);

  const shotMesh = new THREE.InstancedMesh(
    new THREE.SphereGeometry(0.22, 8, 6),
    new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0x221100, roughness: 0.4 }),
    48,
  );
  shotMesh.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(48 * 3), 3);
  shotMesh.count = 0;
  scene.add(shotMesh);

  const ringPool: THREE.Mesh[] = [];
  for (let i = 0; i < 16; i++) {
    const m = new THREE.Mesh(
      new THREE.RingGeometry(0.8, 0.95, 24),
      new THREE.MeshBasicMaterial({ color: 0xe4b15a, transparent: true, opacity: 0.8, side: THREE.DoubleSide }),
    );
    m.rotation.x = -Math.PI / 2;
    m.visible = false;
    scene.add(m);
    ringPool.push(m);
  }

  const aimRing = new THREE.Mesh(
    new THREE.RingGeometry(0.35, 0.48, 20),
    new THREE.MeshBasicMaterial({ color: 0xe7efe6, transparent: true, opacity: 0.8, side: THREE.DoubleSide }),
  );
  aimRing.rotation.x = -Math.PI / 2;
  aimRing.visible = false;
  scene.add(aimRing);

  const clock = { t: 0 };
  let camX = 0;
  let camY = 18;
  let camZ = 40;
  let focusX = 0;
  let focusZ = 0;
  const projV = new THREE.Vector3();
  const col = new THREE.Color();
  let viewW = 1;
  let viewH = 1;

  function resize() {
    const w = canvas.clientWidth || window.innerWidth;
    const h = canvas.clientHeight || window.innerHeight;
    viewW = w;
    viewH = h;
    renderer.setSize(w, h, false);
    camera.aspect = w / Math.max(1, h);
    camera.updateProjectionMatrix();
  }

  function teamMat(team: number) {
    return team === 0 ? dawnGem : team === 1 ? duskGem : neutralGem;
  }

  function makeHero(champ: ChampId, team: number) {
    const g = new THREE.Group();
    const cloth = new THREE.Color(champ === "arcanist" ? 0x245e72 : champ === "ranger" ? 0x2d5a32 : 0x6a4a28);
    const bodyMat = new THREE.MeshStandardMaterial({ color: cloth, roughness: 0.72 });
    const skin = new THREE.MeshStandardMaterial({ color: 0xd7b08a, roughness: 0.65 });
    const metal = new THREE.MeshStandardMaterial({
      color: team === 1 ? 0x8a3a3a : 0xc9853a,
      roughness: 0.45,
      metalness: 0.35,
    });
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.34, 0.62, 4, 8), bodyMat);
    body.position.y = 0.95;
    body.castShadow = true;
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.24, 10, 8), skin);
    head.position.y = 1.68;
    head.castShadow = true;
    const sash = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.12, 0.16), teamMat(team));
    sash.position.set(0, 1.15, 0.28);
    const weapon = new THREE.Group();
    weapon.position.set(0.38, 1.05, 0.05);
    if (champ === "vanguard") {
      const blade = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 1.15), metal);
      blade.position.set(0, 0, 0.55);
      const guard = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.08, 0.08), metal);
      weapon.add(blade, guard);
    } else if (champ === "arcanist") {
      const staff = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 1.5, 6), new THREE.MeshStandardMaterial({ color: 0x4a3424, roughness: 0.8 }));
      staff.rotation.x = Math.PI / 2;
      staff.position.z = 0.2;
      const orb = new THREE.Mesh(new THREE.SphereGeometry(0.16, 10, 8), team === 1 ? duskGem : dawnGem);
      orb.position.set(0, 0, 0.95);
      weapon.add(staff, orb);
    } else {
      const bow = new THREE.Mesh(new THREE.TorusGeometry(0.38, 0.035, 6, 14, Math.PI), new THREE.MeshStandardMaterial({ color: 0x6b4a2a, roughness: 0.7 }));
      bow.rotation.y = Math.PI / 2;
      bow.rotation.z = Math.PI / 2;
      weapon.add(bow);
    }
    g.add(body, head, sash, weapon);
    g.userData = { champ, weapon, mats: [bodyMat, metal] };
    return g;
  }

  function makeTower(team: number) {
    const g = new THREE.Group();
    const base = new THREE.Mesh(new THREE.CylinderGeometry(1.25, 1.55, 1.1, 8), stone);
    base.position.y = 0.55;
    base.castShadow = true;
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.95, 3.8, 8), stone);
    shaft.position.y = 2.9;
    shaft.castShadow = true;
    const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.48), teamMat(team));
    gem.position.y = 5.15;
    g.add(base, shaft, gem);
    g.userData = { gem };
    return g;
  }

  function makeNexus(team: number) {
    const g = new THREE.Group();
    const base = new THREE.Mesh(new THREE.CylinderGeometry(1.8, 2.2, 0.8, 8), stone);
    base.position.y = 0.4;
    base.castShadow = true;
    const gem = new THREE.Mesh(new THREE.OctahedronGeometry(1.05), teamMat(team));
    gem.position.y = 2.3;
    const halo = new THREE.Mesh(new THREE.TorusGeometry(1.5, 0.06, 6, 20), teamMat(team));
    halo.rotation.x = Math.PI / 2;
    halo.position.y = 0.9;
    g.add(base, gem, halo);
    g.userData = { gem, halo };
    return g;
  }

  function makeCreep(e: Ent) {
    const g = new THREE.Group();
    if (e.kind === "boss" || e.creepKind === "golem") {
      const body = new THREE.Mesh(new THREE.DodecahedronGeometry(e.kind === "boss" ? 1.15 : 0.85, 0), new THREE.MeshStandardMaterial({ color: 0x6d7358, roughness: 0.86 }));
      body.position.y = e.kind === "boss" ? 1.3 : 0.9;
      body.castShadow = true;
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 6), duskGem);
      eye.position.set(0.2, body.position.y + 0.2, 0.55);
      g.add(body, eye);
    } else if (e.creepKind === "spirit") {
      const body = new THREE.Mesh(new THREE.SphereGeometry(0.42, 10, 8), new THREE.MeshStandardMaterial({ color: 0x9fd8e8, emissive: 0x3a7888, emissiveIntensity: 0.6, transparent: true, opacity: 0.9 }));
      body.position.y = 0.9;
      g.add(body);
    } else {
      const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.28, 0.35, 3, 6), new THREE.MeshStandardMaterial({ color: 0x4a4038, roughness: 0.8 }));
      body.position.y = 0.5;
      body.rotation.z = Math.PI / 2;
      body.castShadow = true;
      g.add(body);
    }
    return g;
  }

  function releaseHero(g: THREE.Group) {
    const dispose = g.userData.dispose as (() => void) | undefined;
    dispose?.();
    if (!g.userData.herald) {
      g.traverse((obj) => {
        const mesh = obj as THREE.Mesh;
        if (!mesh.isMesh) return;
        mesh.geometry?.dispose();
        const mat = mesh.material as THREE.Material | THREE.Material[] | undefined;
        if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
        else mat?.dispose();
      });
    }
    scene.remove(g);
  }

  function ensureGroup(e: Ent) {
    const prev = groups.get(e.id);
    if (e.kind === "hero") {
      const champ = e.champ ?? "vanguard";
      const skinned = heraldReady();
      if (
        prev &&
        Boolean(prev.userData.herald) === skinned &&
        prev.userData.champ === champ &&
        prev.userData.team === e.team
      ) {
        return prev;
      }
      if (prev) releaseHero(prev);
      if (skinned) {
        const actor = createHerald(champ, e.team);
        if (actor) {
          actor.object.userData = {
            herald: true,
            champ,
            team: e.team,
            step: actor.step,
            dispose: actor.dispose,
          };
          groups.set(e.id, actor.object);
          scene.add(actor.object);
          return actor.object;
        }
      }
      const g = makeHero(champ, e.team);
      g.userData.champ = champ;
      g.userData.team = e.team;
      groups.set(e.id, g);
      scene.add(g);
      return g;
    }
    if (prev) return prev;
    let g: THREE.Group;
    if (e.kind === "tower") g = makeTower(e.team);
    else if (e.kind === "nexus") g = makeNexus(e.team);
    else g = makeCreep(e);
    groups.set(e.id, g);
    scene.add(g);
    return g;
  }

  function placeRing(mesh: THREE.Mesh, ring: Ring) {
    const mat = mesh.material as THREE.MeshBasicMaterial;
    mat.color.setHex(ring.color);
    mat.opacity = Math.max(0.15, ring.life / ring.max);
    const y = groundY(ring.x, ring.z) + 0.18;
    mesh.position.set(ring.x, y, ring.z);
    const s = ring.r * (1.05 - 0.15 * (ring.life / ring.max));
    mesh.scale.setScalar(s);
    mesh.visible = true;
  }

  function render(sim: Sim, dt: number, camYaw: number, aimX: number, aimZ: number, showAim: boolean) {
    clock.t += dt;
    const player = sim.player();
    const menu = sim.phase === "menu";

    const seen = new Set<number>();
    let mi = 0;
    let si = 0;
    for (const e of sim.ents) {
      if (e.kind === "minion") {
        if (!e.alive || mi >= 54) continue;
        const y = groundY(e.x, e.z);
        dummy.position.set(e.x, y + 0.55, e.z);
        dummy.rotation.set(0, e.yaw + Math.PI, 0);
        dummy.scale.setScalar(e.ranged ? 0.85 : 1);
        dummy.updateMatrix();
        minionMesh.setMatrixAt(mi, dummy.matrix);
        col.setHex(e.team === 0 ? 0xe4b15a : 0xd4524a);
        if (e.hitFlash > 0) col.setHex(0xffffff);
        minionMesh.setColorAt(mi, col);
        mi++;
        continue;
      }
      if (e.kind === "hero") {
        const g = ensureGroup(e);
        seen.add(e.id);
        const show = e.alive || e.respawn > 0;
        g.visible = show;
        if (show) {
          g.position.set(e.x, groundY(e.x, e.z), e.z);
          g.rotation.y = e.yaw + Math.PI;
          const step = g.userData.step as ((pose: HeraldPose, dt: number, dist: number) => void) | undefined;
          if (step) {
            const dist = Math.hypot(camera.position.x - e.x, camera.position.z - e.z);
            step(
              {
                champ: e.champ,
                team: e.team,
                vel: e.vel,
                alive: e.alive,
                dashT: e.dashT,
                slowT: e.slowT,
                attackAnim: e.attackAnim,
                twist: Math.atan2(Math.sin(e.faceYaw - e.yaw), Math.cos(e.faceYaw - e.yaw)),
                swing: e.swing,
                hitFlash: e.hitFlash,
              },
              dt,
              dist,
            );
          } else {
            const bob = Math.sin(clock.t * (e.vel > 0.5 ? 9 : 2) + e.id) * (e.vel > 0.5 ? 0.05 : 0.02);
            g.position.y += bob;
            const weapon = g.userData.weapon as THREE.Group | undefined;
            if (weapon) weapon.rotation.x = e.attackAnim > 0 ? Math.sin((0.28 - e.attackAnim) * 12) * -1.1 : 0;
          }
        }
        continue;
      }
      if (!e.alive && e.kind !== "tower" && e.kind !== "nexus" && e.kind !== "boss") continue;
      const g = ensureGroup(e);
      seen.add(e.id);
      g.visible = e.alive;
      if (!e.alive) continue;
      const y = groundY(e.x, e.z);
      g.position.set(e.x, y, e.z);
      g.rotation.y = e.yaw + Math.PI;
      const weapon = g.userData.weapon as THREE.Group | undefined;
      if (weapon) {
        weapon.rotation.x = e.attackAnim > 0 ? Math.sin((0.28 - e.attackAnim) * 12) * -1.1 : 0;
      }
      const mats = g.userData.mats as THREE.MeshStandardMaterial[] | undefined;
      if (mats) {
        for (const m of mats) {
          m.emissive.setHex(e.hitFlash > 0 ? 0xfff2d8 : 0x000000);
          m.emissiveIntensity = e.hitFlash > 0 ? 0.55 : 0;
        }
      }
      const gem = g.userData.gem as THREE.Mesh | undefined;
      if (gem) gem.rotation.y = clock.t * 0.8;
      const halo = g.userData.halo as THREE.Mesh | undefined;
      if (halo) halo.rotation.z = clock.t * 0.4;
    }
    for (const id of [...groups.keys()]) {
      const g = groups.get(id);
      if (!g || seen.has(id)) continue;
      (g.userData.dispose as (() => void) | undefined)?.();
      scene.remove(g);
      groups.delete(id);
    }
    minionMesh.count = mi;
    minionMesh.instanceMatrix.needsUpdate = true;
    if (minionMesh.instanceColor) minionMesh.instanceColor.needsUpdate = true;

    for (const p of sim.projs) {
      if (!p.alive || si >= 48) continue;
      const y = groundY(p.x, p.z) + 1.05;
      dummy.position.set(p.x, y, p.z);
      dummy.rotation.set(0, 0, 0);
      dummy.scale.setScalar(p.kind === "pierce" ? 0.7 : 1);
      dummy.updateMatrix();
      shotMesh.setMatrixAt(si, dummy.matrix);
      col.setHex(p.team === 0 ? 0xf2d48a : p.team === 1 ? 0xff7a72 : 0xd7e7ef);
      if (p.kind === "pierce") col.setHex(0xd7f5c4);
      shotMesh.setColorAt(si, col);
      si++;
    }
    shotMesh.count = si;
    shotMesh.instanceMatrix.needsUpdate = true;
    if (shotMesh.instanceColor) shotMesh.instanceColor.needsUpdate = true;

    ringPool.forEach((m) => {
      m.visible = false;
    });
    let riRing = 0;
    for (const r of sim.rings) {
      if (!r.alive || riRing >= ringPool.length) continue;
      const mesh = ringPool[riRing++];
      if (mesh) placeRing(mesh, r);
    }
    for (const t of sim.traps) {
      if (!t.alive || riRing >= ringPool.length) continue;
      const mesh = ringPool[riRing++];
      if (!mesh) continue;
      placeRing(mesh, {
        alive: true,
        x: t.x,
        z: t.z,
        r: t.radius * (t.arm > 0 ? 0.55 : 1),
        life: t.life,
        max: 7,
        color: t.arm > 0 ? 0x93a399 : 0x7dbe6a,
      });
    }

    if (showAim && !menu) {
      aimRing.visible = true;
      aimRing.position.set(aimX, groundY(aimX, aimZ) + 0.2, aimZ);
    } else aimRing.visible = false;

    const py = groundY(player.x, player.z);
    if (menu) {
      const ang = clock.t * 0.08;
      const tx = Math.sin(ang) * 46;
      const tz = Math.cos(ang) * 34;
      const k = 1 - Math.exp(-0.6 * dt);
      camX += (tx - camX) * k;
      camY += (26 - camY) * k;
      camZ += (tz - camZ) * k;
      camera.position.set(camX, camY, camZ);
      camera.lookAt(0, 2, 0);
    } else {
      const fx = -Math.sin(camYaw);
      const fz = -Math.cos(camYaw);
      const dist = coarse ? 13.5 : 12;
      const wantX = player.x - fx * dist;
      const wantZ = player.z - fz * dist;
      let wantY = py + (coarse ? 8.2 : 6.6);
      const gy = groundY(wantX, wantZ) + 1.4;
      if (wantY < gy) wantY = gy;
      const k = 1 - Math.exp(-5.5 * dt);
      focusX += (player.x - focusX) * k;
      focusZ += (player.z - focusZ) * k;
      camX += (wantX - camX) * k;
      camY += (wantY - camY) * k;
      camZ += (wantZ - camZ) * k;
      let sx = camX;
      let sy = camY;
      let sz = camZ;
      if (player.hitFlash > 0.04) {
        sx += (Math.random() - 0.5) * 0.18;
        sy += (Math.random() - 0.5) * 0.1;
      }
      camera.position.set(sx, sy, sz);
      camera.lookAt(focusX, py + 1.25, focusZ);
    }
    sun.target.position.set(player.x, 0, player.z);
    sun.target.updateMatrixWorld();
    renderer.render(scene, camera);
  }

  function snap(sim: Sim, camYaw: number) {
    const p = sim.player();
    const fx = -Math.sin(camYaw);
    const fz = -Math.cos(camYaw);
    const py = groundY(p.x, p.z);
    camX = p.x - fx * 12;
    camZ = p.z - fz * 12;
    camY = py + 6.6;
    focusX = p.x;
    focusZ = p.z;
  }

  function project(x: number, y: number, z: number) {
    projV.set(x, y, z);
    projV.project(camera);
    return {
      x: (projV.x * 0.5 + 0.5) * viewW,
      y: (-projV.y * 0.5 + 0.5) * viewH,
      visible: projV.z < 1 && projV.z > -1,
    };
  }

  resize();

  return {
    resize,
    render,
    snap,
    project,
    width: () => viewW,
    height: () => viewH,
    camera,
    dispose() {
      renderer.dispose();
      scene.traverse((obj: THREE.Object3D) => {
        const mesh = obj as THREE.Mesh;
        if (mesh.geometry) mesh.geometry.dispose();
        const mat = mesh.material as THREE.Material | THREE.Material[] | undefined;
        if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
        else mat?.dispose();
      });
    },
  };
}
