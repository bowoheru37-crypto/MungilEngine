export interface ScoreNote {
  time: number;
  dur: number;
  freq: number;
  gain: number;
  wave: OscillatorType;
}

export interface Score {
  notes: ScoreNote[];
  duration: number;
}

const TRACKS: ({ wave: OscillatorType; gain: number } | null)[] = [
  null,
  { wave: "triangle", gain: 0.05 },
  { wave: "sine", gain: 0.028 },
  { wave: "sine", gain: 0.07 },
  { wave: "sine", gain: 0.04 },
  { wave: "sine", gain: 0.03 },
  { wave: "sine", gain: 0.018 },
  null,
];

function readVar(data: Uint8Array, at: { i: number }) {
  let value = 0;
  for (let k = 0; k < 4; k++) {
    const byte = data[at.i++] ?? 0;
    value = (value << 7) | (byte & 0x7f);
    if ((byte & 0x80) === 0) break;
  }
  return value;
}

export function parseScore(data: Uint8Array): Score {
  if (data.length < 14 || String.fromCharCode(data[0]!, data[1]!, data[2]!, data[3]!) !== "MThd") {
    return { notes: [], duration: 1 };
  }
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  const hlen = view.getUint32(4);
  const tracks = view.getUint16(10);
  const div = view.getUint16(12) || 480;
  let cursor = 8 + hlen;
  const tempos: { tick: number; mpq: number }[] = [{ tick: 0, mpq: 500000 }];
  const raw: { tick: number; track: number; note: number; vel: number }[] = [];
  for (let track = 0; track < tracks && cursor + 8 <= data.length; track++) {
    if (String.fromCharCode(...data.slice(cursor, cursor + 4)) !== "MTrk") break;
    const len = view.getUint32(cursor + 4);
    cursor += 8;
    const end = cursor + len;
    let tick = 0;
    let running = 0;
    while (cursor < end) {
      const at = { i: cursor };
      tick += readVar(data, at);
      cursor = at.i;
      let status = data[cursor] ?? 0;
      if (status & 0x80) {
        cursor += 1;
        running = status;
      } else status = running;
      if (status === 0xff) {
        const type = data[cursor] ?? 0;
        cursor += 1;
        const meta = { i: cursor };
        const size = readVar(data, meta);
        cursor = meta.i;
        if (type === 0x51 && size === 3) {
          const mpq = ((data[cursor] ?? 0) << 16) | ((data[cursor + 1] ?? 0) << 8) | (data[cursor + 2] ?? 0);
          tempos.push({ tick, mpq });
        }
        cursor += size;
        continue;
      }
      if (status === 0xf0 || status === 0xf7) {
        const sys = { i: cursor };
        const size = readVar(data, sys);
        cursor = sys.i + size;
        continue;
      }
      const kind = status & 0xf0;
      if (kind === 0x80 || kind === 0x90) {
        const note = data[cursor] ?? 0;
        const vel = kind === 0x80 ? 0 : (data[cursor + 1] ?? 0);
        cursor += 2;
        raw.push({ tick, track, note, vel });
      } else if (kind === 0xc0 || kind === 0xd0) cursor += 1;
      else cursor += 2;
    }
  }
  tempos.sort((a, b) => a.tick - b.tick);
  const toTime = (tick: number) => {
    let time = 0;
    let last = 0;
    let mpq = 500000;
    for (const seg of tempos) {
      if (seg.tick >= tick) break;
      time += ((seg.tick - last) * mpq) / div / 1e6;
      last = seg.tick;
      mpq = seg.mpq;
    }
    return time + ((tick - last) * mpq) / div / 1e6;
  };
  const open = new Map<string, { time: number; vel: number }>();
  const notes: ScoreNote[] = [];
  let duration = 1;
  for (const ev of raw) {
    const time = toTime(ev.tick);
    duration = Math.max(duration, time);
    const key = `${ev.track}:${ev.note}`;
    if (ev.vel <= 0) {
      const start = open.get(key);
      open.delete(key);
      const spec = TRACKS[ev.track] ?? null;
      if (!start || !spec) continue;
      const dur = Math.min(3.2, Math.max(0.08, time - start.time));
      notes.push({
        time: start.time,
        dur,
        freq: 440 * 2 ** ((ev.note - 69) / 12),
        gain: spec.gain * (start.vel / 127),
        wave: spec.wave,
      });
    } else open.set(key, { time, vel: ev.vel });
  }
  const kept: ScoreNote[] = [];
  const buckets = new Map<number, ScoreNote[]>();
  for (const note of notes) {
    const key = Math.floor(note.time / 0.09);
    const list = buckets.get(key) ?? [];
    list.push(note);
    buckets.set(key, list);
  }
  for (const list of buckets.values()) {
    list.sort((a, b) => b.gain - a.gain);
    kept.push(...list.slice(0, 4));
  }
  kept.sort((a, b) => a.time - b.time);
  return { notes: kept, duration: duration + 0.4 };
}
