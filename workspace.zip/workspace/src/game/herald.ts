import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { clone as cloneSkinned } from "three/addons/utils/SkeletonUtils.js";
import type { ChampId } from "@/game/content";

export interface HeraldPose {
  champ: ChampId | null;
  team: number;
  vel: number;
  alive: boolean;
  dashT: number;
  slowT: number;
  attackAnim: number;
  /** Chest aim minus hip facing, radians. */
  twist: number;
  /** 0 slash, 1 shot, 2 cast, 3 slam, 4 guard. */
  swing: number;
  hitFlash: number;
}

export interface HeraldActor {
  object: THREE.Group;
  step: (pose: HeraldPose, dt: number, dist?: number) => void;
  dispose: () => void;
}

type Mode = "idle" | "walk" | "run" | "jump" | "crouch" | "sit";

let template: THREE.Object3D | null = null;
let clips: THREE.AnimationClip[] = [];
let scale = 1;
let foot = 0;
let pending: Promise<void> | null = null;

const TINT: Record<ChampId, number> = {
  vanguard: 0xfff6ea,
  arcanist: 0xc5e7f2,
  ranger: 0xd5ebc4,
};

export function heraldReady() {
  return template !== null;
}

export function loadHerald() {
  if (template) return Promise.resolve();
  if (pending) return pending;
  pending = new Promise((resolve) => {
    new GLTFLoader().load(
      "/models/herald.glb",
      (gltf) => {
        template = gltf.scene;
        clips = gltf.animations;
        template.updateMatrixWorld(true);
        const box = new THREE.Box3().setFromObject(template);
        const height = Math.max(0.001, box.max.y - box.min.y);
        scale = 1.7 / height;
        foot = -box.min.y * scale;
        template.traverse((obj) => {
          const mesh = obj as THREE.Mesh;
          if (!mesh.isMesh) return;
          mesh.castShadow = false;
          mesh.receiveShadow = false;
          const sphere = mesh.geometry.boundingSphere ?? mesh.geometry.computeBoundingSphere();
          if (mesh.geometry.boundingSphere) mesh.geometry.boundingSphere.radius *= 1.7;
          void sphere;
          mesh.frustumCulled = true;
        });
        resolve();
      },
      undefined,
      () => resolve(),
    );
  });
  return pending;
}

function modeOf(pose: HeraldPose): Mode {
  if (!pose.alive) return "sit";
  if (pose.dashT > 0) return "jump";
  if (pose.slowT > 0 && pose.vel < 3.2) return "crouch";
  if (pose.vel > 5.3) return "run";
  if (pose.vel > 0.4) return "walk";
  return "idle";
}

const SWING_LEN = [0.46, 0.46, 0.44, 0.5, 0.44];
const _x = new THREE.Vector3(1, 0, 0);
const _y = new THREE.Vector3(0, 1, 0);
const _z = new THREE.Vector3(0, 0, 1);
const _qa = new THREE.Quaternion();
const _qb = new THREE.Quaternion();
const _qc = new THREE.Quaternion();
const _qd = new THREE.Quaternion();

function smooth01(u: number) {
  const t = Math.max(0, Math.min(1, u));
  return t * t * (3 - 2 * t);
}

function sampleArm(phase: number, keys: readonly (readonly [number, number, number, number])[]) {
  const p = Math.max(0, Math.min(1, phase));
  let i = 0;
  while (i < keys.length - 1 && p > keys[i + 1]![0]) i++;
  const a = keys[i]!;
  const b = keys[Math.min(keys.length - 1, i + 1)]!;
  const u = a[0] === b[0] ? 1 : smooth01((p - a[0]) / (b[0] - a[0]));
  return {
    forward: a[1] + (b[1] - a[1]) * u,
    across: a[2] + (b[2] - a[2]) * u,
    up: a[3] + (b[3] - a[3]) * u,
  };
}

const MELEE_MAIN = [
  [0, 0, 0, 0],
  [0.16, -0.25, -0.55, 0.95],
  [0.32, 1.05, 0.95, 0.4],
  [1, 0, 0, 0],
] as const;
const MELEE_OFF = [
  [0, 0, 0, 0],
  [0.16, 0.15, 0.25, 0.2],
  [0.32, -0.35, -0.45, 0.15],
  [1, 0, 0, 0],
] as const;
const SHOT_MAIN = [
  [0, 0, 0, 0],
  [0.2, -0.9, -0.2, 0.55],
  [0.36, 1.15, 0.35, 0.25],
  [1, 0, 0, 0],
] as const;
const SHOT_OFF = [
  [0, 0, 0, 0],
  [0.2, 0.55, 0.1, 0.18],
  [0.55, 0.5, 0.08, 0.12],
  [1, 0, 0, 0],
] as const;
const CAST_ARM = [
  [0, 0, 0, 0],
  [0.28, 0.9, 0.15, 0.8],
  [1, 0, 0, 0],
] as const;
const SLAM_ARM = [
  [0, 0, 0, 0],
  [0.22, 0.15, 0.05, 1.25],
  [0.42, 0.85, 0.2, 0.15],
  [1, 0, 0, 0],
] as const;
const GUARD_ARM = [
  [0, 0, 0, 0],
  [0.3, 0.25, 0.05, 1.2],
  [0.7, 0.2, 0.04, 1.05],
  [1, 0, 0, 0],
] as const;

function addLocal(bone: THREE.Bone | null, axis: THREE.Vector3, angle: number) {
  if (!bone || Math.abs(angle) < 0.0008) return;
  _qd.setFromAxisAngle(axis, angle);
  bone.quaternion.multiply(_qd);
}

function swingBone(model: THREE.Object3D, bone: THREE.Bone | null, pitch: number, yaw: number, lift: number) {
  if (!bone || (Math.abs(pitch) < 0.0008 && Math.abs(yaw) < 0.0008 && Math.abs(lift) < 0.0008)) return;
  const parent = bone.parent;
  if (!parent) return;
  parent.updateWorldMatrix(true, false);
  model.getWorldQuaternion(_qa);
  bone.getWorldQuaternion(_qb);
  _qc.copy(_qa).invert().multiply(_qb);
  _qa.setFromAxisAngle(_x, pitch);
  _qb.setFromAxisAngle(_z, lift);
  _qd.setFromAxisAngle(_y, yaw);
  _qa.premultiply(_qb);
  _qa.premultiply(_qd);
  _qc.premultiply(_qa);
  model.getWorldQuaternion(_qa);
  _qb.copy(_qa).multiply(_qc);
  parent.getWorldQuaternion(_qa);
  bone.quaternion.copy(_qa.invert()).multiply(_qb);
  bone.updateWorldMatrix(false, false);
}

function swingArm(
  model: THREE.Object3D,
  side: 1 | -1,
  clav: THREE.Bone | null,
  upper: THREE.Bone | null,
  fore: THREE.Bone | null,
  forward: number,
  across: number,
  up: number,
) {
  const pitch = -forward;
  const yaw = side === 1 ? -across : across;
  const lift = side === 1 ? up : -up;
  swingBone(model, clav, pitch * 0.28, yaw * 0.28, lift * 0.28);
  swingBone(model, upper, pitch, yaw, lift);
  swingBone(model, fore, pitch * 0.34, yaw * 0.22, lift * 0.16);
}

function grabBone(root: THREE.Object3D, name: string) {
  let found: THREE.Bone | null = null;
  root.traverse((obj) => {
    const bone = obj as THREE.Bone;
    if (bone.isBone && bone.name === name) found = bone;
  });
  return found;
}

export function createHerald(champ: ChampId, team: number): HeraldActor | null {
  if (!template) return null;
  const model = cloneSkinned(template);
  model.scale.setScalar(scale);
  model.position.y = foot;
  const mats: THREE.MeshStandardMaterial[] = [];
  model.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (!mesh.isMesh) return;
    const src = mesh.material as THREE.MeshStandardMaterial;
    const mat = src.clone();
    mat.color = new THREE.Color(TINT[champ]);
    if (team === 1) mat.color.multiply(new THREE.Color(0xe7a098));
    mesh.material = mat;
    mesh.castShadow = false;
    mesh.receiveShadow = false;
    mesh.frustumCulled = true;
    mats.push(mat);
  });
  const root = new THREE.Group();
  root.add(model);
  const mixer = new THREE.AnimationMixer(model);
  const actions: Partial<Record<Mode, THREE.AnimationAction>> = {};
  for (const clip of clips) {
    const name = clip.name as Mode;
    if (name !== "walk" && name !== "run" && name !== "jump" && name !== "crouch" && name !== "sit") continue;
    const action = mixer.clipAction(clip);
    action.enabled = true;
    if (name === "jump" || name === "sit") {
      action.setLoop(THREE.LoopOnce, 1);
      action.clampWhenFinished = true;
    } else {
      action.setLoop(THREE.LoopRepeat, Infinity);
    }
    actions[name] = action;
  }
  const walk = actions.walk;
  if (walk) {
    walk.play();
    walk.time = walk.getClip().duration * 0.22;
    walk.paused = true;
    mixer.update(0);
  }
  let current: Mode = "idle";
  let clipName: Mode = "walk";
  let flashed = false;
  let lodDebt = 0;
  let twistSm = 0;
  const spineA = grabBone(model, "bone_1");
  const spineB = grabBone(model, "bone_2");
  const chest = grabBone(model, "bone_3");
  const clavL = grabBone(model, "bone_6");
  const armL = grabBone(model, "bone_7");
  const foreL = grabBone(model, "bone_8");
  const clavR = grabBone(model, "bone_25");
  const armR = grabBone(model, "bone_26");
  const foreR = grabBone(model, "bone_27");

  function play(nextMode: Mode) {
    const nextClip: Mode = nextMode === "idle" ? "walk" : nextMode;
    const action = actions[nextClip];
    if (!action) return;
    if (nextClip !== clipName) {
      const prev = actions[clipName === "idle" ? "walk" : clipName];
      action.reset();
      if (nextClip === "jump" || nextClip === "sit") {
        action.setLoop(THREE.LoopOnce, 1);
        action.clampWhenFinished = true;
      }
      action.fadeIn(0.16).play();
      prev?.fadeOut(0.16);
      clipName = nextClip;
    }
    if (nextMode === "idle") action.paused = true;
    else {
      action.paused = false;
      action.timeScale = nextMode === "run" ? 1.15 : nextMode === "crouch" ? 0.75 : 1;
    }
    current = nextMode;
  }

  return {
    object: root,
    step(pose, dt, dist = 0) {
      const next = modeOf(pose);
      if (next !== current) play(next);
      else if (actions[clipName]) {
        const action = actions[clipName]!;
        if (next === "walk") action.timeScale = Math.min(1.35, Math.max(0.7, pose.vel / 3.5));
        else if (next === "run") action.timeScale = Math.min(1.4, Math.max(0.85, pose.vel / 6.4));
        if (pose.attackAnim > 0 && pose.vel > 0.45 && (next === "walk" || next === "run")) {
          action.timeScale *= 1.08;
        }
      }
      const budget = dist > 52 ? 0.28 : dist > 30 ? 0.08 : 0;
      if (budget > 0) {
        lodDebt += dt;
        if (lodDebt < budget) return;
        dt = lodDebt;
        lodDebt = 0;
      } else lodDebt = 0;
      mixer.update(Math.min(dt, 0.08));
      const fullBody = next === "jump" || next === "sit" || !pose.alive;
      const k = 1 - Math.exp(-14 * dt);
      const twistTarget = fullBody ? 0 : Math.max(-1.05, Math.min(1.05, pose.twist));
      twistSm += (twistTarget - twistSm) * k;
      if (!fullBody && (Math.abs(twistSm) > 0.012 || pose.attackAnim > 0.001)) {
        const len = SWING_LEN[pose.swing] ?? 0.46;
        const phase = pose.attackAnim > 0 ? Math.max(0, Math.min(1, 1 - pose.attackAnim / len)) : 1;
        const swinging = pose.attackAnim > 0.001;
        let pitch = 0;
        let whip = 0;
        let main = { forward: 0, across: 0, up: 0 };
        let off = main;
        if (swinging) {
          const swing = pose.swing;
          const mainKeys = swing === 1 ? SHOT_MAIN : swing === 2 ? CAST_ARM : swing === 3 ? SLAM_ARM : swing === 4 ? GUARD_ARM : MELEE_MAIN;
          const offKeys = swing === 1 ? SHOT_OFF : swing === 0 ? MELEE_OFF : mainKeys;
          main = sampleArm(phase, mainKeys);
          off = sampleArm(phase, offKeys);
          pitch = swing === 3 ? main.forward * 0.34 : swing === 4 ? -0.16 * main.up : swing === 2 ? -0.1 * main.up : main.forward * 0.2;
          whip = swing === 0 ? main.across * 0.14 : 0;
        }
        addLocal(spineA, _y, twistSm * 0.16);
        addLocal(spineB, _y, twistSm * 0.34);
        addLocal(chest, _y, twistSm * 0.5 + whip);
        addLocal(chest, _x, pitch);
        addLocal(chest, _z, -twistSm * 0.07);
        if (swinging && dist < 46) {
          swingArm(model, -1, clavR, armR, foreR, main.forward, main.across, main.up);
          swingArm(model, 1, clavL, armL, foreL, off.forward, off.across, off.up);
        }
        const align = Math.max(0, 1 - Math.abs(twistSm) / 1.15);
        const weight = swinging ? Math.sin(Math.min(1, phase) * Math.PI) : Math.min(1, Math.abs(twistSm));
        model.position.set(-Math.sin(twistSm) * 0.035 * (swinging ? 1 : 0.65), foot - (swinging ? weight * (pose.swing === 3 ? 0.05 : 0.028) : 0), swinging ? weight * 0.07 * align : 0);
      } else {
        model.position.set(0, foot, 0);
      }
      const hot = pose.hitFlash > 0;
      if (hot !== flashed) {
        flashed = hot;
        for (const mat of mats) {
          mat.emissive.setHex(hot ? 0xfff1d0 : 0x000000);
          mat.emissiveIntensity = hot ? 0.45 : 0;
        }
      }
    },
    dispose() {
      mixer.stopAllAction();
      for (const mat of mats) mat.dispose();
    },
  };
}
