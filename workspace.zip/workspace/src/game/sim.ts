import {
  ALLY_NAMES,
  CHAMPS,
  ENEMY_NAMES,
  ITEMS,
  otherChamps,
  type AbilityDef,
  type ChampId,
  type ItemId,
} from "@/game/content";
import {
  BOSS,
  CAMPS,
  FOUNTAINS,
  LANES,
  LANE_NAMES,
  NEXUS,
  SHRINES,
  TOWERS,
  clampWorld,
  heroSpawn,
  pushOutOfTrees,
  type CampSite,
  type TeamId,
} from "@/game/terrain";

export type Phase = "menu" | "play" | "pause" | "victory" | "defeat";

export interface SimEvent {
  type: "hit" | "cast" | "kill" | "announce" | "level" | "tower" | "end" | "die";
  text?: string;
  big?: boolean;
  kind?: string;
  win?: boolean;
}

export interface Ent {
  id: number;
  alive: boolean;
  kind: "hero" | "minion" | "tower" | "nexus" | "creep" | "boss";
  team: TeamId;
  name: string;
  x: number;
  z: number;
  yaw: number;
  radius: number;
  hp: number;
  maxHp: number;
  mana: number;
  maxMana: number;
  speed: number;
  ad: number;
  ap: number;
  armor: number;
  level: number;
  xp: number;
  gold: number;
  atkRange: number;
  atkCd: number;
  atkTimer: number;
  champ: ChampId | null;
  cds: number[];
  slowT: number;
  shield: number;
  shieldT: number;
  hasteT: number;
  lifestealT: number;
  teamBuffT: number;
  lane: number;
  wp: number;
  dir: number;
  homeX: number;
  homeZ: number;
  leash: number;
  aggro: boolean;
  focus: number;
  respawn: number;
  hitFlash: number;
  attackAnim: number;
  /** Where the chest should look. Hips stay on `yaw`. */
  faceYaw: number;
  /** 0 slash, 1 shot, 2 cast, 3 slam, 4 guard. */
  swing: number;
  windup: number;
  windTarget: number;
  windDmg: number;
  vel: number;
  lastAttacker: number;
  recent: { id: number; t: number }[];
  itemCounts: number[];
  kills: number;
  deaths: number;
  assists: number;
  cs: number;
  baseHp: number;
  baseMana: number;
  baseAd: number;
  baseSpeed: number;
  baseArmor: number;
  player: boolean;
  specialT: number;
  dashT: number;
  dashVX: number;
  dashVZ: number;
  dashDmg: number;
  dashHits: number[];
  ranged: boolean;
  tier: number;
  campId: string;
  creepKind: "wolf" | "golem" | "spirit" | "boss" | "";
  aiCast: number;
}

export interface Proj {
  alive: boolean;
  team: TeamId;
  x: number;
  z: number;
  vx: number;
  vz: number;
  dmg: number;
  life: number;
  radius: number;
  owner: number;
  kind: string;
  pierce: boolean;
  slow: number;
  hits: number[];
}

export interface Ring {
  alive: boolean;
  x: number;
  z: number;
  r: number;
  life: number;
  max: number;
  color: number;
}

export interface Trap {
  alive: boolean;
  team: TeamId;
  x: number;
  z: number;
  life: number;
  arm: number;
  dmg: number;
  owner: number;
  radius: number;
  slow: number;
}

export interface FloatText {
  alive: boolean;
  x: number;
  z: number;
  y: number;
  text: string;
  life: number;
  color: string;
}

export interface InputState {
  wishX: number;
  wishZ: number;
  aimX: number;
  aimZ: number;
  attack: boolean;
  cast: number;
}

interface CampRt extends CampSite {
  ids: number[];
  down: boolean;
  timer: number;
}

interface Strike {
  t: number;
  x: number;
  z: number;
  r: number;
  dmg: number;
  owner: number;
  slow: number;
}

interface ShrineRt {
  id: string;
  x: number;
  z: number;
  name: string;
  kind: "haste" | "lifesteal" | "shield";
  ready: number;
  channel: number;
}

const STEP_CAP_MINIONS = 48;

function makeEnt(p: Partial<Ent> & Pick<Ent, "kind" | "team" | "name">, id: number): Ent {
  const e: Ent = {
    id,
    alive: true,
    x: 0,
    z: 0,
    yaw: 0,
    radius: 0.55,
    hp: 100,
    maxHp: 100,
    mana: 0,
    maxMana: 0,
    speed: 0,
    ad: 10,
    ap: 0,
    armor: 0,
    level: 1,
    xp: 0,
    gold: 0,
    atkRange: 1.6,
    atkCd: 1,
    atkTimer: 0,
    champ: null,
    cds: [0, 0, 0, 0],
    slowT: 0,
    shield: 0,
    shieldT: 0,
    hasteT: 0,
    lifestealT: 0,
    teamBuffT: 0,
    lane: 0,
    wp: 0,
    dir: 1,
    homeX: 0,
    homeZ: 0,
    leash: 14,
    aggro: false,
    focus: -1,
    respawn: 0,
    hitFlash: 0,
    attackAnim: 0,
    faceYaw: 0,
    swing: 0,
    windup: 0,
    windTarget: -1,
    windDmg: 0,
    vel: 0,
    lastAttacker: -1,
    recent: [],
    itemCounts: [0, 0, 0, 0],
    kills: 0,
    deaths: 0,
    assists: 0,
    cs: 0,
    baseHp: 100,
    baseMana: 0,
    baseAd: 10,
    baseSpeed: 3,
    baseArmor: 0,
    player: false,
    specialT: 4,
    dashT: 0,
    dashVX: 0,
    dashVZ: 0,
    dashDmg: 0,
    dashHits: [],
    ranged: false,
    tier: 0,
    campId: "",
    creepKind: "",
    aiCast: 0,
    ...p,
  };
  e.faceYaw = p.faceYaw ?? e.yaw;
  return e;
}

export interface Sim {
  ents: Ent[];
  projs: Proj[];
  rings: Ring[];
  traps: Trap[];
  floats: FloatText[];
  phase: Phase;
  time: number;
  events: SimEvent[];
  dawnKills: number;
  duskKills: number;
  wave: number;
  shrines: ShrineRt[];
  player: () => Ent;
  nearFountain: (e?: Ent) => boolean;
  setPreview: (id: ChampId) => void;
  start: (id: ChampId) => void;
  togglePause: () => void;
  step: (dt: number, input: InputState) => void;
  buy: (id: ItemId) => boolean;
  towersUp: (team: 0 | 1) => number;
}

export function createSim(): Sim {
  let nextId = 1;
  const ents: Ent[] = [];
  const projs: Proj[] = Array.from({ length: 48 }, () => deadProj());
  const rings: Ring[] = Array.from({ length: 20 }, () => ({
    alive: false,
    x: 0,
    z: 0,
    r: 1,
    life: 0,
    max: 1,
    color: 0xe4b15a,
  }));
  const traps: Trap[] = Array.from({ length: 8 }, () => ({
    alive: false,
    team: 0 as TeamId,
    x: 0,
    z: 0,
    life: 0,
    arm: 0,
    dmg: 0,
    owner: -1,
    radius: 2,
    slow: 1.2,
  }));
  const floats: FloatText[] = Array.from({ length: 28 }, () => ({
    alive: false,
    x: 0,
    z: 0,
    y: 2,
    text: "",
    life: 0,
    color: "#e7efe6",
  }));
  let floatCursor = 0;
  const camps: CampRt[] = CAMPS.map((c) => ({ ...c, ids: [], down: false, timer: -1 }));
  const shrines: ShrineRt[] = SHRINES.map((s) => ({ ...s, ready: 0, channel: 0 }));
  let phase: Phase = "menu";
  let time = 0;
  let waveT = 6;
  let wave = 0;
  let dawnKills = 0;
  let duskKills = 0;
  const events: SimEvent[] = [];
  const strikes: Strike[] = [];
  let player: Ent;

  function deadProj(): Proj {
    return {
      alive: false,
      team: 0,
      x: 0,
      z: 0,
      vx: 0,
      vz: 0,
      dmg: 0,
      life: 0,
      radius: 0.4,
      owner: -1,
      kind: "bolt",
      pierce: false,
      slow: 0,
      hits: [],
    };
  }

  function byId(id: number): Ent | null {
    for (const e of ents) if (e.id === id) return e;
    return null;
  }

  function add(p: Partial<Ent> & Pick<Ent, "kind" | "team" | "name">): Ent {
    const e = makeEnt(p, nextId++);
    ents.push(e);
    return e;
  }

  function announce(text: string) {
    events.push({ type: "announce", text });
  }

  function applyBuild(e: Ent) {
    const blade = e.itemCounts[0] ?? 0;
    const heart = e.itemCounts[1] ?? 0;
    const arc = e.itemCounts[2] ?? 0;
    const boots = e.itemCounts[3] ?? 0;
    const lv = e.level - 1;
    e.maxHp = e.baseHp + lv * 52 + heart * 150;
    e.maxMana = e.baseMana + lv * 22 + arc * 45;
    e.ad = e.baseAd + lv * 6 + blade * 16;
    e.ap = lv * 5 + arc * 26;
    e.speed = e.baseSpeed + boots * 1.05;
    e.armor = e.baseArmor + heart * 4;
    e.hp = Math.min(e.hp, e.maxHp);
    e.mana = Math.min(e.mana, e.maxMana);
  }

  function applyChamp(e: Ent, id: ChampId, gold: number) {
    const def = CHAMPS[id];
    e.champ = id;
    e.baseHp = def.hp;
    e.baseMana = def.mana;
    e.baseAd = def.ad;
    e.baseSpeed = def.speed;
    e.baseArmor = e.player ? 14 : 12;
    e.atkRange = def.range;
    e.atkCd = def.range > 4 ? 0.92 : 0.7;
    e.ranged = def.range > 4;
    e.radius = 0.55;
    e.level = 1;
    e.xp = 0;
    e.gold = gold;
    e.itemCounts = [0, 0, 0, 0];
    e.cds = [0, 0, 0, 0];
    e.kills = 0;
    e.deaths = 0;
    e.assists = 0;
    e.cs = 0;
    applyBuild(e);
    e.hp = e.maxHp;
    e.mana = e.maxMana;
  }

  function placeHero(e: Ent, which: "player" | "ally" | "enemy", index: number) {
    const s = heroSpawn(which, index);
    e.x = s.x;
    e.z = s.z;
    e.homeX = s.x;
    e.homeZ = s.z;
    e.yaw = s.yaw;
    e.faceYaw = s.yaw;
    e.lane = s.lane;
    e.wp = which === "enemy" ? LANES[s.lane]!.length - 1 : 0;
    e.dir = which === "enemy" ? -1 : 1;
    e.alive = true;
    e.respawn = 0;
    e.dashT = 0;
    e.slowT = 0;
    e.shield = 0;
    e.aggro = false;
  }

  function bootstrap() {
    for (const t of TOWERS) {
      add({
        kind: "tower",
        team: t.team,
        name: `${t.team === 0 ? "Dawn" : "Dusk"} ${LANE_NAMES[t.lane]} tower`,
        x: t.x,
        z: t.z,
        homeX: t.x,
        homeZ: t.z,
        lane: t.lane,
        tier: t.tier,
        hp: t.tier === 2 ? 1100 : 860,
        maxHp: t.tier === 2 ? 1100 : 860,
        radius: 1.55,
        armor: 22,
        ad: 46,
        atkRange: 9.2,
        atkCd: 0.95,
        atkTimer: 0.4,
      });
    }
    for (const n of NEXUS) {
      add({
        kind: "nexus",
        team: n.team,
        name: n.team === 0 ? "Dawn Conduit" : "Dusk Conduit",
        x: n.x,
        z: n.z,
        homeX: n.x,
        homeZ: n.z,
        hp: 2800,
        maxHp: 2800,
        radius: 2.3,
        armor: 28,
      });
    }
    player = add({
      kind: "hero",
      team: 0,
      name: "Kael",
      player: true,
      gold: 500,
    });
    applyChamp(player, "vanguard", 500);
    placeHero(player, "player", 0);
    const allies = otherChamps("vanguard");
    ALLY_NAMES.forEach((name, i) => {
      const e = add({ kind: "hero", team: 0, name, player: false });
      applyChamp(e, allies[i] ?? "ranger", 500);
      placeHero(e, "ally", i);
    });
    ENEMY_NAMES.forEach((name, i) => {
      const e = add({ kind: "hero", team: 1, name, player: false });
      applyChamp(e, (["vanguard", "arcanist", "ranger"] as ChampId[])[i] ?? "vanguard", 500);
      placeHero(e, "enemy", i);
    });
    const boss = add({
      kind: "boss",
      team: 2,
      name: BOSS.name,
      x: BOSS.x,
      z: BOSS.z,
      homeX: BOSS.x,
      homeZ: BOSS.z,
      hp: 2400,
      maxHp: 2400,
      radius: 1.8,
      armor: 18,
      ad: 42,
      atkRange: 3.1,
      atkCd: 1.15,
      speed: 3.1,
      baseSpeed: 3.1,
      leash: 18,
      creepKind: "boss",
    });
    boss.alive = true;
    for (const camp of camps) spawnCamp(camp);
  }

  function spawnCamp(camp: CampRt) {
    camp.ids = [];
    camp.down = false;
    camp.timer = -1;
    for (let i = 0; i < camp.count; i++) {
      const ang = (i / camp.count) * Math.PI * 2;
      const e = add({
        kind: "creep",
        team: 2,
        name: camp.name,
        x: camp.x + Math.cos(ang) * 1.4,
        z: camp.z + Math.sin(ang) * 1.4,
        homeX: camp.x,
        homeZ: camp.z,
        hp: camp.hp,
        maxHp: camp.hp,
        ad: camp.ad,
        radius: camp.kind === "golem" ? 1.05 : 0.48,
        armor: camp.kind === "golem" ? 10 : 2,
        atkRange: camp.kind === "spirit" ? 6.5 : 1.7,
        atkCd: 1.1,
        speed: camp.kind === "golem" ? 2.6 : 4.2,
        baseSpeed: camp.kind === "golem" ? 2.6 : 4.2,
        ranged: camp.kind === "spirit",
        leash: 12,
        campId: camp.id,
        creepKind: camp.kind,
        yaw: ang,
      });
      camp.ids.push(e.id);
    }
  }

  function resetStructures() {
    for (const e of ents) {
      if (e.kind === "tower" || e.kind === "nexus") {
        e.alive = true;
        e.hp = e.maxHp;
        e.x = e.homeX;
        e.z = e.homeZ;
      }
      if (e.kind === "boss") {
        e.alive = true;
        e.hp = e.maxHp;
        e.x = e.homeX;
        e.z = e.homeZ;
        e.aggro = false;
        e.focus = -1;
        e.respawn = 0;
      }
    }
    for (let i = ents.length - 1; i >= 0; i--) {
      const e = ents[i];
      if (e && (e.kind === "minion" || e.kind === "creep")) ents.splice(i, 1);
    }
    for (const c of camps) spawnCamp(c);
    for (const p of projs) p.alive = false;
    for (const t of traps) t.alive = false;
    for (const r of rings) r.alive = false;
    strikes.length = 0;
    for (const s of shrines) {
      s.ready = 0;
      s.channel = 0;
    }
  }

  function ring(x: number, z: number, r: number, color: number, life: number) {
    const slot = rings.find((n) => !n.alive) ?? rings[0];
    if (!slot) return;
    slot.alive = true;
    slot.x = x;
    slot.z = z;
    slot.r = r;
    slot.life = life;
    slot.max = life;
    slot.color = color;
  }

  function floater(x: number, z: number, text: string, color: string) {
    const f = floats[floatCursor % floats.length];
    floatCursor++;
    if (!f) return;
    f.alive = true;
    f.x = x;
    f.z = z;
    f.y = 2.1;
    f.text = text;
    f.life = 0.85;
    f.color = color;
  }

  function launch(
    owner: Ent,
    x: number,
    z: number,
    tx: number,
    tz: number,
    speed: number,
    dmg: number,
    kind: string,
    opts?: { pierce?: boolean; slow?: number; radius?: number; life?: number },
  ) {
    const p = projs.find((n) => !n.alive);
    if (!p) return;
    const dx = tx - x;
    const dz = tz - z;
    const len = Math.hypot(dx, dz) || 1;
    p.alive = true;
    p.team = owner.team;
    p.x = x;
    p.z = z;
    p.vx = (dx / len) * speed;
    p.vz = (dz / len) * speed;
    p.dmg = dmg;
    p.life = opts?.life ?? 1.35;
    p.radius = opts?.radius ?? 0.42;
    p.owner = owner.id;
    p.kind = kind;
    p.pierce = !!opts?.pierce;
    p.slow = opts?.slow ?? 0;
    p.hits.length = 0;
  }

  function hostilePair(a: Ent, b: Ent): boolean {
    if (!b.alive || a.id === b.id) return false;
    if (a.team === b.team) return false;
    if (a.team === 2 && b.team === 2) return false;
    if (b.team === 2 && (a.kind === "tower" || a.kind === "minion" || a.kind === "nexus")) return false;
    if (a.team === 2 && (b.kind === "tower" || b.kind === "minion" || b.kind === "nexus")) return false;
    return true;
  }

  function dist(a: Ent, b: Ent) {
    return Math.hypot(a.x - b.x, a.z - b.z);
  }

  function noteRecent(target: Ent, id: number) {
    const found = target.recent.find((r) => r.id === id);
    if (found) found.t = time;
    else target.recent.push({ id, t: time });
    if (target.recent.length > 6) target.recent.shift();
  }

  function grantXp(e: Ent, amount: number) {
    if (e.kind !== "hero" || !e.alive) return;
    e.xp += amount;
    let guard = 0;
    while (e.level < 12 && e.xp >= 70 + e.level * 36 && guard++ < 12) {
      e.xp -= 70 + e.level * 36;
      e.level += 1;
      const before = e.maxHp;
      applyBuild(e);
      e.hp = Math.min(e.maxHp, e.hp + (e.maxHp - before));
      e.mana = Math.min(e.maxMana, e.mana + 22);
      if (e.player) {
        events.push({ type: "level" });
        announce(`Level ${e.level}`);
        floater(e.x, e.z, `Level ${e.level}`, "#e4b15a");
      }
    }
  }

  function hurt(target: Ent, raw: number, attacker: Ent | null, slow = 0) {
    if (!target.alive || raw <= 0 || phase !== "play") return;
    let amount = raw;
    if (attacker && attacker.teamBuffT > 0) amount *= 1.18;
    if (target.kind === "nexus") {
      const covered = ents.some((t) => t.alive && t.kind === "tower" && t.team === target.team);
      if (covered) amount *= 0.3;
    }
    const mitigated = amount * (100 / (100 + Math.max(0, target.armor)));
    let rest = mitigated;
    if (target.shield > 0) {
      const used = Math.min(target.shield, rest);
      target.shield -= used;
      rest -= used;
    }
    target.hp -= rest;
    target.hitFlash = 0.14;
    if (attacker) {
      target.lastAttacker = attacker.id;
      noteRecent(target, attacker.id);
      if (attacker.lifestealT > 0 && attacker.alive) {
        attacker.hp = Math.min(attacker.maxHp, attacker.hp + rest * 0.25);
      }
      if (target.team === 2) {
        target.aggro = true;
        target.focus = attacker.id;
      }
    }
    if (slow > 0) target.slowT = Math.max(target.slowT, slow);
    if (rest > 8) {
      floater(
        target.x,
        target.z,
        `${Math.round(rest)}`,
        attacker?.player ? "#f2d7a2" : target.player ? "#d4524a" : "#e7efe6",
      );
    }
    events.push({ type: "hit", big: rest > 80 });
    if (target.hp <= 0) onDeath(target, attacker);
  }

  function onDeath(target: Ent, attacker: Ent | null) {
    target.alive = false;
    target.hp = 0;
    target.dashT = 0;
    target.shield = 0;
    target.windup = 0;
    events.push({ type: "die" });
    if (target.kind === "hero") {
      target.deaths += 1;
      target.respawn = 5 + target.level * 1.15;
      if (target.team === 0) duskKills += 1;
      else dawnKills += 1;
      if (attacker && attacker.kind === "hero" && attacker.team !== target.team) {
        attacker.kills += 1;
        attacker.gold += 150 + target.level * 14;
        grantXp(attacker, 100 + target.level * 12);
        floater(attacker.x, attacker.z, `+${150 + target.level * 14}g`, "#e4b15a");
        for (const rec of target.recent) {
          if (rec.id === attacker.id || time - rec.t > 8) continue;
          const ally = byId(rec.id);
          if (ally && ally.alive && ally.kind === "hero" && ally.team === attacker.team) {
            ally.assists += 1;
            ally.gold += 70;
            grantXp(ally, 48);
          }
        }
        events.push({
          type: "kill",
          text: `${attacker.name} felled ${target.name}`,
        });
      } else {
        events.push({ type: "kill", text: `${target.name} has fallen` });
      }
      if (target.player) announce("Slain — the conduit calls you back");
      return;
    }
    if (target.kind === "minion") {
      if (attacker && attacker.kind === "hero" && attacker.team !== target.team) {
        attacker.gold += 22;
        attacker.cs += 1;
        grantXp(attacker, 26);
      }
      return;
    }
    if (target.kind === "creep") {
      if (attacker && attacker.kind === "hero") {
        attacker.gold += 34;
        attacker.cs += 1;
        grantXp(attacker, 40);
        floater(target.x, target.z, "+34g", "#e4b15a");
      }
      const camp = camps.find((c) => c.id === target.campId);
      if (camp) {
        camp.ids = camp.ids.filter((id) => id !== target.id);
        if (camp.ids.length === 0) {
          camp.down = true;
          camp.timer = 32;
        }
      }
      return;
    }
    if (target.kind === "boss") {
      target.respawn = 80;
      announce("The Rift Colossus falls — spoils to the slayer's side");
      if (attacker) {
        const team = attacker.team === 2 ? 0 : attacker.team;
        for (const e of ents) {
          if (e.kind === "hero" && e.team === team) {
            e.gold += e.id === attacker.id ? 220 : 80;
            e.teamBuffT = Math.max(e.teamBuffT, 22);
            grantXp(e, e.id === attacker.id ? 160 : 70);
          }
        }
        floater(target.x, target.z, "Colossus down", "#e4b15a");
      }
      return;
    }
    if (target.kind === "tower") {
      events.push({ type: "tower" });
      announce(`${target.name} has fallen`);
      const team = attacker && attacker.team !== 2 ? attacker.team : target.team === 0 ? 1 : 0;
      for (const e of ents) {
        if (e.kind === "hero" && e.team === team && e.alive) {
          e.gold += e.id === attacker?.id ? 160 : 90;
          grantXp(e, 80);
        }
      }
      return;
    }
    if (target.kind === "nexus") {
      const win = target.team === 1;
      phase = win ? "victory" : "defeat";
      events.push({
        type: "end",
        win,
        text: win ? "The Dusk Conduit shatters" : "The Dawn Conduit has fallen",
      });
      announce(win ? "Victory — the rift is yours" : "Defeat — dusk swallows the dawn");
    }
  }

  function reviveHero(e: Ent) {
    e.alive = true;
    applyBuild(e);
    e.hp = e.maxHp;
    e.mana = e.maxMana;
    e.x = e.homeX;
    e.z = e.homeZ;
    e.yaw = e.team === 0 ? 0 : Math.PI;
    e.faceYaw = e.yaw;
    e.windup = 0;
    e.cds = [0, 0, 0, 0];
    e.slowT = 0;
    e.shield = 0;
    e.dashT = 0;
    e.respawn = 0;
    if (e.player) announce("You return at the Dawn fountain");
  }

  function moveToward(e: Ent, tx: number, tz: number, dt: number, face = true): number | null {
    const dx = tx - e.x;
    const dz = tz - e.z;
    const len = Math.hypot(dx, dz);
    if (len < 0.2) {
      e.vel = 0;
      return null;
    }
    const slow = e.slowT > 0 ? 0.55 : 1;
    const haste = e.hasteT > 0 ? 1.28 : 1;
    const spd = e.speed * slow * haste;
    const step = Math.min(len, spd * dt);
    const mx = dx / len;
    const mz = dz / len;
    e.x += mx * step;
    e.z += mz * step;
    const my = Math.atan2(-mx, -mz);
    if (face) e.yaw = dampAngle(e.yaw, my, 8, dt);
    e.vel = step / dt;
    return my;
  }

  function separate(e: Ent) {
    let x = e.x;
    let z = e.z;
    for (const o of ents) {
      if (!o.alive || o.id === e.id) continue;
      if (o.kind === "minion" && e.kind === "minion") continue;
      const min = e.radius + (o.kind === "tower" || o.kind === "nexus" ? o.radius : o.kind === "hero" ? o.radius * 0.85 : 0);
      if (min <= 0) continue;
      if (o.kind !== "tower" && o.kind !== "nexus" && o.kind !== "hero" && o.kind !== "boss") continue;
      const dx = x - o.x;
      const dz = z - o.z;
      const d = Math.hypot(dx, dz);
      if (d < min && d > 0.0001) {
        x += (dx / d) * (min - d);
        z += (dz / d) * (min - d);
      }
    }
    if (e.kind === "hero") {
      const pushed = pushOutOfTrees(x, z, e.radius);
      x = pushed.x;
      z = pushed.z;
    }
    const c = clampWorld(x, z);
    e.x = c.x;
    e.z = c.z;
  }

  function tryHit(attacker: Ent, target: Ent) {
    if (attacker.atkTimer > 0 || !target.alive) return;
    const d = dist(attacker, target);
    if (d > attacker.atkRange + target.radius * 0.4) return;
    attacker.atkTimer = attacker.atkCd;
    const face = Math.atan2(-(target.x - attacker.x), -(target.z - attacker.z));
    const dmg = attacker.ad;
    if (attacker.kind === "hero") {
      const casting = attacker.swing >= 2 && attacker.attackAnim > 0.12;
      if (!casting) {
        attacker.attackAnim = 0.46;
        attacker.swing = attacker.ranged ? 1 : 0;
        attacker.faceYaw = face;
      }
      attacker.windup = attacker.ranged ? 0.16 : 0.14;
      attacker.windTarget = target.id;
      attacker.windDmg = dmg;
      return;
    }
    attacker.attackAnim = 0.28;
    attacker.yaw = face;
    if (attacker.ranged || attacker.kind === "tower") {
      launch(attacker, attacker.x, attacker.z, target.x, target.z, attacker.kind === "tower" ? 16 : 20, dmg, "shot", {
        radius: 0.35,
        life: 1.1,
      });
    } else {
      hurt(target, dmg, attacker);
    }
  }

  function connectSwing(e: Ent) {
    if (!e.alive) return;
    const target = byId(e.windTarget);
    if (!target || !target.alive || !hostilePair(e, target)) return;
    const reach = e.atkRange + target.radius + (e.ranged ? 2.4 : 1.45);
    if (dist(e, target) > reach) return;
    if (e.ranged) {
      launch(e, e.x, e.z, target.x, target.z, 20, e.windDmg, "shot", { radius: 0.35, life: 1.1 });
    } else {
      hurt(target, e.windDmg, e);
    }
  }

  function nearest(e: Ent, range: number, filter: (o: Ent) => boolean): Ent | null {
    let best: Ent | null = null;
    let bestD = range;
    for (const o of ents) {
      if (!filter(o)) continue;
      const d = dist(e, o);
      if (d < bestD) {
        bestD = d;
        best = o;
      }
    }
    return best;
  }

  function tickHeroPlayer(e: Ent, input: InputState, dt: number) {
    if (!e.alive) return;
    for (let i = 0; i < 4; i++) e.cds[i] = Math.max(0, (e.cds[i] ?? 0) - dt);
    const ox = e.x;
    const oz = e.z;
    let moveYaw: number | null = null;
    let dashing = false;
    if (e.dashT > 0) {
      dashing = true;
      e.dashT -= dt;
      e.x += e.dashVX * dt;
      e.z += e.dashVZ * dt;
      moveYaw = Math.atan2(-e.dashVX, -e.dashVZ);
      for (const o of ents) {
        if (!hostilePair(e, o) || e.dashHits.includes(o.id)) continue;
        if (Math.hypot(o.x - e.x, o.z - e.z) < o.radius + 1.25) {
          e.dashHits.push(o.id);
          hurt(o, e.dashDmg, e, 0.35);
        }
      }
    } else {
      const len = Math.hypot(input.wishX, input.wishZ);
      if (len > 0.08) {
        const slow = e.slowT > 0 ? 0.55 : 1;
        const haste = e.hasteT > 0 ? 1.28 : 1;
        const spd = e.speed * slow * haste;
        const mx = input.wishX / len;
        const mz = input.wishZ / len;
        e.x += mx * spd * dt;
        e.z += mz * spd * dt;
        moveYaw = Math.atan2(-mx, -mz);
      }
    }
    separate(e);
    e.vel = Math.hypot(e.x - ox, e.z - oz) / dt;
    if (input.cast >= 0) cast(e, input.cast, input.aimX, input.aimZ);
    let aim: number | null = null;
    const tgt = input.attack || e.attackAnim > 0.02 ? acquirePlayerTarget(e, input.aimX, input.aimZ) : null;
    if (input.attack && tgt) tryHit(e, tgt);
    if (e.swing >= 2 && e.attackAnim > 0.08) aim = e.faceYaw;
    else if (tgt && (input.attack || e.attackAnim > 0.02)) aim = Math.atan2(-(tgt.x - e.x), -(tgt.z - e.z));
    else if (e.attackAnim > 0.02) aim = e.faceYaw;
    if ((dashing || e.dashT > 0) && e.dashVX * e.dashVX + e.dashVZ * e.dashVZ > 1) {
      const face = Math.atan2(-e.dashVX, -e.dashVZ);
      e.yaw = dampAngle(e.yaw, face, 14, dt);
      e.faceYaw = e.yaw;
      return;
    }
    settleBody(e, moveYaw, aim, dt);
  }

  function acquirePlayerTarget(e: Ent, aimX: number, aimZ: number): Ent | null {
    let best: Ent | null = null;
    let bestScore = 2.6;
    let fallback: Ent | null = null;
    let fallbackD = e.atkRange + 0.8;
    for (const o of ents) {
      if (!hostilePair(e, o)) continue;
      const dSelf = dist(e, o);
      const dAim = Math.hypot(o.x - aimX, o.z - aimZ);
      if (dSelf <= e.atkRange + o.radius * 0.35 && dAim < bestScore) {
        best = o;
        bestScore = dAim;
      }
      if (dSelf < fallbackD) {
        fallback = o;
        fallbackD = dSelf;
      }
    }
    return best ?? fallback;
  }

  function cast(e: Ent, slot: number, aimX: number, aimZ: number) {
    if (!e.champ || !e.alive) return;
    const def = CHAMPS[e.champ].abilities[slot];
    if (!def) return;
    if ((e.cds[slot] ?? 0) > 0 || e.mana < def.mana) return;
    e.mana -= def.mana;
    e.cds[slot] = def.cd * Math.max(0.7, 1 - (e.level - 1) * 0.02);
    const dmg = (def.dmg + e.ap * 0.55 + e.level * 3) * (e.teamBuffT > 0 ? 1.18 : 1);
    const dx = aimX - e.x;
    const dz = aimZ - e.z;
    const len = Math.hypot(dx, dz);
    const fx = len > 0.4 ? dx / len : -Math.sin(e.yaw);
    const fz = len > 0.4 ? dz / len : -Math.cos(e.yaw);
    events.push({ type: "cast", kind: def.kind });
    if (def.kind !== "dash") {
      e.faceYaw = Math.atan2(-fx, -fz);
      e.swing = def.kind === "buff" ? 4 : def.kind === "aoe" || def.kind === "cone" ? 3 : 2;
      e.attackAnim = e.swing === 3 ? 0.5 : 0.44;
    }
    if (def.kind === "dash") {
      const dist = Math.min(def.range, Math.max(3.5, len));
      e.dashT = dist / def.speed;
      e.dashVX = fx * def.speed;
      e.dashVZ = fz * def.speed;
      e.dashDmg = dmg;
      e.dashHits = [];
      e.yaw = Math.atan2(-fx, -fz);
      e.faceYaw = e.yaw;
      ring(e.x, e.z, 1.2, 0xe4b15a, 0.25);
      return;
    }
    if (def.kind === "aoe") {
      ring(e.x, e.z, def.radius, e.team === 0 ? 0xe4b15a : 0xd4524a, 0.35);
      for (const o of ents) {
        if (!hostilePair(e, o)) continue;
        if (dist(e, o) <= def.radius + o.radius) hurt(o, dmg, e, 0.8);
      }
      return;
    }
    if (def.kind === "buff") {
      e.shield = 90 + e.level * 14 + e.ap * 0.4;
      e.shieldT = 4.5;
      e.hasteT = Math.max(e.hasteT, 3.2);
      ring(e.x, e.z, 1.6, 0xe4b15a, 0.4);
      floater(e.x, e.z, "Shield", "#e4b15a");
      return;
    }
    if (def.kind === "projectile") {
      const reach = def.range;
      const tx = e.x + fx * reach;
      const tz = e.z + fz * reach;
      const slow = def.name === "Frost Bind" ? 1.4 : 0;
      launch(e, e.x, e.z, tx, tz, def.speed, dmg, def.name === "Piercing Shot" ? "pierce" : "bolt", {
        pierce: def.name === "Piercing Shot",
        slow,
        radius: 0.48,
        life: reach / def.speed + 0.05,
      });
      return;
    }
    if (def.kind === "cone") {
      ring(e.x + fx * 2, e.z + fz * 2, 1.4, 0x7dbe6a, 0.25);
      for (const o of ents) {
        if (!hostilePair(e, o)) continue;
        const ox = o.x - e.x;
        const oz = o.z - e.z;
        const od = Math.hypot(ox, oz);
        if (od > def.range + o.radius) continue;
        const dot = (ox / (od || 1)) * fx + (oz / (od || 1)) * fz;
        if (dot > 0.62) hurt(o, dmg, e);
      }
      return;
    }
    if (def.kind === "trap") {
      const slotT = traps.find((t) => !t.alive);
      if (slotT) {
        slotT.alive = true;
        slotT.team = e.team;
        slotT.x = e.x + fx * 1.5;
        slotT.z = e.z + fz * 1.5;
        slotT.life = 7;
        slotT.arm = 0.55;
        slotT.dmg = dmg;
        slotT.owner = e.id;
        slotT.radius = def.radius;
        slotT.slow = 1.5;
      }
      return;
    }
    if (def.kind === "rain") {
      const tx = e.x + fx * Math.min(def.range, Math.max(2, len));
      const tz = e.z + fz * Math.min(def.range, Math.max(2, len));
      ring(tx, tz, def.radius, 0xd4524a, 0.55);
      strikes.push({ t: time + 0.42, x: tx, z: tz, r: def.radius, dmg, owner: e.id, slow: 0.45 });
    }
  }

  function aiHero(e: Ent, dt: number) {
    if (!e.alive) return;
    for (let i = 0; i < 4; i++) e.cds[i] = Math.max(0, (e.cds[i] ?? 0) - dt);
    if (e.dashT > 0) {
      e.dashT -= dt;
      e.x += e.dashVX * dt;
      e.z += e.dashVZ * dt;
      const face = Math.atan2(-e.dashVX, -e.dashVZ);
      e.yaw = dampAngle(e.yaw, face, 14, dt);
      e.faceYaw = e.yaw;
      e.vel = Math.hypot(e.dashVX, e.dashVZ);
      for (const o of ents) {
        if (!hostilePair(e, o) || e.dashHits.includes(o.id)) continue;
        if (Math.hypot(o.x - e.x, o.z - e.z) < o.radius + 1.25) {
          e.dashHits.push(o.id);
          hurt(o, e.dashDmg, e, 0.35);
        }
      }
      separate(e);
      return;
    }
    e.aiCast -= dt;
    const fountain = FOUNTAINS.find((f) => f.team === e.team)!;
    if (e.hp < e.maxHp * 0.28) {
      const my = moveToward(e, fountain.x, fountain.z, dt, false);
      separate(e);
      settleBody(e, my, e.attackAnim > 0.02 ? e.faceYaw : null, dt);
      if (Math.hypot(e.x - fountain.x, e.z - fountain.z) < 8) aiBuy(e);
      return;
    }
    const foe =
      nearest(e, 12, (o) => o.kind === "hero" && hostilePair(e, o)) ||
      nearest(e, 10, (o) => (o.kind === "minion" || o.kind === "tower" || o.kind === "nexus") && hostilePair(e, o));
    if (foe) {
      const d = dist(e, foe);
      const toX = foe.x - e.x;
      const toZ = foe.z - e.z;
      const len = Math.hypot(toX, toZ) || 1;
      const fx = toX / len;
      const fz = toZ / len;
      const side = Math.sin(time * 0.85 + e.id);
      let mx = fx;
      let mz = fz;
      let spdK = 1;
      if (d > e.atkRange * 0.92) {
        mx = fx;
        mz = fz;
        spdK = 1;
      } else if (e.ranged && d < e.atkRange * 0.58) {
        mx = -fx;
        mz = -fz;
        spdK = 0.9;
      } else if (e.ranged) {
        mx = -fz * side;
        mz = fx * side;
        spdK = 0.72;
      } else {
        const inward = d > e.atkRange * 0.78 ? 0.75 : 0.12;
        mx = fx * inward - fz * side;
        mz = fz * inward + fx * side;
        spdK = 0.5;
      }
      const mag = Math.hypot(mx, mz) || 1;
      const slow = e.slowT > 0 ? 0.55 : 1;
      const haste = e.hasteT > 0 ? 1.28 : 1;
      const spd = e.speed * slow * haste * spdK;
      e.x += (mx / mag) * spd * dt;
      e.z += (mz / mag) * spd * dt;
      e.vel = spd;
      const moveYaw = Math.atan2(-mx / mag, -mz / mag);
      separate(e);
      tryHit(e, foe);
      const face = Math.atan2(-(foe.x - e.x), -(foe.z - e.z));
      settleBody(e, moveYaw, face, dt);
      if (e.aiCast <= 0 && e.champ) {
        const slot = pickAiCast(e, foe);
        if (slot >= 0) {
          cast(e, slot, foe.x, foe.z);
          e.aiCast = 1.35;
        }
      }
      return;
    }
    const lane = LANES[e.lane] ?? LANES[0]!;
    const idx = Math.max(0, Math.min(lane.length - 1, e.wp));
    const wp = lane[idx]!;
    const my = moveToward(e, wp.x, wp.z, dt, false);
    separate(e);
    settleBody(e, my, e.attackAnim > 0.02 ? e.faceYaw : null, dt);
    if (Math.hypot(e.x - wp.x, e.z - wp.z) < 2.4) {
      const next = e.wp + e.dir;
      if (next >= 0 && next < lane.length) e.wp = next;
    }
    if (Math.hypot(e.x - fountain.x, e.z - fountain.z) < 9 && e.gold >= 300) aiBuy(e);
  }

  function pickAiCast(e: Ent, foe: Ent): number {
    if (!e.champ) return -1;
    const abs = CHAMPS[e.champ].abilities;
    const d = dist(e, foe);
    let best = -1;
    let score = -1;
    abs.forEach((ab, i) => {
      if ((e.cds[i] ?? 0) > 0 || e.mana < ab.mana) return;
      let s = ab.dmg;
      if (ab.kind === "buff" && e.hp < e.maxHp * 0.6) s = 200;
      if ((ab.kind === "projectile" || ab.kind === "rain" || ab.kind === "cone") && d > ab.range) return;
      if (ab.kind === "dash" && d > 3 && d < ab.range + 2) s += 40;
      if (ab.kind === "aoe" && d > ab.radius) s *= 0.2;
      if (s > score) {
        score = s;
        best = i;
      }
    });
    return best;
  }

  function aiBuy(e: Ent) {
    const order = e.ranged ? [3, 2, 0, 1] : [3, 1, 0, 2];
    for (const idx of order) {
      const item = ITEMS[idx];
      if (!item) continue;
      if ((e.itemCounts[idx] ?? 0) >= 2) continue;
      if (e.gold >= item.cost) {
        e.gold -= item.cost;
        e.itemCounts[idx] = (e.itemCounts[idx] ?? 0) + 1;
        applyBuild(e);
        e.hp = Math.min(e.maxHp, e.hp + 40);
        return;
      }
    }
  }

  function tickMinion(e: Ent, dt: number) {
    const foe = nearest(
      e,
      7.2,
      (o) => hostilePair(e, o) && (o.kind === "minion" || o.kind === "hero" || o.kind === "tower" || o.kind === "nexus"),
    );
    if (foe) {
      if (dist(e, foe) > e.atkRange) moveToward(e, foe.x, foe.z, dt);
      else e.vel = 0;
      tryHit(e, foe);
      return;
    }
    const lane = LANES[e.lane] ?? LANES[0]!;
    const idx = Math.max(0, Math.min(lane.length - 1, e.wp));
    const wp = lane[idx]!;
    moveToward(e, wp.x, wp.z, dt);
    if (Math.hypot(e.x - wp.x, e.z - wp.z) < 1.6) {
      const next = e.wp + e.dir;
      if (next >= 0 && next < lane.length) e.wp = next;
    }
  }

  function tickTower(e: Ent) {
    let minion: Ent | null = null;
    let minD = e.atkRange;
    let hero: Ent | null = null;
    let heroD = e.atkRange;
    for (const o of ents) {
      if (!o.alive || o.team === e.team || o.team === 2) continue;
      if (o.kind !== "minion" && o.kind !== "hero") continue;
      const d = dist(e, o);
      if (o.kind === "minion" && d < minD) {
        minion = o;
        minD = d;
      }
      if (o.kind === "hero" && d < heroD) {
        hero = o;
        heroD = d;
      }
    }
    const tgt = minion || hero;
    if (tgt) tryHit(e, tgt);
  }

  function tickCreep(e: Ent, dt: number) {
    const homeD = Math.hypot(e.x - e.homeX, e.z - e.homeZ);
    const focus = e.focus >= 0 ? byId(e.focus) : null;
    const focusFar =
      !focus ||
      !focus.alive ||
      homeD > e.leash ||
      Math.hypot(focus.x - e.homeX, focus.z - e.homeZ) > e.leash + 1;
    if (!e.aggro || focusFar) {
      e.aggro = false;
      e.focus = -1;
      if (e.hp < e.maxHp && homeD < 1.2) e.hp = Math.min(e.maxHp, e.hp + e.maxHp * 0.25 * dt);
      if (homeD > 0.8) moveToward(e, e.homeX, e.homeZ, dt);
      else e.vel = 0;
      return;
    }
    if (focus) {
      if (dist(e, focus) > e.atkRange) moveToward(e, focus.x, focus.z, dt);
      tryHit(e, focus);
    }
  }

  function tickBoss(e: Ent, dt: number) {
    e.specialT -= dt;
    const homeD = Math.hypot(e.x - e.homeX, e.z - e.homeZ);
    if (!e.aggro) {
      const near = nearest(e, 8, (o) => o.kind === "hero" && o.alive);
      if (near) {
        e.aggro = true;
        e.focus = near.id;
        announce("The Rift Colossus stirs");
      }
      return;
    }
    const focus = e.focus >= 0 ? byId(e.focus) : null;
    if (homeD > e.leash || !focus || !focus.alive) {
      e.aggro = false;
      e.focus = -1;
      e.hp = e.maxHp;
      moveToward(e, e.homeX, e.homeZ, dt);
      return;
    }
    if (dist(e, focus) > e.atkRange) moveToward(e, focus.x, focus.z, dt);
    else tryHit(e, focus);
    if (e.specialT <= 0) {
      e.specialT = 5.4;
      ring(e.x, e.z, 4.4, 0xd4524a, 0.4);
      for (const o of ents) {
        if (o.kind === "hero" && o.alive && dist(e, o) < 4.6) hurt(o, 55 + e.ad * 0.4, e, 0.5);
      }
    }
  }

  function spawnWave() {
    const aliveMinions = ents.filter((e) => e.alive && e.kind === "minion").length;
    if (aliveMinions >= STEP_CAP_MINIONS) return;
    wave += 1;
    for (let lane = 0; lane < 3; lane++) {
      for (const team of [0, 1] as const) {
        const pts = LANES[lane]!;
        const start = team === 0 ? 0 : pts.length - 1;
        const dir = team === 0 ? 1 : -1;
        const origin = pts[start]!;
        const next = pts[Math.max(0, Math.min(pts.length - 1, start + dir))]!;
        const dx = next.x - origin.x;
        const dz = next.z - origin.z;
        const len = Math.hypot(dx, dz) || 1;
        const px = -dz / len;
        const pz = dx / len;
        for (let k = 0; k < 3; k++) {
          if (ents.filter((e) => e.alive && e.kind === "minion").length >= STEP_CAP_MINIONS) return;
          const ranged = k === 2;
          const e = add({
            kind: "minion",
            team,
            name: ranged ? "Archer" : "Footman",
            x: origin.x + px * (k - 1) * 0.85,
            z: origin.z + pz * (k - 1) * 0.85,
            lane,
            wp: start + dir,
            dir,
            yaw: team === 0 ? 0 : Math.PI,
            hp: ranged ? 210 : 320,
            maxHp: ranged ? 210 : 320,
            ad: ranged ? 18 : 16,
            armor: 2,
            radius: 0.42,
            atkRange: ranged ? 6 : 1.55,
            atkCd: ranged ? 1.15 : 0.9,
            speed: 3.45,
            baseSpeed: 3.45,
            ranged,
          });
          void e;
        }
      }
    }
  }

  function tickProjectiles(dt: number) {
    for (const p of projs) {
      if (!p.alive) continue;
      p.x += p.vx * dt;
      p.z += p.vz * dt;
      p.life -= dt;
      if (p.life <= 0) {
        p.alive = false;
        continue;
      }
      const owner = byId(p.owner);
      for (const e of ents) {
        if (!e.alive) continue;
        if (owner) {
          if (!hostilePair(owner, e)) continue;
        } else if (e.team === p.team || e.team === 2) continue;
        if (p.hits.includes(e.id)) continue;
        if (Math.hypot(e.x - p.x, e.z - p.z) <= e.radius + p.radius) {
          hurt(e, p.dmg, owner, p.slow);
          p.hits.push(e.id);
          if (!p.pierce) {
            p.alive = false;
            break;
          }
        }
      }
    }
  }

  function tickTraps(dt: number) {
    for (const t of traps) {
      if (!t.alive) continue;
      t.life -= dt;
      t.arm -= dt;
      if (t.life <= 0) {
        t.alive = false;
        continue;
      }
      if (t.arm > 0) continue;
      const owner = byId(t.owner);
      for (const e of ents) {
        if (!e.alive || !owner || !hostilePair(owner, e)) continue;
        if (Math.hypot(e.x - t.x, e.z - t.z) <= t.radius + e.radius) {
          hurt(e, t.dmg, owner, t.slow);
          ring(t.x, t.z, t.radius, 0x7dbe6a, 0.3);
          t.alive = false;
          break;
        }
      }
    }
  }

  function tickStatus(e: Ent, dt: number) {
    e.hitFlash = Math.max(0, e.hitFlash - dt);
    e.attackAnim = Math.max(0, e.attackAnim - dt);
    if (e.alive && e.windup > 0) {
      e.windup -= dt;
      if (e.windup <= 0) {
        e.windup = 0;
        connectSwing(e);
      }
    }
    e.slowT = Math.max(0, e.slowT - dt);
    e.hasteT = Math.max(0, e.hasteT - dt);
    e.lifestealT = Math.max(0, e.lifestealT - dt);
    e.teamBuffT = Math.max(0, e.teamBuffT - dt);
    e.shieldT = Math.max(0, e.shieldT - dt);
    if (e.shieldT <= 0) e.shield = 0;
    e.atkTimer = Math.max(0, e.atkTimer - dt);
    if (e.alive && e.kind === "hero") {
      e.mana = Math.min(e.maxMana, e.mana + (4 + e.level) * dt);
      const f = FOUNTAINS.find((n) => n.team === e.team);
      if (f && Math.hypot(e.x - f.x, e.z - f.z) < 9) {
        e.hp = Math.min(e.maxHp, e.hp + e.maxHp * 0.09 * dt);
        e.mana = Math.min(e.maxMana, e.mana + e.maxMana * 0.14 * dt);
      }
    }
  }

  function tickShrines(dt: number) {
    const p = player;
    for (const s of shrines) {
      s.ready = Math.max(0, s.ready - dt);
      if (!p.alive || phase !== "play") {
        s.channel = 0;
        continue;
      }
      const d = Math.hypot(p.x - s.x, p.z - s.z);
      if (d < 2.4 && s.ready <= 0) {
        s.channel += dt;
        if (s.channel > 1.5) {
          s.channel = 0;
          s.ready = 36;
          if (s.kind === "haste") p.hasteT = Math.max(p.hasteT, 8);
          if (s.kind === "lifesteal") p.lifestealT = Math.max(p.lifestealT, 10);
          if (s.kind === "shield") {
            p.shield = Math.max(p.shield, 160 + p.level * 8);
            p.shieldT = 8;
          }
          announce(`${s.name} answers`);
          ring(s.x, s.z, 2.2, 0xe4b15a, 0.6);
        }
      } else s.channel = 0;
    }
  }

  function nearFountain(e: Ent = player) {
    const f = FOUNTAINS.find((n) => n.team === e.team);
    if (!f) return false;
    return Math.hypot(e.x - f.x, e.z - f.z) < 10;
  }

  bootstrap();

  const api: Sim = {
    ents,
    projs,
    rings,
    traps,
    floats,
    get phase() {
      return phase;
    },
    set phase(v: Phase) {
      phase = v;
    },
    get time() {
      return time;
    },
    events,
    get dawnKills() {
      return dawnKills;
    },
    get duskKills() {
      return duskKills;
    },
    get wave() {
      return wave;
    },
    shrines,
    player: () => player,
    nearFountain,
    setPreview(id: ChampId) {
      if (phase !== "menu") return;
      applyChamp(player, id, 500);
      player.name = CHAMPS[id].name;
      placeHero(player, "player", 0);
      const allies = ents.filter((e) => e.kind === "hero" && e.team === 0 && !e.player);
      const rest = otherChamps(id);
      allies.forEach((e, i) => {
        const cid = rest[i] ?? "ranger";
        applyChamp(e, cid, 500);
        e.name = ALLY_NAMES[i] ?? e.name;
        placeHero(e, "ally", i);
      });
    },
    start(id: ChampId) {
      resetStructures();
      dawnKills = 0;
      duskKills = 0;
      wave = 0;
      waveT = 5;
      time = 0;
      const heroes = ents.filter((e) => e.kind === "hero");
      const me = heroes.find((e) => e.player)!;
      player = me;
      applyChamp(player, id, 500);
      player.name = CHAMPS[id].name;
      placeHero(player, "player", 0);
      const allies = heroes.filter((e) => e.team === 0 && !e.player);
      const foes = heroes.filter((e) => e.team === 1);
      const rest = otherChamps(id);
      allies.forEach((e, i) => {
        applyChamp(e, rest[i] ?? "ranger", 500);
        e.name = ALLY_NAMES[i] ?? "Ally";
        placeHero(e, "ally", i);
      });
      const foeChamps: ChampId[] = [id, rest[0] ?? "arcanist", rest[1] ?? "ranger"];
      foes.forEach((e, i) => {
        applyChamp(e, foeChamps[i] ?? "vanguard", 500);
        e.name = ENEMY_NAMES[i] ?? "Foe";
        placeHero(e, "enemy", i);
      });
      phase = "play";
      announce("Hold the lanes. Break the Dusk Conduit.");
    },
    togglePause() {
      if (phase === "play") phase = "pause";
      else if (phase === "pause") phase = "play";
    },
    buy(id: ItemId) {
      if (phase !== "play" || !player.alive) return false;
      if (!nearFountain(player)) return false;
      const idx = ITEMS.findIndex((it) => it.id === id);
      const item = ITEMS[idx];
      if (!item || idx < 0) return false;
      if ((player.itemCounts[idx] ?? 0) >= 3) return false;
      if (player.gold < item.cost) return false;
      player.gold -= item.cost;
      player.itemCounts[idx] = (player.itemCounts[idx] ?? 0) + 1;
      const ratio = player.hp / player.maxHp;
      applyBuild(player);
      player.hp = Math.min(player.maxHp, Math.max(ratio * player.maxHp, player.hp));
      floater(player.x, player.z, item.name, "#e4b15a");
      return true;
    },
    towersUp(team: 0 | 1) {
      return ents.filter((e) => e.alive && e.kind === "tower" && e.team === team).length;
    },
    step(dt: number, input: InputState) {
      if (phase !== "play") return;
      time += dt;
      waveT -= dt;
      if (waveT <= 0) {
        waveT = 18;
        spawnWave();
      }
      for (const camp of camps) {
        if (camp.down) {
          camp.timer -= dt;
          if (camp.timer <= 0) spawnCamp(camp);
        }
      }
      for (const e of ents) {
        tickStatus(e, dt);
        if (!e.alive && e.kind === "hero") {
          e.respawn -= dt;
          if (e.respawn <= 0) reviveHero(e);
          continue;
        }
        if (!e.alive && e.kind === "boss") {
          e.respawn -= dt;
          if (e.respawn <= 0) {
            e.alive = true;
            e.hp = e.maxHp;
            e.x = e.homeX;
            e.z = e.homeZ;
            e.aggro = false;
            e.focus = -1;
            announce("The Rift Colossus wakes again");
          }
          continue;
        }
        if (!e.alive) continue;
        if (e.player) tickHeroPlayer(e, input, dt);
        else if (e.kind === "hero") aiHero(e, dt);
        else if (e.kind === "minion") tickMinion(e, dt);
        else if (e.kind === "tower") tickTower(e);
        else if (e.kind === "creep") tickCreep(e, dt);
        else if (e.kind === "boss") tickBoss(e, dt);
      }
      tickProjectiles(dt);
      tickTraps(dt);
      tickShrines(dt);
      for (let i = strikes.length - 1; i >= 0; i--) {
        const s = strikes[i];
        if (!s || time < s.t) continue;
        const owner = byId(s.owner);
        ring(s.x, s.z, s.r, 0xe4b15a, 0.4);
        if (owner) {
          for (const o of ents) {
            if (!hostilePair(owner, o)) continue;
            if (Math.hypot(o.x - s.x, o.z - s.z) <= s.r + o.radius * 0.3) hurt(o, s.dmg, owner, s.slow);
          }
        }
        strikes.splice(i, 1);
      }
      for (const f of floats) {
        if (!f.alive) continue;
        f.life -= dt;
        f.y += dt * 1.4;
        if (f.life <= 0) f.alive = false;
      }
      for (const r of rings) {
        if (!r.alive) continue;
        r.life -= dt;
        if (r.life <= 0) r.alive = false;
      }
      for (let i = ents.length - 1; i >= 0; i--) {
        const e = ents[i];
        if (e && !e.alive && (e.kind === "minion" || e.kind === "creep")) ents.splice(i, 1);
      }
    },
  };

  return api;
}

function dampAngle(current: number, target: number, rate: number, dt: number) {
  const diff = Math.atan2(Math.sin(target - current), Math.cos(target - current));
  return current + diff * (1 - Math.exp(-rate * dt));
}

function settleBody(e: Ent, moveYaw: number | null, aimYaw: number | null, dt: number) {
  if (aimYaw === null) {
    if (moveYaw !== null) e.yaw = dampAngle(e.yaw, moveYaw, 10, dt);
    e.faceYaw = dampAngle(e.faceYaw, e.yaw, 14, dt);
    return;
  }
  e.faceYaw = dampAngle(e.faceYaw, aimYaw, e.vel < 0.9 ? 18 : 14, dt);
  if (moveYaw === null || e.vel < 0.7) {
    e.yaw = dampAngle(e.yaw, e.faceYaw, 12, dt);
    return;
  }
  const delta = Math.atan2(Math.sin(aimYaw - moveYaw), Math.cos(aimYaw - moveYaw));
  const max = 1.05;
  const hips = Math.abs(delta) > max ? aimYaw - Math.sign(delta) * max : moveYaw;
  e.yaw = dampAngle(e.yaw, hips, 10, dt);
}

export function abilityOf(champ: ChampId, slot: number): AbilityDef | undefined {
  return CHAMPS[champ].abilities[slot];
}
