export type ChampId = "vanguard" | "arcanist" | "ranger";
export type ItemId = "blade" | "heart" | "arcanum" | "boots";
export type AbilityKind = "projectile" | "dash" | "aoe" | "buff" | "rain" | "cone" | "trap";

export interface AbilityDef {
  key: string;
  name: string;
  blurb: string;
  cd: number;
  mana: number;
  kind: AbilityKind;
  dmg: number;
  range: number;
  radius: number;
  speed: number;
}

export interface ChampDef {
  id: ChampId;
  name: string;
  title: string;
  role: string;
  blurb: string;
  range: number;
  hp: number;
  mana: number;
  speed: number;
  ad: number;
  color: number;
  swatch: "primary" | "mana" | "ranger";
  abilities: AbilityDef[];
}

const Q = (
  partial: Omit<AbilityDef, "radius" | "speed"> & Partial<Pick<AbilityDef, "radius" | "speed">>,
): AbilityDef => ({
  radius: 3,
  speed: 18,
  ...partial,
});

export const CHAMPS: Record<ChampId, ChampDef> = {
  vanguard: {
    id: "vanguard",
    name: "Kael",
    title: "Dawn Vanguard",
    role: "Melee bruiser",
    blurb: "Closes the gap, shrugs a hit, and spins the lane apart.",
    range: 2.35,
    hp: 820,
    mana: 280,
    speed: 7.15,
    ad: 64,
    color: 0xc9853a,
    swatch: "primary",
    abilities: [
      Q({
        key: "Q",
        name: "Rift Charge",
        blurb: "Dash to your cursor, cutting anyone you pass.",
        cd: 7.5,
        mana: 40,
        kind: "dash",
        dmg: 80,
        range: 9,
        radius: 1.5,
        speed: 28,
      }),
      Q({
        key: "E",
        name: "Earthbreak",
        blurb: "Slam the ground. Damages and slows nearby foes.",
        cd: 8,
        mana: 50,
        kind: "aoe",
        dmg: 95,
        range: 3.4,
        radius: 3.4,
      }),
      Q({
        key: "R",
        name: "Bulwark",
        blurb: "Raise a shield and surge forward faster.",
        cd: 13,
        mana: 55,
        kind: "buff",
        dmg: 0,
        range: 0,
      }),
      Q({
        key: "F",
        name: "Sundering Spin",
        blurb: "Whirl, shredding everyone around you.",
        cd: 30,
        mana: 90,
        kind: "aoe",
        dmg: 190,
        range: 4.6,
        radius: 4.6,
      }),
    ],
  },
  arcanist: {
    id: "arcanist",
    name: "Lyra",
    title: "Rift Arcanist",
    role: "Ranged mage",
    blurb: "Hurls bolts and calls a star down on the siege line.",
    range: 8.2,
    hp: 560,
    mana: 460,
    speed: 6.55,
    ad: 40,
    color: 0x6ec8e0,
    swatch: "mana",
    abilities: [
      Q({
        key: "Q",
        name: "Arc Bolt",
        blurb: "A fast bolt toward your cursor.",
        cd: 3.6,
        mana: 30,
        kind: "projectile",
        dmg: 88,
        range: 15,
        speed: 24,
        radius: 0.45,
      }),
      Q({
        key: "E",
        name: "Nova Ring",
        blurb: "Burst of rift fire around you.",
        cd: 9,
        mana: 55,
        kind: "aoe",
        dmg: 78,
        range: 4.8,
        radius: 4.8,
      }),
      Q({
        key: "R",
        name: "Frost Bind",
        blurb: "A slow orb that bites and chills.",
        cd: 11,
        mana: 60,
        kind: "projectile",
        dmg: 48,
        range: 13,
        speed: 16,
        radius: 0.55,
      }),
      Q({
        key: "F",
        name: "Starfall",
        blurb: "Mark the ground. A star crashes there.",
        cd: 32,
        mana: 110,
        kind: "rain",
        dmg: 220,
        range: 16,
        radius: 4.4,
      }),
    ],
  },
  ranger: {
    id: "ranger",
    name: "Soren",
    title: "Wild Ranger",
    role: "Ranged skirmisher",
    blurb: "Kites from the treeline, snares a path, rains arrows.",
    range: 7.4,
    hp: 620,
    mana: 340,
    speed: 7.35,
    ad: 56,
    color: 0x7dbe6a,
    swatch: "ranger",
    abilities: [
      Q({
        key: "Q",
        name: "Piercing Shot",
        blurb: "An arrow that punches through a line.",
        cd: 4.5,
        mana: 28,
        kind: "projectile",
        dmg: 76,
        range: 16,
        speed: 30,
        radius: 0.4,
      }),
      Q({
        key: "E",
        name: "Snare Trap",
        blurb: "Drop a trap at your feet. It arms, then roots.",
        cd: 12,
        mana: 45,
        kind: "trap",
        dmg: 46,
        range: 2,
        radius: 2.1,
      }),
      Q({
        key: "R",
        name: "Volley",
        blurb: "A fan of arrows toward your cursor.",
        cd: 8.5,
        mana: 48,
        kind: "cone",
        dmg: 62,
        range: 10,
        radius: 0.7,
      }),
      Q({
        key: "F",
        name: "Arrow Rain",
        blurb: "Blanket an area. Anything standing there bleeds.",
        cd: 30,
        mana: 100,
        kind: "rain",
        dmg: 170,
        range: 15,
        radius: 5,
      }),
    ],
  },
};

export const CHAMP_ORDER: ChampId[] = ["vanguard", "arcanist", "ranger"];

export const ITEMS: { id: ItemId; name: string; blurb: string; cost: number }[] = [
  { id: "blade", name: "Sundersword", blurb: "+16 attack", cost: 380 },
  { id: "heart", name: "Heartstone", blurb: "+150 health, +4 armor", cost: 380 },
  { id: "arcanum", name: "Rift Arcanum", blurb: "+26 power, +45 mana", cost: 380 },
  { id: "boots", name: "Swiftstriders", blurb: "+1.05 move speed", cost: 300 },
];

export const ALLY_NAMES = ["Bram", "Nima"];
export const ENEMY_NAMES = ["Vex", "Mora", "Isk"];

export function otherChamps(id: ChampId): ChampId[] {
  return CHAMP_ORDER.filter((c) => c !== id);
}
