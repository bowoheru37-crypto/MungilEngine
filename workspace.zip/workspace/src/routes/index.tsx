import { createFileRoute } from "@tanstack/react-router";
import { RiftApp } from "@/components/aetherfall/RiftApp";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <RiftApp />;
}
