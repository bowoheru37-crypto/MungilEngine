# R8/ProGuard — aman untuk proyek tanpa library eksternal.
-keepattributes Exceptions,Signature,InnerClasses,EnclosingMethod

# Hapus semua panggilan Log kustom saat rilis (hemat CPU & ukuran).
-assumenosideeffects class com.example.lowapp.core.Log {
    public static *** d(...);
    public static *** w(...);
    public static *** e(...);
}

-dontnote **
