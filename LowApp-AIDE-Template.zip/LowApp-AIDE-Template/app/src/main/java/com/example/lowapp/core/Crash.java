package com.example.lowapp.core;

import android.content.Context;
import android.os.Build;
import android.os.Process;

import com.example.lowapp.BuildConfig;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Menangkap semua crash (FC) yang tidak tertangani, menyimpan jejaknya
 * ke berkas lokal agar bisa dianalisis, lalu meneruskan ke handler bawaan.
 */
public final class Crash implements Thread.UncaughtExceptionHandler {

    private final Context app;
    private final Thread.UncaughtExceptionHandler previous;

    private Crash(Context context) {
        this.app = context.getApplicationContext();
        this.previous = Thread.getDefaultUncaughtExceptionHandler();
    }

    public static void install(Context context) {
        Thread.setDefaultUncaughtExceptionHandler(new Crash(context));
    }

    @Override
    public void uncaughtException(Thread thread, Throwable error) {
        try {
            write(error);
        } catch (Throwable ignored) {
            // Jangan pernah melempar dari crash handler.
        }
        if (previous != null) {
            previous.uncaughtException(thread, error);
        } else {
            Process.killProcess(Process.myPid());
            System.exit(10);
        }
    }

    private void write(Throwable error) throws Exception {
        String ts = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
        File dir = new File(app.getFilesDir(), "crash");
        if (!dir.exists() && !dir.mkdirs()) return;
        File out = new File(dir, ts + ".txt");

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        pw.println("device=" + Build.MANUFACTURER + " " + Build.MODEL);
        pw.println("sdk=" + Build.VERSION.SDK_INT + " app=" + BuildConfig.VERSION_NAME);
        error.printStackTrace(pw);
        pw.flush();

        FileOutputStream fos = new FileOutputStream(out);
        try {
            fos.write(sw.toString().getBytes("UTF-8"));
        } finally {
            fos.close();
        }
    }
}
