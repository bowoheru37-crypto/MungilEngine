package com.example.lowapp;

import android.app.Application;
import android.os.StrictMode;

import com.example.lowapp.core.Crash;

/** Titik masuk aplikasi: pasang crash handler & StrictMode (debug saja). */
public class App extends Application {

    private static App instance;

    public static App get() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        Crash.install(this);

        if (BuildConfig.DEBUG) {
            // Deteksi I/O di main thread & resource bocor saat pengembangan.
            StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
                    .detectDiskReads()
                    .detectDiskWrites()
                    .detectNetwork()
                    .penaltyLog()
                    .build());
            StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
                    .detectLeakedClosableObjects()
                    .detectLeakedSqlLiteObjects()
                    .penaltyLog()
                    .build());
        }
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        // Sistem kekurangan RAM: bebaskan cache memori di sini
        // bila level >= TRIM_MEMORY_MODERATE agar tidak kena OOM.
    }
}
