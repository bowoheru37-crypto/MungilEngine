package com.example.lowapp.core;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.GZIPInputStream;

/**
 * HTTP ringan berbasis HttpURLConnection (tanpa library eksternal):
 * - timeout tegas (tidak menggantung & menguras baterai)
 * - gzip untuk hemat kuota
 * - batas ukuran respons agar tidak OOM
 * - semua stream ditutup di finally (anti-leak)
 */
public final class Http {

    private static final int CONNECT_TIMEOUT_MS = 10_000;
    private static final int READ_TIMEOUT_MS = 15_000;
    private static final int MAX_BYTES = 2 * 1024 * 1024; // 2 MB

    private Http() { }

    /** GET sederhana; lempar IOException("offline") bila tidak ada jaringan. */
    public static byte[] get(Context context, String url) throws IOException {
        if (!Net.online(context)) throw new IOException("offline");

        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(CONNECT_TIMEOUT_MS);
            conn.setReadTimeout(READ_TIMEOUT_MS);
            conn.setRequestProperty("Accept-Encoding", "gzip");
            conn.setUseCaches(true);

            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) throw new IOException("HTTP " + code);

            InputStream in = conn.getInputStream();
            if ("gzip".equalsIgnoreCase(conn.getContentEncoding())) {
                in = new GZIPInputStream(in);
            }
            return readCapped(in, MAX_BYTES);
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static byte[] readCapped(InputStream in, int max) throws IOException {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int total = 0;
            int n;
            while ((n = in.read(buffer)) != -1) {
                total += n;
                if (total > max) throw new IOException("respons terlalu besar");
                out.write(buffer, 0, n);
            }
            return out.toByteArray();
        } finally {
            Safe.close(in);
        }
    }
}
