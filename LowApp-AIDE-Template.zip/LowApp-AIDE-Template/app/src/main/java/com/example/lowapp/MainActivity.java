package com.example.lowapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.lowapp.core.Http;
import com.example.lowapp.core.Mem;
import com.example.lowapp.core.Net;
import com.example.lowapp.core.Safe;
import com.example.lowapp.core.Store;
import com.example.lowapp.core.Task;
import com.example.lowapp.ui.BaseActivity;

/**
 * Contoh pola offline-first:
 * online  -> unduh, tampilkan, simpan ke cache
 * offline -> tampilkan cache terakhir (bila ada)
 */
public class MainActivity extends BaseActivity {

    private static final String CACHE_PAGE = "page.cache";

    private Store store;
    private TextView txtStatus;
    private TextView txtResult;
    private EditText edtUrl;
    private Button btnFetch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        store = new Store(this);
        txtStatus = findViewById(R.id.txtStatus);
        txtResult = findViewById(R.id.txtResult);
        edtUrl = findViewById(R.id.edtUrl);
        btnFetch = findViewById(R.id.btnFetch);

        txtStatus.setText(getString(R.string.status_line,
                BuildConfig.VERSION_NAME,
                android.os.Build.VERSION.SDK_INT,
                Mem.lowRam(this) ? "low-ram" : "normal"));

        btnFetch.setOnClickListener(this::onFetchClicked);
    }

    private void onFetchClicked(View v) {
        String url = Safe.trim(edtUrl.getText() == null
                ? "" : edtUrl.getText().toString());
        if (!Safe.validUrl(url)) {
            toast(getString(R.string.err_invalid_url));
            return;
        }

        setBusy(true);
        if (!Net.online(this)) {
            showCachedOrWarn();
            return;
        }

        Task.run(() -> Http.get(getApplicationContext(), url),
                new Task.Done<byte[]>() {
                    @Override
                    public void ok(byte[] value) {
                        if (!alive()) return;
                        store.writeFile(CACHE_PAGE, value);
                        txtResult.setText(new String(value));
                        txtStatus.setText(R.string.status_online_ok);
                        setBusy(false);
                    }

                    @Override
                    public void err(Exception e) {
                        if (!alive()) return;
                        showCachedOrWarn();
                    }
                });
    }

    private void showCachedOrWarn() {
        byte[] cached = store.readFile(CACHE_PAGE, 2 * 1024 * 1024);
        if (cached != null) {
            txtResult.setText(new String(cached));
            txtStatus.setText(R.string.status_offline_cache);
        } else {
            txtStatus.setText(R.string.status_offline_empty);
            toast(getString(R.string.err_offline));
        }
        setBusy(false);
    }

    private void setBusy(boolean busy) {
        btnFetch.setEnabled(!busy);
        if (busy) txtStatus.setText(R.string.status_loading);
    }
}
