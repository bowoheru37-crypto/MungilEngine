package com.example.lowapp.core;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;

/** Deteksi status jaringan (offline/online) lintas API 21+. */
public final class Net {

    private Net() { }

    public static boolean online(Context context) {
        ConnectivityManager cm = manager(context);
        if (cm == null) return false;
        if (Build.VERSION.SDK_INT >= 23) {
            Network network = cm.getActiveNetwork();
            if (network == null) return false;
            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            return caps != null
                    && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } else {
            NetworkInfo info = cm.getActiveNetworkInfo();
            return info != null && info.isConnected();
        }
    }

    /** True bila koneksi berkuota (data seluler) — batasi unduhan besar. */
    public static boolean metered(Context context) {
        ConnectivityManager cm = manager(context);
        return cm != null && cm.isActiveNetworkMetered();
    }

    private static ConnectivityManager manager(Context context) {
        if (context == null) return null;
        return (ConnectivityManager) context.getApplicationContext()
                .getSystemService(Context.CONNECTIVITY_SERVICE);
    }
}
