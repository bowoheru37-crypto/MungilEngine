package com.example.lowapp.core;

import java.nio.ByteBuffer;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Enkripsi data lokal yang benar & kompatibel API 21+:
 * - PBKDF2 untuk kunci dari kata sandi
 * - AES-256/CBC + HMAC-SHA256 (encrypt-then-MAC)
 * - kunci enkripsi & kunci MAC dipisah (key separation)
 * Format paket: salt(16) | iv(16) | tag(32) | ciphertext
 */
public final class Sec {

    private static final int ITERATIONS = 10_000;
    private static final SecureRandom RANDOM = new SecureRandom();

    private Sec() { }

    public static byte[] encrypt(char[] password, byte[] plain)
            throws GeneralSecurityException {
        byte[] salt = new byte[16];
        RANDOM.nextBytes(salt);
        byte[][] keys = derive(password, salt);

        byte[] iv = new byte[16];
        RANDOM.nextBytes(iv);
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(keys[0], "AES"),
                new IvParameterSpec(iv));
        byte[] ct = cipher.doFinal(plain);

        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(keys[1], "HmacSHA256"));
        mac.update(iv);
        byte[] tag = mac.doFinal(ct);

        ByteBuffer out = ByteBuffer.allocate(16 + 16 + 32 + ct.length);
        out.put(salt).put(iv).put(tag).put(ct);
        return out.array();
    }

    public static byte[] decrypt(char[] password, byte[] pack)
            throws GeneralSecurityException {
        ByteBuffer in = ByteBuffer.wrap(pack);
        byte[] salt = new byte[16]; in.get(salt);
        byte[] iv = new byte[16];   in.get(iv);
        byte[] tag = new byte[32];  in.get(tag);
        byte[] ct = new byte[in.remaining()]; in.get(ct);

        byte[][] keys = derive(password, salt);
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(keys[1], "HmacSHA256"));
        mac.update(iv);
        byte[] expected = mac.doFinal(ct);
        if (!MessageDigest.isEqual(expected, tag)) {
            throw new GeneralSecurityException("integritas data gagal diverifikasi");
        }

        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(keys[0], "AES"),
                new IvParameterSpec(iv));
        return cipher.doFinal(ct);
    }

    /** Satu PBKDF2 -> 64 byte: 32 byte kunci AES + 32 byte kunci HMAC. */
    private static byte[][] derive(char[] password, byte[] salt)
            throws GeneralSecurityException {
        PBEKeySpec spec = new PBEKeySpec(password, salt, ITERATIONS, 512);
        byte[] dk = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
                .generateSecret(spec).getEncoded();
        spec.clearPassword();
        byte[] enc = new byte[32];
        byte[] mac = new byte[32];
        System.arraycopy(dk, 0, enc, 0, 32);
        System.arraycopy(dk, 32, mac, 0, 32);
        return new byte[][] { enc, mac };
    }
}
