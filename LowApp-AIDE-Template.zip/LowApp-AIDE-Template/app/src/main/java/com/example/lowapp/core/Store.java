package com.example.lowapp.core;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * Penyimpanan lokal untuk mode offline:
 * - key-value cepat via SharedPreferences (apply = async, tidak blok UI)
 * - berkas dengan penulisan atomik (tmp lalu rename) agar tidak korup
 */
public final class Store {

    private final SharedPreferences prefs;
    private final File dir;

    public Store(Context context) {
        Context app = context.getApplicationContext();
        this.prefs = app.getSharedPreferences("store", Context.MODE_PRIVATE);
        this.dir = app.getFilesDir();
    }

    public void put(String key, String value) {
        prefs.edit().putString(key, value).apply();
    }

    public String get(String key, String def) {
        return prefs.getString(key, def);
    }

    /** Tulis berkas secara atomik: aman walau proses mati di tengah jalan. */
    public boolean writeFile(String name, byte[] data) {
        File tmp = new File(dir, name + ".tmp");
        File dst = new File(dir, name);
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(tmp);
            fos.write(data);
            fos.getFD().sync();
            fos.close();
            fos = null;
            return tmp.renameTo(dst);
        } catch (Exception e) {
            Log.e("Store", "gagal menulis " + name, e);
            return false;
        } finally {
            Safe.close(fos);
            if (tmp.exists()) tmp.delete();
        }
    }

    public byte[] readFile(String name, int maxBytes) {
        File f = new File(dir, name);
        if (!f.exists() || f.length() > maxBytes) return null;
        FileInputStream in = null;
        try {
            in = new FileInputStream(f);
            byte[] data = new byte[(int) f.length()];
            int read = in.read(data);
            return read == data.length ? data : null;
        } catch (Exception e) {
            Log.e("Store", "gagal membaca " + name, e);
            return null;
        } finally {
            Safe.close(in);
        }
    }
}
