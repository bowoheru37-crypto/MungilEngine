package com.example.lowapp.core;

import com.example.lowapp.BuildConfig;

/** Log hanya aktif di build debug; dihapus total oleh R8 saat rilis. */
public final class Log {

    private static final boolean ON = BuildConfig.DEBUG;

    private Log() { }

    public static void d(String tag, String msg) {
        if (ON) android.util.Log.d(tag, msg);
    }

    public static void w(String tag, String msg) {
        if (ON) android.util.Log.w(tag, msg);
    }

    public static void e(String tag, String msg, Throwable t) {
        if (ON) android.util.Log.e(tag, msg, t);
    }
}
