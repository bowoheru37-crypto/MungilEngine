package com.example.lowapp.core;

import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Eksekutor latar belakang minimal:
 * - pool kecil (maks 2 thread) agar RAM & CPU perangkat lemah tidak jebol
 * - hasil selalu kembali ke main thread (aman untuk update UI)
 * - menggantikan AsyncTask yang deprecated & rawan bocor
 */
public final class Task {

    private static final ExecutorService BG = Executors.newFixedThreadPool(
            Math.max(1, Math.min(2, Runtime.getRuntime().availableProcessors())));
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    public interface Job<T> {
        T run() throws Exception;
    }

    public interface Done<T> {
        void ok(T value);
        void err(Exception e);
    }

    private Task() { }

    public static <T> void run(Job<T> job, Done<T> done) {
        BG.execute(() -> {
            try {
                T value = job.run();
                MAIN.post(() -> done.ok(value));
            } catch (Exception e) {
                MAIN.post(() -> done.err(e));
            }
        });
    }
}
