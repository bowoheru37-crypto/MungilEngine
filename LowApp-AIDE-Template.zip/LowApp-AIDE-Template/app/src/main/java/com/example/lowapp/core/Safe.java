package com.example.lowapp.core;

import java.io.Closeable;

/** Util null-safe & validasi: benteng pertama melawan NPE dan FC. */
public final class Safe {

    private Safe() { }

    /** Nilai default bila objek null. */
    public static <T> T nn(T value, T def) {
        return value != null ? value : def;
    }

    public static boolean empty(CharSequence s) {
        return s == null || s.length() == 0;
    }

    public static String trim(String s) {
        return s == null ? "" : s.trim();
    }

    public static int parseInt(String s, int def) {
        try {
            return Integer.parseInt(trim(s));
        } catch (Exception e) {
            return def;
        }
    }

    public static long parseLong(String s, long def) {
        try {
            return Long.parseLong(trim(s));
        } catch (Exception e) {
            return def;
        }
    }

    public static float parseFloat(String s, float def) {
        try {
            return Float.parseFloat(trim(s));
        } catch (Exception e) {
            return def;
        }
    }

    /** Tutup stream/cursor tanpa risiko NPE. */
    public static void close(Closeable c) {
        if (c != null) {
            try {
                c.close();
            } catch (Exception ignored) { }
        }
    }

    /** Validasi argumen: gagal cepat dengan pesan jelas. */
    public static void checkArg(boolean ok, String message) {
        if (!ok) throw new IllegalArgumentException(message);
    }

    /** Hanya izinkan URL http/https yang berbentuk benar. */
    public static boolean validUrl(String s) {
        String u = trim(s).toLowerCase();
        return u.startsWith("https://") || u.startsWith("http://");
    }
}
