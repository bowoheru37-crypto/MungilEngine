package com.example.lowapp.ui;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

/**
 * Kelas dasar semua layar:
 * - membersihkan callback Handler di onDestroy (anti memory leak)
 * - membatalkan Toast yang tertinggal
 * - helper alive() sebelum menyentuh UI (anti FC setelah layar ditutup)
 */
public abstract class BaseActivity extends Activity {

private final Handler ui = new Handler(Looper.getMainLooper());
private Toast toast;

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
}

protected void post(Runnable r) {
    ui.post(r);
}

protected boolean alive() {
    return !isFinishing()
            && (Build.VERSION.SDK_INT < 17 || !isDestroyed());
}

protected void toast(String message) {
    if (!alive()) return;
    if (toast != null) toast.cancel();
    toast = Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT);
    toast.show();
}

@Override
protected void onDestroy() {
    ui.removeCallbacksAndMessages(null);
    if (toast != null) {
        toast.cancel();
        toast = null;
    }
    super.onDestroy();
}
}
