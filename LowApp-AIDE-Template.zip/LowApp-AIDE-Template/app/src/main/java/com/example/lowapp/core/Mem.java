package com.example.lowapp.core;

import android.app.ActivityManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

/** Util memori: deteksi perangkat low-RAM & decode gambar anti-OOM. */
public final class Mem {

    private Mem() { }

    /** True pada perangkat Android Go / RAM kecil (mis. itel A70). */
    public static boolean lowRam(Context context) {
        ActivityManager am = (ActivityManager) context.getApplicationContext()
                .getSystemService(Context.ACTIVITY_SERVICE);
        return am != null && am.isLowRamDevice();
    }

    /**
     * Decode bitmap yang di-downsample ke ukuran target:
     * - inSampleSize pangkat dua (hemat RAM drastis)
     * - RGB_565 (2 byte/piksel, setengah ARGB_8888) — cukup untuk foto UI
     */
    public static Bitmap decodeSampled(String path, int reqWidth, int reqHeight) {
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, opts);
        if (opts.outWidth <= 0 || opts.outHeight <= 0) return null;

        opts.inSampleSize = sampleSize(opts.outWidth, opts.outHeight, reqWidth, reqHeight);
        opts.inJustDecodeBounds = false;
        opts.inPreferredConfig = Bitmap.Config.RGB_565;
        return BitmapFactory.decodeFile(path, opts);
    }

    static int sampleSize(int w, int h, int reqW, int reqH) {
        int size = 1;
        while (w / (size * 2) >= reqW && h / (size * 2) >= reqH) {
            size *= 2;
        }
        return size;
    }
}
