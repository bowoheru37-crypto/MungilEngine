# LowApp — Template Android Hemat Sumber Daya (untuk AIDE)

Template aplikasi Android ringan untuk perangkat kelas bawah
(itel A70 / Android Go) dan kompatibel mulai Android 5.0 (API 21).

- Tanpa dependensi eksternal -> APK sangat kecil, tanpa konflik library
- Offline-first: cache lokal + deteksi jaringan
- Anti-NPE / anti-leak / anti-OOM by design (lihat paket `core/`)
- HTTPS-only, enkripsi lokal AES+HMAC tersedia di `core/Sec.java`
- Rilis: R8 + shrinkResources sudah aktif di `app/build.gradle`

Baca panduan lengkap: file "Panduan-LowApp-AIDE.md" yang disertakan.
