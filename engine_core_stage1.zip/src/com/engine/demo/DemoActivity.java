package com.engine.demo;

import android.app.Activity;
import android.os.Bundle;
import com.engine.core.EngineView;

public final class DemoActivity extends Activity {
    private EngineView view;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        view = new EngineView(this, new DemoGame(), DemoGame.VW, DemoGame.VH, 30);
        setContentView(view);
    }

    @Override protected void onPause()  { super.onPause();  view.onPause(); }
    @Override protected void onResume() { super.onResume(); view.onResume(); }
}
