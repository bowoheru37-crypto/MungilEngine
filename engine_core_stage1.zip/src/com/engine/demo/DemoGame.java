package com.engine.demo;

import com.engine.core.*;
import java.nio.ByteBuffer;

/** Demo gate G1: 500 sprite memantul di 480x270 virtual. Bukti pola zero-GC dan satu draw call. */
public final class DemoGame implements Game {
    public static final int VW = 480, VH = 270;
    private final World world = new World();
    private final IndexedImage img = new IndexedImage(16 * 16);
    private ByteBuffer scratch;
    private int tex;

    public DemoGame() {
        // Aset contoh dibuat langsung di memori: lingkaran 16x16, palet 2 warna (0 = transparan)
        img.w = 16; img.h = 16; img.palCount = 2;
        img.pal[0] = 0; img.pal[1] = 0; img.pal[2] = 0; img.pal[3] = 0;
        img.pal[4] = (byte) 255; img.pal[5] = (byte) 200; img.pal[6] = (byte) 60; img.pal[7] = (byte) 255;
        for (int y = 0; y < 16; y++)
            for (int x = 0; x < 16; x++) {
                int dx = x - 8, dy = y - 8;
                img.idx[y * 16 + x] = (byte) (dx * dx + dy * dy < 56 ? 1 : 0);
            }
        int seed = 12345;
        for (int i = 0; i < 500; i++) {
            int id = world.create();
            if (id < 0) break;
            seed = seed * 1103515245 + 12345;                      // LCG tanpa objek Random
            world.x[id] = (seed >>> 8) % (VW - 16);
            seed = seed * 1103515245 + 12345;
            world.y[id] = (seed >>> 8) % (VH - 16);
            seed = seed * 1103515245 + 12345;
            world.vx[id] = ((seed >>> 8) % 120) - 60;
            seed = seed * 1103515245 + 12345;
            world.vy[id] = ((seed >>> 8) % 120) - 60;
            world.w[id] = 16; world.h[id] = 16;
        }
    }

    @Override public void onGlCreated(SpriteBatch b) {
        if (scratch == null) scratch = GlTexture.newScratch(16 * 16);
        tex = GlTexture.createFromIndexed(img, scratch);
    }

    @Override public void update(float dt) {
        world.integrate(dt);
        final int n = world.high();
        for (int i = 0; i < n; i++) {
            if (!world.isActive(i)) continue;
            if (world.x[i] < 0f)          { world.x[i] = 0f;          world.vx[i] = -world.vx[i]; }
            if (world.x[i] > VW - 16f)    { world.x[i] = VW - 16f;    world.vx[i] = -world.vx[i]; }
            if (world.y[i] < 0f)          { world.y[i] = 0f;          world.vy[i] = -world.vy[i]; }
            if (world.y[i] > VH - 16f)    { world.y[i] = VH - 16f;    world.vy[i] = -world.vy[i]; }
        }
    }

    @Override public void render(SpriteBatch b, float alpha) {
        b.bind(tex);
        final int n = world.high();
        final float dt = alpha / 30f;                 // interpolasi posisi
        for (int i = 0; i < n; i++) {
            if (!world.isActive(i)) continue;
            b.draw(world.x[i] + world.vx[i] * dt, world.y[i] + world.vy[i] * dt, 16f, 16f, 0f, 0f, 1f, 1f);
        }
    }
}
