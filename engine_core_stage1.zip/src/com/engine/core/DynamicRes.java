package com.engine.core;

/**
 * Pengatur skala resolusi. Turun cepat bila interval frame melebihi target,
 * naik pelan dan hanya bila CPU-side work rendah. Setelah turun, kenaikan diblok
 * beberapa ratus frame agar tidak bolak-balik (oscillation).
 * Keterbatasan: workMs hanya mengukur sisi CPU; beban GPU terlihat lewat intervalMs.
 */
public final class DynamicRes {
    private final float targetMs;
    private final float minScale;
    private float scale = 1f;
    private float avgInterval;
    private float avgWork;
    private int cool = 0;
    private int upBlock = 0;

    public DynamicRes(int fps, float minScale) {
        this.targetMs = 1000f / fps;
        this.minScale = minScale;
        this.avgInterval = targetMs;
        this.avgWork = targetMs * 0.5f;
    }

    public float scale() { return scale; }

    public float update(float intervalMs, float workMs) {
        avgInterval += (intervalMs - avgInterval) * 0.1f;
        avgWork += (workMs - avgWork) * 0.1f;
        if (upBlock > 0) upBlock--;
        if (cool > 0) { cool--; return scale; }

        if (avgInterval > targetMs * 1.15f && scale > minScale) {
            scale = quant(Math.max(minScale, scale - 0.1f));
            cool = 45;
            upBlock = 300;
            avgInterval = targetMs;
        } else if (upBlock == 0 && scale < 1f
                && avgWork < targetMs * 0.55f && avgInterval < targetMs * 1.05f) {
            scale = quant(Math.min(1f, scale + 0.05f));
            cool = 90;
        }
        return scale;
    }

    private static float quant(float s) { return Math.round(s * 20f) / 20f; }
}
