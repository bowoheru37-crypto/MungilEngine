package com.engine.core;

/**
 * Penyimpanan entity struct-of-arrays. Tanpa objek per entity => nol alokasi di loop.
 * id = indeks array. create() mengembalikan -1 bila penuh (tidak melempar exception).
 */
public final class World {
    public static final int MAX = 1024;
    public static final int F_ACTIVE = 1;
    public static final int F_VISIBLE = 2;

    public final float[] x = new float[MAX];
    public final float[] y = new float[MAX];
    public final float[] vx = new float[MAX];
    public final float[] vy = new float[MAX];
    public final float[] w = new float[MAX];
    public final float[] h = new float[MAX];
    public final short[] sprite = new short[MAX];
    public final int[] flags = new int[MAX];

    private final int[] free = new int[MAX];
    private int freeTop = 0;
    private int high = 0;   // indeks tertinggi yang pernah dipakai + 1
    private int alive = 0;

    public int create() {
        int id;
        if (freeTop > 0) {
            id = free[--freeTop];
        } else if (high < MAX) {
            id = high++;
        } else {
            return -1;
        }
        x[id] = 0f; y[id] = 0f; vx[id] = 0f; vy[id] = 0f;
        w[id] = 0f; h[id] = 0f; sprite[id] = 0;
        flags[id] = F_ACTIVE | F_VISIBLE;
        alive++;
        return id;
    }

    public void destroy(int id) {
        if (id < 0 || id >= high || (flags[id] & F_ACTIVE) == 0) return;
        flags[id] = 0;
        free[freeTop++] = id;
        alive--;
    }

    public boolean isActive(int id) {
        return id >= 0 && id < high && (flags[id] & F_ACTIVE) != 0;
    }

    /** Batas atas iterasi: for (i = 0; i < world.high(); i++) if active... */
    public int high() { return high; }
    public int alive() { return alive; }

    public void integrate(float dt) {
        final int n = high;
        for (int i = 0; i < n; i++) {
            if ((flags[i] & F_ACTIVE) != 0) {
                x[i] += vx[i] * dt;
                y[i] += vy[i] * dt;
            }
        }
    }

    public void clear() {
        for (int i = 0; i < high; i++) flags[i] = 0;
        freeTop = 0; high = 0; alive = 0;
    }
}
