package com.engine.core;

/**
 * Gambar berpalet. Layout aset: u16 w | u16 h | u8 jumlahPalet(1..64) | u8 flags(bit0=RLE)
 *  | palet (jumlah x RGBA) | piksel (1 byte indeks/piksel, RLE bila flag).
 * Satu instance dipakai ulang: buffer dialokasikan sekali (maxPixels).
 */
public final class IndexedImage {
    public int w, h, palCount;
    public final byte[] idx;
    public final byte[] pal = new byte[64 * 4];

    public IndexedImage(int maxPixels) { idx = new byte[maxPixels]; }

    public boolean decode(byte[] d, int off, int len) {
        if (len < 6 || off < 0 || off > d.length - len) return false;
        int iw = Pak.u16(d, off), ih = Pak.u16(d, off + 2);
        int pc = d[off + 4] & 0xFF, fl = d[off + 5] & 0xFF;
        if (iw <= 0 || ih <= 0 || pc < 1 || pc > 64) return false;
        long total = (long) iw * ih;
        if (total > idx.length) return false;
        int n = (int) total;
        int p = off + 6, end = off + len, palBytes = pc * 4;
        if (p + palBytes > end) return false;
        System.arraycopy(d, p, pal, 0, palBytes);
        p += palBytes;
        if ((fl & 1) != 0) {
            if (Rle.decode(d, p, end - p, idx, 0, n) != n) return false;
        } else {
            if (end - p < n) return false;
            System.arraycopy(d, p, idx, 0, n);
        }
        for (int i = 0; i < n; i++) if ((idx[i] & 0xFF) >= pc) return false;
        w = iw; h = ih; palCount = pc;
        return true;
    }
}
