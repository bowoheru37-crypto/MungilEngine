package com.engine.core;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

/**
 * Batch sprite GLES 2.0. Vertex = x,y,u,v (16 byte). Satu draw call per tekstur/tint.
 * Koordinat: kiri-atas = (0,0), satuan = piksel virtual. Tanpa alokasi di draw().
 * Gunakan: bind(tex) -> draw(...) berulang -> end(). Panggil create() lagi setelah konteks hilang.
 */
public final class SpriteBatch {
    public static final int MAX_SPRITES = 512;
    private static final int FPV = 4;                  // float per vertex
    private static final int STRIDE = FPV * 4;         // byte

    private static final String VS =
            "attribute vec2 a_pos;\n" +
            "attribute vec2 a_uv;\n" +
            "uniform vec2 u_scale;\n" +
            "varying vec2 v_uv;\n" +
            "void main(){\n" +
            "  v_uv = a_uv;\n" +
            "  gl_Position = vec4(a_pos.x * u_scale.x - 1.0, 1.0 - a_pos.y * u_scale.y, 0.0, 1.0);\n" +
            "}\n";
    private static final String FS =
            "precision mediump float;\n" +
            "varying vec2 v_uv;\n" +
            "uniform sampler2D u_tex;\n" +
            "uniform vec4 u_tint;\n" +
            "void main(){ gl_FragColor = texture2D(u_tex, v_uv) * u_tint; }\n";

    private final float[] verts = new float[MAX_SPRITES * 4 * FPV];
    private final FloatBuffer vbuf;
    private final ShortBuffer ibuf;
    private int n = 0;          // float terpakai
    private int sprites = 0;    // sprite di batch saat ini
    private int tex = 0;

    private int program, locScale, locTint, locTex;
    private float viewW, viewH;
    private float tr = 1f, tg = 1f, tb = 1f, ta = 1f;
    private boolean tintDirty = true;
    private boolean drawing = false;

    /** Statistik per frame (direset di begin()). */
    public int drawCalls, spriteCount;

    public SpriteBatch() {
        vbuf = ByteBuffer.allocateDirect(verts.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        ibuf = ByteBuffer.allocateDirect(MAX_SPRITES * 6 * 2).order(ByteOrder.nativeOrder()).asShortBuffer();
        short[] idx = new short[MAX_SPRITES * 6];
        for (int s = 0, v = 0, i = 0; s < MAX_SPRITES; s++, v += 4, i += 6) {
            idx[i] = (short) v;       idx[i + 1] = (short) (v + 1); idx[i + 2] = (short) (v + 2);
            idx[i + 3] = (short) (v + 2); idx[i + 4] = (short) (v + 3); idx[i + 5] = (short) v;
        }
        ibuf.put(idx);
        ibuf.position(0);
    }

    /** Kompilasi shader. Panggil di onSurfaceCreated. */
    public void create() {
        int vs = compile(GLES20.GL_VERTEX_SHADER, VS);
        int fs = compile(GLES20.GL_FRAGMENT_SHADER, FS);
        program = GLES20.glCreateProgram();
        GLES20.glAttachShader(program, vs);
        GLES20.glAttachShader(program, fs);
        GLES20.glBindAttribLocation(program, 0, "a_pos");
        GLES20.glBindAttribLocation(program, 1, "a_uv");
        GLES20.glLinkProgram(program);
        int[] ok = new int[1];
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) {
            String log = GLES20.glGetProgramInfoLog(program);
            GLES20.glDeleteProgram(program);
            throw new RuntimeException("link gagal: " + log);
        }
        GLES20.glDeleteShader(vs);
        GLES20.glDeleteShader(fs);
        locScale = GLES20.glGetUniformLocation(program, "u_scale");
        locTint = GLES20.glGetUniformLocation(program, "u_tint");
        locTex = GLES20.glGetUniformLocation(program, "u_tex");
        tintDirty = true;
        tex = 0;
        n = 0; sprites = 0;
    }

    private static int compile(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        int[] ok = new int[1];
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) {
            String log = GLES20.glGetShaderInfoLog(s);
            GLES20.glDeleteShader(s);
            throw new RuntimeException("shader gagal: " + log);
        }
        return s;
    }

    public void begin(float viewW, float viewH) {
        this.viewW = viewW;
        this.viewH = viewH;
        drawing = true;
        drawCalls = 0;
        spriteCount = 0;
        n = 0; sprites = 0; tex = 0;
        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        GLES20.glDisable(GLES20.GL_CULL_FACE);
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
        GLES20.glUseProgram(program);
        GLES20.glUniform2f(locScale, 2f / viewW, 2f / viewH);
        GLES20.glUniform1i(locTex, 0);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glEnableVertexAttribArray(0);
        GLES20.glEnableVertexAttribArray(1);
        tintDirty = true;
    }

    public void end() {
        flush();
        GLES20.glDisableVertexAttribArray(0);
        GLES20.glDisableVertexAttribArray(1);
        drawing = false;
    }

    public void setColor(float r, float g, float b, float a) {
        if (r == tr && g == tg && b == tb && a == ta) return;
        flush();
        tr = r; tg = g; tb = b; ta = a;
        tintDirty = true;
    }

    public void bind(int texId) {
        if (texId != tex) {
            flush();
            tex = texId;
        }
    }

    /** Sprite sejajar sumbu. Sprite di luar layar dilewati. */
    public void draw(float x, float y, float w, float h, float u0, float v0, float u1, float v1) {
        if (x > viewW || y > viewH || x + w < 0f || y + h < 0f) return;
        if (sprites == MAX_SPRITES) flush();
        final float[] v = verts;
        int i = n;
        v[i]      = x;     v[i + 1]  = y;     v[i + 2]  = u0; v[i + 3]  = v0;
        v[i + 4]  = x + w; v[i + 5]  = y;     v[i + 6]  = u1; v[i + 7]  = v0;
        v[i + 8]  = x + w; v[i + 9]  = y + h; v[i + 10] = u1; v[i + 11] = v1;
        v[i + 12] = x;     v[i + 13] = y + h; v[i + 14] = u0; v[i + 15] = v1;
        n = i + 16;
        sprites++;
    }

    /** Sprite berotasi (radian) di sekitar titik (ox,oy) relatif pojok kiri-atas sprite. */
    public void drawRot(float x, float y, float w, float h, float ox, float oy, float rad,
                        float u0, float v0, float u1, float v1) {
        if (sprites == MAX_SPRITES) flush();
        final float c = (float) Math.cos(rad), s = (float) Math.sin(rad);
        final float ax = -ox, ay = -oy, bx = w - ox, by = h - oy;
        final float px = x + ox, py = y + oy;
        final float[] v = verts;
        int i = n;
        v[i]      = px + ax * c - ay * s; v[i + 1]  = py + ax * s + ay * c; v[i + 2]  = u0; v[i + 3]  = v0;
        v[i + 4]  = px + bx * c - ay * s; v[i + 5]  = py + bx * s + ay * c; v[i + 6]  = u1; v[i + 7]  = v0;
        v[i + 8]  = px + bx * c - by * s; v[i + 9]  = py + bx * s + by * c; v[i + 10] = u1; v[i + 11] = v1;
        v[i + 12] = px + ax * c - by * s; v[i + 13] = py + ax * s + by * c; v[i + 14] = u0; v[i + 15] = v1;
        n = i + 16;
        sprites++;
    }

    public void flush() {
        if (sprites == 0 || !drawing) return;
        if (tintDirty) {
            GLES20.glUniform4f(locTint, tr, tg, tb, ta);
            tintDirty = false;
        }
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex);
        vbuf.clear();
        vbuf.put(verts, 0, n);
        vbuf.position(0);
        GLES20.glVertexAttribPointer(0, 2, GLES20.GL_FLOAT, false, STRIDE, vbuf);
        vbuf.position(2);
        GLES20.glVertexAttribPointer(1, 2, GLES20.GL_FLOAT, false, STRIDE, vbuf);
        ibuf.limit(sprites * 6);
        ibuf.position(0);
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, sprites * 6, GLES20.GL_UNSIGNED_SHORT, ibuf);
        drawCalls++;
        spriteCount += sprites;
        n = 0;
        sprites = 0;
    }
}
