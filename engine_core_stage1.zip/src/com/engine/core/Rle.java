package com.engine.core;

import java.util.Arrays;

/** RLE byte: pasangan (run 1..255, nilai). Dekode tanpa alokasi. */
public final class Rle {
    private Rle() {}

    /** @return jumlah byte tertulis, atau -1 bila data rusak / melebihi dMax */
    public static int decode(byte[] src, int off, int len, byte[] dst, int dOff, int dMax) {
        final int end = off + len;
        final int limit = dOff + dMax;
        int d = dOff;
        while (off + 1 < end) {
            int run = src[off++] & 0xFF;
            byte v = src[off++];
            if (run == 0 || d + run > limit) return -1;
            Arrays.fill(dst, d, d + run, v);
            d += run;
        }
        if (off != end) return -1; // byte sisa ganjil
        return d - dOff;
    }
}
