package com.engine.core;

/** Kontrak game. Semua callback berjalan di thread GL, kecuali dinyatakan lain. */
public interface Game {
    /** Dipanggil saat konteks GL dibuat (juga setelah konteks hilang): muat ulang semua tekstur di sini. */
    void onGlCreated(SpriteBatch batch);

    /** Langkah logika tetap; dt konstan = 1/hz detik. */
    void update(float dt);

    /** alpha 0..1 = posisi di antara dua langkah logika, untuk interpolasi. */
    void render(SpriteBatch batch, float alpha);
}
