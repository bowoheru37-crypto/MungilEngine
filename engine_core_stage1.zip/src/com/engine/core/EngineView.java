package com.engine.core;

import android.content.Context;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * View + renderer. Fitur: fixed timestep, batas fps (sleep, hemat baterai), letterbox ke
 * resolusi virtual, resolusi dinamis lewat setFixedSize, input dipetakan ke koordinat virtual.
 * Activity wajib meneruskan onPause()/onResume() ke view ini.
 */
public final class EngineView extends GLSurfaceView implements GLSurfaceView.Renderer {
    public final Input input = new Input();
    public final SpriteBatch batch = new SpriteBatch();
    /** Statistik untuk overlay debug. */
    public volatile float avgIntervalMs = 33f;

    private final Game game;
    private final float virtualW, virtualH;
    private final int hz;
    private final long frameNs;
    private final FixedLoop loop;
    private final DynamicRes dyn;
    private final float stepDt;

    private final FixedLoop.Step stepper = new FixedLoop.Step() {
        public void update() { game.update(stepDt); }
    };

    private long nextNs = 0L, lastStart = 0L;
    private volatile boolean resetClock = true;

    // viewport (piksel surface), ditulis thread GL, dibaca thread UI
    private volatile float vpX, vpY, vpScale, surfW;
    private int vpWi, vpHi;
    private float curScale = 1f;
    private volatile float pendingScale = 1f;

    private final Runnable applyRes = new Runnable() {
        public void run() {
            float s = pendingScale;
            if (s >= 0.999f) {
                getHolder().setSizeFromLayout();
            } else {
                int fw = Math.max(64, (int) (getWidth() * s));
                int fh = Math.max(64, (int) (getHeight() * s));
                getHolder().setFixedSize(fw, fh);
            }
        }
    };

    public EngineView(Context ctx, Game game, int virtualW, int virtualH, int hz) {
        super(ctx);
        this.game = game;
        this.virtualW = virtualW;
        this.virtualH = virtualH;
        this.hz = hz;
        this.frameNs = 1000000000L / hz;
        this.loop = new FixedLoop(hz, 3);
        this.stepDt = loop.stepSeconds();
        this.dyn = new DynamicRes(hz, 0.6f);
        setEGLContextClientVersion(2);
        setEGLConfigChooser(5, 6, 5, 0, 0, 0);   // RGB565, tanpa depth/stencil: hemat memori
        setRenderer(this);
        setRenderMode(RENDERMODE_CONTINUOUSLY);
    }

    @Override public void onResume() {
        super.onResume();
        resetClock = true;
    }

    // ---------------- Renderer (thread GL) ----------------

    @Override public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        batch.create();
        GLES20.glClearColor(0f, 0f, 0f, 1f);
        game.onGlCreated(batch);
        resetClock = true;
    }

    @Override public void onSurfaceChanged(GL10 gl, int w, int h) {
        float s = Math.min(w / virtualW, h / virtualH);
        vpWi = (int) (virtualW * s);
        vpHi = (int) (virtualH * s);
        vpX = (w - vpWi) * 0.5f;
        vpY = (h - vpHi) * 0.5f;     // simetris: offset atas = offset bawah
        vpScale = s;
        surfW = w;
    }

    @Override public void onDrawFrame(GL10 gl) {
        long now = System.nanoTime();
        if (resetClock) {
            resetClock = false;
            loop.reset();
            nextNs = now;
            lastStart = 0L;
        }
        long wait = nextNs - now;
        if (wait > 2000000L) {
            try { Thread.sleep((wait - 1000000L) / 1000000L); } catch (InterruptedException e) { /* abaikan */ }
            now = System.nanoTime();
        }
        nextNs += frameNs;
        if (now - nextNs > frameNs) nextNs = now;   // tertinggal: sinkron ulang

        final long start = now;
        float interval = lastStart == 0L ? (1000f / hz) : (start - lastStart) / 1000000f;
        lastStart = start;

        float alpha = loop.advance(start, stepper);

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        GLES20.glViewport((int) vpX, (int) vpY, vpWi, vpHi);
        batch.begin(virtualW, virtualH);
        game.render(batch, alpha);
        batch.end();

        float work = (System.nanoTime() - start) / 1000000f;
        avgIntervalMs += (interval - avgIntervalMs) * 0.05f;
        float s = dyn.update(interval, work);
        if (s != curScale) {
            curScale = s;
            pendingScale = s;
            post(applyRes);
        }
    }

    // ---------------- Input (thread UI) ----------------

    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int i = e.getActionIndex();
                setPointer(e.getPointerId(i), e.getX(i), e.getY(i), true);
                break;
            }
            case MotionEvent.ACTION_MOVE: {
                for (int i = 0, c = e.getPointerCount(); i < c; i++)
                    setPointer(e.getPointerId(i), e.getX(i), e.getY(i), true);
                break;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP: {
                int i = e.getActionIndex();
                setPointer(e.getPointerId(i), e.getX(i), e.getY(i), false);
                break;
            }
            case MotionEvent.ACTION_CANCEL:
                for (int i = 0; i < Input.MAX; i++) input.down[i] = false;
                break;
            default:
                break;
        }
        return true;
    }

    private void setPointer(int id, float tx, float ty, boolean down) {
        if (id < 0 || id >= Input.MAX) return;
        float sc = vpScale;
        int vw = getWidth(), vh = getHeight();
        if (sc > 0f && vw > 0 && vh > 0) {
            float sx = tx * surfW / vw;
            float sy = ty * surfW / vw;       // rasio surface/view sama di kedua sumbu
            input.x[id] = (sx - vpX) / sc;
            input.y[id] = (sy - vpY) / sc;
        }
        input.down[id] = down;
    }
}
