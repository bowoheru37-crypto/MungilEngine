package com.engine.core;

/**
 * Status sentuhan dalam koordinat virtual. Ditulis thread UI, dibaca thread GL.
 * Race pada float/boolean tunggal tidak berbahaya untuk input (paling buruk terlambat satu frame).
 */
public final class Input {
    public static final int MAX = 4;
    public final float[] x = new float[MAX];
    public final float[] y = new float[MAX];
    public final boolean[] down = new boolean[MAX];
}
