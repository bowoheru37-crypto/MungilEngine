package com.engine.core;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Helper tekstur. Hanya dipanggil dari thread GL. */
public final class GlTexture {
    private static final int[] TMP = new int[1];

    private GlTexture() {}

    /** Buffer sementara sekali alokasi: maxPixels * 4 byte. Gunakan ulang untuk semua unggahan. */
    public static ByteBuffer newScratch(int maxPixels) {
        return ByteBuffer.allocateDirect(maxPixels * 4).order(ByteOrder.nativeOrder());
    }

    public static int createFromIndexed(IndexedImage img, ByteBuffer scratch) {
        final int n = img.w * img.h;
        if (scratch.capacity() < n * 4) throw new IllegalArgumentException("scratch terlalu kecil");
        final byte[] pal = img.pal, idx = img.idx;
        scratch.clear();
        for (int i = 0; i < n; i++) {
            int p = (idx[i] & 0xFF) << 2;
            scratch.put(pal[p]);
            scratch.put(pal[p + 1]);
            scratch.put(pal[p + 2]);
            scratch.put(pal[p + 3]);
        }
        scratch.position(0);

        GLES20.glGenTextures(1, TMP, 0);
        int id = TMP[0];
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glPixelStorei(GLES20.GL_UNPACK_ALIGNMENT, 1);
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, img.w, img.h, 0,
                GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, scratch);
        return id;
    }

    public static void delete(int id) {
        TMP[0] = id;
        GLES20.glDeleteTextures(1, TMP, 0);
    }
}
