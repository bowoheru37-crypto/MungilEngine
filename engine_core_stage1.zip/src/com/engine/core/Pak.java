package com.engine.core;

import java.io.IOException;
import java.io.InputStream;

/**
 * Kontainer aset biner (little-endian).
 *  Header 16B : 'P''A''K''1' | u16 versi=1 | u16 jumlah | i32 dataStart | i32 totalSize
 *  Tabel      : jumlah x { i32 id, i32 offset, i32 length }  (id naik ketat)
 *  Data       : byte mentah
 * Seluruh file dibaca ke satu byte[]; akses lewat offset, tanpa parsing teks.
 */
public final class Pak {
    public static final int HEADER = 16;
    public static final int ENTRY = 12;

    public final byte[] data;
    private final int count;

    public Pak(byte[] d) {
        if (d == null || d.length < HEADER) throw new IllegalArgumentException("pak: terlalu pendek");
        if (d[0] != 'P' || d[1] != 'A' || d[2] != 'K' || d[3] != '1')
            throw new IllegalArgumentException("pak: magic salah");
        if (u16(d, 4) != 1) throw new IllegalArgumentException("pak: versi tidak didukung");
        int c = u16(d, 6);
        int tableEnd = HEADER + c * ENTRY;
        if (tableEnd > d.length) throw new IllegalArgumentException("pak: tabel melebihi file");
        if (i32(d, 12) > d.length) throw new IllegalArgumentException("pak: ukuran total tidak cocok");
        int prevId = Integer.MIN_VALUE;
        for (int i = 0; i < c; i++) {
            int p = HEADER + i * ENTRY;
            int id = i32(d, p), off = i32(d, p + 4), len = i32(d, p + 8);
            if (i > 0 && id <= prevId) throw new IllegalArgumentException("pak: id tidak terurut");
            if (off < tableEnd || len < 0 || off > d.length - len)
                throw new IllegalArgumentException("pak: entri di luar batas");
            prevId = id;
        }
        this.data = d;
        this.count = c;
    }

    public int count() { return count; }

    /** @return indeks entri atau -1 (pencarian biner) */
    public int indexOf(int id) {
        int lo = 0, hi = count - 1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            int v = i32(data, HEADER + mid * ENTRY);
            if (v < id) lo = mid + 1;
            else if (v > id) hi = mid - 1;
            else return mid;
        }
        return -1;
    }

    public int idAt(int i)     { return i32(data, HEADER + i * ENTRY); }
    public int offsetAt(int i) { return i32(data, HEADER + i * ENTRY + 4); }
    public int lengthAt(int i) { return i32(data, HEADER + i * ENTRY + 8); }

    public static int u16(byte[] b, int o) { return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8); }

    public static int i32(byte[] b, int o) {
        return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8) | ((b[o + 2] & 0xFF) << 16) | ((b[o + 3] & 0xFF) << 24);
    }

    /** Baca seluruh stream. Beri sizeHint (mis. AssetFileDescriptor.getLength()) agar tanpa salinan ganda. */
    public static byte[] readAll(InputStream in, int sizeHint) throws IOException {
        byte[] buf = new byte[sizeHint > 0 ? sizeHint : 65536];
        int n = 0;
        while (true) {
            if (n == buf.length) {
                byte[] nb = new byte[buf.length * 2];
                System.arraycopy(buf, 0, nb, 0, n);
                buf = nb;
            }
            int r = in.read(buf, n, buf.length - n);
            if (r < 0) break;
            n += r;
        }
        if (n == buf.length) return buf;
        byte[] out = new byte[n];
        System.arraycopy(buf, 0, out, 0, n);
        return out;
    }
}
