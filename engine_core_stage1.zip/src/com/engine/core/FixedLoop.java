package com.engine.core;

/**
 * Fixed timestep dengan akumulator. Waktu dimasukkan dari luar (nanoTime), jadi mudah diuji.
 * Spiral-of-death dicegah: maksimal maxSteps update per frame, sisa tunggakan dibuang.
 */
public final class FixedLoop {
    public interface Step { void update(); }

    private static final long MAX_DELTA_NS = 250000000L; // 250 ms (mis. setelah resume)

    private final long stepNs;
    private final int maxSteps;
    private final float stepSeconds;
    private long acc = 0L;
    private long prev = 0L;
    private boolean started = false;
    /** Jumlah frame yang tunggakannya dibuang (indikator beban berlebih). */
    public int droppedFrames = 0;

    public FixedLoop(int hz, int maxSteps) {
        this.stepNs = 1000000000L / hz;
        this.stepSeconds = 1f / hz;
        this.maxSteps = maxSteps;
    }

    public float stepSeconds() { return stepSeconds; }

    public void reset() { started = false; acc = 0L; }

    /** @return alpha interpolasi 0..1 untuk render */
    public float advance(long nowNs, Step s) {
        if (!started) { prev = nowNs; started = true; }
        long d = nowNs - prev;
        prev = nowNs;
        if (d < 0L) d = 0L;
        if (d > MAX_DELTA_NS) d = MAX_DELTA_NS;
        acc += d;
        int n = 0;
        while (acc >= stepNs && n < maxSteps) {
            s.update();
            acc -= stepNs;
            n++;
        }
        if (acc >= stepNs) { acc = 0L; droppedFrames++; }
        return acc / (float) stepNs;
    }
}
