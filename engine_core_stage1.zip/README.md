# Engine Core Tahap 1 (Java 7, GLES 2.0)

## Isi
src/com/engine/core : World, FixedLoop, DynamicRes, Pak, Rle, IndexedImage, GlTexture, SpriteBatch, Input, Game, EngineView
src/com/engine/demo : DemoGame (500 sprite memantul), DemoActivity
tools/              : PakBuilder (buat .pak di PC), TestCore (tes desktop)

## Pasang di AIDE
1. Salin folder `com/engine` ke source project. Package nama bebas, ubah `package` bila perlu.
2. AndroidManifest: tambahkan `<activity android:name="com.engine.demo.DemoActivity" />`
   dan `<uses-feature android:glEsVersion="0x00020000" android:required="true" />`.
3. Jalankan DemoActivity di Itel A70. Gate G1: 500 sprite, 30 fps, 1 draw call.
   Cek `adb logcat` tidak ada GC_FOR_ALLOC berulang saat berjalan.

## Game sendiri
Implementasikan `Game` (onGlCreated, update, render), lalu
`new EngineView(this, game, virtualW, virtualH, 30)`.
Teruskan onPause/onResume Activity ke EngineView.
Koordinat render: kiri-atas (0,0), satuan piksel virtual; input di `view.input` sudah dalam koordinat virtual.

## Yang sudah diuji / belum
Diuji di PC (javac --release 8): World, FixedLoop, Pak, Rle, IndexedImage, DynamicRes, 0 alokasi di jalur panas.
Dikompilasi terhadap stub Android: SpriteBatch, GlTexture, EngineView, Demo.
BELUM diuji di perangkat: rendering GL, resolusi dinamis (setFixedSize), pemulihan konteks GL, suhu/baterai.
Perilaku `setFixedSize` pada beberapa GPU Mali bisa membuat surface dibuat ulang: periksa kedipan saat skala berubah.

## Batas desain
- MAX 1024 entity, 512 sprite per flush (ubah konstanta bila perlu).
- Resolusi virtual di-letterbox; tidak ada peregangan.
- Tekstur berpalet 64 warna, filter NEAREST.
