import com.engine.core.*;
import java.lang.management.ManagementFactory;

public final class TestCore {
    static int fails = 0;
    static void check(boolean c, String m) { System.out.println((c ? "OK   " : "FAIL ") + m); if (!c) fails++; }

    public static void main(String[] args) throws Exception {
        // ---- World ----
        World w = new World();
        int[] ids = new int[World.MAX];
        for (int i = 0; i < World.MAX; i++) ids[i] = w.create();
        check(w.alive() == World.MAX && w.create() == -1, "World: penuh mengembalikan -1");
        w.destroy(10); w.destroy(10);
        check(w.alive() == World.MAX - 1, "World: destroy ganda aman");
        check(w.create() == 10 && w.alive() == World.MAX, "World: id dipakai ulang");
        w.vx[3] = 60f; w.x[3] = 0f; w.integrate(0.5f);
        check(Math.abs(w.x[3] - 30f) < 1e-4f, "World: integrate");

        // ---- FixedLoop ----
        final int[] steps = {0};
        FixedLoop.Step st = new FixedLoop.Step() { public void update() { steps[0]++; } };
        FixedLoop lp = new FixedLoop(30, 3);
        lp.advance(0L, st);
        lp.advance(100000000L, st);
        check(steps[0] == 3, "Loop: 100ms = 3 langkah (" + steps[0] + ")");
        steps[0] = 0; lp.advance(1100000000L, st);   // lompatan 1 detik, di-clamp 250ms
        check(steps[0] == 3 && lp.droppedFrames == 1, "Loop: spiral dicegah, tunggakan dibuang");
        steps[0] = 0; float a = lp.advance(1100000000L + 16666666L, st);
        check(steps[0] == 0 && a > 0.45f && a < 0.55f, "Loop: alpha ~0.5 (" + a + ")");

        // ---- Pak + IndexedImage + Rle ----
        byte[] pal = {0,0,0,0, (byte)255,0,0,(byte)255, 0,(byte)255,0,(byte)255};
        byte[] idx = new byte[64];
        for (int i = 0; i < 64; i++) idx[i] = (byte) (i < 40 ? 0 : (i % 2 == 0 ? 1 : 2));
        byte[] imgRle = PakBuilder.encodeImage(8, 8, pal, idx, true);
        byte[] imgRaw = PakBuilder.encodeImage(8, 8, pal, idx, false);
        byte[] file = new PakBuilder().add(30, imgRle).add(5, imgRaw).add(17, new byte[]{1,2,3}).build();
        Pak pk = new Pak(file);
        check(pk.count() == 3 && pk.indexOf(5) == 0 && pk.indexOf(17) == 1 && pk.indexOf(30) == 2, "Pak: urutan & pencarian biner");
        check(pk.indexOf(99) == -1 && pk.indexOf(-4) == -1, "Pak: id tak ada = -1");
        IndexedImage im = new IndexedImage(64);
        boolean r1 = im.decode(file, pk.offsetAt(pk.indexOf(30)), pk.lengthAt(pk.indexOf(30)));
        boolean same = r1 && im.w == 8 && im.h == 8 && im.palCount == 3;
        for (int i = 0; same && i < 64; i++) same = im.idx[i] == idx[i];
        check(same, "Image: RLE roundtrip");
        boolean r2 = im.decode(file, pk.offsetAt(0), pk.lengthAt(0));
        same = r2;
        for (int i = 0; same && i < 64; i++) same = im.idx[i] == idx[i];
        check(same, "Image: raw roundtrip");
        byte[] badIdx = idx.clone(); badIdx[7] = 9;
        byte[] bad = PakBuilder.encodeImage(8, 8, pal, badIdx, false);
        check(!im.decode(bad, 0, bad.length), "Image: indeks palet di luar jangkauan ditolak");
        check(!im.decode(imgRle, 0, imgRle.length - 1), "Image: RLE terpotong ditolak");
        byte[] c1 = file.clone(); c1[0] = 'X';
        byte[] c2 = file.clone(); c2[16 + 4] = 0x7f; c2[16 + 5] = 0x7f; c2[16 + 6] = 0x7f; c2[16 + 7] = 0x7f;
        byte[] c3 = java.util.Arrays.copyOf(file, 20);
        int rej = 0;
        for (byte[] c : new byte[][]{c1, c2, c3}) { try { new Pak(c); } catch (IllegalArgumentException e) { rej++; } }
        check(rej == 3, "Pak: file rusak ditolak (" + rej + "/3)");

        // ---- DynamicRes ----
        DynamicRes dr = new DynamicRes(30, 0.6f);
        for (int i = 0; i < 200; i++) dr.update(55f, 40f);
        check(Math.abs(dr.scale() - 0.6f) < 1e-3f, "DynamicRes: turun sampai batas minimum (" + dr.scale() + ")");
        for (int i = 0; i < 100; i++) dr.update(33.3f, 8f);
        check(dr.scale() == 0.6f, "DynamicRes: naik diblok sementara setelah turun");
        for (int i = 0; i < 3000; i++) dr.update(33.3f, 8f);
        check(dr.scale() == 1f, "DynamicRes: pulih ke 1.0 saat beban ringan (" + dr.scale() + ")");

        // ---- Alokasi nol di jalur panas ----
        try {
            com.sun.management.ThreadMXBean mx = (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
            long tid = Thread.currentThread().getId();
            FixedLoop l2 = new FixedLoop(30, 3);
            DynamicRes d2 = new DynamicRes(30, 0.6f);
            long t = 0;
            for (int i = 0; i < 2000; i++) { t += 16666666L; l2.advance(t, st); w.integrate(0.033f); d2.update(33f, 10f); }  // pemanasan JIT
            long b0 = mx.getThreadAllocatedBytes(tid);
            for (int i = 0; i < 200000; i++) { t += 16666666L; l2.advance(t, st); w.integrate(0.033f); d2.update(33f, 10f); }
            long used = mx.getThreadAllocatedBytes(tid) - b0;
            check(used < 4096, "Hot path (loop+world+dynres) 200k iterasi: alokasi = " + used + " byte");
        } catch (Throwable e) {
            System.out.println("SKIP alokasi: " + e);
        }

        System.out.println(fails == 0 ? "SEMUA LULUS" : fails + " GAGAL");
        System.exit(fails == 0 ? 0 : 1);
    }
}
