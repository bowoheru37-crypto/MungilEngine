import java.io.*;
import java.util.*;

/** Alat desktop (boleh alokasi): bangun .pak dan aset gambar berpalet. */
public final class PakBuilder {
    private final TreeMap<Integer, byte[]> items = new TreeMap<Integer, byte[]>();

    public PakBuilder add(int id, byte[] data) { items.put(id, data); return this; }

    public byte[] build() throws IOException {
        int c = items.size();
        int tableEnd = 16 + c * 12;
        int total = tableEnd;
        for (byte[] d : items.values()) total += d.length;
        ByteArrayOutputStream o = new ByteArrayOutputStream(total);
        o.write('P'); o.write('A'); o.write('K'); o.write('1');
        w16(o, 1); w16(o, c); w32(o, tableEnd); w32(o, total);
        int off = tableEnd;
        for (Map.Entry<Integer, byte[]> e : items.entrySet()) {
            w32(o, e.getKey()); w32(o, off); w32(o, e.getValue().length);
            off += e.getValue().length;
        }
        for (byte[] d : items.values()) o.write(d);
        return o.toByteArray();
    }

    public static byte[] encodeImage(int w, int h, byte[] palRGBA, byte[] idx, boolean rle) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        w16(o, w); w16(o, h);
        o.write(palRGBA.length / 4);
        o.write(rle ? 1 : 0);
        o.write(palRGBA);
        if (rle) o.write(rleEncode(idx, w * h)); else o.write(idx, 0, w * h);
        return o.toByteArray();
    }

    public static byte[] rleEncode(byte[] src, int n) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        int i = 0;
        while (i < n) {
            int j = i + 1;
            while (j < n && src[j] == src[i] && j - i < 255) j++;
            o.write(j - i); o.write(src[i]);
            i = j;
        }
        return o.toByteArray();
    }

    private static void w16(OutputStream o, int v) throws IOException { o.write(v & 255); o.write((v >> 8) & 255); }
    private static void w32(OutputStream o, int v) throws IOException { w16(o, v); w16(o, v >> 16); }

    public static void main(String[] a) throws IOException {
        if (a.length < 1) { System.out.println("pakai: PakBuilder out.pak"); return; }
        byte[] pal = {0,0,0,0, (byte)255,(byte)200,60,(byte)255};
        byte[] idx = new byte[256];
        for (int i = 0; i < 256; i++) idx[i] = (byte) ((i / 16 + i % 16) % 2);
        FileOutputStream f = new FileOutputStream(a[0]);
        f.write(new PakBuilder().add(2, encodeImage(16, 16, pal, idx, true)).add(1, encodeImage(16, 16, pal, idx, false)).build());
        f.close();
    }
}
